inductive Phase | c0 | cm | cp
def metricAdmissible : Phase → Bool
  | .c0 => false | .cm => true | .cp => false
def diffOpAdmissible : Phase → Bool
  | .c0 => false | .cm => true | .cp => false
theorem no_metric_c0 : metricAdmissible .c0 = false := by decide
theorem no_mass_cp_current : restMassAdmissible .cp = false := by decide  -- K2 fix
-- X type candidate
structure Resolver where
  ctx : Context
  regime : Phase → Prop
