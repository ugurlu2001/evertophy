# EVERTOPHY — LEAN DERLEMESİ (KİMİ TOPLAMA ARŞİVİ)

**Oluşturan:** Kimi · 2026-10-09
**Amaç:** Evertophy kapsamında üretilmiş tüm Lean materyalinin tek ZIP'te toplanması (çapraz denetim öncesi).
**Durum:** KISMİ ARŞİV — eksikler ve gerekçeleri aşağıda dürüstçe listelenmiştir.

---

## 1. Bu arşivde OLAN (bizzat erişilebilen kaynaklardan toplandı)

| Dizin | Dosya | Kaynak | Not |
|---|---|---|---|
| `lean_oturum_parcalari/` | `Absence_Tur5.lean` (2.669 B) | Bu oturumun temp dizini | İki-yokluk / faz-indeksli değer parçası |
| `lean_oturum_parcalari/` | `BridgeNoGo.lean` (2.246 B) | Bu oturumun temp dizini | Köprü tekil-olmama karşı-örneği |
| `lean_maraton_snmario/` | `formal_core_v02_snmario.lean` (1.122 B) | 23–26 Eylül maraton final derleme TXT'sindeki ```lean``` bloğu | Eylül maratonu FORMAL-CORE v0.2 taslağı |
| `lean_maraton_snmario/` | 4 snippet dosyası (1.375 B toplam) | Aynı TXT'ten | resolve_is_admissible, phase_absence, bridge_nonunique, exp_deriv |
| `lean_erken_arsiv/` | `Omega.lean` (1.523 B) · `Assoc.lean` (3.074 B) | Claude_runs_for_chatgpt_gpts_files_20260916_2358.zip | Eylül-öncesi erken arşiv |

**Toplam:** 9 dosya, ~11,7 KB.

## 2. Bu arşivde OLMAYAN (kritik eksik — dürüst bildirim)

**Tam üretim FORMAL-CORE reposu (259–269 teorem bildirimli paket):**

`Production.lean` · `Final.lean` · `Production_Tur12.lean` · `GateLock.lean` · `GateLockGen.lean` · `GateLockChar.lean` · `Types.lean` · `Types_Tur6.lean` · `Confluence.lean` · `Topology.lean` · `Ledger.lean` · `Quarantine.lean` · `Extended.lean` · `Roles.lean` · `Phase.lean` · `Global.lean` · `Range.lean` · `Quantity.lean` · `StampSpec.lean` · `StampAssoc.lean` · `Idem.lean` · `Consistency.lean` · `Rewrite.lean` · `Rewrite_Tur6.lean` · `Patches.lean` · `Absence.lean` (tam) · `BridgeNoGo.lean` (tam) · `lakefile.lean` · `lean-toolchain` · `BUILD_LOG.txt` · `SHA256_MANIFEST.txt` · `README_BUILD.md`

**Gerekçe:** Bu dosyalar Eylül 2026 maratonunda Claude'un VS Code ortamında üretildi ve sohbet dosya-eki olarak iletildi. Kaynak kodların tamamı Kimi'nin dosya sistemine hiç ulaşmadı; eldeki 1,37 MB'lık maraton TXT'si bu dosyaların **içeriklerini değil, denetim raporlarını ve manifest adlarını** taşıyor. Codex Tur15 kaydı da aynı durumu doğruluyor: "mevcut Tur15 ZIP'i production Lean projesini içermiyor."

**Çözüm (tek yol):** Eylül maratonundaki orijinal Lean ZIP'i (Claude'un ürettiği paket) bu oturuma yüklerseniz, Kimi: (i) ZIP'i açıp doğrular, (ii) bu manifestoyu tam envanterle günceller, (iii) tek ZIP olarak yeniden paketler, (iv) `lake build` doğrulamasını çapraz denetime hazır manifestle teslim eder.

## 3. Ortam notu

Bu ortamda `lean` / `lake` toolchain'i **yoktur** — build doğrulaması burada koşulamaz. Çapraz denetimde toolchain'i olan bacak (Codex/Claude/Wolfram) koşabilir; Kimi bu aşamada içerik bütünlüğü + manifest denetimi yapar.

## 4. Bütünlük manifesti

`SHA256_MANIFEST.txt` dosyasındaki hash'ler bu ZIP'in içeriğinin birebir doğrulamasıdır.
