theorem chain_no_skip_fwd     : adjacent .c0 .cp = false     -- zincir, AYAKTA
theorem chain_no_skip_bwd     : adjacent .cp .c0 = false     -- zincir, AYAKTA
theorem transition_chain_preserved                            -- açık koruma
theorem triangle_complete                                     -- üçgen, üç kenar
theorem U0_derives_all_three                                  -- öncül katman
