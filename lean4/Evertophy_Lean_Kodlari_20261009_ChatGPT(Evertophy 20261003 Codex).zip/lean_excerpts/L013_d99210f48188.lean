def gateRelated : Phase → Phase → Bool   -- ÜÇ KENAR AÇIK
theorem gate_c0_cp_open  : gateRelated .c0 .cp = true
theorem gate_symmetric_1/2/3             -- her kenar simetrik
def adjacent_LEGACY := adjacent          -- teorem SİLİNMEDİ, taşındı
