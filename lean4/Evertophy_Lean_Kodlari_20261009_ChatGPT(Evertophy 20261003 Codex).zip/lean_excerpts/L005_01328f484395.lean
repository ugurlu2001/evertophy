theorem no_budget_is_predictive :
    budgets.all (fun b => !isPredictive b) = true := by decide
