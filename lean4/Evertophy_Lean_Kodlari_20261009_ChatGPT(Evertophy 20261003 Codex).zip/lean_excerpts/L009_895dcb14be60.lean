theorem transition_chain_preserved : adjacent .c0 .cp = false ∧ adjacent .cp .c0 = false
theorem triangle_complete : related .c0 .cp = true ∧ related .Cm .cp = true ∧ related .c0 .Cm = true
theorem U0_derives_all_three : derivedFromU0 .c0 ∧ derivedFromU0 .Cm ∧ derivedFromU0 .cp
theorem U0_arrow_is_one_way : U0_bidirectional = false
