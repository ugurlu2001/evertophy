theorem F_dimensionless_ok    -- F boyutsuz (468.1)
theorem F_old_form_violates   -- eski F=(16πG)⁻¹ → M², İHLAL
theorem omega_dimensionless   -- ω_Φ = ZF/(M_Pl²F'²)
theorem A0_dimensionless      -- A₀ = M_Pl|F'|/√(ZF)
theorem Cm_lemma_main         -- m² = V''/(FZ) ~ M²
theorem Cm_lemma_corr         -- V₀≠0 düzeltmesi AYNI boyut ⟹ toplanabilir
theorem EF_term1 / EF_term2   -- Einstein-frame iki terim boyutsuz
theorem eta_clock_dimensionless
theorem dt_dimensional        -- [Γ]=T
theorem gamma_wrong           -- Γ boyutsuz sanılırsa sonuç zaman DEĞİL
