rate_not_in_c0 : carriable .c0 Dim.freq = false
rate_not_in_cp : carriable .cp Dim.freq = false
