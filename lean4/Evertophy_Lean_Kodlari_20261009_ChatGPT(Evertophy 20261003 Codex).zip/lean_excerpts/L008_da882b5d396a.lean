theorem registry_size      : debtRegistry.length = 14 := by decide
theorem count_resolved     : countBy .resolved     = 3 := by decide
theorem count_transferred  : countBy .transferred  = 2 := by decide
theorem count_reservedCore : countBy .reservedCore = 5 := by decide
theorem count_open         : countBy .open_        = 3 := by decide
theorem count_retired      : countBy .retired      = 1 := by decide
theorem counts_sum_to_total : ... = debtRegistry.length := by decide
