theorem K2_cp_mass : carriable .cp Dim.mass = true := by decide
