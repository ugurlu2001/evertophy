def falsified (p o : Band) : Bool :=
  match p.kind, o.kind with
  | .pred, .obs => p.iv.disjoint o.iv
  | _, _        => false        -- obs-vs-obs GEÇERSİZ
