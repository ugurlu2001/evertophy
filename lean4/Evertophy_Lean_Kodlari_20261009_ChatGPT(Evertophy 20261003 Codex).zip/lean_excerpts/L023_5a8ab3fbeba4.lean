inductive Phase
  | c0
  | cm
  | cp

inductive TemporalRole
  | preEmergent
  | physicalTime
  | atemporalRecord

inductive EdgeClass
  | e0m
  | emp
  | e0p

inductive ArchiveEffect
  | noMutation
  | append
  | readProject

inductive CoordEffect
  | none
  | xCoord

structure TransitionSemantics where
  src : Phase
  dst : Phase
  edge : EdgeClass
  stampEmission : Option Stamp
  archiveEffect : ArchiveEffect
  coordEffect : CoordEffect
