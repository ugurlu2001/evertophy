theorem c0_cp_roles_differ : temporalRole .c0 ≠ temporalRole .cp := by decide
