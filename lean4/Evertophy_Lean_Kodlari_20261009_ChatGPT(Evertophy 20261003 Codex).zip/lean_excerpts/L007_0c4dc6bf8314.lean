def canonicalPredictions : Nat := 0
theorem still_zero : canonicalPredictions = 0 := by decide
