inductive Phase
| c0 | cm | cp

inductive GlobalState
| U0 | Ux | Up
