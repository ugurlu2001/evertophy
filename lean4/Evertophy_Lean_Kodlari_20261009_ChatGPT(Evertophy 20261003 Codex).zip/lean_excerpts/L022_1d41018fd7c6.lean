inductive CmOnlyValue (α : Type) : Phase → Type
  | undefined0    : CmOnlyValue α .c0
  | presentCm     : α → CmOnlyValue α .Cm
  | dissolvedPlus : CmOnlyValue α .cp
