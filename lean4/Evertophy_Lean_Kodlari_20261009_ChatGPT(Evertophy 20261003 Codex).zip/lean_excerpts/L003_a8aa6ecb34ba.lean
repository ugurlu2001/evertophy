theorem op_c0_none : hasDifferentialOp .c0 = false := by decide
theorem op_cp_none : hasDifferentialOp .cp = false := by decide
theorem op_Cm_yes  : hasDifferentialOp .Cm = true  := by decide
