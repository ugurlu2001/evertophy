theorem idempotent_forces_zero (K : Ivl) (h : K.add K = K) : K = Ivl.zero
theorem omega_kappa_forced (Ω : OmegaHom) (k : Gen) (hidem : mulW [k] [k] = [k]) :
    Ω.map [k] = Ivl.zero
theorem M_not_cancellative
theorem no_commutativity / no_absorption_L / no_absorption_R / no_torsion_gate
theorem archive_not_idempotent
theorem sealRec_preserves_band          -- aralık-güvenli mühürleme
theorem trole_differs_c0_cp             -- iki farklı zamansızlık
