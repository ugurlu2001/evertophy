def phaseSupportsMetric (p : Phase) : Bool :=
  carriable p Dim.len && carriable p Dim.time
theorem mpb_c0 : phaseSupportsMetric .c0 = false := by decide   ✅
theorem mpb_cp : phaseSupportsMetric .cp = false := by decide   ✅
theorem mpb_Cm : phaseSupportsMetric .Cm = true  := by decide   ✅
