inductive CarrierKind | xCoordinate | ordinaryDimensionless | dimensioned
def crossesPhaseGate : CarrierKind → Bool
  | .xCoordinate => true
  | .ordinaryDimensionless => false    -- boyutsuz AMA pasaportsuz
  | .dimensioned => false

theorem only_X_crosses              : crossesPhaseGate .xCoordinate = true
theorem plain_dimensionless_blocked : crossesPhaseGate .ordinaryDimensionless = false
theorem crossable_implies_not_dimensioned
