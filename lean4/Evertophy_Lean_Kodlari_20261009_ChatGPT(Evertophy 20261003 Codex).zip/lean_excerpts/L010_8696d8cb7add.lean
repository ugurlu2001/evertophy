tri_edge_only_dimensionless : crossable_c0_cp Dim.one  = true
tri_edge_no_mass / no_len / no_time                    = false
