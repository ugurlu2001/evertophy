structure ParamBudget where
  claim : String
  freeInputs : Nat
  predictedObservables : Nat

def isPredictive (b : ParamBudget) : Bool := b.freeInputs < b.predictedObservables
