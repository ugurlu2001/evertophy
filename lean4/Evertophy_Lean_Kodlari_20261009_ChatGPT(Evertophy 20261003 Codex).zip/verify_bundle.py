from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text())
expected = {row["path"] for row in manifest["files"]}
actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()} - {"manifest.json"}
assert actual == expected, ("file set differs", actual ^ expected)
for row in manifest["files"]:
    data = (root / row["path"]).read_bytes()
    assert len(data) == row["bytes"], row["path"]
    assert hashlib.sha256(data).hexdigest() == row["sha256"], row["path"]
print(f"PASS: {len(expected)} files verified; Lean compilation not performed.")
