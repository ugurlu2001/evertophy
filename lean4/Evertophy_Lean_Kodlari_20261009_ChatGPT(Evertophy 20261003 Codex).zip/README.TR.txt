EVERTOPHY — LEAN KODLARI TOPLAMA PAKETİ — 2026-10-09

Bu paket, bu sohbetin erişilebilir çalışma alanındaki Evertophy belgeleri ve
önceki ZIP arşivlerinde gerçekten mevcut Lean içeriklerini toplar.
23 farklı kod içeriği; 836 kaynak görünümü; 379 belge/üye tarandı.
Aynı bayt içeriğine sahip tekrarlar tek dosyada tutulur, tüm kaynakları kaydedilir.
İçerik değiştirilmedi; eski, çelişkili veya eksik kodlar da denetim için korundu.

ÖZGÜN REPO DURUMU
Bu kaynaklarda ayrı özgün .lean dosyası sayısı: 0.
Belgelerde repo yapısı, modüller ve geçmiş derleme sonuçları anlatılıyor;
özgün repo dosyaları burada bulunmadığı için repo yeniden üretilmiş değildir.
Eksik özgün dosyalar missing_originals.json içindedir. Diğer sohbetlerde olup
buraya aktarılmamış kodlar için eksiksizlik iddiası yoktur.

İÇERİK
lean_excerpts/: Kaynaktan bayt düzeyinde çıkarılmış kodlar; birleştirilmiş
Lean projesi değildir. Bazıları yalnız imza, şema, kısaltma veya bağımlı parçadır.
KOD_ENVANTERI.tsv: İnsan tarafından okunabilir kaynak/satır envanteri.
code_index.json: Tüm kökenler, SHA256, bağlam ve basit statik işaretler.
contexts/: Kaynak çevresinden değiştirilmeden alınmış metinler.
source_documents/: Son Core minor11 ve V24 minor18 belgeleri, tam bağlam için.
scanned_sources.json: Taranan belge ve arşiv üyelerinin özeti/hash'leri.
missing_originals.json: Belgelerde adı geçen, özgün dosyası bulunmayan modüller.
manifest.json ve verify_bundle.py: Paket bütünlüğü kontrolü.

ÇAPRAZ DENETİM
1. Önce python3 verify_bundle.py ile dosya bütünlüğünü kontrol edin.
2. Kodların code_index.json içindeki kaynak, bölüm ve sürümünü inceleyin.
3. Orijinal repo ve araç zinciri sağlandığında gerçek Lean/lake derlemesini
   ayrı kaydedin; özgün parçalar üzerinde yapılan her düzeltmenin farkını tutun.
Bu paket hazırlanırken Lean derlemesi yapılmadı; EXTRACTED_NOT_TYPECHECKED
durumu kullanıldı. Statik işaretler hata kararı veya derleyici sonucu değildir.
Arşiv kontrolü matematiksel/ontolojik doğrulama anlamına gelmez.
