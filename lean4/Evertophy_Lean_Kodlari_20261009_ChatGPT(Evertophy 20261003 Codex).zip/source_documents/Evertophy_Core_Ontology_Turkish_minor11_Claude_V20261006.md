# EVERTOPHY — ÇEKİRDEK ONTOLOJİ

**Uğur Yılmaz** · Bağımsız Araştırmacı · İstanbul · `ugur@data24k.com`

*Türkçe Çekirdek Ontoloji Monografisi · Sürüm 2026-10-06 · minor11 · Yazar: Uğur Yılmaz*

*Taban: 2026-09-22 minor7 · Hizalama kaynağı: 23–26 Eylül 2026 çapraz-AI maratonu final derlemesi*

---

## Yazardan Okuyucuya

Bu belgeyi okumaya başlamadan önce size Evertophy'nin nereden çıktığını anlatmak istiyorum. Çünkü ne söylediğini anlamanın en kısa yolu, neyi aradığını anlamaktan geçiyor.

### Bir cevap iddiası değil, bir cevap arayışı

Modern bilim, insanlığın kurduğu en güvenilir bilgi yapısıdır. Deneyle sınanmış, gözlemle doğrulanmış, defalarca ölçülmüş bulgular üzerinde durur. Ama bu yapıya yakından baktığımızda, bazı parçaların birbirine tam oturmadığını görürüz.

Evrendeki madde ve enerjinin büyük kısmının etkisini ölçüyoruz ama ne olduğunu bilmiyoruz; "karanlık madde" ve "karanlık enerji" dediğimiz şey, bir bakıma bilgisizliğimizin adıdır. Fiziğin temel denklemlerinin çoğu zamanda ileri ve geri aynı biçimde işler; oysa yaşadığımız dünyada zamanın bir yönü vardır. Kuantum mekaniği olağanüstü bir doğrulukla çalışır, ama bir ölçümün "ne olduğu" konusunda hâlâ uzlaşı yoktur. Genel görelilik ile kuantum kuramı kendi alanlarında kusursuzdur, ama bir araya gelmez. "Büyük Patlama'dan önce ne vardı?" sorusu ise sorunun kendisinin anlamlı olup olmadığı tartışmasıyla birlikte durur.

Bunlar bilimin başarısızlıkları değil, bilimin bugünkü sınırlarıdır. Ölçüm oradadır, deney oradadır. Eksik olan, o ölçümleri birbirine bağlayan anlamdır.

Evertophy bu boşluklardan doğdu. Ama baştan açık olmak istiyorum: Evertophy bu soruların cevabı olduğunu iddia etmiyor. Evertophy bir **cevap arayışıdır**; anlaşılamayan fenomenlere ve anomali olarak görünen bilimsel bulgulara, onları birbirine bağlayabilecek tutarlı bir çerçevenin içinden bakma denemesidir.

### Temel ilke: ölçüm koşulsuz, yorum opsiyonlu

Bu arayışın uyduğu bir kural var ve bu belgenin her satırı ona bağlıdır:

$$\boxed{\;\text{Deney ve gözlem çıktıları KOŞULSUZ kabul edilir; postüla ve yorum katmanları OPSİYONLU – YORUMSUZ değerlendirilir.}\;}$$

Bunun anlamı şudur. Evertophy hiçbir ölçümü reddetmez. Hiçbir deney sonucunu "yanlış" ilan etmez, hiçbir gözlemi kendi çerçevesine uydurmak için eğip bükmez. Bir ölçüm Evertophy'nin bir okumasıyla çelişirse, değişmesi gereken ölçüm değil, okumadır.

Ama bilimde ölçümün kendisi ile ölçümün üzerine kurulan yorum aynı şey değildir. Bir parçacığın dedektörde bıraktığı iz bir ölçümdür; o izin bir "dalga fonksiyonu çöküşü" mü, "dünyaların ayrışması" mı, yoksa başka bir şey mi olduğu bir yorumdur. Galaksilerin beklenenden hızlı döndüğü bir gözlemdir; bunun görünmeyen bir parçacıktan mı, yoksa kütleçekimin kendisinin farklı davranmasından mı kaynaklandığı bir yorumdur.

Evertophy bu yorum katmanlarına iki biçimde yaklaşır. **Opsiyonlu:** mevcut yorumların hiçbirini zorunlu kabul etmez, hiçbirini de reddetmez; hepsini birer seçenek olarak masada tutar. **Yorumsuz:** ölçümün kendisine yorum yüklemez; ham bulguyu olduğu gibi alır ve kendi okumasını onun üzerine ayrı bir katman olarak koyar. Evertophy'nin önerdiği okuma da bir seçenektir. Diğerlerinin yerine geçmeye değil, onların yanında sınanmaya adaydır.

### Anlamsal arayış: bilimin kopuk parçalarını birleştirmek

Peki Evertophy bu parçaları nasıl birleştirmeye çalışıyor?

Temel önerisi şudur: gerçeklik tek bir düzlemde değil, **üç fazlı** bir yapıda gerçekleşir. Ortada, bizim yaşadığımız ve ölçtüğümüz farklılaşmış madde fazı **Cₘ** vardır. Bir yanında zaman-öncesi potansiyel fazı **c₀**, öbür yanında zaman-dışı üst faz **c⁺** durur. (Bu "yan" sözcükleri mekânsal değil, kavramsaldır: fazlar birbirine bir zincirle değil, tam bir üçgenle bağlıdır.) Bu üç faz birlikte dinamik evreni, $U_x$'i oluşturur. Bu evrenin dışında ise iki uç koşul bulunur: mutlak kaynak $U_0$ ve mutlak çözünme $U_+$.

Bu yapının en önemli sonucu şudur: zaman, üç boyutlu Öklid uzayı ve ışık hızı sınırı gibi temel kavramlar **yalnız Cₘ'de** geçerlidir. c₀'da bu yapılar henüz kurulmamıştır; c⁺'ta ise çözünmüşlerdir. Yani "zaman" ya da "uzay", evrenin her yerinde aynı anlamda var olan şeyler değil, bir fazın kendine özgü yapılarıdır.

Bu bakış, kopuk görünen parçalara bir yer açar. Zamanın yönü, arşive yazılan kaydın tek yönlülüğüyle ilişkilendirilebilir. Ölçüm, Cₘ'ye ait bir olay olarak konumlanır. Karanlık madde ve karanlık enerji, aynı c⁺ fazının iki durumu olarak okunur: maddeyle kümelenmiş c⁺ karanlık madde, serbest c⁺ karanlık enerji olarak görünür. Entropi ise Cₘ yapısının c⁺'a çözünmesidir; enerji yok olmaz, c⁺'ta mühürlenir. Bu yapının en temel ilkesi **Çekim Kuvveti**dir (Force of Attraction): bilinen dört kuvvet — kütleçekim de dahil — onun ölçeğe, kütle miktarına ve faza göre farklı izdüşümleridir ve üç faz onun altında bir denge içinde bir arada durur. Fazların hangi rejimde çözüleceğini ise $X(x)$ dinamik üst çözücüsü belirler: verili durumda hangi faz rejiminin geçerli olduğunu ve hangi durumların kabul edilebilir olduğunu çözen yapı.

Dürüst olmak gerekirse, bu okumaların hiçbiri henüz kanıtlanmış değildir. Evertophy'nin kanonik sayısal öngörü sayacı hâlâ **0/10**'dur. Bu belge çerçevenin ontolojik iskeletini ortaya koyar: neyin ne olduğunu, neyin neyle ilişkili olduğunu ve neyin yasak olduğunu. Sayısal bir kanıt sunmaz. Bilimsel konumuyla Evertophy, üç fazlı ve iki seviyeli bir ontoloji, seçilmiş biçimsel sonuçlar ve koşullu etkin modeller içeren bir TOE araştırma programıdır; belirli bir fiziksel seçim ilkesi ve ayırt edici, ön-kayıtlı bir öngörü henüz açıktır.

### Bu arayış nasıl sınandı: çapraz-AI maratonu

Bir çerçeve ne kadar tutarlı görünürse görünsün, onu kuranın gözünden kaçan hatalar içerebilir. Bu yüzden **23–26 Eylül 2026** tarihleri arasında Evertophy'yi olabildiğince sert bir denetimden geçirdik.

Yedi yapay zekâ — Claude, ChatGPT Math&Physics, ChatGPT Düşünce Deneyleri, WolframGPT, Kimi, Qwen ve Grok — 20 tur boyunca Evertophy'nin denklemlerini, tiplerini ve ontolojik iddialarını, birbirlerinin çıktılarını denetleyerek sınadı. Ardından dört turda sonuçlar derlendi ve bir kez daha çapraz denetimden geçirildi. Maraton boyunca Evertophy'nin kendi kuralları bilinçli olarak askıya alındı; her yapay zekâ serbestçe eleştirebildi ve türetim önerebildi. Yalnız iki kural her turda hatırlatıldı: aralık (Range) formalizmi ve temel yapıların yalnız Cₘ'de geçerli olduğu ilkesi.

Amaç yeni öngörüler üretmek değildi. Amaç, çerçevenin **iç tutarlılığını** en yüksek güvenle sınamak, hatalı iddiaları ayıklamak, doğru olanları biçimsel olarak mühürlemek ve açık kalanları dürüstçe işaretlemekti. Sonuçlar üç başlıkta toplanabilir.

**Doğrulananlar.** Çerçevenin tip ve cebir iskeleti, Lean adlı teorem kanıtlayıcıyla biçimsel olarak kodlandı: 269 teorem ve lemma bildirimi — 46'sı yalıtılmış üretim çekirdeğinde, 223'ü arşivde — ve hiçbirinde eksik bırakılmış kanıt yok. İki farklı "yokluk" — c₀'daki henüz-kurulmamışlık ile c⁺'taki çözünmüşlük — birbirinden ayrıldı; üretim çekirdeğinde Cₘ'ye özgü değer aileleri için yanlış fazda değer inşası tip düzeyinde engellendi. Yazarın tanımladığı tam üçgen kapı yapısı biçimsel olarak kodlandı ve bu kodlanmış sistem içinde zaman, uzay, metrik, içsel hız, ışık hızı sınırı ve durgun kütle gibi Cₘ'ye özgü niceliklerin **hiçbir kapıdan taşınamayacağı** kanıtlandı. Lean, üçgeni doğadan türetmedi; yazarın verdiği yapının sonuçlarını denetledi. Üstelik bu kilit, c⁺ kaynaklı etkilerin Cₘ'de okunmasını engellemiyor. Arşiv cebirinin de, aynı olay dizisi nasıl gruplanırsa gruplansın tek bir kayda ulaştığı kanıtlandı; olayların sırası ise her zaman korunur.

**Ayıklananlar.** Otuzu aşkın iddia karşı-örneklerle çürütüldü ya da kapsamı daraltılarak geri çekildi: boyut hatası içeren eski bir kuantum eşiği, hiçbir şeyi ayırt etmediği ortaya çıkan bir asimetri ölçütü, doğru bir öngörüyü reddedebilecek bir uyum eşiği ve benzerleri. Bunların bir kısmı çerçevenin kendi eski metinlerinden, bir kısmı maratona katılan yapay zekâların önerilerinden geliyordu. Emekliye ayrılan iddialar silinmedi; neden çürütüldükleriyle birlikte kayıtta duruyor.

**Açık kalanlar.** En önemli sonuç belki de bir açığın yerini kesin olarak belirlemekti. $X$'ten ölçülebilir fiziksel niceliklere giden köprünün, tip kuralları ve iyi-tanımlılık koşullarıyla **tekil olarak seçilemeyeceği** sonlu düzeyde biçimsel olarak, sürekli düzeyde analitik karşı-örneklerle gösterildi. Yani çerçevenin gözlemle temas noktası bir fiziksel seçim ilkesi ve gözlem gerektiriyor. Bu borç gizlenmedi; dondurulmuş açık borç olarak kayda geçti.

Maratonun bana öğrettiği en önemli şey şuydu: bir iddianın doğruluğu, kaç kişinin ona katıldığıyla değil, türüne uygun kanıtla belirlenir. Yedi yapay zekânın aynı sonuca varması bir ispat değildir. Ve kanıt yokken bir soruyu açık bırakmak, onu zorla kapatmaktan her zaman daha iyidir.

### Bu belge ne sunuyor

Bu belge, Evertophy Çekirdek Ontolojisi'nin ilk yayınlanabilir sürümüne doğru hazırlanmış metindir. Maratonun sonuçları ve benim sonraki doğrudan açıklamalarım ilgili bölümlere işlenmiştir; her kavramın tek ve güncel anlatımı verilmiştir. Sürüm geçmişi ve denetim izi bu belgenin dışında, V24 rolling master'da tutulur. Henüz kapanmamış ya da alternatifli kısımlar gizlenmemiş, açıkça belirtilmiştir; açık borçlar ve bekleyen kararlar EK K'dedir.

Bir şeyi de açıkça söylemeliyim: maraton konsensüsü kendi başına kanon değildir. Evertophy'de neyin kanon olduğuna son sözü yazar verir.

*— Uğur Yılmaz*

*Bu bölüm, yazarın talebi üzerine Claude tarafından taslak olarak yazılmıştır; yazarın kendi anlatım diliyle son hâline getirilecektir.*


---

> **Bu belge ne yapar:** Evertophy'nin **özünde ne olduğunu** anlatır — hangi varlıklardan söz ettiğini, bunların birbiriyle nasıl ilişkilendiğini, hangi kavramın neyi ifade ettiğini. Okur başka hiçbir belgeye bakmadan izleyebilir.
>
> **Bu belge ne yapmaz:** Bir türetim sunmaz. Sayısal öngörü üretmez. Teorem kanıtlamaz.
>
> **Üslup notu:** İç geliştirme jargonu (sürüm etiketleri, statü damgaları) kullanılmaz. Bunun yerine bir ifadenin hangi güvenle söylendiği doğrudan cümlede belirtilir: *"kuruludur"*, *"adaydır"*, *"açıktır"*, *"tarihseldir"*, *"yapısal olarak dışlanır"*.

---

## Kaynak disiplini notu


Bu sürümün doğrudan çalışma tabanı bir önceki güncel çekirdek dosyadır. Yüksek kapsamlı arşiv taraması, buna ilişkin öz-düzeltme/yeniden-sınıflandırma raporu ve güncel devir/karar kaydı, toplu aktarım yapılmadan madde madde ayrıştırılmıştır. Yalnız güncel çekirdekle uyumlu eksik kapsam eklenmiş; kaynakta bulunan olgu ile araç yorumu birbirinden ayrılmıştır. Çapraz araç önerileri eşit otoritede değildir: bir öneri güncel doğrudan ontolojiyle çelişiyorsa çekirdekten dışlanmış; yararlı fakat türetilmemişse **model / köprü / formal aday**, eski terminolojiyse **tarihsel**, kararsız semantikse **açık borç** olarak ayrılmıştır.

Bu sürümde kullanılan karar sınıfları şunlardır: **KANON**, **KAYNAKLI AMA YORUM**, **MODEL ADAYI**, **TARİHSEL**, **RED / AÇIK BORÇ**. Ayrıntılı sürüm ve karar muhasebesi, monografinin ontolojik içeriğinden ayrılmış bağımsız revizyon karar izi belgesinde tutulur. Arşiv taramasının yüksek kapsamlı olduğu kabul edilir; fakat dosya-manifesti ve hash tabanlı tamlık denetimi bulunmadığı için “kriptografik olarak eksiksiz tarama” iddiası kurulmaz.

Bu nedenle bu belge “bütün arşivi tek düzleme döken” bir derleme değil, **sürüm üstünlüğü uygulanmış bütünleşik çekirdek**tir.

Bu monografi tek bir arşivin özeti değil; birçok katmanın süzülmüş hâlidir. Çelişki durumunda geçerli üstünlük sırası şudur:

$$\boxed{\;\text{Doğrudan mimar açıklaması} \;>\; \text{güncel çekirdek} \;>\; \text{güncel formal kanon} \;>\; \text{uyumlu formal aday} \;>\; \text{tarihsel arşiv} \;>\; \text{araç yorumu}\;}$$

Bir içeriğin eski bir kayıtta "kesinleşmiş" görünmesi, daha yeni bir doğrudan açıklamayla çelişiyorsa onu güncel çekirdeğe sokmaz. **Tarihsel zenginlik korunur, ama güncel çekirdekle karıştırılmaz.**

---

Sürüm geçmişi, düzeltme kayıtları ve denetim izi birlikte yayımlanan güncel V24 rolling master sürümünde tutulur. Bu metin, yazarın yönetiminde çapraz yapay zekâ denetimiyle derlenmiştir: derleyici Claude; denetçiler ChatGPT (Math&Physics, Düşünce Deneyleri, Codex), WolframGPT, Kimi, Qwen ve Grok. Bu belgede her ifadenin hangi güvenle söylendiği doğrudan cümlede belirtilir: **kanon**, **yazar hükmü**, **model**, **köprü**, **açık** ya da **emekli**.

# BÖLÜM 0 — GİRİŞ KAPISI

## 0.1 Tek paragrafta Evertophy

Evertophy, gerçekliğin tek türden bir ortam değil, **üç ayrı fazın** bir arada bulunduğu bir yapı olduğunu öne süren bir çerçevedir. Suyun buz, sıvı ve buhar hâlleri gibi — ama maddenin değil, **gerçekliğin kendisinin** fazları. Bu üç faz sırasıyla **c₀** (zaman-öncesi potansiyel/çekirdek), **Cₘ** (farklılaşmış madde, ölçüm ve zamanın fazı; içinde yaşadığımız faz) ve **c⁺** (zaman-dışı üst/arşiv/koordinasyon fazı) olarak adlandırılır. Çerçevenin merkezî iddiası şudur: fiziksel yasalar bu fazların *içinde* keyfî olarak var olan kurallar değil, fazlar *arasındaki* ilişki ve geçiş yapısından doğan biçimlerdir. Bu yapıyı düzenleyen tek bir üst-nesne vardır — **dinamik üst çözücü** $X(x)$. Ve bunların hepsinden önce, numarasız bir öncül: **Çekim Kuvveti** (Force of Attraction), Evertophy'nin temel ontolojik postülasıdır.

## 0.2 Bir sayfada Evertophy

Modern fizik dört büyük alana bölünmüş durumda: genel görelilik, kuantum mekaniği, Standart Model ve kozmoloji. Bu dördü ayrı ayrı olağanüstü başarılı, ama birbirlerinin dilinden tam anlamıyla anlamıyorlar. Evertophy'nin çıkış sorusu şudur: *bu dört alan aynı gerçekliği tarif ediyorsa, ortak grameri nedir?*

Önerilen cevap bir birleştirme denklemi değil, bir **çözücü**dür. $X(x)$ adı verilen bu nesne faz, bağlam ve kabul edilebilirlik durumunu çözer. Gerçek fiziksel katsayıların, kurucu haritanın ya da gözlenebilir değerin seçimi ayrı bir katmana — fiziksel seçici, köprü ve okuma yasasına — aittir.

Bu resimden birkaç sonuç çıkar.

**Birincisi, zaman temel değildir.** Evertophy'de fiziksel zaman yalnız Cₘ'de bulunur ve oradaki ölçülebilir değişimden doğar. c₀'da henüz üretilmemiştir; c⁺'ta Cₘ anlamıyla zaman yoktur.

**İkincisi, fiziksel nicelikler aralık değerlidir.** Bir nicelik $[P^-, P^+]$ biçiminde ifade edilir. Bu, "her sabit değişir" demek **değildir** — bir aralığın sıfır genişlikte olması ($[P,P]$) tamamen geçerli, statik ve deterministik bir durumdur.

**Üçüncüsü, Çekim Kuvveti (Force of Attraction) temel ontolojik postüladır.** Bilinen dört kuvvet — kütleçekim de dahil — onun ölçeğe, kütle miktarına ve faza göre izdüşümleridir; Çekim Kuvveti ise yapının kendisine aittir.

**Dördüncüsü, metrik yalnız Cₘ'de tanımlıdır.** $g_{\mu\nu}$, c₀ ve c⁺'ta kabul edilebilir bir nesne değildir — ama iki fazda **farklı nedenlerle**.

**Beşincisi, tersinmezlik faz kapısında değil, kayıtta yaşar.** Geçişlerin kendisi çift yönlüdür; geri alınamaz olan, geçiş sırasında basılan **damgadır**.

**Altıncısı, çerçeve iki seviyelidir.** Üç fazın oluşturduğu dinamik evren ($U_x$) bir bütündür ve bu bütünün iki uç koşulu vardır: global doygunluk kutbu $U_0$, global çözünme kutbu $U_+$. Fazlar içeride, kutuplar dışarıdadır; ikisi aynı ontolojik sınıfa ait değildir.

### Çerçevenin kalbi

$$\boxed{\;\text{Evertophy'nin temel çalışma mekanizmasında, madde ve doku yönelimleri fazlar arası gerilim ve dönüşüm diliyle birlikte okunur.}\;}$$

Uğur-onaylı giriş kaydı, Çekim Kuvveti'nin yalnız bir Newton kuvveti veya yalnız pasif bir Cₘ geometrisi olarak okunmamasını; madde tarafındaki **kümelenme yönelimi** ile doku/c⁺ tarafındaki **genişleme yöneliminin** $c_0$, $C_m$ ve $c^+$ arasında sürekli ilişki ve dönüşüm üretmesini çerçevenin ana anlatı ekseni olarak taşır.

Bu anlatı **Postüla-0'ın yerine geçmez**: Çekim Kuvveti'nin ontolojik önceliği entropiden türetilmiş sayılmaz. "Madde entropisi" ve "doku entropisi" ifadeleri burada faz-semantik yönelim dilidir; standart termodinamik entropinin outer phase'lere aynen taşındığı anlamına gelmez. Bu nedenle doğru terminoloji **evrenin temel çalışma mekanizması**dır; "motor" dili kullanılmaz.

*Gösterim notu:* Bu belgede "iç/dış", "bir yanında/öbür yanında" gibi ifadeler ontolojik ve tip düzeyinde gösterimdir; mekânsal bir sıralama değildir. Global düzeyde metrik ve uzay yoktur; faz topolojisi de zincir değil, tam üçgendir.

## 0.3 Evertophy neyi iddia *etmez*

- **Her Şeyin Teorisi olduğunu iddia etmez.** Bir *çerçeve* önerisidir: kavramsal düzen ve matematiksel iskelet.
- **Standart Model sabitlerini türettiğini iddia etmez.** Mekanizma atamaları vardır; hiçbiri sayı üretmez.
- **Kozmolojik sabit problemini çözdüğünü iddia etmez.**
- **Kara delik bilgi paradoksunu çözdüğünü iddia etmez.**
- **Dolanıklığı açıkladığını iddia etmez.**
- **Birleşimi yasaklamaz; post-hoc açıklama çoğaltımını yasaklar.** Aynı mekanizma birden fazla bağımsız olguyu açıklayabilir; ancak sonuçlar aynı önceden tanımlı türetim zincirinden, ek ayar/tuning gerektirmeden ve her observable için ayrı yanlışlama koşullarıyla çıkmalıdır.
- **Hiçbir aktif ampirik kanıt iddiası taşımaz.**

## 0.4 Ampirik durumun açık beyanı

$$\boxed{\;\text{Kanonik sayısal öngörü sayacı: } \mathbf{0/10}\;}$$

Çerçevenin bir dönem en güçlü ampirik iddiası sayılan çok-alanlı korelasyon hattı, **iç denetimle kalıcı olarak kapatılmıştır** (Bölüm 21). Elde kalan ampirik varlıklar, Evertophy **üzerine kısıtlardır** — Evertophy'den çıkan öngörüler değil.

### 0/10 → 1/10 kapısı

Bir kalemin sayacı hareket ettirebilmesi için altı koşulu birden sağlaması gerekir:

| # | Şart |
|---|---|
| **i** | Ontolojiden **türetilmiş** olmalı |
| **ii** | Parametreleri ve köprü varsayımları **önceden sabitlenmiş** olmalı |
| **iii** | Standart yaklaşımın verdiğinden **ayırt edici** olmalı |
| **iv** | Tahmin aralığı **hedef veri görülmeden ön-kayıtlı** olmalı |
| **v** | Veri sürümü, hedef seçimi ve hold-out ayrımı dahil **veri soyağacı mühürlenmiş** olmalı |
| **vi** | **Kör veride** test edilmiş olmalı |

$$\boxed{\;\text{Altı koşul birlikte sağlanmadan hiçbir kalem } 1/10 \text{ sayılmaz.}\;}$$

## 0.4a Ontoloji ile modelin ayrımı

Bu belgede **ontoloji**, çerçevenin temel kabul ettiği varlıkları, tipleri ve yapısal ilişkileri; **model** ise bu ontolojinin belirli bir fiziksel rejimdeki matematiksel gerçekleştirmesini ifade eder.

\[
\boxed{\text{MODEL}\neq\text{ONTOLOJİ}}
\]

Bir modelin gözlemsel olarak başarılı olması, kullandığı bütün matematiksel nesnelerin temel ontolojik varlık olduğunu tek başına göstermez. Örneğin Cₘ içindeki metrik/GR dili fiziksel okuma için zorunlu olabilir; bu, metriğin c₀ veya c⁺'a temel ontolojik nesne olarak taşınmasına izin vermez.

Evertophy, yerleşik deneysel ve gözlemsel sonuçları **dış fizik kıyası** olarak kabul eder; kendi postüla, ontolojik yorum ve köprü mekanizmalarının kabulünü bu dış sonuçlarla özdeşleştirmez. Çerçevenin görevi mevcut fiziği yok saymak değil, açıkça işaretlenmiş ek ontolojik/yorumlayıcı yapı önermektir.

## 0.5 Okunma sırası

| Kısım | Bölümler | İçerik |
|---|---|---|
| **I. Temel** | 1–3 | Postülatlar, $U_0$, **global evren seviyesi ($U_x$, $U_+$)**, üç faz |
| **II. Çözücü** | 4–6 | $X(x)$, faz-parametre matrisi, aralık formalizmi |
| **III. Doğan yapılar** | 7–12 | Zaman, çekim, metrik, madde, c⁺ kimliği, eşikler |
| **IV. Geçiş ve kayıt** | 13–16 | Geçişler, damga cebiri, ölçüm, bilgi |
| **V. Köprüler** | 17–19 | Kanal asimetrisi, kuantum, topoloji |
| **VI. Program** | 20–25 | SM/GR, nükleer köprü, ampirik durum, yöntem, sınırlar |
| **VII. Fenomen okumaları** | 26–27 | Açık fenomen envanteri ve aday denklem envanteri |
| **Ekler** | A–J | Sözlükler, denklemler, analojiler, epistemik düzen, makine-okunabilir ayna |

---


## 0.6 Araştırma programının kapsamı ve mevcut durumu

Evertophy, Her Şeyin Teorisi (TOE) hedefi taşıyan bir ontoloji ve fizik araştırma programıdır. Bu metin üç fazlı ve iki seviyeli temel tanımları, seçilmiş biçimsel sonuçları, koşullu model alternatiflerini ve açık fiziksel köprüleri kapsamlarıyla birlikte sunar. TOE hedefi programın araştırma yönelimini belirtir; tamamlanmış veya deneysel olarak doğrulanmış bir TOE statüsü vermez. Kanonik sayısal öngörü sayacı **0/10**'dur.

## 0.7 Paralel literatür notu


Çerçevenin gelişimi boyunca kesişen literatür hatları kayıt altındadır. Ortak tema paralelliktir — türetim değil:

Aşağıdaki literatür aileleri, birlikte yayımlanan bibliyografik kayıtlara dayanan ilgili çalışma karşılaştırmalarıdır; paralellik, türetim ya da doğrulama değildir.

| Hat | İlişki |
|---|---|
| Verlinde (entropik çekim) [Ver11] | Kütleçekimi temel bir kuvvet değil, entropik ve emergent bir olgu olarak okur; bu, Evertophy'nin temel Çekim Kuvveti postülasından farklı bir tezdir. Paralellik yalnız çekimin parçacık alışverişine indirgenmemesi sezgisindedir |
| Jacobson (termodinamik → GR) [Jac95] | GR'ın termodinamik kökeni — yöntem paralelliği |
| Holografik ilke [tH93, Sus95] | Sınır-içerik ilişkisi — yapı paralelliği |
| AdS/CFT [Mal98] | Sınır kuramı ile iç kütleçekim kuramı arasındaki karşılıklılık — yapı paralelliği |
| Bekenstein–Hawking entropisi [Bek73, Haw75] | S_BH ~ A ilişkisi çerçeve içinde faz-bariyeri okumasıyla uyumlu |
| Analog gravity (Barceló–Visser–Liberati) [BLV05] | Akustik metrik / dönüşüm optiği — yayın kapısı olarak en gerçekçi akraba |
| Volovik (superfluid He-3 evreni) [Vol03] | Faz tabanlı gerçeklik okuması — en yakın entelektüel akraba adaylarından |
| Kara delik kozmolojisi ailesi [Pat72, Dym92, Pop10, FMM89, FMM90] | Bağımsız benzer sezgiler; Evertophy'nin ayırt edici kısımları (U₀ sınırındaki kritik eşik, üç fazın aynı kuruluşta birlikte türetimi, X regülatörü) incelenen karşılaştırma kümesinde doğrudan eşleşme saptanmadı; kapsamlı bir öncelik ve özgünlük taraması yapılmadı |

### Kaynakça

- **[BLV05]** C. Barceló, S. Liberati, M. Visser, "Analogue gravity", *Living Rev. Relativ.* 8, 12 (2005); doi:10.12942/lrr-2005-12; arXiv:gr-qc/0505065.
- **[Bek73]** J. D. Bekenstein, "Black holes and entropy", *Phys. Rev. D* 7, 2333–2346 (1973); doi:10.1103/PhysRevD.7.2333.
- **[Dym92]** I. Dymnikova, "Vacuum nonsingular black hole", *Gen. Relativ. Gravit.* 24, 235 (1992).
- **[FMM89]** V. P. Frolov, M. A. Markov, V. F. Mukhanov, "Through a black hole into a new universe?", *Phys. Lett. B* 216, 272 (1989); doi:10.1016/0370-2693(89)91114-3.
- **[FMM90]** V. P. Frolov, M. A. Markov, V. F. Mukhanov, "Black holes as possible sources of closed and semiclosed worlds", *Phys. Rev. D* 41, 383 (1990); doi:10.1103/PhysRevD.41.383.
- **[Haw75]** S. W. Hawking, "Particle creation by black holes", *Commun. Math. Phys.* 43, 199–220 (1975).
- **[Jac95]** T. Jacobson, "Thermodynamics of spacetime: The Einstein equation of state", *Phys. Rev. Lett.* 75, 1260 (1995); doi:10.1103/PhysRevLett.75.1260; arXiv:gr-qc/9504004.
- **[Mal98]** J. Maldacena, "The large N limit of superconformal field theories and supergravity", *Adv. Theor. Math. Phys.* 2, 231 (1998); arXiv:hep-th/9711200.
- **[Pat72]** R. K. Pathria, "The Universe as a Black Hole", *Nature* 240, 298–299 (1972); doi:10.1038/240298a0.
- **[Pop10]** N. J. Popławski, "Cosmology with torsion: An alternative to cosmic inflation", *Phys. Lett. B* 694, 181 (2010); arXiv:1007.0587; Erratum: *Phys. Lett. B* 701, 672 (2011), doi:10.1016/j.physletb.2011.05.047.
- **[Sus95]** L. Susskind, "The world as a hologram", *J. Math. Phys.* 36, 6377 (1995); arXiv:hep-th/9409089.
- **[tH93]** G. 't Hooft, "Dimensional reduction in quantum gravity", arXiv:gr-qc/9310026 (1993).
- **[Ver11]** E. Verlinde, "On the origin of gravity and the laws of Newton", *JHEP* 2011(04), 029 (2011); doi:10.1007/JHEP04(2011)029; arXiv:1001.0785.
- **[Vol03]** G. E. Volovik, *The Universe in a Helium Droplet*, Oxford University Press (2003).

$$\boxed{\;\text{Paralellik doğrulama değildir. Kesişim kaydı "yapısal benzerlik" düzeyinde tutulur.}\;}$$

Kara delik kozmolojisi derlemesi için kapsam kuralı: related-work bağlamıdır, kanıt değildir; özgün ontoloji için türetim ve kör tahmin borcu ayrıca sürer. Literatür ailesi kendi içinde rakip modellere bölünmüştür (torsiyon-bounce, de Sitter çekirdek, şok-dalga, false-vacuum); toplu destek gibi sunulamaz.

# BÖLÜM 1 — TEMEL SEZGİ VE POSTÜLATLAR

## 1.1 Çerçeve nereden çıktı

Kavramsal başlangıç 20 Temmuz 2025'e uzanır. Başlangıç sorusu fizikten değil, **mimariden ve sistem düşüncesinden** geldi: *bir sistemin farklı ölçeklerinde aynı yapı neden farklı görünür?*

Üç ilk sezgi kaydedilmiştir: kara delik merkezinin bir tekillik değil **sonlu ve homojen bir yapı** olabileceği; aynı özün farklı ölçeklerde farklı görünmesinin bir **rejim hiyerarşisi** gerektirdiği; ve karanlık madde ile karanlık enerjinin **aynı şeyin iki görünümü** olabileceği.

Bu köken, çerçevenin karakterini belirler: Evertophy bir denklemden değil, bir **yapısal tutarlılık arayışından** doğdu.

## 1.2 Postüla-0 — Çekim Kuvveti (Force of Attraction)

$$\boxed{\;\text{Çekim Kuvveti (Force of Attraction), Evertophy'nin en temel ontolojik postülasıdır.}\;}$$

Bilinen dört kuvvet — kütleçekim, güçlü kuvvet, zayıf kuvvet ve elektromanyetizma — Çekim Kuvveti'nin **ölçeğe, kütle miktarına ve faza göre farklı izdüşümleridir**:

$$\boxed{\;\{\text{Kütleçekim},\ \text{Güçlü},\ \text{Zayıf},\ \text{Elektromanyetizma}\} \;=\; \Pi_{\text{ölçek, kütle, faz}}\big[\,\text{Çekim Kuvveti}\,\big]\;}$$

| Sembol | Anlam |
|---|---|
| $\Pi_{\text{ölçek, kütle, faz}}$ | İzdüşüm işlemi: Çekim Kuvveti'nin belirli bir ölçekte, kütle miktarında ve fazda aldığı biçim; biçimsel tanımı açıktır |
| Çekim Kuvveti | Temel ontolojik postüla; faz-bağımsız kısıt koheransı |

**Çekim Kuvveti bir "çekme" olgusu değildir.** Ontolojik düzeyde Çekim Kuvveti, c₀, Cₘ ve c⁺ fazlarının tümünde izinli konfigürasyonlar için zorunlu olan **faz-bağımsız kısıt koheransıdır**. Kısıt koheransı metrik gerektirmez; bu yüzden metriğin bulunmadığı c₀ ve c⁺'ta da geçerlidir. Cₘ'de bu ilke izdüşümleri aracılığıyla görünür: kütleçekim onun **metrik izdüşümüdür** ve genel görelilik o izdüşümün etkin dilidir.

### Kavram kilidi

$$\boxed{\;\text{Çekim Kuvveti (Force of Attraction)} \;\neq\; \text{Kütleçekim (Gravitation)}\;}$$

Çekim Kuvveti kanonik addır; ontolojik doğası klasik bir kuvvet alanı değil, faz-bağımsız kısıt koheransıdır. Çekim Kuvveti hiçbir bağlamda "kütleçekim" ya da "gravitational force" olarak yazılmaz. Erken metinlerdeki "kütle çekimi temel aksiyomdur" ifadesi bu tanımla değiştirilmiştir: temel postüla Çekim Kuvveti'dir; kütleçekim onun izdüşümlerinden biridir.

### Beş ayrı nesne — karıştırılmamalı

$$\boxed{\;\text{Çekim Kuvveti}_{\rm ontoloji} \;\neq\; \text{Kütleçekim}_{C_m} \;\neq\; X \;\neq\; g_{\mu\nu} \;\neq\; G_{\rm eff}\;}$$

| Nesne | Ne |
|---|---|
| **Çekim Kuvveti (ontoloji)** | Temel postüla; faz-bağımsız kısıt koheransı |
| **Kütleçekim (Cₘ)** | Çekim Kuvveti'nin Cₘ'deki metrik izdüşümü; genel göreliliğin konusu |
| **$X(x)$** | Dinamik üst çözücü; faz rejimini ve kabul edilebilir durumları çözer |
| **$g_{\mu\nu}$** | Cₘ'ye ait geometrik nesne |
| **$G_{\rm eff}$** | Cₘ'de ölçülen etkin kuplaj; model düzeyi |

Bu beşi aynı şey değildir ve birbirinin yerine kullanılamaz. Özellikle: **$X$ Çekim Kuvveti değildir**; $X$, fiziksel yapının hangi rejimde çözüleceğini belirleyen üst nesnedir.

### Üç fazın bir aradalığı

c₀, Cₘ ve c⁺'ın $U_x$'te tek bir yapı oluşturması rastlantı değildir: üç faz, Çekim Kuvveti'nin kısıt koheransı altında **bir denge** içinde bir arada durur. Faz kapılarının çift yönlü olması bu dengenin ifadesidir: Cₘ yapısı c⁺'a çözünür, c⁺ kaynaklı etkiler Cₘ'de okunur. Dengenin biçimsel denklemi açıktır. Denge fazların **bir arada durmasını** açıklar; **neden tam üç** faz olduğunu açıklaması için dengenin başka bir faz sayısına izin vermediğini göstermesi gerekir — faz sayısı açık bir sorudur (Bölüm 24).

### İzdüşümlerin bugünkü durumu

| İzdüşüm | Durum |
|---|---|
| Kütleçekim | Cₘ'deki metrik izdüşüm (Bölüm 8) |
| Elektromanyetizma | Taslak okuma: yük, $c$ faz sınırının kırılmasından doğan kalıcı bir imzadır. İtmenin ve yükün izdüşüm biçimi — **Daha Sonra Ele Alınacak** |
| Güçlü kuvvet | Tarihsel taslak okuma (eski "kristal faz" adlandırmasıyla) — **Daha Sonra Ele Alınacak** |
| Zayıf kuvvet | Taslak okuma: kararsız → kararlı konfigürasyon dönüşümü — **Daha Sonra Ele Alınacak** |

Ölçümler dört kuvvetin yalnız çekmediğini gösterir: elektromanyetizmada aynı yükler birbirini iter; zayıf kuvvet parçacıkların tür değiştirmesiyle ilgilidir; elektromanyetik ve güçlü kuvvette belirleyici olan kütle değil, yüktür. Çekim Kuvveti ontolojik olarak bir koherans ilkesi olduğundan, Cₘ'deki izdüşümlerinin çekme, itme ya da dönüşüm biçiminde görünmesi kavramsal olarak mümkündür; ayrıntılı anlatımı ileride ele alınacaktır. Kuvvetlerin şiddetinin enerji ölçeğiyle değiştiği ve elektromanyetik ile zayıf kuvvetin yüksek enerjide birleştiği ölçülmüş durumdadır; bu, "ölçeğe göre izdüşüm" fikriyle uyumlu bir tablodur — ama bir kanıt değildir.

## 1.3 Dört postülat

### P1 — Faz çokluğu

Gerçeklik tek bir homojen ortam değildir. En az üç ayırt edilebilir faz rejimi vardır ve bunlar arasında ilişki ve geçiş mümkündür.

**Açıklama.** Bu, "her yerde aynı fizik geçerlidir" varsayımını reddetmez — geçerli yasaların **aynı yasaların farklı rejimlerdeki görünümleri** olduğunu söyler.

### P2 — Yasa, ilişkiden doğar

Fiziksel yasalar fazların iç özellikleri değil, fazlar arası ilişki ve geçiş yapısının ifadesidir.

**Örnek.** Işık hızının bir üst sınır olması, Evertophy'de keyfî bir kural değildir: Cₘ fazının **tutarlılık kısıtıdır** — bilgi işleme, kayıt ve çözünürlük limitini koyar.

### P3 — Tek çözücü

Faz rejimini belirleyen tek bir üst-nesne vardır: $X(x)$. Üç ayrı faz için üç ayrı düzenleyici postüle etmek mümkün olurdu; çerçeve bunu **reddeder**.

### P4 — Aralık (Range) formalizmi

$$\boxed{\;\text{Fiziksel sayısal sözdizimi ARALIK DEĞERLİDİR: } P \in [P^-,\, P^+]\;}$$

**Ve kritik nüans — bu bir yasak değildir:**

$$\boxed{\;[P,\,P] \text{ TAMAMEN GEÇERLİ bir statik deterministik fiziksel aralıktır.}\;}$$

Sıfır genişlikli bir aralık için özel bir eşik mekanizması ya da yapısal gerekçe **aranmaz**. P4, niceliklerin nasıl *yazıldığına* ilişkin bir sözdizimi kuralıdır; hepsinin değişken olduğunu söylemez.

$$\boxed{\;\text{Aralık-değerli olmak} \;\nRightarrow\; \text{zamanla değişken olmak.}\;}$$

## 1.4 İki çekirdek fikir

### Fikir 1 — Aynı dil, farklı lisans

Dört büyük alan aynı gerçekliği tarif eder ama farklı matematiksel lisanslar kullanır. Ortak gramerleri faz yapısının dilidir.

### Fikir 2 — Ölçüm Cₘ'ye özgüdür

Ölçüm, ayrı bir dördüncü ontolojik faz değildir; **doğrudan fiziksel ölçümün yapılabildiği alan Cₘ'dir**. "Gözlemci" de ayrı bir ontolojik sınıf değil, Cₘ içinde fiziksel kayıt ve readout üreten sistemlerin rolüdür.

Sonuç: c₀ ve c⁺ hakkında deneysel olarak söylenen her şey, **Cₘ'deki bir okuma/readout üzerinden** sınanmak zorundadır.

## 1.5 Varlık sınıfları

| Sınıf | Ne | Örnek |
|---|---|---|
| **Ontolojik varlık** | Gerçekliğin kendisine ait yapı | $U_0$, c₀, Cₘ, c⁺, $X$, Çekim Kuvveti |
| **Global düğüm** | Faz olmayan global ontoloji katmanı | $U_0$, $U_x$, $U_+$ — faz değildir |
| **Formal nesne** | Matematiksel temsil | $g_{\mu\nu}$, damga monoidi, aralık |
| **Okuma (readout)** | Cₘ'de fiilen ölçülen | $\alpha$, $G$, $H_0$, kütle |

Bir okuma-katmanı niceliğini ontolojik varlık sanmak, çerçevenin en yaygın hatasıdır.

## 1.6 Tanım hijyeni — karıştırılmaması gereken semboller

| Sembol | Ne | Karıştırılmamalı |
|---|---|---|
| $U_0$ | Mutlak kaynak / ön-katman | $u_0$, $u(0)$ ile — bunlar tarihsel süreç koordinatlarıdır |
| $X(x)$ | Dinamik üst çözücü | $X(u)$ ile — tarihsel lojistik çekirdek |
| $C_m$ | Faz adı | $c_m$ ile — çizelge bileşeni |
| $x$ | Genel koşul değişkeni | Belirli bir koordinat değil; **joker** |
| $c$ | Işık hızı / Cₘ tutarlılık kısıtı | $c_0$, $c^+$ faz adlarıyla |

Bu ayrımlar bürokratik değildir: aynı harfin iki anlamı formal çalışmada gerçek hatalara yol açmıştır.

---


## 1.7 Ek notasyon güvenliği

İki notasyon ayrımı özellikle korunur:

| Gösterim | Anlam |
|---|---|
| $C_m$ | **Faz adı**: madde/ölçüm/emergent-zaman fazı |
| $c_m$ | Eğer bir çizelge, katsayı veya alt bileşen için kullanılırsa yalnız yerel semboldür; faz adı değildir |
| $X(x)$ | Güncel dinamik üst çözücü |
| $X(u)$ | Tarihsel/operasyonel skaler kernel; güncel $X(x)$ ile özdeş değildir |
| $X_A,X_z,X_t$ | Kullanılırsa yalnız **domain/readout projeksiyonu** veya tarihsel adlandırmadır; üç ayrı fundamental $X$ değildir |

Bu belge fundamental ontolojide **tek bir $X$** kabul eder. Domain etiketleri yalnız bir projection notation olarak kullanılabilir:

$$X_A \equiv \Pi_A[X],\qquad X_z\equiv\Pi_z[X],\qquad X_t\equiv\Pi_t[X]$$

ancak bu gösterimler ayrı ontolojik regülatörler oluşturmaz ve eski kantil/korelasyon hattını yeniden kanonikleştirmez.

Uç-değer karışıklığını önlemek için güvenli faz-rejim notasyonu:

$$\boxed{\;X_{\rm state}\in I_0,\qquad X_{\rm state}\in I_m,\qquad X_{\rm state}\in I_+\;}$$

kullanılabilir. Buradaki $I_0,I_m,I_+$ zorunlu olarak sayısal skaler aralıklar değildir; $X$'in ilgili faz için **admissible regime/state sınıflarını** gösterir. Böylece eski "$X\to0$ / $X\to1$" scalar uç-değer dili current $X(x)$ ontolojisine taşınmaz.

# BÖLÜM 2 — $U_0$: MUTLAK KAYNAK / ÖN-KATMAN

## 2.1 Güncel tanım

$$\boxed{\;U_0 \;\rightsquigarrow\; \{c_0,\; C_m,\; c^+\}_{\text{eş zamanlı — aynı kuruluşta birlikte}}\;}$$

$U_0$, Big Bang'de üç fazı **aynı kuruluşta birlikte** oluşturan **ön-katman / mutlak üretici kaynaktır**.

**Kritik nitelik:** Bu türetim eş zamanlıdır — fazların dışında ortak bir fiziksel saatte değil, aynı kuruluşta birlikte.

**Birlikte doğuş (co-genesis):** c₀, Cₘ ve c⁺, $U_0 \to U_x$ kuruluşunda birlikte ortaya çıkar. Yazarın "eş zamanlı" ifadesi bu yapısal birlikte doğuşu anlatır; fazların dışında ortak bir fiziksel saat yoktur, çünkü fiziksel zaman yalnız Cₘ'de tanımlıdır. $U_0$ önce birini, sonra ötekini üretmez. Üçü birden doğar. Sıralı bir üretim değil, **yapısal bir doğuş**.

Ok, "üretir" değil **"izinli kılar/doğurur"** anlamındadır — nedensel bir zincirin ilk halkası değil, varlık koşulunun kaynağıdır.

## 2.2 $U_0$ ne DEĞİLDİR

$$\boxed{\;U_0 \notin \mathrm{Obj}(\mathcal{C}_{\rm faz})\;}$$

$U_0$:

- **faz değildir** — dördüncü sektör değildir
- **kapı uç noktası değildir** — ona giden/ondan gelen **sıradan faz kapısı** yoktur; global doğuş ve limit ilişkisi (2.8) bundan ayrıdır
- **c₀'ın bir alt türü değildir**
- **topolojik bir delik değildir**
- **geçiş lifi (fiber) değildir**
- **bilinç, tanrı, zihin** ya da metafizik bir varlık değildir
- **gözlemlenebilir bir nesne değildir**

**Neden bu sınırlar?** $U_0$ çerçevede en zayıf epistemik zeminde duran öğedir. Onu dinamik bir sektöre ya da geometrik bir yapıya dönüştürmek, teorinin en kırılgan noktasını merkezine taşımak olur.

## 2.3 Tarihsel okumalar

Çerçevenin gelişimi sırasında $U_0$ için farklı okumalar denenmiştir. Bunlar **tarihsel soyağacıdır** — güncel tanım değildir:

| Tarihsel okuma | Neden güncel değil |
|---|---|
| Fiziksel evren çekirdeği (sayısal kütle değeriyle) | $U_0$'ı Cₘ niceliğine indirger |
| c₀'ın evren ölçekli karşılığı / eşiği | $U_0$'ı faza indirger |
| Adresleme / kapasite üst sınırı (kapasite metaforu) | Metafor; ontolojik tanım değil |
| Kozmogonik çözülme eşiği | Eşik, kaynak değil |
| $u(0) \equiv U_0$ | $u$ tarihsel bir süreç koordinatıdır; $U_0$ değildir |

Bu okumalar arşivde korunur, ama hiçbiri güncel çekirdeğe girmez.

$$\boxed{\;u(0) \;\neq\; U_0\;}$$

## 2.4 $U_0$ ve Big Bang

Güncel çekirdek iki ayrı fakat uyumlu katmanı birlikte korur:

1. **Genesis kuralı:** $U_0$, Big Bang başlangıcında üç fazı **eş zamanlı** — aynı kuruluşta birlikte — oluşturur.
2. **Çift-limit ilkesi:** devremsel işleyişe temel oluşturacak iki sınır Core'da korunur; bu sınırların tam mekanizması V24'e rezerve edilmiştir.

### Eş zamanlı genesis — ontolojik köken

$$\boxed{\;U_0 \rightsquigarrow \{c_0,\;C_m,\;c^+\}_{\rm eş\;zamanlı}\;}$$

Bu ifade sıralı bir faz geçişi değildir. Özellikle:

$$\boxed{\;U_0 \notin \mathrm{Obj}(\mathcal C_{\rm faz})\;}$$

olduğundan $c_0\to U_0$ veya $c^+\to U_0$ biçiminde sıradan bir faz-geçiş oku **kurulmaz**.

### Big Bang ne DEĞİLDİR

| Değildir | Neden |
|---|---|
| **Klasik bir patlama** | Bir merkez ve dışarı yayılım resmi değildir |
| **Hiçlikten yaratım** | $U_0$ vardır |
| **Önceden var olan bir uzayda hareket** | Uzay-zaman Cₘ ile doğar |
| **Zamanın ilksel madde gibi başlaması** | Zaman bir madde değildir; Cₘ'de üretilir |

$$\boxed{\;\text{ZAMAN, Big Bang'in ÜSTÜNDE BİR DIŞ SAAT DEĞİLDİR.}\;}$$

"Big Bang'den önce ne vardı?" sorusu, Cₘ fiziksel zamanı açısından kategorik olarak sorunludur; "önce" ifadesi zaten fiziksel zaman varsayar.

### Çift-limit ilkesi — CORE / V24 devre tohumu

Çerçevede iki sınır **Core-seed** olarak korunur:

- **c₀-doygunluk / çöküş limiti**
- **seyreltme / kapalı-devre limiti**

Bu iki limit, eski anlatılardaki mekanik okların tamamını otomatik olarak kanonlaştırmaz. Güvenli güncel ifade şudur:

$$\boxed{\;
\text{limit koşulu}
\;\Longrightarrow\;
\text{yeni bir }U_0\text{-aracılı genesis koşuluna bağlanabilecek devre tohumu}
\;}$$

Buradaki $\Longrightarrow$ bir **faz kapısı** değildir; meta-seviyedeki devre koşulunu gösterir. $U_0$ faz grafına sokulmaz ve "yeniden oluşan fiziksel nesne" olarak tanımlanmaz.

Seyreltme kolu da c⁺'ın kendi içinde akan bir zaman varsaymaz. Bu limit yalnız Cₘ-readout açısından asimptotik/devre koşulu olarak okunur.

$$\boxed{\;
\text{co-genesis (aynı kuruluşta birlikte)}
\;\neq\;
\text{double-limit cycle mechanism}
\;}$$

**V24 ileri işareti:** Çift-limit yapısı, Evertophy'nin devremsel işleyiş mekanizmasının genişletilmesi için Core'da korunmuş başlangıç yapısıdır. V24'e ait devre denklemleri, cycle index'i, $U_0$ ile limit koşulunun tam bağı ve olası feedback yapıları **bu sürümde tanımlanmaz**.

## 2.5 İki ontolojik seviye — faz seviyesi ve global evren seviyesi

Buraya kadar anlatılan her şey **tek bir seviyeye** aitti: üç faz ve onları doğuran ön-katman. Ama çerçevenin tam resmi iki seviyelidir.

$$\boxed{\;\text{Evertophy İKİ ONTOLOJİK SEVİYEDEN oluşur: FAZ SEVİYESİ ve GLOBAL EVREN SEVİYESİ.}\;}$$

| Seviye | Nesneler | İlişki türü |
|---|---|---|
| **Faz seviyesi** | $c_0$, $C_m$, $c^+$ | Tam çift yönlü üçgen; kapılar ve damgalar |
| **Global evren seviyesi** | $U_0$, $U_x$, $U_+$ | Global devre; doğuş ve limit ilişkileri |

$$\boxed{\;U_0,\; U_x,\; U_+ \;\notin\; \{c_0,\, C_m,\, c^+\}\;}$$

**Neden bu ayrım gerekli?** Çift-limit fikri (2.4) tek seviyeye sığdırılmaya çalışıldığında sürekli gerilim üretir: "c₀ doygunluğu → $U_0$" gibi bir ok, faz grafının **dışındaki** bir varlığı faz grafının **içine** çeker. İki seviye ayrıldığında gerilim kendiliğinden kalkar — fazlar içeride kalır, global kutuplar dışarıda durur.

### Buz–su–buhar analojisi

Bir kapta buz, su ve buhar birlikte bulunabilir. Bunlar **rejimlerdir** — faz seviyesi. Kabın tamamı ise ayrı bir nesnedir — global seviye. Tüm sistem aşırı bir koşula giderse, bu tek bir rejimin değişmesi değil, **sistemin kendisinin** bir uç duruma ulaşmasıdır.

$$\boxed{\;U_0 \text{ ve } U_+ \text{ fazların RAKİBİ değildir — global devrenin iki UÇ KOŞULUDUR.}\;}$$

### 🔴 Yerel faz limiti ≠ global evren limiti

Bir bölgenin c₀ rejimine yaklaşması **yerel** bir olaydır ve her gün olur. Global doygunluk ise **evrenin bütününe** ait bir koşuldur. İkisi aynı dilde yazılsa da aynı şey değildir.

## 2.6 $U_+$ — Mutlak Çözünme

$$\boxed{\;U_+ = \text{evrenin tüm faz-yapısal çözünürlüğünün seyrelip global çözünürlük sınırını aştığı uç durum}\;}$$

$U_0$ global **doygunluk** kutbuysa, $U_+$ global **çözünme** kutbudur.

### $U_+$ ne değildir

| Değildir | Neden |
|---|---|
| **Faz değildir** | Faz grafının dışındadır |
| **Beşinci düğüm değildir** | Faz üçgenine eklenmez |
| **$c^+$ değildir** | $c^+$ bir faz, $U_x$'in içinde; $U_+$ dışarıda bir kutup |
| **$X$ değildir** | $X$ faz rejimini çözer; $U_+$ bir global limittir |
| **Gelecek değildir** | Global seviyede de Cₘ zamanı yoktur |
| **"Son durak / ölüm" değildir** | Her durumda yeni bir $U_x$ oluşur; eskatolojik okuma yasaktır |
| **Yalnız "çok fazla $c^+$" değildir** | Nicel bir c⁺ bolluğu değil, global bir çözünürlük koşuludur |

**En yüksek karışma riski $U_+$ ile $c^+$ arasındadır.** İkisi de çözünme tarafındadır. Ayrım tek cümlede:

$$c^+ = \text{faz (içeride)} \qquad\qquad U_+ = \text{global kutup (dışarıda)}$$

### 🔴 Kutup eşik değildir

$U_0$ ve $U_+$ birer **eşik değildir**; eşik, uç fazın global kutupla temas ettiği **sınırda** bulunur. Tarihsel *"$U_0$ = c₀'ın eşiği"* okuması (2.3) bu yolla geri gelmemelidir.

### $U_+$ için işlev cümlesi — açık

$U_0$'ın bir işlev cümlesi vardır: *üç fazı eş zamanlı — aynı kuruluşta birlikte — doğurur.* $U_+$'ın karşılığı henüz yazılmamıştır. Aşağıdaki genelleşmiş biçim adaydır, **kanon değildir**:

$$U_\ast \;\rightsquigarrow\; \{c_0,\; C_m,\; c^+\}_{\text{eş zamanlı — aynı kuruluşta birlikte}}, \qquad \ast \in \{0,\, +\}$$

## 2.7 $U_x$ — Dinamik Evren

$$\boxed{\;U_x = \text{üç fazın birlikte gerçekleştiği dinamik evrensel yapı}\;}$$

$U_x$ yalnız bir grafik çerçevesi değildir; global seviyenin ortadaki nesnesidir.

### Notasyon hijyeni — üç benzer sembol

| Sembol | Ne |
|---|---|
| $U_x$ | Dinamik evren — global seviye nesnesi |
| $U(x)$ | Tarihsel/işlevsel kullanım — **yalnız bağlam açıkça $U_x$'i gösteriyorsa** eşlenir |
| $X(x)$ | **Dinamik üst çözücü** — tamamen farklı bir nesne (Bölüm 4) |

$$\boxed{\;U_x \;\neq\; X(x) \qquad U_x \;\neq\; U_0 \qquad U_x \;\neq\; c_0,\, C_m,\, c^+\;}$$

**Koşulsuz kimlik kurulmaz:** $U(x) \equiv U_x$ yazımı otomatik değildir. Güncel kanonik gösterim $U_x$'tir; $U(x)$ ancak bağlam açıkça dinamik evreni gösteriyorsa onunla eşlenir.

$U_x$'in ontolojik tipi — "küme üyeliği" mi, "ontolojik kapsama" mı — **açık bir sorudur**.

### Denklem seti — Global seviye

**Ne işe yarar, neden gerekli?** Faz düzeyi ile global düzeyi ($U_0$, $U_x$, $U_+$) birbirinden ayırır; global düğümleri faz sanmak iki seviyeli mimariyi çökertir.

$$U_0,\ U_x,\ U_+ \notin \{c_0,\ C_m,\ c^+\} \qquad \text{GlobalRel} \neq \text{Gate}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $U_0$ | Mutlak Çekirdek — **sınırındaki** kritik eşik: **Big Bang** |
| $U_x$ | Dinamik Evren — **kutup değil** |
| $U_+$ | Mutlak Çözünme — **sınırındaki** kritik eşik: **Big Yırtılma** |

**Statü:** ✅ faz ≠ global düğüm · $U_x$ yapısal tipi ⏸


## 2.8 Global devre ve iki doğuş olayı

**Birlikte doğuş.** $U_0 \to U_x$ doğuşunda c₀, Cₘ ve c⁺ **aynı kuruluşta birlikte** oluşur. Fazların dışında işleyen ortak bir saat olmadığından bu, bir saatin "aynı anı" değil, aynı kuruluşta birlikte bulunmadır. c⁺'ın c-ötesi niteliği sonradan kazanılmış bir özellik değil, fazın kuruluş özelliğidir. Üç faz, doğuştan itibaren Çekim Kuvveti'nin kısıt koheransı altında bir arada durur (1.2).

$$\boxed{\;U_0 \;\leftrightarrow\; U_x \;\leftrightarrow\; U_+\;}$$

Uç faz rejim limiti aşıldığında:

$$\begin{cases} U_x\text{, } U_0 \text{ sınırındaki kritik eşiği aşar} & \Rightarrow\; \textbf{Big Bang} \\[4pt] U_x\text{, } U_+ \text{ sınırındaki kritik eşiği aşar} & \Rightarrow\; \textbf{Big Yırtılma} \end{cases} \qquad\Longrightarrow\qquad \text{yeni bir } U_x \text{ oluşur}$$

### Beş hüküm

| # | Hüküm |
|---|---|
| **G-1** | Dinamik evren mutlak çöküşle ya da mutlak çözünmeyle **son bulabilir — bulmayabilir de** |
| **G-2** | Çöküş ucu → $U_0$ sınırındaki kritik eşik → **Big Bang** |
| **G-3** | Seyrelme ucu → $U_+$ sınırındaki kritik eşik → **Big Yırtılma** |
| **G-4** | **Her iki durumda da** yeni bir $U_x$ oluşur |
| **G-5** | $U_0 \leftrightarrow U_+$ doğrudan ilişkisi olabilir, ama **temsili yoktur** |

### 🔴 Sessizlik ilkesi

$$\boxed{\;\textbf{Temsili olmayan yerde Evertophy hüküm vermez.}\;}$$

$U_0$ ile $U_+$ arasında doğrudan bir geçiş bulunabilir; ama bilinen anlamda bir temsili yoktur ve ötesi metafiziğe aittir. Evertophy bilim, gözlem ve deney çizgisinde kalır; burada **sessiz kalmayı tercih eder**.

Bu, c⁺'ın kapalı devre olmasıyla aynı ilkedir (Bölüm 11): *önce akademik sınır, sonra gözlemsizlik.* Fark yalnız katmandır — orada faz seviyesinde, burada en dış katmanda.

### Dört yön ve anlamları

$$U_0 \Rightarrow U_x, \qquad U_x \Rightarrow U_0, \qquad U_x \Rightarrow U_+, \qquad U_+ \Rightarrow U_x$$

| Yön | Anlam |
|---|---|
| $U_0 \Rightarrow U_x$ | **Doğuş** — üç fazın aynı kuruluşta birlikte oluşumu |
| $U_x \Rightarrow U_0$ | **Limit** — çöküş ucunun global kutba teması |
| $U_x \Rightarrow U_+$ | **Limit** — çözünme ucunun global kutba teması |
| $U_+ \Rightarrow U_x$ | **Yeniden oluşum sonucu** — kanonik; üretim mekanizması açık |

### 🔴 Sonuç ile mekanizma ayrımı

G-4 iki ayrı önerme gibi okunabilir; ama bunlar **aynı iddia değildir**:

$$\boxed{\;U_+ \Rightarrow U_x' \qquad \textbf{KANONİK: global yeniden-oluşum SONUCU}\;}$$

$$\boxed{\;U_+ \rightsquigarrow \{c_0, C_m, c^+\}_{\text{eş zamanlı — aynı kuruluşta birlikte}} \qquad \textbf{AÇIK: genesis MEKANİZMASI}\;}$$

$$\boxed{\;\text{Yeni bir } U_x \text{'in oluşması KANONDUR; bunun } U_0\text{-genesis ile AYNI ontolojik üretim işlemi üzerinden gerçekleştiği KANON DEĞİLDİR.}\;}$$

İkinci önerme $U_+$'ın $U_0$ ile **aynı doğuş operatörüne** sahip olduğunu söyler ve daha güçlüdür; $U_+$'ın kendi işlev cümlesi yazılana kadar (2.6) açık kalır.

### Dört zorunlu koruma

**(i) Oklar bütüne bağlanır, faza değil.**

$$U_0 \leftrightarrow U_x \;(\text{bütünle ilişki}) \qquad \text{değil} \qquad U_0 \leftrightarrow c_0 \;(\text{kapı})$$

Böylece *"$U_0$ hiçbir kapının ucu değildir"* kuralı korunur.

**(ii) Global çift yönlülük matematiksel tersinirlik değildir.** $\leftrightarrow$ sembolü burada bir ilişkinin iki ucunu gösterir; ters bir operatörün varlığını **iddia etmez**.

**(iii) Devre bir konveyör bandı değildir.** Soldan sağa okuma bir süreç izlenimi verir; oysa zaman $U_x$'in **içindedir**. Global devre bir akış değil, **limit koşulları** ilişkisidir.

$$\boxed{\;\text{Devre indeksi} \;\neq\; t\;}$$

$U_x$'ler arasında saat yoktur. Sıra, arşivdeki kayıt sırası gibi **mantıksal/kaynak sırasıdır**.

**(iv) Devre zorunlu periyodik çevrim değildir.** G-1 gereği evren son bulmak **zorunda değildir**. "Devre" sözcüğü bir kapalılık imkânını anlatır, bir döngü yasasını değil. Bu ilişkiler faz üçgeninin topolojik hesabına da **karışmaz** (Bölüm 19).

### Simetri — ölçülü ifade

Çöküş kolu ile çözünme kolu **global limit-kutbu düzeyinde yapısal simetri** taşır. Ama aşağıdaki eşleme **kurulmaz**:

$$U_0 : c_0 \;::\; U_+ : c^+ \qquad \text{(ontolojik izomorfizm YOKTUR)}$$

Çünkü $U_0$ yalnız $c_0$'ı değil, **üç fazı birden** doğurur. Aynı nedenle $U_+$, $c^+$'ın global eşleniği ya da dış kabuğu olarak tanımlanamaz.

### "Big Bang" kelimesinin iki anlamı

| Anlam | İçerik |
|---|---|
| **İlksel doğuş** | Gözlediğimiz evrenin başlangıcı |
| **Devre koşulu** | Herhangi bir $U_x$'in çöküş ucunda eşiğin aşılmasıyla tetiklenen doğuş |

İlksel doğuşun bir önceki $U_x$'ten gelip gelmediği sorusu **sessizlik ilkesi** kapsamındadır.

### 🔴 "Big Yırtılma" eşsesli bir terimdir

Standart kozmolojide *Big Rip*, karanlık enerjinin evreni **sonlandırdığı** terminal olaydır. Evertophy'de **Big Yırtılma bir son ve aynı zamanda yeni bir doğuştur** (G-4). Ortak sözcük, anlam birleştirme yetkisi vermez.

## 2.9 Global seviyede geçerli olmayanlar

Faz seviyesi için konan kısıtlar global seviyede de geçerlidir; birkaçı özellikle belirtilmelidir:

- **Metrik global seviyede tanımlı değildir.** $g_{\mu\nu}$ yalnız Cₘ'ye aittir (Bölüm 9); $U_0$, $U_x$, $U_+$ için bir metrik ya da tetrad yazılmaz.
- **$X$'in alan izdüşümleri global nesnelere uygulanmaz.** $X$ faz rejimini çözer; global kutuplar onun tanım alanı değildir.
- **Hız ve zaman dili kullanılmaz.** Global ilişkiler için oran, hız ya da süre yazılmaz.
- **Global okların matematiksel tipi açıktır.** Bunların faz kapısı **olmadığı** bilinir; tam tipleri (global-durum / doğuş haritası türünden ayrı operatörler) tanımlanmamıştır.

### Doğuş ≠ devre

$$\mathrm{Genesis} = U_0 \rightsquigarrow \{c_0,\, C_m,\, c^+\}_{\text{eş zamanlı — aynı kuruluşta birlikte}} \qquad\qquad \mathrm{CycleSeed} = \{\mathcal{L}_{\rm çöküş},\; \mathcal{L}_{\rm seyrelme}\}$$

$$\boxed{\;\text{Eş zamanlı doğuş} \;\neq\; \text{çift-limit devre mekanizması}\;}$$

İkisi arasındaki tam bağ — $\mathrm{CycleSeed} \dashrightarrow \mathrm{Genesis}$ — **açık problemdir**.

---


## 2.10 Evren başlangıç kütlesi ve türetim zinciri kaydı


Arşivde evrensel ölçek tahminleri zinciri hâlinde korunur. Bu kayıt sayıları ontolojik nicelik olarak değil, **tarihsel hesap ve ölçek analojisi** olarak sınıflandırır.

### Zincirin halkaları

1. **CMB kilitli ölçek:** t_CMB ≈ 3.8×10⁵ yıl (rekombinasyon) → D_çekirdek ≈ 3.8×10⁵ ışık yılı. CMB'yi gördüğümüz an, c_m'nin ilk gözlemsel faz geçişi olarak okunur.
2. **Planck-yoğunluk projeksiyonu:** M ~ ρ_Planck · V_çekirdek ~ 10¹⁶¹ kg mertebesi.
3. **Baryon/toplam düzeltmesi:** 10⁵³ kg yalnızca baryonik kütle (~%5); Planck 2018 Ω_b ≈ %5, Ω_DM ≈ %27, Ω_DE ≈ %68 ile M_cm ~ 2×10⁵⁴ kg.
4. **Dirac büyük sayıları:** D_evren/D_çekirdek ~ 10⁴¹ — bu oran varsayımsal model çapına dayanır (ör. $10^{47}$ ışık yılı); gözlenebilir evren çapı ($\approx 9{,}3\times10^{10}$ ışık yılı) kullanılırsa oran $\approx 2{,}45\times10^{5}$'tir ve ikisi aynı girdi değildir; klasik Dirac oranları (F_e/F_g ~ 10³⁹⁻⁴⁰, R_evren/r_proton ~ 10⁴⁰) ile aynı mertebe.

### Kritik statü hükümleri

$$\boxed{\;10^{161}\ \mathrm{kg}\ \text{fiziksel kütle DEĞİLDİR — "tam-dolu Planck evreni anında çöküşe gider"; doğru kullanım üst-sınır/kapasite metaforudur.}\;}$$

$$\boxed{\;\text{U₀ için sayısal kütle okuması güncel ontolojiye (Bölüm 2) taşınmaz; } U_0 \text{ faz ve kapı uç-noktası değildir.}\;}$$

$$\boxed{\;10^{161}\ \leftrightarrow\ 10^{120}\ \text{(kozmolojik sabit) eşlemesi desteksizdir — "unsupported mapping" olarak geri çekilmiştir.}\;}$$

İki bağımsız yolun ~10⁴⁷ ışık yılına yakınsaması iç tutarlılık işareti olarak kaydedilmiştir; ancak varsayım ağacı ayrıştırılmadan sayı kanonikleştirilmez. U₀ başlangıç kütlesi Range Formalizmi ile yazılmış hâli (U₀ ∈ [ρ_P^min·V_CMB^min, ρ_P^max·V_CMB^max]) bantlar netleşmeden kilitlenmemiştir — "anlatı şişirmesi" riskine karşı guard kayıtlıdır.

---

# BÖLÜM 3 — ÜÇ FAZLI ONTOLOJİK MİMARİ

## 3.1 Neden üç faz?

Üçlü mimari, üç ayrı sınır yöneliminden **motive edilir**; bu, üçlüğün tek mümkün ontoloji olduğunu kanıtlamaz. Faz sayısının ilkel mi türetilmiş mi olduğu açık borçtur (EK K.1). Aşağı doğru: farklılaşmanın çözüldüğü **c₀**. Yukarı doğru: Cₘ madde desteğinin çözüldüğü **c⁺**. Arada: ölçümün mümkün olduğu **Cₘ**.

Mevcut çerçeve dördüncü bir **bağımsız sınır** tanımlamaz; bu, dördüncü bir fazın imkânsız olduğunu değil, önerilmediğini gösterir.

**İki uç yönelim, iki global kutup.** Üç-faz mimarisindeki bu iki uç yönelim, global seviyede sırasıyla **doygunluk** ve **çözünme** kutuplarıyla **ilişkilidir** (Bölüm 2.8). Çift-limit yapısı sonradan eklenmiş bir kozmoloji varsayımı değil, **üç-faz mimarisinin içinde zaten bulunan iki yönelimin global okumasıdır**.

$$\boxed{\;\text{Bu ilişki } c_0 \leftrightarrow U_0 \text{ ya da } c^+ \leftrightarrow U_+ \text{ biçiminde BİRE-BİR ONTOLOJİK EŞLEME DEĞİLDİR.}\;}$$

## 3.2 c₀ — Zaman-öncesi potansiyel / çekirdek fazı

### Güncel çekirdek tanım

```
c₀ = zaman-öncesi potansiyel / çekirdek faz
içsel fiziksel zaman yok
g_μν kabul edilebilir değil
Cₘ farklılaşmış maddesi → toplu tek-yapı limiti
```

### c₀'da zaman

$$\text{c}_0\text{'da içsel fiziksel zaman YOKTUR.}$$

Kritik ayrım:

| Durum | Anlamı |
|---|---|
| Zaman **durmuş** | Bir saat var ama ilerlemiyor |
| Zaman **yok** | Saat kavramının kendisi kurulamaz |

c₀'daki durum ikincidir: zaman henüz **üretilmemiştir**. Buna **zaman-öncesi** denir.

### c₀'da madde

$$\boxed{\;C_m \to c_0: \quad \text{farklılaşmış madde} \;\longrightarrow\; \text{TOPLU TEK-YAPI LİMİTİ}\;}$$

Ayrık nesneler arasındaki ayrım çözülür. "Bu parçacık" ile "şu parçacık" ayrımı operasyonel içeriğini kaybeder ve rejim **toplu** bir karakter kazanır.

### c₀'da metrik

$g_{\mu\nu}$ c₀'da **kabul edilebilir bir nesne değildir**.

### Toplu davranış analojileri

Bose-Einstein yoğuşması ve süperakışkanlık, **toplu/koherent davranışın** laboratuvarda erişilebilir örnekleridir ve c₀'ın **tek-yapı sezgisi** için kullanılabilir.

$$\boxed{\;\text{Bunlar ANALOJİDİR — literal kimlik DEĞİLDİR.}\;}$$

### c₀ ve kara delikler

Kara deliğin merkezi bir tekillik değil, sonlu ve homojen bir yapı olabilir. **Evertophy ontolojisinde kara delik ile c₀ fazı ontolojik olarak özdeştir** (Uğur Yılmaz'ın doğrudan onayladığı temel tanım). Bu kimliğin Cₘ'deki gözlenebilirlerle nicel bağlantısı, oluşum mekanizması ve olay ufku–faz sınırı ilişkisi ayrıca türetilmelidir; "olay ufku = faz sınırı" birebir özdeşliği kurulmuş değildir. Ontolojik özdeşlik, c₀ içinde Cₘ-tipi zaman, üç boyutlu Öklid uzay ya da metrik tanımlamaz.

### Tarihsel aşırı-somut tanımlar

Şunlar **tarihsel/model** düzeyindedir, güncel çekirdek değildir: tam Planck doygunluk durumu · durağanlık kilidi · sıfır-diferansiyel motor · belirli bir Planck yoğunluğu.

“Sonsuz yoğunluk değil, sıfır diferansiyel” ve `dt=0, dx=0` yazımları güncel ontolojik tanım değildir. Bununla birlikte bunlar bütünüyle silinmiş de sayılmaz: c₀'da sıradan Cₘ zaman/uzay serbestliklerinin kabul edilebilir olmadığını anlatan **tarihsel-pedagojik kısaltmalar** olarak anılabilir. Güvenli çekirdek ifade şudur:

$$\boxed{\;c_0\text{'da Cₘ-tipi }dt\text{ ve }dx\text{ ontolojik primitive değildir; “}dt=0,dx=0\text{” yalnız pedagojik sınır dilidir.}\;}$$

Bu kısaltma, c₀ içinde önceden kurulmuş bir saatin durduğu veya Cₘ metriğinin sıfıra eşitlendiği anlamına gelmez.

### c₀'da zamansal konum

c₀ **zamansal bir öncelik değil, rejimsel bir konumdur**. Güncel $U_x$ içinde de yüksek-yoğunluk rejimlerinde c₀ üyeliği mümkün olabilir; hangi fiziksel sistemin c₀ üyeliği taşıdığı nicel köprüye bağlıdır ve açık borçtur.

## 3.3 Cₘ — Farklılaşmış madde / ölçüm / emergent zaman

### Güncel çekirdek tanım

```
Cₘ = farklılaşmış madde fazı
doğrudan fiziksel ölçüm burada
emergent fiziksel zamanın TEK evi
g_μν'nün TEK alanı
```

Standart fiziksel hızlar, oranlar ve metrik okumalar **yalnız burada** anlamlıdır.

### Cₘ ve ışık bariyeri

$$\boxed{\;c \text{ bir HIZ LİMİTİNDEN ÖNCE, Cₘ'nin TUTARLILIK KISITIDIR.}\;}$$

$c$, Cₘ fazının bilgi işleme, kayıt ve çözünürlük limitini koyar. Uzayda hareket eden bir nesnenin hız sınırı olarak değil — fazın kendi iç tutarlılığının sınırı olarak okunur.

### Kinematik üyelik bandı

$$\boxed{\;\text{Cₘ'nin madde-üyelik koşulu korunabilir hız bandı } 0<v<c\text{'dir; } v=c \text{ liminal faz sınırıdır.}\;}$$

Bu, yazarın çekirdek hükmüdür. Buradaki $v$ yerel laboratuvar koordinat hızı değildir: bandın ontolojik statüsü kesindir; $v$'nin kesin matematiksel okuması ve ölçümle bağlantısı açıktır.

$$\underbrace{0<v<c}_{\text{çekirdek üyelik hükmü}} \;+\; \underbrace{\mathcal R_v:\ \text{durum} \to v_{\rm üyelik}}_{\text{açık okuma}}, \qquad v_{\rm lab}=0 \;\not\Rightarrow\; c_0$$

**Işık liminaldir:** foton $v=c$ sınırında bulunur. **Bandın aşılması bir hızlanma değildir.** Evertophy, Cₘ'deki deneysel olarak doğrulanmış relativistik sonuçları açıklanması gereken fiziksel kısıtlar olarak kabul eder; bunların emergent yapıdan türetimi ayrıca kurulmalıdır. Kütleli bir cisim Cₘ içinde hızlanarak $c$'ye ulaşamaz. c⁺'a geçiş, $v=c$ eşiğinde gerçekleşen bir **faz geçişidir**: aşılan şey bir hız değeri değil, Cₘ'nin üyelik bandıdır; geçişten sonra Cₘ'nin hız dili tanımsızdır.


> Bu band bir laboratuvar-koordinat hızı **değildir**. Üyelik, evrensel/kozmolojik referansta — nesnenin uzaysal konumu, genel hareketi ve iç dinamiklerinin **birlikte** okunmasıyla belirlenir.

$$v_{\rm lab}=0 \;\not\Rightarrow\; c_0, \qquad 0<v<c \;\neq\; \text{laboratuvar-koordinat hızı}$$

> Buna göre Bölüm 3.7'nin kuralı ("harita konumu ≠ faz üyeliği") kinematik üyelik için de geçerlidir: bir nesnenin ölçülen yerel hızı, tek başına faz üyeliğini belirlemez. Foton ($v=c$) bant üyesi değil, sınırın liminal durumudur — Bölüm 7.6 ile tutarlı — bu liminal durum c⁺ üyeliği veya c⁺ sınır-nesnesi olmak anlamına gelmez (bkz. 7.6).

"Evrensel referans" ifadesi klasik bir preferred-frame koordinat hızı değildir; üyelik okuması X-çözümü düzeyindedir (Bölüm 4). Bandın matematiksel referans nesnesi, okuma haritası (15.2) ve X'in gerçekleştirmesi (24.3) kapanana dek bilinçli olarak açıktır.

Cₘ içindeki yapıların yalnız kinematik bantla değil, phase-parameter landscape'in **iç bölgesindeki** çoklu constraint çözümüyle sınıflandığı unutulmamalıdır (Bölüm 12.3).

Bu okuma, yerel laboratuvar hızının ontolojik üyelik değişkeniyle özdeşleştirilmemesine dayanır: laboratuvarda $v_{\rm lab}=0$ ölçülmesi tek başına c₀ üyeliği değildir. Cₘ'nin $0<v<c$ ontolojik üyelik hükmü korunur; operasyonel eşleme $\mathcal R_v$ açıktır.

### Cₘ ve ölçüm

$$\boxed{\;c_0 \text{ ve } c^+ \text{ hakkında söylenen her şey, Cₘ'den yapılan bir OKUMADIR.}\;}$$

### Cₘ epistemik merkezdir — topolojik zorunlu aracı değildir

Bu ayrım kritiktir. Cₘ'nin merkezî olması **ölçüm ve kayıt** açısındandır. Faz topolojisinde Cₘ'den geçmek zorunlu değildir (Bölüm 3.5).

### Model katmanı notu

Aşağıdaki ek kayıtlar tarihsel geliştirme katmanından devralınmış **model ve aday köprülerdir**. Hesaplanabilirlik ve sınanabilirlik hedefi taşırlar; hiçbiri Postüla-0'ı, üç-faz ontolojisini, $X$'in çekirdek tanımını veya damga cebirini yeniden tanımlamaz. Model ile ontoloji ayrımı Bölüm 1.5 ve EK E'deki epistemik düzenle aynen korunur.

### Ölçek-rejim çalışma sınıfları — aday model

$$\boxed{\;\text{Kuantum, termal, astrofizik ve kozmolojik sınıflar Cₘ içindeki ÖLÇEK-REJİM sınıflarıdır; ontolojik faz değildir.}\;}$$

Cₘ içindeki çalışma sınıfları dört kaba rejimde gruplanabilir:

| Ölçek-rejim sınıfı | Tipik çalışma alanı |
|---|---|
| **Kuantum** | atom-altı sistemler |
| **Termal** | laboratuvar ve çok-cisimli termal sistemler |
| **Astrofizik** | yıldız, kompakt nesne ve galaksi ölçekleri |
| **Kozmolojik** | evren ölçeği |

Bu sınıflar $c_0$, $C_m$, $c^+$ ontolojik fazları **değildir**. Faz-parametre matrisinde satırların veya gözlenebilir ailelerin ölçek-temelli gruplandırılması için kullanılabilir; ayrı bir ontoloji katmanı oluşturmaz.

## 3.4 c⁺ — Zaman-dışı üst / arşiv / koordinasyon fazı

### Güncel çekirdek tanım

```text
c⁺ = zaman-dışı üst/arşiv/koordinasyon fazı
içsel Cₘ fiziksel zamanı YOK
içsel Cₘ hızı YOK
g_μν YOK
Cₘ madde desteği ÇÖZÜLÜR
gelecek kâhini DEĞİL
QFT vakumu DEĞİL
```

### c⁺'ın ayırt edici özelliği

$$\boxed{\;\mathrm{supp}_{C_m}(\text{madde}) \to \varnothing,\qquad
g_{\mu\nu}^{(C_m)}\to\bot_+\;}$$

**Cₘ madde desteğinin çözülmesi**, c⁺'ın ana ontolojik ayrımıdır.

### 🔴 c⁺'a Cₘ kavramları aynen taşınmaz

| Kullanılmaz / düzeltilir | Güncel güvenli ifade |
|---|---|
| ~~c⁺'ta Cₘ maddesel kütle/rest-mass taşıyan madde aynen kalır~~ | Cₘ madde desteği çözülür |
| ~~uzunluk seyrelmiş~~ | Cₘ metrik uzunluğu c⁺'ta kabul edilemez |
| ~~süre seyrelmiş~~ | Cₘ fiziksel süresi c⁺'ta kabul edilemez |
| ~~$v>c$, ışık-üstü madde~~ | İçsel Cₘ-hız dili tanımsızdır |
| ~~dış kabuk ışıktan hızlı hareket eder~~ | Hareket kavramı Cₘ readout'una aittir |

Bu koruma, **Cₘ madde ontolojisinin c⁺'a doğrudan taşınmasını** engeller.

#### Tarihsel K2 nüansı

Eski formal çekirdeğin bir sürümünde c⁺ için soyut `Dim.mass` taşıyıcısı izinli (`actM cp = true`) kodlanmıştır. Bu kayıt formal provenance olarak korunur; fakat aynı eski spesifikasyonun bugün supersede edilmiş başka varsayımlar da taşıması nedeniyle bu satır tek başına **current physical canon** sayılmaz.

Dolayısıyla güncel ayrım:

$$\boxed{
\text{Cₘ maddesel/rest-mass desteği c⁺'ta korunmaz}
}
$$

fakat:

$$\boxed{
\text{tarihsel K2'nin soyut mass-dimension kaydı}
\neq
\text{güncel c⁺-native mass observable}
}
$$

şeklindedir. Dark-sector'ın Cₘ'de kütleçekimsel readout üretmesi, c⁺ içinde Cₘ-tipi kütle taşıyıcısı bulunduğunu kanıtlamaz. Postüla-0 ile maddeden daha temel konumda olan Çekim Kuvveti'dir; kütleçekim onun Cₘ'deki metrik/fiziksel izdüşümlerinden biridir.

### c₀ ve c⁺ madde ontolojisi AYNI DEĞİLDİR

$$\boxed{\;C_m\to c_0:\text{ toplu tek-yapı limiti}\qquad
C_m\to c^+:\text{ Cₘ madde desteğinin çözülmesi}\;}$$

Birincisinde farklılaşmış madde **kolektif tek-yapı limitine** gider; ikincisinde Cₘ madde desteği **çözülür**.

### c⁺ ve arşiv

c⁺'ın karakteristik özelliği **arşiv/koordinasyon** niteliğidir. Cₘ'de üretilen kayıtlar orada mühürlenir ve **zamansal sıralama gerektirmeksizin birlikte bulunur**.

"Tüm geçmiş aynı anda mevcut" ifadesi kullanılmaz; "aynı anda" fiziksel zaman kavramıdır.

$$\boxed{\;\text{Cₘ-kökenli mühürlü kayıtlar, zamansal sıralama gerektirmeksizin birlikte bulunur.}\;}$$

Birlikte bulunmak, Cₘ'den erişilebilir olmak demek değildir; Cₘ'den erişim açık okuma yasasına bağlıdır (15.2).

### c⁺ ve ışık hızı

c⁺'ın ışık hızıyla ilişkisi üç cümleyle kilitlenir:

$$\boxed{\;c^+,\ \text{Cₘ'nin } c\text{-sınırlı uzay-zaman rejiminin ötesindeki } c\text{-ötesi ontolojik fazdır.}\;}$$

$$\boxed{\;c^+\text{'ın } c\text{-ötesi olması} \;\not\equiv\; \text{Cₘ-tipi } v_{c^+}=\frac{dx}{dt}>c\;}$$

$$\boxed{\;c\text{-ötesi ontolojik rejim} \;\neq\; \text{Cₘ içinde ölçülen sıradan ışık-üstü madde hareketi}\;}$$

İkinci ve üçüncü cümlenin nedeni şudur: c⁺'ta Cₘ'ye özgü fiziksel zaman, üç boyutlu Öklid uzay, metrik ve farklılaşmış madde desteği çözünmüştür; dolayısıyla orada $dx/dt$ biçiminde bir Cₘ hızı tanımlı değildir. Bu, yazarın hükmüdür: **c⁺, $0<v<c$ bandının dışında, ışık hızı eşiğinin aşılmasıyla madde yapısının korunamadığı üst fazdır; aynı zamanda Cₘ'de oluşmuş zamansal kayıt ve sıra bilgisinin mühürlendiği zamansız fazdır; fiziksel zamanın kendisi c⁺'ta yoktur.** c⁺, $U_0$ doğuşunda c₀ ve Cₘ ile aynı kuruluşta birlikte oluşur (2.8). Açık kalan yalnız c-ötesiliğin nihai matematiksel temsilidir. Belgenin diğer bölümlerinde c⁺ ve hız üzerine geçen ifadeler bu formülasyona göre okunur.

### c⁺ ≠ vakum, c⁺ ≠ gelecek

$$\boxed{\;c^+\neq\text{QFT vakumu}\qquad c^+\neq\text{gelecek}\;}$$

Vakum Cₘ içinde tanımlı bir alan durumudur. c⁺ bir kehanet kaynağı veya kontrol edilebilir süperluminal iletişim kanalı değildir.

### Tarihsel dil

Şunlar **tarihsel/analojiktir**, güncel çekirdek değildir: "evren kozası" · "graf durumu" · "dış kabuk" · "iç uzaya sızan doku".

## 3.5 Faz topolojisi — tam çift yönlü üçgen

$$\boxed{\;c_0 \leftrightarrow C_m, \qquad C_m \leftrightarrow c^+, \qquad c_0 \leftrightarrow c^+\;}$$

**Tam çift yönlü üçgen, güncel topolojidir.**

Eski zincir modeli ($c_0 \rightleftarrows C_m \rightleftarrows c^+$, "atlama yok" anlamında) **güncel topoloji değildir**. Zincir, tarihsel bir gösterimdir.

$$\boxed{\;\text{Cₘ EPİSTEMİK/ÖLÇÜM merkezidir — TOPOLOJİK olarak zorunlu aracı DEĞİLDİR.}\;}$$

### Kapı ve damga

$$\boxed{\;\text{KAPI ÜÇ KENARDA DA ÇİFT YÖNLÜDÜR. Tersinmezlik faz kapısında değil, MÜHÜRLEME EYLEMİNDE yaşanır.}\;}$$

Aday yorumda zaman oku, geçiş yönünden değil, **kayıt ve mühür birikimiyle** ilişkilendirilir; bu ilişki henüz fiziksel bir türetim değildir (7.8, 16.7).

## 3.6 Faz karışımı — zorunlu bir model değildir

Bir bölgenin birden fazla fazdan pay taşıdığı karışım modelleri ($\sum_i \sigma_i = 1$ biçiminde) arşivde bulunur.

$$\boxed{\;\text{Karışım-simpleks modeli, güncel ontolojinin ZORUNLU parçası DEĞİLDİR. Tam üçgen ontolojisi bundan bağımsızdır.}\;}$$

Bu modeller bir **temsil aracı** olarak kullanılabilir; ontolojik bir gereklilik olarak dayatılamaz.

## 3.7 🔴 Harita konumu ≠ Faz üyeliği

$$\boxed{\;\text{HARİTA KONUMU} \;\neq\; \text{FAZ ÜYELİĞİ}\;}$$

**Örnek.** Atom-altı hızlı parçacıklar **Cₘ yasalarına** tabidir. Faz haritasında c⁺ komşuluğunda görünmeleri onları c⁺ üyesi yapmaz. Harita konumu, bir nesnenin hangi rejime **yaklaştığını** gösterir.

## 3.8 $U_x$ — üçlü faz sisteminin bütünsel gösterimi

> **Tarihsel provenance kaydı.** Aşağıdaki denklem yalnız arşiv kaydıdır; **içindeki zincir gösterimi güncel faz topolojisini temsil etmez.** Güncel topoloji tam çift yönlü üçgendir (Bölüm 3.5), ve $U_x$'in güncel tanımı Bölüm 2.7'dedir.

Arşivdeki kanonik kapanış kaydında şu ilişki korunmuştur:

$$\boxed{\;U_0\;\leftrightarrow\;[c_0,\ C_m,\ c^+]_{K_3}\;\equiv\;U_x\;}$$

Üç faz tam çift yönlü üçgen olarak bağlıdır; arşivdeki lineer yazım tarihsel bir kısaltmadır.

Bu sürümde güvenle sabitlenen asgari anlam şudur:

$$\boxed{\;U_x = \text{üç fazın birlikte gerçekleştiği bütünsel Dinamik Evren}\;}$$

**Bu ifade küme-teorik bir ontolojik tip ataması değildir.** $U_x$'in tipi — kapsama mı, üyelik mi — açık bir sorudur; tek tanım otoritesi **Bölüm 2.7**'dir.

$U_x$, üçlü faz sisteminin **bütünsel gösterimidir**; faz üçgeninde dördüncü bir faz ya da yeni bir düğüm değildir; global ontoloji katmanında bir **global düğümdür**. $X(x)$'in başka adı da değildir. Özellikle:

$$U_x\neq U_0,\qquad U_x\neq X(x),\qquad X\notin\{c_0,C_m,c^+\}.$$

Buradaki kayıt, $U_0$ ile $U_x$ arasındaki ilişkinin tam ontolojik semantiğini tek başına kapatmaz. `\leftrightarrow` ile `\equiv` aynı ilişki değildir. Bu nedenle “$U_0$ yalnız doğuran ön-katmandır, $U_x$ yalnız doğmuş sistemdir” yorumu makul olsa da bu sürümde ek bir kanon tanımı yapılmaz; ilişkinin tam semantiği **açık borçtur**.

Görsel üçgen çiziminde c₀'ın tepeye yerleştirilmesi ile Cₘ'nin “epistemik/ölçüm merkezi” olarak anılması farklı gösterim katmanlarıdır. İlki çizim düzeni, ikincisi ölçüm konumudur; hiçbiri yeni bir topolojik merkez tanımlamaz.

---


## 3.9 Tarihsel alternatif faz anlatıları kaydı


Çerçevenin erken katmanlarında faz zinciri için farklı sıralamalar ve eşlemeler denenmiştir. Bunlar güncel ontolojiyle çelişir ve koruma cümleleriyle kayıtlıdır:

| Tarihsel yazım | Güncel karşılık |
|---|---|
| Zincir sıralaması varyantları (c₀⇄Cₘ⇄c⁺ dışı dizilimler) | Güncel faz topolojisi tam çift yönlü K3'tür: c₀↔Cₘ, Cₘ↔c⁺ ve c₀↔c⁺. Cₘ ölçüm ve epistemik merkezdir; topolojik zorunlu aracı değildir. Lineer yazım tarihsel ya da pedagojik kısaltmadır |
| "c₀ merkez / çatı" dili | Geri çekildi: c₀ yerel ve tekrarlı bir fazdır; merkez metaforu topolojik bir vurgu değildir |
| "Kara delik = c⁺" okuması | Reddedildi. Güncel: kara delik ≡ c₀ — yazarın ontolojik tanımı; nicel ve gözlemsel köprü ayrıca türetilmelidir (3.2) |
| "U₀ = c₀ fazının evren-çekirdeği ölçeğindeki eşiği" | Güncel: U₀ ön-katman; eşik uç fazın global kutupla temas sınırındedir — kaynak değildir |
| Big Bang = c₀→Cₘ sıradan geçişi | Güncel: Big Bang = global $U_x$'in $U_0$ sınırındaki kritik eşiği aşmasıyla üç fazın aynı kuruluşta birlikte türetimi |

## 3.10 Faz kompozisyon kesirleri — statü kaydı


Faz kompozisyonu için Σσ_i = 1 normalizasyonlu kesir gösterimi arşivde iki ayrı katmanda geçer:

| Katman | Gösterim | Statü |
|---|---|---|
| Karışım-simpleks modeli | Bölge payları σ_i, Σσ_i = 1 | Model/temsil aracı — ontolojik zorunluluk değil (Bölüm 3.6) |
| Master regülatör gerçekleşmesi | Φ(x) ↦ (σ₀, σ_m, σ₊), faz koordinatı ailesi | Formal aday — tipi kapanmamış |

$$\boxed{\;\text{Kesir gösterimi "aynı anda üç fazın üyesi" anlamına gelmez; faz üyeliği ile fazlar arası kısıt ilişkisi ayrıdır.}\;}$$

Master domain vektörü x_E ≡ (z, a, ρ, A, 𝒮; τ) için **t ∉ x_E** kilidi arşivde açıkça kayıtlıdır: zaman domain girdisi değil, çözümün Cₘ-okumasıdır.

## 3.11 c⁺ nedensellik zırhı


c⁺'ın nedensellikle ilişkisi katman katman korunur:

$$\boxed{\;\text{c⁺ nedensellik gevşetir; nedenselliği kaldırmaz.}\;}$$

| Faz | Nedensellik durumu | Ölçüm durumu |
|---|---|---|
| c₀ | Ölçüm öncesi — nedensellik henüz kurulmamış | Ölçüm kavramı admissible değil |
| Cₘ | Nedensellik zorunlu ve seri | Ölçüm zorunlu |
| c⁺ | Nedensellik var ama **zamansız**; korelasyon fazı | Ölçüm sonrası serbestlik — sinyal kanalı değil |

Kilitli cümle (arşiv): *"Nedensellik = c⁺ zamansız korelasyonlarının Cₘ'de ölçümle seri hâle getirilmiş izdüşümüdür."* Dolanıklık bu çerçevede en fazla "faz-korelasyonunun Cₘ izdüşümü" olarak okunur — aday yorum, türetim değil. Bu aday okumada c⁺ kaynaklı karanlık-sektör etkileri Cₘ'de kütleçekimsel ve metrik kanallarla ele alınır; bu, c⁺'a içsel metrik ya da durgun kütle eklemez ve "yalnız çekim üzerinden etkileşme"yi türetilmiş evrensel bir mekanizma olarak sunmaz. Ontolojik c⁺ ≡ karanlık madde ≡ karanlık enerji kimliği korunur; nicel bağlaşım ve gözlemsel okuma haritası açıktır.

---

# BÖLÜM 4 — $X(x)$: DİNAMİK ÜST ÇÖZÜCÜ

## 4.1 Güncel tanım

$$\boxed{\;X(x) \;=\; \textbf{dinamik üst/meta ÇÖZÜCÜ (resolver)}\;}$$

$X$, verili koşullar altında hangi faz rejiminin geçerli olduğunu ve hangi durumların kabul edilebilir olduğunu **çözen** aşamalı meta-çözücüdür. Skaler okumalar üretilebilir; ama $X$ gerçek fizik yasasını, kurucu haritayı ya da fiziksel katsayıyı **tek başına seçmez** — bu, açık fiziksel seçici borcudur (24.1):

$$\text{Bağlam} \to \text{Faz lisansı} \to X_{\rm resolved} \to \xi_k \to \text{Fiziksel seçici} \to J_X/\mathcal E_\phi \to \text{Cₘ durumu ve okuma}$$

### Özellikleri

| Özellik | Anlamı |
|---|---|
| **Tek** | Bir tane $X$ vardır; alt-$X$'lere bölünmez |
| **Faz-duyarlı** | Hangi fazda olduğunu bilir |
| **Aralık-duyarlı** | Çıktısı aralık değerli olabilir |
| **Bağlam-duyarlı** | Koşullara göre farklı çözer |
| **Değişken arite** | Argüman sayısı faza/rejime göre değişebilir |
| **Deterministik** | Tam belirtilmiş aynı durum, aynı çıktıyı verir |
| **Özyinelemeli/bileşimsel olabilir** | Alt ölçekleri içerebilir |
| **Zaman gerektirmez** | İçsel fiziksel zamana ihtiyaç duymaz |

### Determinizm güvencesi

$$\boxed{\;S_1 = S_2 \;\Longrightarrow\; X(S_1) = X(S_2)\;}$$

Tam belirtilmiş aynı durum, aynı çözümü verir. Buradaki "durum", ilgili phase/regime/context bilgisinin tamamını kapsar; provenance/history fiziksel olarak ilgiliyse bu bilgi state tanımına dahil edilebilir. Bu nedenle ilke bir Markov aksiyomu değildir. Bu, $X$'in "dinamik" olmasıyla çelişmez.

## 4.2 $X$ ne DEĞİLDİR

$$\boxed{\;X \;\neq\; \text{Çekim Kuvveti} \quad X \;\neq\; \text{kütleçekim} \quad X \;\neq\; \text{metrik} \quad X \;\neq\; \text{tek skaler} \quad X \;\neq\; \text{lojistik fonksiyon}\;}$$

Ayrıca $X$:

- **faz-parametre matrisinin bir satırı değildir** — matrisin **üst çözücüsüdür**
- **özelliklerin ortalaması ya da toplamı değildir**
- **$[0,1]$ ile sınırlı değildir**
- **yalnız bir izinlilik filtresi değildir** — filtreleme yaptığı işlerden biridir, tanımı değil
- bir **kuvvet ya da enerji taşıyıcısı değildir**

### Tarihsel lojistik çekirdek

Arşivde şu biçim bulunur:

$$X(u) = \frac{1}{1 + e^{-s(u - u_t)}}, \qquad \frac{dX}{du} = s\,X(1-X)$$

$$\boxed{\;Bu, TARİHSEL / FENOMENOLOJİK bir skaler çekirdektir — güncel ontolojik tanım DEĞİLDİR.\;}$$

$X(u) \neq X(x)$. İkisi karıştırılmamalıdır.

### Tarihsel dualite kaydı — karar bekleyen biçimsel aday

Erken master arşivinde şu "madde–doku / zaman–geometri" dualite formu bulunur:

$$\Phi(c^+,C_m,c_0)=\Tau(z^+,z_m,z_0).$$

Kaynak sürümdeki eski $c_m$ notasyonu burada güncel faz adı $C_m$ ile yazılmıştır. Bu denklem **current $X$ tanımı değildir**; $\Phi$ ve $\Tau$'nun güncel Core'da tamamlanmış type'ları yoktur. Özellikle bu $\Phi$ sembolü, Bölüm 17'deki ölçülebilir kanal adayı $\Phi_\chi=\Lambda\ln\chi_S$ ile özdeşleştirilmez.

Arşivdeki dinamik-denge formu:

$$\Phi\,e^{+i\pi}=\Tau\,e^{-i\pi}$$

henüz kurulmuş bir yasa değildir; aday düzeyindedir. $e^{+i\pi}=e^{-i\pi}=-1$ olduğundan cebirsel olarak yalnız $\Phi=\Tau$ eşitliğine indirgenir; tek başına yeni bir dinamik yasa veya karşı-faz hareketi türetmez.

$$\boxed{\;\text{Tarihsel dualite kaydı korunur; current Core postülasına yükseltilmez.}\;}$$

## 4.3 Programlama analojisi

$X$'in davranışını sezdirmek için tek bir analoji kullanılır:

```cpp
X = *Resolve(phase, regime, range, conditions, ...);
```

Yani $X$ bir **değer** değil, bir **çözümleme çağrısının sonucudur**: bağlamı alır, o bağlamda geçerli olanı döndürür.

$$\boxed{\;Bu YALNIZCA bir programlama analojisidir — matematiksel bir tanım değildir.\;}$$

## 4.4 $X$'in belirleyicileri — kapalı bir liste değil

Çalışma listesi yoğunluk, eğrilik ve entropi yoğunluğu gibi nicelikleri içerir. Ancak:

$$\boxed{\;\text{Argüman kümesi KAPALI DEĞİLDİR. } X \text{ sabit bir fonksiyon formuna DARALTILAMAZ.}\;}$$

Hız, ölçek, toplam kütle, yük, yapısal düzenleniş de rol oynayabilir. Dahası, **farklı fazlarda farklı argüman kümeleri** anlamlı olabilir — bu, değişken arite özelliğidir.

### Nihai matematiksel tip bilinçli olarak açıktır

$$\boxed{\;X\text{'in TAM MATEMATİKSEL GERÇEKLEŞTİRMESİ, BİLİNÇLİ OLARAK AÇIK BIRAKILMIŞTIR.}\;}$$

Bu bir eksiklik itirafı değil, bir **tasarım kararıdır**: erken bir form seçimi, çerçeveyi o formun sınırlarına hapsederdi.


## 4.4a Formal resolver arayüzü — tipi erken kilitlemeden

$X$'in kavramsal anlamı artık açık olmakla birlikte nihai mathematical type'ı bilinçli olarak açıktır. Bu iki durum karıştırılmamalıdır.

En type-safe minimal arayüz bir ilişki olarak yazılabilir:

$$\mathrm{Resolve}_X(\phi,\mathcal S,\mathcal I;\mathcal O)$$

Burada $\phi$ faz, $\mathcal S$ tam durum/koşul bağlamı, $\mathcal I$ ilgili özellik-ailesi girdileri ve $\mathcal O$ çözülen çıktıdır. **Aynı tam durum için deterministik çıktı** kuralı:

$$\boxed{
\mathrm{Resolve}_X(s,o_1)\land \mathrm{Resolve}_X(s,o_2)
\;\Longrightarrow\;
o_1=o_2
}$$

şeklinde yazılabilir.

Tam tanımlanmamış state veya Range-valued input için output da Range/relation olabilir. Tam tanımlanmış admissible state'te ise resolver function-like davranır. Bu ayrım:

```text
partial information → relation / Range
fully specified admissible state → deterministic resolution
transition bidirectionality → exact inverse olmak zorunda değil
```

hiyerarşisini korur.

Bir dependent-function realizasyonu gelecekte:

$$X:(\phi:\mathrm{Phase})\to Context(\phi)\to Resolved(\phi)$$

biçimini alabilir; bu **formal adaydır**, current ontology'nin tek zorunlu type'ı değildir.

### Denklem seti — Değişken arite ve sabit-nokta kapanışı

**Ne işe yarar, neden gerekli?** $X$'in argümanları (yoğunluk $\rho$, eğrilik $\mathcal{R}$, entropi $\mathcal{S}$) **metrik gerektirir** — ama metrik yalnız Cₘ'de var. Ayrıca $X$ faz rejimini, faz rejimi metriği, metrik $X$'in argümanlarını belirliyordu: **döngüsel bağımlılık**.

$$X : \bigsqcup_p \mathcal{A}_p \to \text{Aralık} \qquad X^* = \mathcal{F}_X\!\left(\mathcal{A}[X^*]\right)$$

$$x = \sigma(a x + c),\quad h(x) = \mathrm{logit}(x) - a x - c,\quad x_\pm = \tfrac12\!\left(1 \pm \sqrt{1 - 4/a}\right)$$

$$a \leq 4 \Rightarrow \text{tek kök (yeterli)}; \qquad a > 4:\ \text{üç kök} \iff c \in \big(g(x_+),\ g(x_-)\big),\ \ g(x) = \mathrm{logit}(x) - a x$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $\mathcal{A}_p$ | $p$ fazında tanımlı argüman kümesi |
| $\sqcup_p$ | Fazlar üzerinden ayrık birleşim |
| $\mathcal{F}_X$ | $X$'in çözümleyici fonksiyonu |
| $X^*$ | Sabit nokta |
| $a = \beta k$ | Lojistik geri beslemenin kazancı |
| $c = \beta(b - u_0)$ | Önyargı (bias) |
| $h(x)$ | Sabit-nokta denkleminin sıfır fonksiyonu |
| $x_\pm$ | $h$'nin kritik noktaları |

**Statü:** Değişken arite ✅ · aşamalı çözümleyici ★ · lojistik sabit nokta MODEL · lojistik temel $X$ ❌ · "$a\le4 \iff$ tek kök" ❌ · çözümün varlığı ve tekliği, seçilen algoritmanın yakınsamasından ayrı koşullardır: tek sabit noktaya rağmen belirli bir doğrudan iterasyon yerel olarak kararsız olabilir ($f(x)=\sigma(4-8x)$, $x_*=1/2$, $f'(x_*)=-2$); kontraksiyon dalında doğrudan iterasyon başarılı bir alternatiftir; $X$ için genel algoritmik yakınsama türetim bekler


## 4.5 Okuma yüzleri

$X$ tek bir nesnedir; nasıl erişildiğine göre farklı yüzler gösterir.

| Yüz | Ne |
|---|---|
| **Temel durum yüzü** | Faz ve bağlam durumunun çözülen yüzü; fiziksel sabit ya da gözlenebilir değer üretimi ayrıca seçici, köprü ve okuma yasası gerektirir |
| **Alan izdüşümü** | Belirli bir fiziksel alana yansıması |
| **Okuma** | Cₘ'de fiilen ölçülen değer |

### Alan izdüşümleri kapalı bir liste değildir

Belirli alanlara izdüşümler tanımlanabilir (nükleer, kozmolojik, kronometrik gibi). Ama:

$$\boxed{\;\text{Bu izdüşümler AYRI TEMEL } X\text{'ler DEĞİLDİR ve KANONİK KAPALI BİR LİSTE oluşturmazlar.}\;}$$

**Tek $X$ vardır.** İzdüşümler, aynı $X$'in farklı alanlardaki gölgeleridir.

### Okuma katmanının sınırı

$$\boxed{\;\text{Okuma katmanında yapılan bir hesap TEMEL BİR SAYI ÜRETEMEZ.}\;}$$

Bir örnek: iki okuma-katmanı niceliği arasında tanımsal bir özdeşlik kurmak, birini ötekinden "türetmek" değildir. Bilinmeyen kapanmaz, **yer değiştirir**.

### Tarihsel B-hipotezi — $X$'in readout'a indirgenmesi

Arşivdeki eylem-prensibi tartışmalarında “$X$ temel alan değil, çözüm-sonrası gözlenebilir haritadır” biçiminde bir **B-hipotezi** bulunur. Bu, kaynaklı bir model seçeneğidir; güncel çekirdek tanımı değildir.

$$\boxed{\;X\text{ yalnız readout değildir.}\;}$$

Çünkü güncel mimari $X$'in temel durum, alan izdüşümü ve okuma yüzlerini birlikte korur. B-hipotezi ileride bir model karşılaştırmasında sınanabilir; fakat $X$'i yalnız okuma katmanına indirgerse çekirdek çözücü tanımıyla çatışır.

## 4.6 $X$ faz-aşırı meta-koordinasyon yapısıdır; fiziksel taşıyıcı değildir

$$\boxed{\;\mathrm{MetaCrossPermission}(X) = \text{true},\qquad \mathrm{MetaCrossPermission} \neq \mathrm{TransportPermission}\;}$$

Ve iki yönlü bir kural vardır:

boyutsuzluk fiziksel taşıma için genel bir teorem değildir. Bir niceliğin taşınıp taşınamayacağı 13.1a'daki taşıma iznine bağlıdır.

### 🔴 Kritik uyarı

$$\boxed{\;X\text{'in faz-aşırı statüsü YALNIZ boyutsuz olmasından TÜRETİLMEZ.}\;}$$

$X$'in meta-geçiş statüsü boyutsuzluktan türetilmez; boyutsuzluk burada uyumlu bir özellik olabilir, ama taşınabilirlik için genel bir gerekli ya da yeterli koşul değildir. $X$ fiziksel bir taşıyıcı değil, meta-koordinasyon yapısıdır. Boyutsuzluk, bu niteliğin bir **sonucudur**, nedeni değil.

## 4.7 Faz peyzajı

Faz haritasında köşeler, $X$'in **rejim örnekleridir** — sabit çapa değerleri değil. Bir köşeye yaklaşmak, o rejimin kilitleyici etkisinin artması demektir.

$$\boxed{\;\text{Köşeler SABİT DEĞİL, dinamik } X\text{'in FAZ-REJİM ÖRNEKLERİDİR.}\;}$$

Fiziksel yapıların büyük kısmı (gezegenler, atomlar, elektromanyetik olgular, biyoloji) hiçbir köşede değil, **üçünün de etkisi altındaki iç bölgede** bulunur.

## 4.8 Özyinelemeli makro-nesne okuması

$X$, bir nesnenin bulunduğu bağlamı özetleyen **özyinelemeli bir tanımlayıcı** gibi düşünülebilir. Bir atom için bir şeydir; onu içeren molekül için başka; molekülü içeren hücre için başka. Her ölçekte yeniden çözülür ve alt ölçekleri **içerir ama onlara indirgenmez**.

Bu bir **analojidir** — yapısal sezgi verir, sonuç üretmez.

---

# BÖLÜM 5 — FAZ-PARAMETRE MATRİSİ

## 5.1 Statü

$$\boxed{\;\text{Faz-parametre matrisi, çerçevenin ÇEKİRDEK yapılarından biridir.}\;}$$

Bu bir opsiyon, bir "riskli genişleme" ya da bir sunum aracı değildir. Yöntem kararı olarak çekirdeğe aittir.

Mendeleyev'in periyodik tablosuyla benzetmenin **doğru** yanı: Mendeleyev elementleri keşfetmedi — **düzenledi**, ve düzen **boşlukları** gösterdi.

## 5.2 Ana mimari

$$\boxed{\;\text{ÖzellikAilesi} \times \text{Faz} \;\longrightarrow\; \text{Aralık} \;\;\text{ya da}\;\; \bot\;}$$

Her hücre, bir özellik ailesinin belirli bir fazdaki durumunu verir: ya bir aralık, ya da o fazda **kabul edilemez** işareti.

### $X$ matriste nerede

$$\boxed{\;X \text{ matrisin BİR SATIRI DEĞİLDİR. } X, \text{ matrisin ÜST ÇÖZÜCÜSÜDÜR.}\;}$$

Matris $X$'i içermez; $X$ matrisi çözer. Bu yüzden 5.4 tablosunda $X$ satırı yoktur; $X$, tablonun üstündeki çözücü meta-verisidir.

## 5.3 Hücre tipleri — beş farklı "boş" ve bir bilgi durumu

| Sembol | Anlamı |
|---|---|
| $0$ | Gerçek sayısal sıfır |
| $[0,0]$ | Geçerli, sıfır genişlikli fiziksel aralık |
| $\texttt{None}$ | Bu geçişte damga üretilmedi ($\text{NoStamp} \neq \text{NoTransition}$) |
| $\bot_0$ | c₀'da: kavram **henüz kurulmamış** — tanımsız |
| $\bot_+$ | c⁺'ta: kavram **çözünmüş** — artık o fazın dilinde yok |

Bunlar karıştırılmamalıdır. Örneğin c₀'da içsel fiziksel zaman $\bot_0$'dır — $0$ değil. "Sıfır zaman geçti" demek bile bir zaman kavramı gerektirir. c⁺'ta ise zaman $\bot_+$'dır: Cₘ'de kurulmuş olan yapı orada çözünmüştür.

İki yokluğu tek bir $\bot$ altında toplamak bilgi kaybettirir, çünkü **"henüz yok" ile "artık yok" aynı şey değildir.** Bu ayrım, zaman, üç boyutlu uzay ve $c$ sınırının yalnız Cₘ'de geçerli olduğu; c₀'da tanımsız, c⁺'ta çözünmüş olduğu yönündeki yazar hükmünün doğrudan sonucudur. Bu ayrım biçimsel olarak doğrulanmış ve faz-indeksli bir değer tipiyle zorlanmıştır: c₀ ya da c⁺ için Cₘ'ye özgü bir değer "mevcut" diye inşa edilemez.

$$\boxed{\;\bot_0 \neq \bot_+ \neq 0 \neq [0,0] \neq \texttt{None}\;}$$

Bunlardan ayrı bir durum daha vardır: **eksik veri.** Bir niceliği ölçemediğimizde ya da bilmediğimizde, bu o niceliğin ontolojik olarak yok olduğu anlamına gelmez; bu bir **bilgi durumudur**. Eksik veri yukarıdaki beş "boş"tan hiçbiri değildir ve ayrı bir eksende tutulur.

*Okuma kuralı:* Belgenin önceki bölümlerinde tek başına $\bot$ görüldüğünde, c₀ bağlamında $\bot_0$, c⁺ bağlamında $\bot_+$ olarak okunur.

### 5.3a Nicelik türü ile boyut aynı şey değildir

Bir niceliğin fiziksel boyutu (kütle, uzunluk, zaman) ile ne tür bir nicelik olduğu farklı şeylerdir. Eski bir kayıtta "kütle c⁺'ta taşınır" deniyordu; bu cümle iki şeyi karıştırır. Kütlenin **boyut etiketi** fazdan bağımsız bir etiket olarak her bağlamda görülebilir; ama Cₘ'deki **durgun kütle** Cₘ'ye özgü bir niceliktir ve c⁺'a taşınmaz. Benzer biçimde metrik bir boyut etiketinden türetilmez; metriğin nerede tanımlı olduğu ayrıca belirtilir — yalnız Cₘ'de.

### Denklem seti — İki yokluk, faz-indeksli değer, global düğümler

**Ne işe yarar, neden gerekli?** Yazarın hükmü: *"Zaman, 3B Öklid–düz uzay, c faz sınırı vb. temel tanımlar Cₘ'de geçerli. Bu yapılar c₀'da tanımsız, c⁺'ta çözünmüş."* Tek bir $\bot$ bu iki **ontolojik olarak farklı** yokluğu ayırt edemiyordu.

```lean
inductive CmOnlyValue (α : Type) : Phase → Type
  | undefined0    : CmOnlyValue α .c0
  | presentCm     : α → CmOnlyValue α .Cm
  | dissolvedPlus : CmOnlyValue α .cp
```

**Semboller**

| Sembol | Anlam |
|---|---|
| $\bot_0$ / `undefined0` / `preAdmissible` | c₀: yapı **henüz kurulmamış** |
| $\bot_+$ / `dissolvedPlus` / `dissolved` | c⁺: yapı **çözünmüş** |
| `CmOnlyValue α p` | Faz-indeksli değer tipi |
| `Knowledge` | Epistemik durum: `observed` · `missingData` · `imputed` |
| `GlobalNode` | $U_0$, $U_x$, $U_+$ |
| `isPole` | $U_0$ ve $U_+$ kutup; **$U_x$ değil** |
| `MetricAdmissible p` | Metrik yalnız Cₘ |

**Statü:** ★✅ iki ontik yokluk ve faz-indeksli değer · $U_x$ kutup değil ✅


## 5.4 Genişletilmiş örnek matris

Aşağıdaki tablo **nihai sayısal tablo değildir**. Amacı özellik-ailesi kapsamını ve faz türlemesini göstermektir. Hücrelerde sayısal değer yoksa bunun nedeni eksiklik değil, sayısal köprünün henüz türetilmemiş olmasıdır.

| Özellik ailesi | Önerilen gösterim | c₀ | Cₘ | c⁺ | Ontolojik not |
|---|---|---|---|---|---|
| İçsel fiziksel zaman | $T(x)$ / temporal role | $\bot_0$ | Range / physical time | $\bot_+$ | Zaman yalnız Cₘ-native |
| Causal/speed family | $C(x)$ | Cₘ speed dili $\bot_0$ | $0<v<c$ bandı (çekirdek üyelik hükmü); $v=c$ liminal | Cₘ speed dili $\bot_+$ | c⁺ c-ötesi ontolojik rejimdir; Cₘ-tipi $dx/dt>c$ uygulanamaz (3.4) |
| Çekim Kuvveti izdüşüm ailesi | $G(x),g(x)$ | Faz rejimi | Ölçülebilir readout | Üst-faz rejimi | $g(x)\neq g_{\mu\nu}$ |
| Metrik | $g_{\mu\nu}$ | $\bot_0$ | Tanımlı | $\bot_+$ | Yalnız Cₘ |
| Topoloji/boyut | $d(x)$ | metric-dışı | Cₘ geometry | metric-dışı | “kaç boyut?” ayrıca formalization ister |
| Enerji | $e(x)$ | Range / phase-semantic | Ölçülebilir | Cₘ energy type doğrudan taşınmaz | İki-kanallı eşik programıyla ilişkili |
| Ölçek | $s(x)$ | Range | Range | Range | X bağlam girdilerinden biri olabilir |
| Entropi/order | $S(x)$ | pre-temporal semantics | thermodynamic/readout | atemporal record semantics | Üçü ham eşit değildir |
| Regulation/reporting | $\Gamma(x)$ | intrinsic time üretmez | time/readout coefficient family | intrinsic time üretmez | $X$ ile özdeş değildir |
| İmpedans | $Z(x)$ | model-dependent | ölçülebilir bridge olabilir | model-dependent | Kanal köprüsüne açık |
| Momentum | $p(x)$ | standard Cₘ type $\bot$/açık | standard readout | standard Cₘ type $\bot$/açık | Fazlar arası aynen taşınmaz |
| Cₘ metrik uzunluğu | $L_{C_m}$ | $\bot$ | Range | $\bot$ | c⁺ için “seyrelmiş length” kullanılmaz |
| Yoğunluk | $\rho(x)$ | core/collective semantics | physical density | Cₘ matter density $\bot$ | c₀ için “sonsuz density” zorunlu değildir |
| Madde | $m(x)$ | toplu tek-yapı limiti | farklılaşmış madde | Cₘ madde desteği çözülür | En güçlü faz ayrımlarından |
| Information | $I(x)$ | potential/pre-temporal | measurable record | sealed provenance semantics | Global conservation theorem açık |
| Registry/provenance | $R(x)$ | archive değil | event source olabilir | sealed archive role | Registry=existence değildir |
| Force/field family | $F(x)$ | phase-regime | effective interactions | phase-regime | Gravity'den türetim açık |
| Potential/scaffold | $\Phi(x)$ | model/scaffold | Cₘ EFT scaffold | model/scaffold | $X\neq\Phi$ |
| Gauge/kinetic | $Z_B,Z_W,Z_G$ | rezerve program | Cₘ EFT readout | rezerve program | SM makine-1 hedefi |
| Couplings | $\alpha_i(x)$ | bridge açık | effective constants | bridge açık | Sayısal türetim yok |
| Temperature | $\mathcal T(x)$ | standard thermal type $\bot$/açık | thermodynamic readout | standard thermal type $\bot$/açık | $0$ ile $\bot$ ayrılmalı |
| Heat | $Q(x)$ | standard heat type $\bot$/açık | thermodynamic readout | standard heat type $\bot$/açık | “ısı yok” = otomatik $T=0$ değildir |
| Frequency/clock | $\nu(x)$ | intrinsic frequency $\bot$ | ölçülebilir | intrinsic frequency $\bot$ | Fiziksel periyot Cₘ zamanı gerektirir |
| Pressure/stress | $P(x)$ | phase-limit semantics | stress-energy readout | Cₘ pressure type $\bot$/açık | Outer phases'e otomatik taşınmaz |
| Coherence | $\mathcal C(x)$ | collective | quantum/classical regimes | coordination semantics | BEC analogisi literal değildir |
| Measurement | $\mathcal M(x)$ | direct ölçüm $\bot$ | direct measurement | direct ölçüm $\bot$ | Cₘ epistemik merkez |
| Archive state | $A(x)$ | archive değil | record source | sealed provenance phase | c⁺ future oracle değildir |
| Erişilebilirlik/eşik | $\mathcal A(x)$ | Range | Range | Range | Geçiş izinliliğine bağlanabilir |

Bu satırların bir kısmı yalnız **ayrılmış özellik ailesi** statüsündedir. Matrisin çekirdek oluşu, her satırın bugün sayısal bir yasaya sahip olduğu anlamına gelmez.

## 5.5 Satır listesi açıktır

$$\boxed{\;\text{YÖNTEM KARARI çekirdektir; SATIR SAYISI ve SIRASI açıktır.}\;}$$

Matrisin hangi özellik ailelerini içereceği ve hangi sırada düzenleneceği kapalı değildir. Bu bir eksiklik değil, tablonun **canlı bir çalışma aracı** olmasının gereğidir.

### Tarihsel derlemelerdeki sayısal değerler

Arşiv taramalarından gelen sayısal katsayılar, doğrudan doğrulanmadıkça matrise girmez. Emekli bir hattan gelen sabitler **geri getirilemez** (Bölüm 21).

---

# BÖLÜM 6 — ARALIK (RANGE) FORMALİZMİ

## 6.1 Temel sözdizimi

$$\boxed{\;P \in [P^-,\, P^+]\;}$$

Fiziksel sayısal ifade, aralık değerlidir. Bu, çerçevenin nicelikleri **nasıl yazdığına** ilişkin bir kuraldır.

## 6.2 🔴 Sıfır genişlikli aralık tamamen geçerlidir

$$\boxed{\;[P,\,P] \text{ TAM GEÇERLİ bir STATİK DETERMİNİSTİK fiziksel aralıktır.}\;}$$

Bu, çerçevenin en sık yanlış anlaşılan noktasıdır ve açıkça belirtilmelidir:

| Yanlış okuma | Doğrusu |
|---|---|
| ~~"Noktasal fizik yasaktır"~~ | Aralık-değerli sözdizimi kullanılır; $[P,P]$ meşrudur |
| ~~"$[P,P]$ özel bir eşik durumudur"~~ | Özel bir mekanizma **gerekmez** |
| ~~"$[P,P]$ bir Heaviside/yapısal tekilliktir"~~ | Böyle bir zorunluluk **yoktur** |
| ~~"Her sabit $X$ ile değişir"~~ | Bir nicelik belirli rejimde $[P,P]$ **kalabilir** |

$$\boxed{\;\text{Aralık-değerli olmak} \;\nRightarrow\; \text{zamanla değişken olmak.}\;}$$

Bir niceliğin aralık sözdizimiyle yazılması, onun değişken olduğunu **ima etmez**. Statik ve deterministik bir sabit, $[P,P]$ olarak yazılır ve bu tam olarak doğrudur.

## 6.3 Üç aralık türü

| Sembol | Adı | Ne |
|---|---|---|
| $\Delta X_{\rm acc}$ | **Kabul aralığı** | Çerçevenin izin verdiği |
| $\Delta X_{\rm pred}$ | **Öngörü aralığı** | Çerçeveden **türetilmiş** |
| $\Delta X_{\rm obs}$ | **Gözlem aralığı** | Veriden gelen |

**Yanlışlama kuralı yalnız ikisi arasında işler:**

$$\boxed{\;\Delta X_{\rm pred} \;\cap\; \Delta X_{\rm obs} = \varnothing \;\Longrightarrow\; \text{yanlışlanmıştır.}\;}$$

İki **gözlem** aralığının uyuşmaması bir teoriyi yanlışlamaz.

## 6.3a Neyin aralık, neyin sabit olduğu — katmanlar

Aralık formalizmi "her şeyi aralığa çevir" demek değildir. Yazarın vurguladığı gibi, bazı denklemlerde aralık değil sabit kullanılır ve bu bir hata değildir. Doğru olan, her büyüklüğün hangi katmana ait olduğunu bilmektir:

| Katman | Örnek | Nasıl taşınır |
|---|---|---|
| Yapısal kesin | $\pi$, faz sayısı 3, sayımlar | Kesin — aralığa çevrilmez |
| Tanımsal nokta | $c_{C_m} = [c,c]$ | Sıfır genişlikli aralık $[P,P]$ |
| Belirsiz ya da değişken fiziksel parametre | kuyu genişliği, bağlaşımlar, enerji yayılımı | Aralık ya da ortak olurluk kümesi |
| Epistemik | Ölçüm belirsizliği | Aralık ya da küme |
| Genişletilmiş | Enerji yayılımı sıfırı içerirse zaman sınırı $+\infty$'a uzanır | Genişletilmiş uç |
| Faz-yok | c₀/c⁺'ta zaman | $\bot_0$ / $\bot_+$ |

Gerçekten sabit alınan bir parametre, bu varsayım açıkça yazılarak sabit kalır. Sabit kullanmak tek başına bir eksiklik ya da hata gerekçesi değildir.

## 6.4 Boşluk yasağı

$$\boxed{\;[0,\infty) \text{ geçerli bir genişletilmiş aralıktır; ama önsel alanı daraltmıyorsa öngörü gücü taşımaz.}\;}$$

Yani sorun aralığın geçersizliği değil, **bilgi vermemesidir**: her veriyle "uyar" ve bu yüzden ayırt edici bir öngörü bandı sayılmaz.

Bir öngörü aralığı **türetilmiş** ve **önselden anlamlı biçimde dar** olmalıdır.

## 6.4a Aralık hesabının güvenilirliği

Aralık hesabının temel işlemleri **kesin tam sayı bant katmanında** biçimsel olarak kanıtlanmıştır. Toplama, negatif alma, kesişim ve çarpım güvenlidir: gerçek değerler aralıkların içindeyse, sonuç da sonuç aralığının içindedir. Çarpımda dört köşe kuralı geçerlidir:

$$x\in[a,b],\ y\in[c,d] \;\Rightarrow\; xy \in \big[\min(ac,ad,bc,bd),\ \max(ac,ad,bc,bd)\big]$$

Üç koruma da kuruludur: sıfırı içeren bir aralığın tersi alınamaz; boş küme ile $[0,0]$ farklıdır; $+\infty$ bir uç noktadır, yokluk değildir. Tam aralık hesabı — kesin ters alma ve bölme, genişletilmiş uçlarla tam cebir, değişkenler arasındaki bağımlılığın izlenmesi — henüz kısmen kuruludur. Bu bir ontoloji borcu değil, bir kütüphane mühendisliği borcudur.

### Denklem seti — Range Formalizmi ve Band aritmetiği

**Ne işe yarar, neden gerekli?** Evertophy fiziksel değerleri **aralık** olarak taşır. Aralığın geçerliliği ($lo \leq hi$) ve aralık işlemlerinin **sağlamlığı** (gerçek değer aralıkta ise sonuç da aralıkta) kanıtlanmazsa, tüm öngörü bandları güvenilmez olur.

$$x \in [a,b],\ y \in [c,d] \;\Rightarrow\; xy \in \big[\min(ac, ad, bc, bd),\ \max(ac, ad, bc, bd)\big]$$

**Range tip katmanları:**

| Katman | Örnek | Tip |
|---|---|---|
| Yapısal kesin | $\pi$, faz sayısı 3, sayımlar | Kesin — aralığa **çevrilmez** |
| Tanımsal nokta | $c_{C_m} = [c,c]$ | $[P,P]$ |
| **Belirsiz / değişken fiziksel parametre** | $\sigma$, $\beta$, $k$, $\Delta E$, $\eta_{\rm clock}$ | Uygun aralık ya da ortak olurluk kümesi. **Gerçekten sabit alınan** parametre açık sabit varsayımıyla, gerekirse $[P,P]$ olarak taşınır; bu tercih tek başına başarısızlık ya da kısmi başarı gerekçesi **değildir** |
| Epistemik | Ölçüm belirsizliği | Aralık / küme |
| Genişletilmiş | $\Delta E \ni 0$ → $+\infty$ | ExtendedBand |
| Faz-yok | c₀/c⁺'ta zaman | `undefined0` / `dissolvedPlus` |

**Semboller**

| Sembol | Anlam |
|---|---|
| `Band` | $\langle lo, hi, valid : lo \leq hi\rangle$ |
| `mem x b` | $lo \leq x \leq hi$ |
| `cmin`, `cmax` | Dört köşe çarpımının min/max'ı |
| `ZeroExcluded b` | $0 < lo \ \lor\ hi < 0$ |
| `Ext` | $-\infty$ · sonlu · $+\infty$ uç noktaları |

**Statü:** Temel kesin aritmetik ★✅ · tam aralık hesabı 🟡


## 6.5 Duyarlılık

$X$ tek bir sayı olmadığı için, bir niceliğin $X$'e duyarlılığı doğrudan $d\ln c/dX$ biçiminde yazılamaz; türev, $X$'in belirli bir okuması üzerinden alınır:

$$S_c^{(k)} \equiv \frac{\partial \ln c}{\partial \xi_k} \in [S^-, S^+], \qquad \xi_k = \pi_k(X)$$

Burada $\xi_k$, $X$'in $k$-ıncı skaler okumasıdır. $S \approx 0$ ise nicelik o rejimde pratikte sabittir. Bu, çerçeveyle tamamen tutarlıdır.

Işık hızı için çekirdek hüküm şudur: Cₘ'de $c$ tanımsal bir nokta aralıktır, $c_{C_m} = [c,c]$; dolayısıyla çekirdekte $c$'nin herhangi bir okumaya duyarlılığı sıfırdır. "Değişen ışık hızı" yalnız etkin bir model büyüklüğü olarak ele alınabilir ve ancak ince yapı sabiti gibi **boyutsuz** gözlenebilirler üzerinden sınanabilir; birim seçimindeki bir değişiklik gözlem sayılmaz.

*Okuma kuralı:* Belgede $X$ üzerinde skaler işlem (türev, ters alma, logaritma, limit) görülen tarihsel ya da model ifadeleri, bir okuma $\xi = \pi(X)$ açıkça tanımlanana kadar çekirdek ifade değil, tarihsel model ya da henüz kurulmamış köprüdür. Yalnız $X$ harfini $\xi$ ile değiştirmek fiziksel köprüyü kurmuş sayılmaz.

### Denklem seti — $X$ skaler değil — izdüşüm disiplini

**Ne işe yarar, neden gerekli?** $X(x)$, Evertophy'nin faz düzenleyici alanı. Kanon $X$'i bazen tek bir sayı gibi kullanıyordu: karşılaştırıyor ($X(x) > X(0)$), türevini alıyor ($d\ln c/dX$). Ama $X$ çok bileşenli bir nesneyse bu işlemler **tanımsızdır**.

$$\xi_k = \pi_k(X), \qquad S_c^{(k)} \equiv \frac{\partial \ln c}{\partial \xi_k} \in [S^-, S^+], \qquad \xi_{ij} \in \big[\xi^{\rm crit,-}_{ij},\ \xi^{\rm crit,+}_{ij}\big]\ \ (\text{nokta}) \ \text{ya da}\ \ B_{\xi_{ij}} \cap [\cdot] \neq \varnothing\ \ (\text{bant})$$

*Notasyon notu:* $\xi_{ij}$ nokta ise üyelik, bant ise $B_{\xi_{ij}}$ adıyla küme kesişimi yazılır. Sorun genel olarak vektör/tensör türevinin alınamaması değil, **temel $X$ için gerekli diferansiyel yapının verilmemiş olması**dır.

**Semboller**

| Sembol | Anlam |
|---|---|
| $X$ | Faz düzenleyici — skaler olmayan, aşamalı çözümleyici ($X_{\rm prior} \to X_{\rm resolved} \to X_{\rm read}$) |
| $\pi_k$ | $k$-ıncı okuma izdüşümü |
| $\xi_k$ | $X$'in $k$-ıncı skaler okuması |
| $\xi_{ij}$ | $i \to j$ kenarına özgü izdüşüm |
| $\mathcal{A}_{ij}(X, \Theta_{ij})$ | $i \to j$ geçişinin kabul yüklemi |
| $S_c^{(k)}$ | $c$'nin $\xi_k$'ya duyarlılığı |

**Statü:** İlke ★✅ · kesin $X$ tipi ve fiziksel izdüşüm ⏸


## 6.6 Sektör hiyerarşisi türetilmelidir

$$\boxed{\;\text{Hangi sektörün SABİT, hangisinin DEĞİŞKEN olduğu ATANAMAZ — TÜRETİLMELİDİR.}\;}$$

Aksi hâlde formalizm her sonucu barındırır ve hiçbir şeyi yasaklamaz.

## 6.7 Aralık-güvenli mühürleme

$$\mathrm{Seal}\big([p^-,\,p^+]\big) \;=\; \big(\mathrm{rid},\; [p^-,\,p^+],\; \text{damga}\big)$$

Kayıt **kimliği** tekildir; fiziksel **içerik** aralık kalabilir. $p^- = p^+$ zorlanmaz.

---

# BÖLÜM 7 — ZAMAN ONTOLOJİSİ

## 7.1 Fiziksel zamanın tek evi

$$\boxed{\;\text{EMERGENT FİZİKSEL ZAMAN, YALNIZ Cₘ'DE BULUNUR.}\;}$$

c₀ zaman-öncesi (pre-emergent) potansiyel/core fazıdır; c⁺ ise zaman-dışı (atemporal) üst/arşiv fazıdır. Her ikisinde de Cₘ'ye ait içsel saat, hız, süre veya fiziksel akış değişkeni kullanılmaz.

Bu nedenle:

$$\boxed{\;t_{c_0}\text{ ve }t_{c^+}\text{ çekirdek ontolojinin değişkenleri değildir.}\;}$$

`dt = 0` ifadesi yalnız pedagojik bir kısaltma olarak kullanılabilir; ontolojik olarak daha güvenli ifade **"fiziksel zaman bu fazda admissible değildir"** biçimidir.

## 7.2 Zaman üretimi — çekirdek iskele

Çekirdekte korunan en genel çalışma biçimi:

$$\boxed{\;dt \;=\; \Gamma\,\mathcal{G}_{C_m}\,d\tau\;}$$

Burada:

- $\Gamma$, Cₘ readout/raporlama-regülasyon ailesinin katsayısıdır;
- $\mathcal{G}_{C_m}$, Cₘ içinde ölçülebilir değişim/ayrışma yapısını temsil eden henüz kapanmamış bir nesnedir;
- $\tau$, **formal sıralama/parametrizasyon değişkenidir**; gizli bir temel fiziksel zaman değildir.

$$\boxed{\;\tau \neq \text{fundamental physical time.}\;}$$

Bu iskele, zamanın Cₘ'ye özgü emergent readout olduğunu söyler; $\mathcal{G}_{C_m}$'nin tekil mikrofiziksel tanımını henüz vermez.

## 7.3 Normalize edilmiş realizasyon — model düzeyi

Boyut muhasebesi gerektiğinde şu normalize biçim kullanılabilir:

$$dt \;=\; \tau_0\,\tilde\Gamma\,\mathcal{G}_{C_m}\,d\lambda$$

Burada $\tilde\Gamma$ boyutsuz, $\tau_0$ seçilen realizasyonun zaman ölçeği ve $\lambda$ salt parametrizasyon değişkenidir. Bu, 7.2'deki çekirdek iskelenin **bir realizasyonudur**, ontolojinin zorunlu tek biçimi değildir.

Benzer biçimde,

$$\mathcal{G}_{C_m} \stackrel{\rm model}{=} \left\|\frac{d\rho_{C_m}}{d\lambda}\right\|$$

gibi density-matrix normları yalnız **Cₘ kuantum/açık-sistem modeli** olarak değerlendirilebilir. $\rho_{C_m}$ çekirdek ontolojinin zorunlu primitive'i değildir.

Bu model katmanında aday norm aileleri arasında **trace norm**, **Hilbert–Schmidt normu** ve **operatör normu** bulunur. Hiçbiri current Core tarafından seçilmiş değildir; seçim fiziksel bridge ve parametrizasyon-invariance testi gerektirir.

## 7.4 Parametrizasyon bağımsızlığı — formal aday

Bir realizasyonda yay uzunluğu benzeri nesne:

$$s(\lambda)=\int \left\|\frac{d\rho_{C_m}}{d\lambda}\right\|d\lambda$$

monoton yeniden parametrizasyonlara karşı invariant kurulabilir. Bu özellik yararlı bir tutarlılık testi sağlar; fakat seçilen normu veya $\rho_{C_m}$'nin ontolojik statüsünü tekilleştirmez.

Arşivde bulunan

$$\int \mathcal G_{C_m}\,d\lambda \ge \frac{\hbar}{2}$$

şeklindeki minimum-eşik ifadesi **model/tarihsel adaydır**; current core zaman postülası değildir. Bu ifadede bir boyut uyuşmazlığı da vardır: sağ taraf eylem boyutundadır, sol taraf ise normalizasyona bağlı olarak boyutsuz kalabilir. Tutarlı biçim boyutsuz bir eşiktir; ondan sabit enerji yayılımında bir zaman **hız sınırı** çıkar — ulaşılmış bir süre değil:

$$\int \mathcal G_{\rm FS}\,d\lambda \ge \theta_{\min}, \qquad \Delta t_{\min} = \frac{\hbar\,\theta_{\min}}{\Delta E}$$

Bu biçim yalnız kuantum-Cₘ rejiminde, saf durum ve üniter evrim koşullarıyla anlamlı bir **köprüdür**; çekirdek zaman ontolojisi değildir.

### Aktif akromatiklik / Lorentz-readout kısıtı

Prob-enerjisi bağımsızlığı ise tamamen tarihsele indirilmez. Aynı fiziksel durum $\mathcal S$ ve aynı admissible Cₘ readout rejimi altında:

$$\boxed{
\left.\frac{\partial X}{\partial E_{\rm probe}}\right|_{\mathcal S}=0,
\qquad
\left.\frac{\partial\Gamma}{\partial E_{\rm probe}}\right|_{\mathcal S}=0
}
$$

aktif bir **Cₘ okuma / Lorentz-uyumluluk kısıtı** olarak korunur.

Bu, $E_{\rm probe}$'un hiçbir modelde asla ilgili olamayacağı anlamına gelmez. Kuralın amacı, **aynı fiziksel state'in ontolojik çözümünün yalnız ölçüm probunun enerjisi değişti diye keyfî biçimde kaymamasını** sağlamaktır.

$$\boxed{
\text{aktif readout kısıtı}
\neq
\text{$X$'in fundamental tanımı}
}
$$

### Denklem seti — Zaman ve kuantum eşiği

**Ne işe yarar, neden gerekli?** Evertophy'de zaman Cₘ'ye özgü bir yapı. Kanon, zamanın "en küçük anlamlı adımını" bir kuantum eşiğine bağlıyordu. Bu eşik yanlış kurulursa, zaman tanımının kendisi boyutsal olarak tutarsız olur — üzerine kurulan her şey de öyle.

$$\int \mathcal{G}\,d\tau \geq \frac{\hbar}{2} \quad \text{(eski — ❌ boyut hatası)}$$

$$\int \mathcal{G}_{\rm FS}\,d\lambda \geq \theta_{\min}, \qquad \Delta t_{\min} = \frac{\hbar\,\theta_{\min}}{\Delta E} \quad \text{(düzeltme)}$$

$$dt = \frac{\hbar}{\Delta E_{C_m}}\,ds_{\rm FS} \quad \text{(C-1 köprüsü)}, \qquad dt_{\rm ET} = \eta_{\rm clock}\,d\tau_{\rm GR},\ \ \eta_{\rm clock} \in [\eta^-, \eta^+],\ \text{GR limitinde } [1,1]$$

$$\Gamma \cdot \mathcal{G}_{C_m} = \frac{1}{\sqrt{-g_{00}}} \quad \text{(GR limitinde sayısal eşdeğerlik; aday köprü)}, \qquad \Delta t_{\min} \in \left[\frac{\hbar\theta^-}{\Delta E^+},\ \frac{\hbar\theta^+}{\Delta E^-}\right] \quad \text{(Range formu)}$$


**Tarihsel boyut denetimi:** tarihsel saat çarpanı $dt = \Gamma\,G_t\,d\tau$ ancak $[\Gamma] = T$, $[G_t] = T^{-1}$, $[d\tau] = T$ ise tutarlı; boyutsuz biçim $dt = \tau_0\,\tilde\Gamma\,G_t\,d\tau$, $[\tilde\Gamma] = 1$. Burada $G_t$ çekim sabiti **değildir**. Cₘ dışına fiziksel saat taşımaz; c₀/c⁺'ta sıfır türev de tanımlanmaz. Statü: 🟡 arşiv/boyut kontrolü, fizik köprüsü ⏸.

**Semboller**

| Sembol | Anlam |
|---|---|
| $\mathcal{G}$ | Faz durumunun değişim hızı (durum uzayında "hız") |
| $\mathcal{G}_{\rm FS}$ | Aynı hızın Fubini–Study metriğiyle ölçülmüş hâli (kuantum durumları arası doğal uzaklık) |
| $\tau$, $\lambda$ | Parametre; $\lambda$ **boyutsuz** |
| $\hbar$ | İndirgenmiş Planck sabiti — boyutu [enerji × zaman] |
| $\theta_{\min}$ | Ayırt edilebilir iki durum arasındaki en küçük açı (boyutsuz) |
| $\Delta E$ | Cₘ sisteminin enerji yayılımı |
| $ds_{\rm FS}$ | Fubini–Study yay uzunluğu elemanı |
| $\eta_{\rm clock}$ | Evertophy zamanı ile GR özzamanı arasındaki oran (aralık) |
| $g_{00}$ | Metriğin zaman–zaman bileşeni |

**Statü:** Eski eşik ❌ · boyutsuz eşik 🟡 MODEL/geometrik köprü · FS zaman köprüsü KÖPRÜ · $\eta_{\rm clock}$ 🟡 KÖPRÜ/MODEL (GR limiti $[1,1]$) · açık sistem genellemesi ⏸


## 7.5 İki farklı zamansızlık

| Faz | Temporal rol | Ontolojik anlam |
|---|---|---|
| **c₀** | Pre-emergent | Fiziksel zaman henüz ontolojik readout değildir; potansiyel/core rejimi |
| **Cₘ** | Physical time | Fiziksel saat, proper-time readout ve ölçülebilir değişim burada anlamlıdır |
| **c⁺** | Atemporal record | Cₘ zamanı taşınmaz; sealed provenance birlikte var olabilir |

$$\boxed{\;\text{c₀ zamansızlığı} \neq \text{c⁺ zamansızlığı.}\;}$$

## 7.6 Foton, proper time ve faz üyeliği

Özel görelilikte ışık-benzeri dünya-çizgisinde proper time sıfırdır. Bu gerçek, fotonu ontolojik olarak c⁺ üyesi veya c⁺ sınır nesnesi yapmaz.

$$\boxed{\;d\tau_{\rm proper}=0 \;\nRightarrow\; \text{phase}(\text{photon})=c^+.\;}$$

Foton $v=c$ sınırında, **liminal** durumdadır (3.3). Liminal olmak, Cₘ'nin üyelik bandının sınırında bulunmak demektir; c⁺ üyeliği ya da c⁺ sınır nesnesi olmak değildir.

## 7.7 İki saat sorunu — açık gerilim

Cₘ'nin etkin geometrisi zaten proper time üretir; emergent-time iskele ise ikinci bir readout dili sunar. Dolayısıyla iki saat problemi açıkça çözülmelidir.

| Yol | İçerik | Bedel |
|---|---|---|
| **A** | Emergent readout proper time ile özdeş | Yeni zaman yapısı fiziksel içerik eklemeyebilir |
| **B** | İki saat bağımsız | Hassas uyumun açıklanması gerekir |
| **C** | Dinamik/tekil eşleme | İlave bridge yasası gerekir |

Bu problem kapanmadan emergent-time denklemi GR proper time'ın türetilmiş alternatifi olarak sunulamaz.

### 7.7a Registry — güvenli çekirdek okuma

**Registry bağımsız bir varlık değildir.** Cₘ içindeki farklılaşmış olayların/provenance'ın kayıt izi için kullanılan bir okuma dilidir. Bu nedenle “kayıt vardır” ifadesi “yeni ontolojik varlık vardır” anlamına gelmez.

Tarihsel arşivde

\[
\Delta\sigma_m\neq0\Rightarrow Registry\Rightarrow Zaman
\]

ve

\[
\frac{dS_{\rm Reg}}{d\tau}\ge0
\]

biçimleri kullanılmıştır. Güncel çekirdekte bunlar **zamanın temel türetimi veya evrensel entropi yasası olarak yükseltilmez**; Bölüm 7.2'deki zaman iskelesi ve Bölüm 14'teki mühür/arşiv ontolojisi üstündür.

Özellikle tarihsel “c⁺ = bütün fazların global/anlık Registry'si” okuması güncel kanon değildir. c⁺ zamansız, mühürlü/append-only arşiv-koordinasyon fazıdır; “anlık” Cₘ-zaman dili c⁺'a taşınmaz.

## 7.8 Zaman ve entropi

Zaman ile entropi **özdeş değildir**.

Cₘ'ye ait zaman oku ile kayıt/entropi davranışı ortak yapısal köklere sahip olabilir; ancak:

$$\boxed{\;\text{physical time} \neq \text{thermodynamic entropy} \neq \text{archive order.}\;}$$

Birinin artışı diğerinin tanımı değildir.

## 7.9 Faz hafızası — zamansız ifade

"Faz hafızası", bir outer phase içinde akan tarih değişkeni anlamına gelmez. Güvenli yorum, eşik/geçiş geçmişinin daha sonraki Cₘ readout'unda **yapısal kalıntı veya provenance kısıtı** bırakmasıdır.

Arşiv için çekirdek monotonluk zaman değişkeniyle değil, bir kaynak sırası ile ifade edilir:

$$\boxed{\;A \preceq A'\;}$$

Burada $\preceq$ append-only/provenance order'dır; c⁺'ta fiziksel zaman değildir.

Arşivde görülen

$$R_\phi(t+\Delta t)\ge R_\phi(t)$$

ifadesi ancak **Cₘ-zamanlı etkili model** olarak kullanılabilir; çekirdek outer-phase aksiyomu değildir.

### Faz Skarı — model adayı

Arşivdeki “Faz Skarı”, faz hafızasının bir etkin-model gerçekleştirmesi olarak korunur:

$$\Delta X_{\rm res}(x)=\int \Gamma(x,t')\,dt',\qquad X_{\rm eff}(x)=X_0(x)+\Delta X_{\rm res}(x).$$

Alternatif fonksiyonel mühür adayı $\Xi=\int(\partial\Gamma/\partial X)\,dX$ biçiminde yazılmıştır. Bu denklemler **çekirdek yasa değildir**; $X$'i skalerleştirmez ve zaman-dışı fazlara Cₘ zamanı taşımaz. Kullanılacaksa $t'$ integralinin yalnız Cₘ etkin modeline ait olduğu, zamansız çekirdek ifadenin ise append-only/provenance sırası olarak kaldığı açıkça belirtilmelidir.

### Denklem seti — Faz hafızası

**Ne işe yarar, neden gerekli?** Faz sistemlerinin "geçmişi unutmadığı" ilkesi. Kanon bunu fiziksel zamana göre yazıyordu — ama c₀/c⁺'ta zaman yok.

$$R_\varphi(r_{n+1}) \geq R_\varphi(r_n) \quad \text{(kaynak indeksine göre — fiziksel zamana göre değil)}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $R_\varphi$ | Faz hafızası ölçüsü |
| $r_n$ | $n$-inci kaynak (provenance) kaydı |

**Statü:** Kaynak-indeksli yazım ✅ · monotonluğun kendisi 🟡 mimari kural


## 7.10 Hız dili yalnız Cₘ'de meşrudur

$$\boxed{\;\text{c}_0 \text{ ve c}^+ \text{ için intrinsic RATE/SPEED dili kullanılmaz.}\;}$$

Aynı nedenle $dX/dt$, "faz akış hızı", "c⁺'ın genişleme hızı" gibi ifadeler temel ontolojik katmana ait değildir. Bunlar ancak Cₘ readout/model düzeyinde tanımlanabilir.

---


## 7.11 Emergent-time okullarıyla karşılaştırma haritası


Zamanın statüsü konusunda dört büyük pozisyon ve Evertophy'nin konumu kayıt altındadır. Bu karşılaştırma konumlandırmadır; eleştiri değildir.

| Okul | Zamanın statüsü | Motor | Evertophy ile ilişki |
|---|---|---|---|
| **Barbour** | Zamansız ontolojide konfigürasyon sıralaması; "time capsules" | Motor yok | Ortak: zaman ≠ temel. Fark: Evertophy zamanı **yeniden üretmeye** çalışır — "Barbour dissolves time philosophically; Evertophy tries to re-generate it physically" |
| **Rovelli** | Termal zaman: durumdan belirlenen modüler akış; zaman türetilmiş | State → termal akış | Ortak: türetilmişlik. Evertophy'de motor regülatör/mühürleme/faz geçişidir |
| **Smolin** | Zaman temel ve gerçek | Zaman = motor | Kısmi yakınlık: zamansız ontoloji ile fiziksel zaman realizmi arasında köprü adayı |
| **Wheeler–DeWitt** | HΨ = 0 — zamansız dalga denklemi | Problem olarak durur | Evertophy zamansızlığı faz ayrımıyla okur: c₀'da tanımsız, c⁺'ta aşılmış |

### 7.11a Page–Wootters formalizmi

Klasik "zamansız evren + saat alt-sistemi → koşullu dalga fonksiyonundan zaman" yapısı. Evertophy okuması: saat alt-sistemi rolü Cₘ'deki fiziksel süreçlere aittir; mekanizma adayı "regülatör akışı"dır. Formal özdeşlik kurulmamıştır.

### 7.11b Holografik zaman yaklaşımı

Sınır-zaman/bulk-zaman ilişkisi. Evertophy'de karşılığı c⁺–Cₘ okuma ilişkisidir — ancak holografik eşleşme (AdS/CFT türü) çekirdeğe ithal edilmez (Bölüm 19.2).

### 7.11c Termodinamik / entropik zaman

Zaman oku entropi artışından doğar. Evertophy'de ayrım serttir: zaman, entropi ve arşiv sırası üç ayrı kavramdır (Bölüm 7.8, 16.3); hiçbiri diğerinin tanımı değildir.

### 7.11d Relational Quantum Mechanics

Ölçüm = etkileşim; gözlemci önceliği yok. Evertophy'de paralel: gözlemci ayrı bir ontolojik sınıf değil, Cₘ-içi kayıt üreten sistem rolüdür (Bölüm 1.4).

### 7.11e Wheeler–DeWitt ve zamansızlık literatürü

"Zamansızluğun nasıl aşıldığı" sorusu literatürde açıktır. Evertophy'nin önerisi faz-bağımlı üretimdir; matematiksel derinlik bakımından çerçeve henüz **parçalıdır** — "pattern + faz modeli" düzeyindedir, kapalı formal sistem değildir.

### 7.11f Barbour derin karşılaştırması

Dört fark kayıtlıdır: **(A)** zamansız ontoloji ↔ faz-üretimli zaman; **(B)** epistemik ↔ fiziksel ("emergent ≠ unreal": saatler, drift, morfolojik korelasyon fiziksel veridir); **(C)** faz mimarisi (c₀, Cₘ, c⁺ Barbour'da yoktur); **(D)** residual imprint (δX, Φ(x), ρ(τ)) — Evertophy'nin Barbour'dan ileri tek iddiası ölçülebilir kalıntıdır, ve bu iddia kapanmamıştır.

$$\boxed{\;\text{En sade konum: "No fundamental time; time is generated in } C_m \text{ through regulation/sealing and may leave measurable structure."}\;}$$

Uyarı kilitlidir: bu cümlenin gerçekleşmiş olduğu kabul edilemez — denetim açık borçtur.

---

### Denklem seti — $c$ — Cₘ ışık konisi sınırı

**Ne işe yarar, neden gerekli?** Işık hızının Evertophy'deki yerini belirler: $c$ fazdan bağımsız evrensel bir sabit mi, yoksa Cₘ'ye özgü bir sınır mı? Yanlış bir tanım, c₀ ve c⁺'a içsel hız ithal eder.

$$\text{Çekirdek: } g(k,k) = 0,\quad c_{C_m} = [c,c] \qquad \text{(K12: } c = \sup d\ell/d\tau \text{ — ❌, } \gamma v \to \infty\text{)}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $k^\mu$ | Işık-benzeri vektör |
| $d\ell/d\tau$ | Parçacık özzamanına göre yol hızı |

**Statü:** Boş koni $c_{C_m}=[c,c]$ ★✅ · özzaman tanımı (K12) ❌


# BÖLÜM 8 — ÇEKİM ONTOLOJİSİ

## 8.1 Postüla-0'ın açılımı

$$\boxed{\;\text{Çekim Kuvveti (Force of Attraction) temel ontolojik postüladır; kütleçekim onun Cₘ'deki izdüşümlerinden biridir.}\;}$$

Ve Bölüm 1.2'nin ayrımı burada tekrarlanır çünkü kritiktir:

$$\text{Çekim Kuvveti}_{\rm ontoloji} \;\neq\; \text{Kütleçekim}_{C_m} \;\neq\; X \;\neq\; g_{\mu\nu} \;\neq\; G_{\rm eff}$$

### 8.1a Pozitif organizasyon okuması — daraltılmış güncel form

Postüla-0'ın pozitif içeriği, çekimin yalnızca “neyin olmadığı” ile bırakılmamasını gerektirir: Çekim Kuvveti, Evertophy'de **faz organizasyonunun temel ontolojik kısıtlayıcısı/organize edicisi** olarak okunur.

Ancak tarihsel kayıttaki

\[
X=\text{gravity-induced admissibility / organization index}
\]

özdeşliği **güncel kanon değildir**. Güncel \(X\), Bölüm 4'te tanımlanan evrensel, faz-duyarlı resolver'dır; Çekim Kuvveti \(X\)'in belirleyicilerinden biri olabilir fakat \(X\)'i tek başına tüketmez. Böylece:

\[
\boxed{\text{Çekim Kuvveti temel organize edici}\;\not\Rightarrow\;X\equiv \text{çekim indeksi}}
\]

## 8.2 Çekim Kuvveti ≠ gözlemlenen kütleçekim

Genel görelilik **yanlış değildir** — Çekim Kuvveti'nin Cₘ'deki metrik izdüşümü olan kütleçekimin etkin dilidir. Ontolojik postüla ile onun Cₘ'deki izdüşümü farklı katmanlardır.

## 8.3 Etkin kuplaj — model düzeyi

Skaler-tensör dilinde yazılabilecek bir köprü formu:

$$G_{\rm eff} = \frac{G_N}{F}, \qquad\qquad \frac{\dot G}{G} = -\frac{\dot F}{F}$$

$$\boxed{\;Bu form ÇEKİRDEK ONTOLOJİ DEĞİL, bir MODEL GERÇEKLEŞTİRMESİDİR.\;}$$

$F$'nin formu bilinmemekte ve $X$ ile ilişkisi kurulmamıştır. Değeri, gözlemsel kısıtlarla temas kurmasıdır — bu kısıtlar Evertophy **üzerine** kısıtlardır, ondan çıkan öngörüler değil.

## 8.4 Yerel çekim şiddeti

Yerel çekim şiddeti, faz konumuyla **ilişkili** bir niceliktir — onun **eşdeğeri değildir**. Aynı değer farklı yapısal düzenlenişlerde farklı faz konumlarına karşılık gelebilir.

### Gradyan formülleri

Arşivde $\mathbf{a} \sim -c^2\nabla\ln X$ gibi hareket yasası formları geçer (tarihsel form; $X$ skaler kullanıldığı için bir okuma tanımlanmadan çekirdek ifade değildir).

$$\boxed{\;Bu formlar ÇEKİRDEK YASA DEĞİLDİR. } X \text{ zorunlu olarak skaler olmadığından böyle bir gradyan formu ontoloji tarafından GEREKTİRİLMEZ.\;}$$

Ayrıca türetilirse model/köprü katmanında değerlendirilir.

## 8.5 Diğer kuvvetler

Elektromanyetik, güçlü ve zayıf kuvvetler — kütleçekimle birlikte — Çekim Kuvveti'nin Cₘ'deki izdüşümleridir (1.2). Kuplaj sabitleri ilkece bu izdüşümün ölçeğe, kütleye ve faza bağlı biçimiyle belirlenir — ama bu bağımlılığın formu bilinmemektedir.

### Üç-katmanlı okuma mimarisi — model adayı

| Katman | Ne tarif eder | Statü |
|---|---|---|
| **Maxwell / alan dili** | Cₘ içindeki elektromanyetik alan ve ölçülebilir alan okumaları | Yerleşik efektif fizik |
| **CMT / kanal dili** | Modlar, saçılma, empedans ve yönsel kanal davranışı | Deneysel/model köprü dili |
| **Evertophy / faz-kısıt dili** | Hangi faz/rejim/okumanın admissible olduğunu çözen üst constraint yapısı | Ontolojik/program katmanı |

$$\boxed{\;\text{Maxwell}\neq\text{CMT}\neq\text{Evertophy};\quad
\text{katmanlar birbirinin yerine kullanılmaz.}\;}$$

Tarihsel geliştirme kayıtlarında kuvvetler için ayrıca aşağıdaki fenomenolojik aday atamalar bulunur:

| Cₘ etkileşimi | Tarihsel/aday Evertophy okuması |
|---|---|
| Güçlü | "kristal/faz bütünlüğü" benzeri bağlayıcı yapı (eski adlandırma; Daha Sonra Ele Alınacak) |
| Elektromanyetik | $c$-sınırıyla ilişkili kalıcı Cₘ imza/okuma programı (yük); itme ve yükün izdüşüm biçimi Daha Sonra Ele Alınacak |
| Zayıf | kararsız→kararlı konfigürasyon dönüşümü |

Bu tablo **türetim değildir**; Standart Model gauge yapısını veya kuplajlarını açıklamış sayılmaz. Özellikle $c$ ile ilgili satır, Cₘ'nin kinematik/tutarlılık sınırını fiziksel olarak "kıran" bir süperluminal süreç iddia etmez.

## 8.6 Çekim ve dış fazlar

$$\boxed{\;\text{Çekim Kuvveti faz-bağımsızdır: } c_0 \text{ ve } c^+ \text{ da onun kısıt koheransına tabidir.}\;}$$

> Metrik, madde desteği ve ivme dili Cₘ'ye ait **okuma araçlarıdır**; Çekim Kuvveti bu araçlara muhtaç değildir. c⁺'ın çekimsel etkisi — karanlık madde ve karanlık enerji olarak gözlemlenen (Bölüm 11) — Cₘ'de metrik diliyle okunur; fakat etkinin kaynağı c⁺'ın kendi faz rejimidir, Cₘ maddesi değildir. Çekimin dış fazlarda "nasıl" işlediğinin matematiksel dili bilinçli olarak açıktır ve V24'ün devre mekanizması katmanının doğal konusudur.

Bu okuma c⁺'a metrik veya Cₘ-madde desteği geri getirmez; **kimlik ≠ mekanizma** ayrımı korunur ve burada nicel bir türetim iddia edilmez.

## 8.7 Gravitasyonel empedans — Cₘ GR model okuması

Zayıf-alan GR dilinde, ontolojideki $\tau$ sembolüyle karışmaması için yerel öz zaman değişkenini $\tau_{\rm GR}$ ve koordinat zamanını $t_{\rm coord}$ ile ayıralım. Aşağıdaki iki bağıntı **koordinatlarda duran gözlemci** ($v^i=0$) içindir; son yaklaşım zayıf alanda ve $g_{00}=-(1+2\Phi_N/c^2)+\dots$ gösteriminde geçerlidir. Genel dünya çizgisi biçimi aşağıdaki notasyon bölümündedir:

$$d\tau_{\rm GR}\simeq\left(1+\frac{\Phi_N}{c^2}\right)dt_{\rm coord},$$

$$\boxed{\;Z_g(x)\equiv\frac{dt_{\rm coord}}{d\tau_{\rm GR}}
=\frac{1}{\sqrt{-g_{00}}}
\simeq1-\frac{\Phi_N}{c^2}\;}$$

ve zayıf alan ivme okuması:

$$\mathbf a\simeq-c^2\nabla\ln\sqrt{-g_{00}}.$$

Kanal modeliyle kurulabilecek aday sözlük:

$$\Phi_g\;\longleftrightarrow\;\Phi_{\rm ch}
=\lambda\ln Z_{\rm eff}$$

biçiminde araştırılabilir.

$$\boxed{\;Z_g\text{ yalnız Cₘ'de tanımlı bir GR okuma büyüklüğüdür; }c_0/c^+\text{'a taşınmaz.}\;}$$

Buradaki $dt_{\rm coord}/d\tau_{\rm GR}$ oranı, Bölüm 7.2'deki ontolojik $dt=\Gamma\mathcal G_{C_m}d\tau$ iskelesiyle **özdeş değildir**. İki dil arasında bir köprü kurulması ayrıca türetim gerektirir. Aynı şekilde $\Phi_{\rm ch}$, Bölüm 17'deki $\Phi_\chi$ ile kalibrasyon/eşleme gösterilmeden özdeş sayılmaz.

---


GR limitindeki sayısal eşdeğerlik önerisi (7.4) bu ayrımı kaldırmaz: eşdeğerlik okuma katmanında, özdeşlik ontolojik katmandadır.

### Notasyon: öz zaman, koordinat zamanı ve işlem gecikmesi

Bu bölümde $\tau$ Cₘ öz zamanını, $t$ uzak gözlemcinin koordinat zamanını gösterir. Genel bir zamansı dünya çizgisi için ($x^0=ct$, $v^i=dx^i/dt$):

$$Z_g = \frac{dt}{d\tau} = \Big[-\big(g_{00} + 2g_{0i}\,v^i/c + g_{ij}\,v^iv^j/c^2\big)\Big]^{-1/2}$$

Koordinatlarda duran gözlemci için ($v^i=0$) bu $Z_g = 1/\sqrt{-g_{00}} \simeq 1-\Phi/c^2$'ye indirgenir ve $\mathbf a \simeq +c^2\nabla\ln Z_g = -\nabla\Phi$ verir.

| Sembol | Anlam |
|---|---|
| $\tau$ | Cₘ öz zamanı |
| $t$ | Koordinat zamanı |
| $v^i$ | Koordinat hızı |
| $g_{00}, g_{0i}, g_{ij}$ | Metriğin bileşenleri |
| $Z_g$ | Gravitasyonel empedans (genel görelilik okuması) |

Arşivdeki işlemsel okumada $n$ bir **işlem sırası indeksidir** ve fiziksel bir süre değildir; c₀'a fiziksel zaman atfetmez. İndeks ile Cₘ'de ölçülen süre arasındaki bağ bir ölçek $\tau_*$ ve bir eşleme $f$ gerektirir:

$$dt_{\rm gösterge} = \tau_*\,f\,dn$$

$f=\sqrt{-g_{00}}$ seçimi, genel görelilik oranını yeniden üretmek için yapılabilecek bir köprü seçimidir; türetilmiş değildir ve gerekçelendirilmesi gerekir. Bu okumada kütleçekimsel zaman genişlemesi bir **işlem gecikmesi**, Shapiro gecikmesi de yüksek empedanslı bölgeden geçişin gecikmesi olarak okunur — genel göreliliğin sayısal sonuçlarını yeniden adlandırır, onları türetmiş sayılmaz.

## 8.8 CMT → çekim türetim zinciri (model adayı)


Bağlı-mod (CMT) dilinden çekim okumasına giden aday zincir:

$$(\Gamma, \kappa, \nu) \;\Rightarrow\; S(\omega; \mathcal C) \;\Rightarrow\; \chi_S \;\Rightarrow\; \Xi = \ln\chi_S \;\Rightarrow\; \mathbf g_\chi = -\Lambda(\xi)\nabla\ln\chi_S-(\ln\chi_S)\nabla\Lambda(\xi) \quad (\chi_S>0;\ \text{kısa biçim yalnız } \nabla\Lambda=0)$$

Burada Γ iç kayıp, κ port kuplajı, ν karşılıklılık-kırıcı parametredir. Zincirin her halkası ayrıca türetilmesi gereken köprüdür; zincirin yazılmış olması türetim değildir.

### Nonreciprocity için zorunlu koşullar (model kaydı)

Tek-mod CMT ile karşılıklılık kırılması çıkmaz. Beş mekanizma sınıfından en az biri gerekir:

| Sınıf | Örnek |
|---|---|
| Manyeto-optik bias | ferrit, magneto-optik ortam |
| Zamana bağlı modülasyon | parametric driving |
| Çok-mod + dolaşım | ring resonator |
| Arka plan yolu + girişim | interferometric |
| Doğrusal-olmayan aktif ortam | — |

Doğru ifade "tek mod + ν parametresi" değil, "karşılıklılığı bozan somut fiziksel sınıf + port yapılandırması + referans düzlemi"dir. Bölüm 17.1'deki karşılıklılık sınırı burada da geçerlidir.

Pasiflik ve zamanla değişmezlik tek başına karşılıklılığı garanti etmez; statik manyetik bias altındaki ferrit sistemler pasif ama karşılıklı olmayan örneklerdir. Çok mod, halka rezonatör ya da girişim yolu da tek başına karşılıklılık kırılmasının kanıtı değildir.

### Gravitasyonel empedans zinciri (arşiv kaydı)

Adım adım: (1) EM↔GR analojisi; (2) dτ ≈ (1+Φ/c²)dt; (3) Z_g = dt/dτ = 1/√(−g₀₀) ≈ 1−Φ/c²; (4) a ≈ +c²∇lnZ_g = −c²∇ln√(−g₀₀) → Newton limiti −∇Φ (işaret düzeltmesi: ln Z_g ≈ −Φ/c²); (5) Φ_g ↔ Φ_ch = ΛlnZ_eff köprü adayı.

$$\boxed{\;Z_g \text{ yalnız Cₘ'de tanımlı bir GR okuma büyüklüğüdür; } c_0/c^+ \text{'a taşınmaz (Bölüm 8.7 ile aynı koruma).}\;}$$

## 8.9 Shapiro gecikmesi — işlemsel gecikme okuması


GR Shapiro gecikmesi Δt_Shapiro verili kalır; Evertophy okuması işlemseldir:

$$X_{\rm clock}(r) \equiv \pi_{\rm clock}[X](r), \qquad t_{\rm obs} = \int \frac{d\tau}{X_{\rm clock}(r)} \qquad (X_{\rm clock} > 0;\ \text{fiziksel köprü, açık})$$

Kritik güvenlik kısıtı: ∂X/∂E_probe = 0 (aktif akromatiklik — LHAASO/GRB221009A kısıtlarıyla uyum). Bu kısıt, köprünün Lorentz-ihlali üretmemesinin matematik ifadesidir.

Köprüye eklenebilecek stokastik residual adayı (arşiv): δt = δt_GR + η, E[η] = 0, Var(η) ∝ ∫F(ρ,Z)dx — PTA/interferometri penceresi. Bu öngörü değildir; test tasarımıdır.

## 8.10 Kozmik genişleme ve çöküş okuması



Nicel genişleme–çöküş dinamiği ve üç faz denge denklemi **Türetim Bekleniyor** statüsündedir.
Kozmik ölçekte genişleme kolu c⁺, çöküş kolu c₀ ile ilişkilidir (Bölüm 3.1); tek-satırlık eylemsizlik ilkesi olarak kilitlenmemiştir. Bu başlık tarihsel olarak korunur; güncel çekirdekte karşılığı Bölüm 2'nin çift-limit tohumudur.

---

# BÖLÜM 9 — METRİK ONTOLOJİSİ

## 9.1 Metriğin tek alanı

$$\boxed{\;g_{\mu\nu} \text{ YALNIZ Cₘ'de kabul edilebilir bir nesnedir.}\;}$$

Metrik, Cₘ'nin **çıktısıdır** — girdisi değil.

## 9.2 Faz-bariyeri ve Cₘ-içi geometrik realizasyon

Ontolojik çekirdek kriter:

$$\boxed{\;\mathrm{MetricAdmissible}(\phi)\Longleftrightarrow \phi=C_m\;}$$

Tetrad $E^A{}_\mu$, **yalnız Cₘ geometrisi kurulduktan sonra** kullanılabilen bir temsil aracıdır. Cₘ içinde non-degenerate Lorentzian metric için uygun tetrad rank koşulları incelenebilir; fakat:

$$\boxed{\;\operatorname{rank}(E)=4\;}$$

ifadesi outer-phase ontolojisinin faz-bariyeri tanımı değildir.

### 🔴 Tetrad dış fazlara sokulmaz

$$\boxed{\;\text{Tetrad, c}_0 \text{ ve c}^+ \text{'ta TANIMLI BİR NESNE DEĞİLDİR.}\;}$$

Dolayısıyla "outer phase'de rank düşer" değil, **tetrad/metric type outer phase'de inadmissible'dır** denir.

### Denklem seti — Metrik faz-bariyeri

**Ne işe yarar, neden gerekli?** Metriğin **nerede var olabileceğini** belirler: metrik, tetrad (dört çerçeve vektörü) tam ranklı olduğu yerde vardır.

$$g = E^{\mathsf T}\eta E,\ \ \eta = \mathrm{diag}(-1,1,1,1),\ \ E \in \mathbb{R}^{4\times4}: \qquad \det g = -(\det E)^2, \qquad \operatorname{rank} E = 4 \iff g \text{ dejenere olmayan Lorentz metriği}$$

*Konvansiyon notu:* rank 4, bu inşanın **dejenere olmayan** Lorentz metriği vermesinin koşuludur; rank düşükken matris ifadesi yine yazılabilir ama dejeneredir.

**Semboller**

| Sembol | Anlam |
|---|---|
| $g_{\mu\nu}$ | Metrik tensör |
| $E$ | Tetrad matrisi |
| $\theta^a$ | Çerçeve 1-formları |

**Statü:** ✅ koşullu özdeşlik · ontolojiden metrik yeniden inşası ⏸


## 9.2a Üç boyutlu Öklid-düz uzay ve emergent zaman
**Yazar hükmü:** Cₘ'nin temel uzayı, bildiğimiz $x$–$y$–$z$ koordinatlarından oluşan düz, üç boyutlu Öklid uzayıdır; dördüncü ya da ek bir boyut yoktur. Fiziksel zaman bu fazda **emergenttir**, temel bir boyut değildir. c₀'da Cₘ-tipi uzay ve zaman tanımsız, c⁺'ta çözünmüştür.

$$\boxed{\;\mathrm{Space}_{\rm temel}(C_m) = E^3,\qquad {}^{(3)}R_{ijkl}=0\;}$$

Bunun önemli bir sonucu vardır: genel göreliliğin **4B eğri uzay-zamanı** temel bir yapı değil, Cₘ'nin emergent etkin okuma geometrisidir. Etkin 3+1 Lorentz metrik dili ($g = E^{\mathsf T}\eta E$, rank 4) Cₘ ölçüm ve model katmanında kullanılabilir. Merceklenme, Shapiro gecikmesi ve kütleçekim dalgaları gibi ölçülmüş eğrilik etkileri koşulsuz kabul edilir; Evertophy'de bunlar düz temel uzayın kendisinin bükülmesi olarak değil, Çekim Kuvveti'nin metrik izdüşümünün **okumaları** olarak anlaşılır. Genel göreliliğin gözlemsel sonuçlarının bu etkin geometriden geri kazanılması açık bir köprü problemidir.

Bağlam olarak, kanıt sayılmadan: kozmolojik veriler belirli modeller altında büyük ölçekte uzaysal eğriliği sıfıra yakın sınırlar — bu tam sıfırın kanıtı değildir; fizikte genel göreliliğin düz bir arka plan üzerinde alan kuramı olarak yazılabildiği de bilinmektedir.

## 9.3 İki faz, iki farklı neden

| Faz | Neden metrik yok |
|---|---|
| **c₀** | Zaman-öncesi; metrik **henüz kabul edilebilir değil** |
| **c⁺** | Cₘ madde desteği **çözülür**; $g_{\mu\nu}^{(C_m)} \to \bot$ |

$$\boxed{\;\text{İki faz AYNI NEDENLE metrik dışı DEĞİLDİR.}\;}$$

c₀'da metrik **henüz doğmamıştır**; c⁺'ta desteği **çözülmüştür**.

## 9.4 Metriğin yeniden inşası — iki ayrı yol

Bir fazdan Cₘ'ye geçişte eski metrik **taşınmaz**; yeni Cₘ durumu kendi metriğini yeniden kurar.

$$\mathcal{E}_m^{(0)} : (\Delta_{0m},\, X,\, \Theta_m) \to E^A{}_\mu, \qquad\qquad \mathcal{E}_m^{(+)} : (\Delta_{+m},\, X,\, \Theta_m) \to E^A{}_\mu$$

Bu iki haritanın **aynı olması gerekmez**. c₀'dan geliş geometriyi **yeni kurar**; c⁺'tan geliş madde desteğini **yeniden kazandırır**.

Her iki durumda:

$$g_{\mu\nu} = \eta_{AB}\,\mathcal{E}^A{}_\mu\,\mathcal{E}^B{}_\nu, \qquad\qquad \text{başarı koşulu: } \operatorname{rank}\mathcal{E}_m = 4$$

## 9.5 Kalan boşluk

$$\mathcal{E}_m^{(0)}[\cdot] = ?, \qquad \mathcal{E}_m^{(+)}[\cdot] = ?$$

Tetradın $X$ ve faz geçişinden nasıl türetileceği **açıktır**.

## 9.6 Dış fazlar için eylem yazılmaz

$$\boxed{\;\text{c}_0 \text{ ve c}^+ \text{ için 4-boyutlu eylem / Lagrange yoğunluğu YAZILMAZ.}\;}$$

Standart Cₘ-tipi eylem integrali $\sqrt{-g}\,d^4x$ ölçüsünü kullanır; bu ölçü dış fazlarda tanımlı değildir. Metriksiz ya da topolojik eylem biçimleri matematiksel olarak mümkündür; Evertophy dış fazlarda yalnız Cₘ-tipi 4B metrik eylemini dışlar. Evertophy'nin kullandığı eylemler **Cₘ'ye aittir**.

---

# BÖLÜM 10 — MADDE ONTOLOJİSİ

## 10.1 Üç fazda madde

| Faz | Madde durumu |
|---|---|
| **c₀** | Farklılaşma çözülmüş; **toplu tek-yapı** limiti |
| **Cₘ** | **Farklılaşmış madde**: parçacıklar, atomlar, yapılar |
| **c⁺** | Cₘ madde desteği **çözülür**; Cₘ madde türü kabul edilemez |

## 10.2 İki geçiş, iki farklı olay

$$\boxed{\;C_m \to c_0: \text{ farklılaşmış madde} \to \text{TOPLU TEK-YAPI LİMİTİ}\;}$$

$$\boxed{\;C_m \to c^+: \text{ Cₘ madde desteği} \to \text{ÇÖZÜLME / KABUL EDİLEMEZLİK}\;}$$

Bunlar **aynı olay değildir**. Birincisinde madde birleşir ve ayrım kaybolur; ikincisinde maddenin Cₘ'deki dayanağı ortadan kalkar.

## 10.3 Parçacık kavramı

Parçacık, Cₘ'de belirli okuma koşullarının ürettiği bir **projeksiyondur**. İki gözlemcinin farklı parçacık sayması ontolojik bir çelişki değildir.

**Dürüst not:** Bu, standart kuantum alan teorisinin operasyonel okumasıyla büyük ölçüde örtüşür. Evertophy burada yeni bir pozisyon üretmez; mevcut bir pozisyona **katılır**.

---

# BÖLÜM 11 — c⁺ VE KARANLIK SEKTÖR

## 11.1 İç ontolojik kimlik

$$\boxed{\;c^+ \;\equiv\; \text{KARANLIK MADDE} \;\equiv\; \text{KARANLIK ENERJİ}\;}$$

Evertophy'nin iç ontolojisinde bunlar **aynı varlıktır**. Karanlık madde ile karanlık enerji iki ayrı şey değil, aynı fazın Cₘ'den bakıldığında farklı görünen yüzleridir.

## 11.1a Karanlık madde ve karanlık enerji: kümelenmiş ve genişlemeyi sürdüren c⁺
Karanlık madde ile karanlık enerji iki ayrı gizemli bileşen değildir; **aynı c⁺ yapısının iki farklı görünümüdür**. Ayrım enerjetik değil, **yoğunluk ve topoloji** farkıdır.

| Görünüm | Cₘ'deki okuma |
|---|---|
| **Kümelenmiş c⁺** → karanlık madde | Madde kümeleriyle korele okunan c⁺ etkisi. Gözlenen ek kütleçekimsel etki — galaktik dönme eğrileri, kütleçekimsel merceklenme — bu görünümün Cₘ'deki okumasıdır |
| **Genişlemeyi sürdüren c⁺** → karanlık enerji | Madde baskısından uzak, düşük madde yoğunluklu bölgelerde okunan, genişlemeyle ilişkili c⁺ etkisi |

Arşivde bu iki görünüm için "tutuklu" ve "serbest" adlandırmaları da geçer; birincil terimler yukarıdakilerdir.

Bu okumanın beş inceliği vardır:

- **"Dış çeper" mekânsal bir kenar değildir.** "Dış" ontolojik anlamda kullanılır: madde baskısından uzak, kümelenmemiş görünüm. c⁺'ta üç boyutlu uzay çözünmüş olduğundan, c⁺'ın kendisinin mekânsal bir kenarda bulunması tanımlı değildir. Okumanın izotropi ve homojenlik ölçümleriyle nicel uyumu henüz gösterilmemiştir; bu, model ve gözlemle sınanacak bir koşuldur.
- **Ölçüm ile okuma ayrıdır.** Ölçülen şey genişlemenin **hızlanmasıdır** ve koşulsuz kabul edilir. Uzak galaksilerin ışıktan hızlı uzaklaşması standart kozmolojinin de sonucudur ve yerel bir ışık-üstü hareket değildir. c⁺'ın c-ötesi niteliğiyle genişleme arasındaki bağ Evertophy okumasıdır.
- **Kaynak ile görünüm ayrıdır.** c⁺'ın kendi fazında Cₘ tipi durgun kütle ve metrik yoktur; ama c⁺ kaynaklı etkinin Cₘ'deki görünümü kütleçekimsel ya da metrik bir okuma olabilir. Çekim Kuvveti ≠ kütleçekim ayrımı, kaynak faz ile Cₘ'deki ölçüm dili arasında uygulanır (1.2). Kapı-kilidi bu okumayı engellemez (13.1a).
- **Kimlik, eşit yoğunluk demek değildir.** c⁺ ≡ karanlık madde ≡ karanlık enerji ontolojik kimliği, gözlenen karanlık madde yoğunluğunun karanlık enerji yoğunluğuna eşit olduğu anlamına gelmez; okuma notasyonu gözlem katmanını tarif eder, kimliği değil.
- **Nicel mekanizma açıktır.** c⁺'tan karanlık madde ve enerjinin farklı basınç, kümelenme ve genişleme davranışlarına giden nicel köprü açık borçtur (EK K).

## 11.2 🔴 Kimlik ile mekanizma ayrılır

$$\boxed{\;\text{ONTOLOJİK KİMLİK, NİCEL GÖZLEMSEL TÜRETİM DEĞİLDİR.}\;}$$

Şunlar **ayrı ayrı türetilmedikçe** model/köprü düzeyindedir:

- "Kümelenmiş c⁺ tam olarak karanlık madde mekanizmasıdır"
- "Seyrelmiş c⁺ tam olarak karanlık enerji mekanizmasıdır"
- Rotasyon eğrileri, kütleçekimsel mercekleme, hızlanan genişleme için nicel açıklamalar

Kimlik iddiası ontolojiktir; **her bir gözlemsel olgu için ayrı bir türetim gerekir** ve bunların hiçbiri yapılmamıştır.

### UĞUR-ÖZGÜ KANON — c⁺ dark-sector tezahürleri ve kapalı devre

Üç fazın $U_0$ tarafından aynı kuruluşta birlikte doğumu korunur. Bu mimaride c⁺, **karanlık madde ve karanlık enerjinin aynı phase-entity'nin iki Cₘ tezahürü** olarak okunmasının kaynağıdır:

$$\boxed{\;c^+\equiv{\rm DM}\equiv{\rm DE}\quad\text{(ontolojik kimlik; Cₘ tezahürleri farklı)}\;}$$

**Kümelenmiş tür:** c⁺'ın galaktik/küme ölçeğinde kütleçekimsel olarak belirginleşen, **parçacık-olmayan** yapılanma rejimidir. "Kütleçekimle ışık hızı limitini aşmış" ifadesinin tür-güvenli okuması şudur:

$$\boxed{\;\text{Cₘ'nin }v<c\text{ madde-üyelik bandı artık uygulanabilir değildir}
\;\neq\;
v_{c^+}>c\text{ biçiminde intrinsic hız iddiası.}\;}$$

Bu okumanın ontolojik kısmı — c⁺'ın c-ötesi bir rejim olması ve Cₘ-tipi hızın orada uygulanamaması — 3.4'teki kilitli formülasyondur. Tarihsel "ışık hızı limitini aşmış" ifadesinin **nihai matematiksel temsili** ise onay bekleyen yorumdur; bu başlık altındaki kanon kaydı, ontolojik kimliği kapsar.

Dolayısıyla bu kayıt "ışık-üstü madde"yi geri getirmez; c⁺'ta Cₘ hız tipi, metrik ve madde desteğinin tanımsızlığını korur. Cₘ gözleminde görülen kütleçekimsel etki, c⁺ rejiminin **Cₘ okumasıdır**.

**Seyrelmiş tür:** aynı ontolojik c⁺ rejiminin kozmik ölçekte genişleme/karanlık-enerji tezahürüdür. Kümelenmiş ve seyrelmiş görünümler iki ayrı substance değil, aynı phase identity'nin farklı Cₘ readout rejimleridir.

**Kapalı-devre bağlantısı:** Bu kimlik, Bölüm 2.4'te Core-seed olarak tutulan çift-limit yapısının seyreltme koluyla birlikte okunur; tam cycle law ve matematiksel devre mekanizması V24'e rezerve kalır.

$$\boxed{\;\text{c⁺ ETKİ EDER; kontrol edilebilir bir kanal veya intrinsic-speed sektörü DEĞİLDİR.}\;}$$

## 11.3 c⁺'a Cₘ kavramları aynen taşınmaz

Doğru güncel kısıt:

$$\boxed{
\mathrm{supp}_{C_m}(\mathrm{matter})\to\varnothing
}
$$

Bu nedenle c⁺, Cₘ'nin parçacık/rest-mass, metrik uzunluk, fiziksel süre veya hız tiplerini **aynı anlamla** taşıyan bir sektör olarak okunmaz.

Tarihsel K2'deki soyut `Dim.mass` izin kaydı ayrıca provenance olarak saklanır; bu kayıt güncel c⁺ içinde bağımsız bir Cₘ-tipi mass observable tanımlamaz.

## 11.4 Kozmolojik yönelim

Kozmik çağ ilerledikçe Cₘ-okumasında c⁺ bileşeninin katkısının artması, çerçeve içinde **meşru bir yönelimdir**.

$$\boxed{\;\text{Bu bir YÖNELİM kaydıdır — nicel bir kozmolojik model DEĞİLDİR.}\;}$$

Ve ifade dikkatli kurulmalıdır: c⁺'ın kendisi "zamanla değişmez" — Cₘ okumasında payı büyür.

## 11.4a $c^+$ ile $U_+$ karıştırılmaz

$c^+$ bir **fazdır**, $U_x$'in içindedir. $U_+$ ise global **çözünme kutbudur**, $U_x$'in dışındadır (Bölüm 2.6). Kozmik çağla c⁺ payının artması bir faz-seviyesi okumasıdır; $U_+$'a yaklaşmak global bir koşuldur.

## 11.5 Kapalı devre

| Sıra | Gerekçe |
|---|---|
| **Temel** | **Akademik-bilimsel sınır** — metafizik yorumu önleme |
| İkincil | Gözlemsizlik |

$$\boxed{\;c^+ \text{ ETKİ EDER ama SİNYAL KANALI DEĞİLDİR: kontrol edilebilir, bilgi taşıyan bir bağ kurulamaz.}\;}$$

## 11.6 c⁺ bir kehanet kaynağı değildir

$$\boxed{\;c^+ \text{ ARŞİVİNE ERİŞİM} \;\neq\; \text{Cₘ GELECEĞİNİ OKUMAK.}\;}$$

c⁺'ta zaman yoktur; dolayısıyla "gelecek" de yoktur.

---

## 11.7 Kozmolojik köprü adayları — model/program düzeyi

c⁺ = DM = DE iç ontolojik kimliği Core'dur; bunun Cₘ gözlemlerine hangi quantitative bridge ile yansıdığı ise açık programdır.

| Aday mekanizma | Gerekli türetim | Gözlenebilir hedef | Kill koşulu |
|---|---|---|---|
| Ölçek-bağımlı etkin gravity readout'u | $X$/faz koşullarından $\kappa_g(\text{ölçek})$ | Hubble-gerilimi benzeri ölçek farkları | Parametre fit'i olmadan belirgin band üretilemezse |
| c⁺ dark-sector readout'u | c⁺→Cₘ lensing/dynamics map | galaksi/küme dinamiği ve mercekleme | Baryonik+bridge model gözlemi birlikte karşılayamazsa |
| Seyrelme / kozmik eylemsizlik | devre/limit yapısından quantitative law | hızlanan genişleme readout'u | yalnız slogan düzeyinde kalırsa |
| Redshift'in phase-level yorumu | standard redshift ilişkisini bozmadan ek neden katmanı | spektral/kozmolojik consistency | GR/QFT limitini yanlış üretirse |

$$\boxed{
\text{“uyumlu olabilir”}
\neq
\text{“çözdü / doğruladı”}
}
$$

Hubble gerilimi, Bullet Cluster veya hızlanan genişleme gibi başlıklar current evidence değil, **bridge falsification programı** olarak ele alınır.


## 11.8 Karanlık madde arayışının paradigma eleştirisi — kayıt


Çerçevenin karanlık madde deneylerine karşı konumu gözlük analojisiyle özetlenmiştir:

$$\boxed{\;\text{"Onlar görüntüyü bozan görünmez nesne arıyor; biz ortamın kırıcılık indisinin değişken olduğunu söylüyoruz."}\;}$$

Bu bir paradigma eleştirisidir, deneysel sonuç reddi değildir. Deney programlarının null sonuçları Evertophy **üzerine kısıtlardır**: hiçbir null sonuç c⁺ = DM = DE kimliğini kanıtlamaz; kimlik ancak pozitif bir köprü öngörüsüyle sınanabilir (Bölüm 11.7). DM deneylerinin çeşitliliği ("karanlık madde hayvanat bahçesi" kaydı) tek parçacık adayının zayıfladığını gösteren gözlemsel bağlam olarak korunur — yine de bağlam, kanıt değildir.

## 11.9 Fantom sınırı geçişi okuması

*Kırmızıya kayma alanı:* fiziksel alan $z>-1$'dir; genişlemenin sınırsız geleceği $z\to-1^+$'dır. $z\to-\infty$ yalnız matematiksel uzantıdır.


Dark-energy denkleminin durumunun w = −1 çizgisini geçmesi (fantom bölgesi), çerçevede "c⁺ payının Cₘ okumasındaki rejim değişimi" olarak okunmaya adaydır. Literatürde phantom-crossing gözlemleri destekleyici bağlam olarak izlenir; nicel eşleme yoktur.

$$\boxed{\;\text{"Uyumlu olabilir" ≠ "çözdü / doğruladı" — Bölüm 11.7 hükmü burada da geçerlidir.}\;}$$

---

### Denklem seti — A1 — lojistik okuma modeli

**Ne işe yarar, neden gerekli?** $X$'in kırmızıya kaymaya göre lojistik bir izdüşümünden karanlık enerji durum denklemi $w(z)$ türetmeye çalışan **model**.

$$w = -1 + \frac{(1+z)s}{3\Delta}\cdot\frac{(T - X_{\min})(X_{\max} - T)}{T(1-T)}\cdot\big[p(1-T) - qT\big]$$

$$\text{Karşı-örnek } (X_{\min}=0, X_{\max}=1, s=p=q=1):\quad w = -1 + \tfrac{(1+z)(1-2X)}{3},\quad w(10) = -4.66633374896$$

$$z \to +\infty:\ w/z \to -\tfrac13, \qquad z \to -\infty:\ w/z \to +\tfrac13, \qquad \text{her iki uçta } w \to -\infty$$

Standart tanımda $1+z=a_{\rm ref}/a$, $a>0$ olduğundan fiziksel alan $z>-1$'dir ve genişlemenin sınırsız geleceği $z\to-1^+$'a karşılık gelir; $z\to-\infty$ yalnız matematiksel bir uzantıdır.

$$\text{Doğru koşul } (0 \leq u < v \leq 1,\ s>0,\ p,q \text{ sonlu}):\quad (u > 0 \lor p = 0) \wedge (v < 1 \lor q = 0) \;\Rightarrow\; w \to -1 \text{ iki uçta}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $X(z)$ | Lojistik okuma: $1/[1 + e^{-s(z - z_t)}]$ |
| $T$ | $X_{\min} + \Delta X(z)$, $\Delta = X_{\max} - X_{\min}$ |
| $s$, $z_t$ | Diklik ve geçiş kırmızıya kayması |
| $p$, $q$ | Üstel ağırlık parametreleri |
| $w$ | Durum denklemi parametresi |

**Statü:** Koşullu MODEL · koşulsuz çift asimptot ❌ · K1v2 çekirdek ❌ · MINILAB-4 kaynak türetimi ⏸


# BÖLÜM 12 — EŞİK VE YAPI BANTLARI

## 12.1 İki kanallı eşik

### Kütle kanalı

$$\text{yıldız kütlesi} \;\to\; \text{kritik kütle eşiği} \;\to\; \text{doygunluk} \;\to\; \text{kara delik oluşumu}$$

Kara delik oluşumu dış fizikte yerleşik bir olgudur; Evertophy'deki kütle kanalı için nicel eşik ve geçiş yasası henüz türetilmemiştir. Kara delik ≡ c₀, bu mekanizmanın sonucu olarak sunulmayan, yazarın ontolojik tanımıdır (3.2).

Kütle arttıkça sistem c₀ rejimine yaklaşır; bu yaklaşımın nicel biçimi model düzeyindedir.

### Enerji kanalı

$$\text{ışıma} \;\to\; c^+ \text{ bandına yakınsama} \;\to\; \text{enerji tükenişi} \;\to\; \text{seyrelme}$$

$$\boxed{\;Enerji kanalı MODEL/KAVRAMSAL düzeydedir.\;}$$

İki kanal da keskin bir sınır değil, **geçişli bir bant** olarak çalışır.

## 12.2 Bant merdiveni — model/harita adayı

Aşağıdaki yerleşimler current core'un zorunlu sayısal phase assignment'ı değildir; arşivdeki **harita/model adaylarıdır**.

| Nesne | Harita yerleşimi |
|---|---|
| Kahverengi cüce | Cₘ bandının hemen öncesi |
| Nötrino-magnetar | c₀ ön bölgesi |
| Elektron-nötrino yapıları | c⁺ köşe bandı |

**Bölüm 3.7'nin uyarısı geçerlidir:** bunlar **harita konumudur**, faz üyeliği değil.

## 12.2a Yoğunluk spektrumu — yoğunluk-rejim analojisi

Aşağıdaki sıra ölçülmüş evrensel yoğunluk eşikleri değil, **ordinal bir yapı/yoğunluk analojisidir**:

| Yoğunluk-rejim etiketi | Tarihsel yapı eşlemesi |
|---|---|
| **Nihai** | kara delik çekirdeği |
| **Süper** | nötron yıldızı çekirdeği |
| **Çok yüksek (“Kristal”)** | atom çekirdeği |
| **Yüksek (“Sıvı”)** | elektron bulutu / atomik madde |
| **Orta (“Gaz”)** | galaksi halesi; karanlık-madde Cₘ okumasıyla ilişkili |
| **Düşük (“Buhar”)** | galaksiler arası boşluk |

$$\boxed{\;\text{Bu etiketler faz üyeliği değildir; yalnız yoğunluk-rejim analojisidir.}\;}$$

Bölüm 3.7'nin “harita konumu ≠ faz üyeliği” kuralı burada da geçerlidir. Bu tablo sayısal eşik üretmez ve “Kristal/Sıvı/Gaz/Buhar” sözcüklerini literal madde fazları olarak kullanmaz.

## 12.3 Yapı bandı

Gezegen, atom, elektromanyetik ve biyolojik yapıların phase-parameter landscape içinde farklı relation/constraint'lerle temsil edilmesi mümkündür. Bu, nesnelerin aynı anda üç fazın üyesi olduğu anlamına gelmez.

$$\boxed{\;\text{Harita konumu}\neq\text{faz üyeliği.}\;}$$

Cₘ doğrudan measurement/readout fazıdır; diğer fazlarla ontolojik relation bulunması "Cₘ saf değildir" şeklinde zorunlu mixture ontology üretmez.

### UĞUR-ÖZGÜ KANON — Cₘ yapı bandı ve iç bölge

$$\boxed{\;\text{Gezegenler, atomlar, elektromanyetik yapılar ve biyolojik yapılar; Cₘ üyeliğinde kalırken üç fazla sürekli ilişki/etkileşim kısıtları taşıyabilir.}\;}$$

Bu yapıların faz-parametre peyzajındaki doğal çalışma alanı, tek bir köşeye indirgenmeyen **iç bölgedir**. İç bölge, $X$'in farklı özellik ailelerini birlikte çözmek zorunda olduğu türetim/çözümleme alanıdır:

$$\boxed{\;\mathcal S_{\rm structure}\in\mathcal D_{\rm inner}
\quad\Longrightarrow\quad
X\text{, }c_0/C_m/c^+\text{ relation ve kısıtlarını birlikte çözer.}\;}$$

"Üç fazla sürekli etkileşim" ifadesi **eşzamanlı üç-faz üyeliği** değildir. Faz üyeliği ile fazlar arası kısıt/okuma ilişkisi ayrıdır; Bölüm 3.7'nin "harita konumu ≠ faz üyeliği" koruması aynen korunur.

## 12.4 Nükleer alanda katman ayrımı

| Katman | Ne | Kim açıklıyor |
|---|---|---|
| **Zarf (1B)** | Bağlanma enerjisi eğrisinin genel şekli | Sıvı-damla + Evertophy modülasyonu |
| **Kabuk (2B)** | Sihirli sayılar, kabuk kapanmaları | Kabuk modeli — **dokunulmaz** |

$$\boxed{\;\text{Evertophy ZARFI modüle eder — KABUK KONUMLARINI İCAT ETMEZ.}\;}$$

**Neden kritik?** Monoton bir zarf hiçbir yerde tümsek öngörmez. "Kabuk etkisi yok" denirse, bu ölçülmüş kapanmaları da inkâr eder. Doğru iddia, kabukların **varlığını** değil, **güçlerinin nasıl modüle olduğunu** konu edinir.

---


## 12.5 Tam yoğunluk spektrumu tablosu (model adayı)


Bölüm 12.2a'nın genişletilmiş hâli. Etiketler yoğunluk-rejim analojisidir; literal madde fazları veya faz üyeliği değildir.

| Yoğunluk-rejim etiketi | Tarihsel yapı eşlemesi | Not |
|---|---|---|
| **Nihai** | kara delik çekirdeği | c₀ (kara delik ≡ c₀, yazar tanımı); tablo sayısal eşik ya da genel üyelik ölçütü üretmez |
| **Süper** | nötron yıldızı çekirdeği | kinetik ayrışma bölgesi |
| **Çok yüksek ("Kristal")** | atom çekirdeği | kabuk yapısı burada |
| **Yüksek ("Sıvı")** | elektron bulutu / atomik madde | — |
| **Orta ("Gaz")** | galaksi halesi | karanlık madde Cₘ okumasıyla ilişkili |
| **Düşük ("Buhar")** | galaksiler arası boşluk | c⁺ payının büyüdüğü bölge olarak okunabilir |

$$\boxed{\;\text{Tablo sayısal eşik üretmez; Bölüm 3.7'nin "harita konumu ≠ faz üyeliği" kuralı geçerlidir.}\;}$$

## 12.6 Kinematik ayrışma ilkesi


Yerel laboratuvar hızı, tek başına faz üyeliğini belirlemez: bir nesnenin laboratuvarda ölçülen kinematik durumu ile faz üyeliği ayrı okunur. Cₘ'nin $0<v<c$ bandı ise ontolojik madde-üyelik hükmüdür (3.3); bu hükümdeki üyelik değişkeni sıradan laboratuvar koordinat hızıyla özdeş değildir. Üyelik değişkeninin operasyonel tanımı ve yerel kinematikle bağı açıktır.

## 12.7 Hız ayıklaması hipotezi (tarihsel)


Erken katmanda "fazlar hıza göre ayrışır" hipotezi denenmiştir. Güncel çekirdek bu ayrışmayı bant diliyle yazar (Bölüm 3.3) ve ek ayıklama mekanizması önermez. Hipotez tarihsel olarak korunur.

## 12.8 Atom çekirdeği = QGP faz geçişi okuması


"Atom çekirdeği, quark-gluon plazmasından c_m-yönüne geçişin doygunluk ürünüdür" okuması model adayıdır. QGP literatürü (yüksek sıcaklık faz geçişleri, lattice sonuçları) bağlam olarak izlenir; nicel köprü kurulmamıştır.

---

# BÖLÜM 13 — FAZ GEÇİŞLERİ

## 13.1 Kapı ve damga

$$\boxed{\;\text{KAPI ÇİFT YÖNLÜDÜR} \qquad \text{DAMGA TEK YÖNLÜDÜR}\;}$$

Tersinmezlik faz kapısından değil, **mühürleme eyleminden** gelir.

## 13.1a Kapı, taşıma ve kilit

Kapı, iki faz arasında geçişin mümkün olduğunu söyler. Ama bir kapının varlığı, her niceliğin o kapıdan geçebileceği anlamına gelmez. Bu iki şey ayrı tutulmalıdır:

$$\boxed{\;\text{Kapı} \;\neq\; \text{Taşıma izni}\;}$$

Kapı yapısı tam bir üçgendir: her faz diğer ikisiyle kapı ilişkisindedir (c₀↔Cₘ, Cₘ↔c⁺, c₀↔c⁺). Bir niceliğin bir kapıdan taşınabilmesi içinse, o niceliğin kapının **iki ucundaki fazda da** içsel olarak tanımlı olması gerekir.

Buradan biçimsel olarak kanıtlanmış önemli bir sonuç çıkar — kodlanmış biçimsel sistem kapsamında, çekirdek ontolojinin bir teoremi olarak. Zaman, üç boyutlu uzay, metrik, içsel hız, ışık hızı sınırı ve durgun kütle yalnız Cₘ'de tanımlıdır; bu yüzden **hiçbir kapıdan taşınamazlar**. Genel hâli şöyledir:

$$\boxed{\;q \text{ kapı-kilitlidir} \;\Longleftrightarrow\; q \text{ en fazla bir fazda içsel olarak tanımlıdır}\;}$$

Bir niceliğin Cₘ'ye özgü nicelikler listesinde yer almaması, onun başka fazlardaki içsel tanımını ya da belirli bir faz çifti için taşıma iznini belirlemez; biçimsel izin ile fiziksel gerçekleşme ayrıca ayrılır. Bu kilit, c⁺ kaynaklı bir etkinin Cₘ'de **okunmasını** engellemez. Taşıma ile okuma farklı şeylerdir: c⁺'tan Cₘ'ye bir nicelik taşınmaz, ama c⁺ kaynaklı bir etki Cₘ'de, Cₘ'nin kendi dilinde ölçülebilir (15.1a). Kapılardan yalnız faza bağlı olmayan etiketler geçer. $X$'in fazlar arasındaki koordinasyonu ise ayrı bir meta-geçiştir ve fiziksel taşıma sayılmaz.

*Okuma kuralı:* Belgenin diğer bölümlerinde "geçiş", "etki" ya da "kapıdan geçen" ifadeleri üç ayrı kavrama göre okunur: **kapı** (yapısal izin), **taşıma izni** (niceliğe özgü) ve **okuma** (c⁺ kaynaklı etkinin Cₘ'de gözlenmesi — taşıma değildir).

### Denklem seti — Kapı, taşıma izni ve kapı-kilidi

**Ne işe yarar, neden gerekli?** Fazlar arası **geçiş** (kapı) ile bir niceliğin fazlar arasında **taşınması** aynı şey değildir. Eski `adjacent` fonksiyonu c₀↔c⁺ kapısını yok sayıyordu; eski K2 "kütle c⁺'ta taşınır" diyordu.

$$\text{GateLocked}(nat) \iff \text{AtMostOneNative}(nat) \qquad \text{(tam K3 altında)}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| `GateRelated a b` | $a \neq b$ — **tam K3** |
| `NativeOK q p` | $q$ niceliği $p$ fazında içsel olarak tanımlı mı |
| `TransportPermission q a b` | `Gate ∧ NativeOK q a ∧ NativeOK q b` |
| `CmOnlyKind` | Durgun kütle, zaman, 3B uzay, metrik, içsel hız, $c$ sınırı |
| `GateLocked nat` | $\forall a\,b,\ \neg\,\text{Transport}$ |
| `AtMostOneNative nat` | $\forall x\,y,\ nat\,x \to nat\,y \to x = y$ |

**Statü:** ★✅ kapı ≠ taşıma, kapı-kilidi · eski tanık-varlığı genellemesi ❌


## 13.2 Geçiş kriteri

$X$ tek bir skaler olmak zorunda olmadığı için genel geçiş koşulu bir scalar $X_{\rm crit}$ eşitliğiyle tanımlanmaz. Type-safe çekirdek ifade:

$$\boxed{\;(X,\Theta_{ij}) \in \mathcal D_{ij}^{\rm adm} \;\Longleftrightarrow\; \mathcal A_{ij}(X,\Theta_{ij})=1\;}$$

Burada $\Theta_{ij}$ geçişe özgü bağlam/koşul ailesini, $\mathcal D_{ij}^{\rm adm}$ ise ilgili kenarın admissible domain'ini temsil eder.

Skaler ya da bant gerçeklemesi seçilen modellerde, $X$'in kendisi yerine o kenara özgü okuma $\xi_{ij}$ kullanılır:

$$\xi_{ij} \in [\xi_{ij}^{\rm crit,-},\ \xi_{ij}^{\rm crit,+}] \ \ (\text{nokta okuma}) \qquad B_{\xi_{ij}} \cap [\xi_{ij}^{\rm crit,-},\ \xi_{ij}^{\rm crit,+}] \neq \varnothing \ \ (\text{bant okuma})$$

özel durum olarak kullanılabilir. Bu, $X$'in ontolojik tanımı değildir.

Vurgu **"izinli"** üzerinedir: izinlilik geçişi **zorunlu kılmaz**.

## 13.3 Kenar sınıflandırması

| Kenar | Damga taşıyıcı mı | Cₘ'de gözlenebilir mi |
|---|---|---|
| $\Delta_{0m}$ | Evet | Evet |
| $\Delta_{+m}$ | Evet | Dolaylı |
| $\Delta_{0+}$ | Hayır | Hayır |

$\Delta_{0+}$ damga üretmez çünkü Cₘ'ye değmez — kayıt Cₘ-temaslı kenarlarda açılır.

### Kenar taşıyıcılığı ≠ yönlü emisyon

$$\boxed{\;\text{Bir kenarın DAMGA TAŞIYICI olması, HER İKİ YÖNDE damga ürettiği anlamına GELMEZ.}\;}$$

Yön semantiği ayrı bir konudur ve bazı yönler için henüz kesinleşmemiştir.

Özellikle formal pakette `stampOf(c^+\to C_m)=\kappa_{+m}` biçimindeki damga taşıma kaydı ile ontolojik arşive-yazma yönünün $C_m\to c^+$ olarak okunması aynı semantik katman olmak zorunda değildir. Bu sürümde koruma cümlesi şudur:

$$\boxed{\;\kappa_{+m}\text{'in taşındığı yön bilinçli olarak açıktır; damga taşıyıcılığı yön semantiğini tek başına belirlemez.}\;}$$

Formal kod bu borcu kapatmak amacıyla sessizce ters çevrilemez; ontoloji de yalnız mevcut kod yönünden türetilemez.

## 13.4 Üç farklı "yokluk" — ve doğru formalizasyon

| Kavram | Anlamı |
|---|---|
| **Geçiş yok** | Kenar mevcut değil |
| **Damgasız geçiş** | Kenar var, geçiş var, damga üretilmedi |
| **Cebirsel birim** | Damga cebirinde nötr eleman |

### 🔴 Doğru ayrım

Semantik düzeyde "damga yok" ile cebirsel düzeyde "birim" **farklı** şeylerdir. Ama bunları iki ayrı haritayla ifade etmek gerekir:

$$\boxed{\;\text{emittedStamp}(T_{0+}) = \texttt{None} \qquad\qquad \Sigma(T_{0+}) = e\;}$$

Neden? Çünkü $\Sigma : \text{Geçiş} \to M$ bir monoide gider; monoid `None` içermez. Damga **emisyonu** ayrı bir haritadır (`Option Stamp`), damga **cebirsel görüntüsü** ayrı.

$$\boxed{\;e = \texttt{NoStamp} \text{ biçiminde bir TİP-DÜZEYİ ÖZDEŞLİK KURULMAZ.}\;}$$

## 13.5 $\Delta_{0+}$ için güvenli aday

Bu kenar için en güvenli formal aday:

$$\text{ArşivEtkisi} = \text{Değişiklik yok}, \qquad\qquad \text{KoordinasyonEtkisi} = X\text{-koordinasyonu}$$

$$\boxed{\;\text{c}_0 \leftrightarrow c^+ \text{ için doğrudan HAM ARŞİV yazma/okuma İTHAL EDİLMEZ.}\;}$$

Doğrudan arşiv erişimi c₀'ı tarih-duyarlı hâle getirirdi — bu, zaman-öncesi niteliğiyle çelişir.

Ve bu koordinasyon yapısı **$U_0$ ile özdeşleştirilmez**.

Formal adayın en zayıf ve güvenli arayüzü bir uyumluluk ilişkisidir:

$$\boxed{\;\mathcal R^X_{0+}\subseteq \mathcal X_0\times\mathcal X_+\;}$$

Buradaki $\mathcal X_0$ ve $\mathcal X_+$ iki ayrı temel $X$ değildir; tek $X$ üst-çözücüsünün faz-indexli admissible sunum uzaylarıdır.

İç realizasyon için bir span/fiber adayı kullanılabilir:

$$\boxed{\;\mathcal X_0 \xleftarrow{p_0}\mathfrak F^X_{0+}\xrightarrow{p_+}\mathcal X_+\;}$$

$\mathfrak F^X_{0+}$ yeni bir faz değildir, $U_0$ değildir ve fiziksel zaman taşımaz. Bir transition-witness/correspondence yapısıdır.

İlişkide kaynak başına tekil hedef kanıtlanırsa partial map elde edilebilir. Çift yönlü gate tek başına:

$$F^X_{+0}=(F^X_{0+})^{-1}$$

sonucunu vermez; exact inverse/bijection ayrıca kanıt gerektirir.

---


## 13.6 $c_0\leftrightarrow c^+$ için X-koordinasyon formal adayı

*Statü:* Bu bölüm, c₀ ile c⁺ arasındaki belirli ilişki ve lif gerçeklemesi için bir **biçimsel adaydır**. $X$'in genel meta-koordinasyonu (4.6) kesindir.

Direct edge'nin current güvenli semantiği, raw archive transport veya matter transport değil, **X-düzeyi compatibility/coordination** olarak formalize edilebilir:

$$\boxed{
\mathcal R^X_{0+}
\subseteq
\mathcal X_0\times\mathcal X_+
}$$

Buradaki $\mathcal X_0$ ve $\mathcal X_+$, ayrı fundamental X'ler değil, **tek $X$'in phase-indexed admissible presentation/context kümeleridir**.

Relation için internal witness-space realizasyonu:

$$\boxed{
\mathcal X_0
\xleftarrow{p_0}
\mathfrak F^X_{0+}
\xrightarrow{p_+}
\mathcal X_+
}$$

olarak düşünülebilir.

Bu yapıda:

- $\mathfrak F^X_{0+}$ **yeni faz değildir**;
- $U_0$ değildir;
- fiziksel zaman veya rate parametresi taşımaz;
- her kaynak state için unique target kanıtlanırsa partial function'a yükseltilebilir;
- bidirectional gate, $F_{+0}=F_{0+}^{-1}$ exact bijection'ını otomatik vermez.

Aynı fully specified state altında X'in deterministic resolution kuralı, **resolver output'unun işlevselliğini** destekler; fakat phase transition'ın tersinirliğini kanıtlamaz.

# BÖLÜM 14 — DAMGA CEBİRİ VE ARŞİV

## 14.1 Mühürleme

$$\boxed{\;\text{MÜHÜRLEME} = \text{bir kaydın GERİ ALINAMAZ biçimde yazılmasıdır.}\;}$$

Mühürleme Cₘ'nin içinde değil, **Cₘ-temaslı eşik arayüzlerinde** gerçekleşir.

## 14.2 Damga monoidi

$$M = \big\langle s,\; s',\; \kappa_{0m},\; \kappa_{+m} \;\big|\; \kappa_{0m}^2 = \kappa_{0m},\;\; \kappa_{+m}^2 = \kappa_{+m} \big\rangle$$

İki ayrı kilit üreteci olması önemlidir: hangi kenardan gelindiği bilgisi korunur.

### Neden monoid, neden grup değil

$$\boxed{\;s^{-1} \text{ YOKTUR — çünkü SİLME PRİMİTİFİ yoktur. Tersinirlik yasağı, } M\text{'nin grup olmamasının KENDİSİDİR.}\;}$$

### İdempotentler

$$\mathrm{Idem}(M) = \{e,\; \kappa_{0m},\; \kappa_{+m}\}$$

Kanıt fikri: serbest sektörde bir kelimenin karesi kelimeden uzundur, dolayısıyla $ww = w$ olamaz. Bu sınıflandırma biçimsel olarak kanıtlanmıştır: $w\cdot w = w$ ancak ve ancak $w \in \{e,\ \kappa_{0m},\ \kappa_{+m}\}$.

### Yasaklı bağıntılar

| Bağıntı | Neden yasak |
|---|---|
| $ss' = s's$ | Kelime sırası = olay sırası; silinemez |
| $\kappa s = \kappa$ | Kilit sonrası kayıt eklenemez olurdu |
| $s^N = \kappa$ | Serbest damga kendiliğinden kilide dönüşemez |

### Grup tamamlaması — ve yorumu

Grupta tersinirlik olduğundan kilitler tamamlamada ölür; geriye serbest grup kalır.

$$\boxed{\;\text{BU, FİZİKSEL TERSİNİRLİK ANLAMINA GELMEZ. Grup tamamlaması bir CEBİRSEL ARAÇTIR.}\;}$$

Kilitlerin cebirsel tamamlamada sıfırlanması, arşivde bir kaydın silinebileceğini **ima etmez**.

Ayrıca kilitleri tek bir soğurucu sıfıra çökertmek **reddedilir** — bu, kaynak ve sıra bilgisini siler.

Sunumun yalnız aşağıdaki idempotent bağıntılarla kapalı kaldığı varsayımında:

$$M=\langle s,s',\kappa_{0m},\kappa_{+m}\mid \kappa_{0m}^2=\kappa_{0m},\;\kappa_{+m}^2=\kappa_{+m}\rangle$$

evrensel grup tamamlamasında idempotentler birime gider ve:

$$\boxed{\;G_{\rm univ}(M)\cong F_2\;}$$

elde edilir. Abelianization/universal abelian group completion için:

$$\boxed{\;K(M)\cong \mathbb Z^2\;}$$

sonucu çıkar. Bu sonuçlar **sunum kapalı kaldığı sürece koşulludur**; gelecekte yeni bağıntı eklenirse yeniden denetlenir.

### Anti-damga yoktur

Bir damganın "negatifi" fiziksel bir nesne olarak **yoktur**. Cebirsel tamamlamada türetilebilir; bu bir **muhasebe aracıdır**.

### Damga cebirinin kanıt durumu

Damga cebirinin temel özellikleri sonlu örneklemenin ötesinde, genel olarak kanıtlanmıştır: birleşme özelliği, yeniden yazma sürecinin her zaman sonlandığı, her kelimenin tek bir normal forma ulaştığı ve farklı indirgeme yollarının aynı sonuca vardığı (konfluans).

Bir inceliğe dikkat etmek gerekir: konfluans, **olayların yer değiştirebileceği** anlamına gelmez. Olay sırası sabit tutulduğunda farklı gruplamalar ve indirgeme yolları aynı normal forma ulaşır; ama genel olarak $ab \neq ba$'dır ve olayların sırası sonucu değiştirir. Arşiv, tarihin sırasını korur.

### Denklem seti — Damga monoidi — arşiv cebiri

**Ne işe yarar, neden gerekli?** Fazlar arası geçişler arşive "damga" olarak yazılır. **Olay sırası sabit tutulduğunda**, farklı parantezlemeler ve izinli yeniden-yazma sıraları aynı normal forma ulaşmalıdır — yoksa aynı tarihçenin arşiv karşılığı belirsiz olur. bu, olayların **yer değiştirmesinden** bağımsızlık değildir; genel olarak $ab \neq ba$ ve olay sırası sonucu değiştirir.

$$u\,\kappa\,\kappa\,v \;\to\; u\,\kappa\,v \qquad (\kappa \in \{\kappa_{0m}, \kappa_{+m}\})$$

$$w \cdot w = w \iff w \in \{e,\ \kappa_{0m},\ \kappa_{+m}\}$$


**Grup tamamlama:** $G(M) \cong F_2$ ($s, s'$ üzerinde serbest grup), $K_{ab}(M) \cong \mathbb{Z}^2$ — belirtilen kapalı sunum için; kapı damgaları grup tamamlamada birime gider. Ayrıca `None ≠ Some(e)`: **damga üretilmemesi** ile **birim damga** farklıdır. Statü ✅ (sunum kapsamıyla).

**Semboller**

| Sembol | Anlam |
|---|---|
| $s$, $s'$ | Geçiş üreteçleri |
| $\kappa_{0m}$, $\kappa_{+m}$ | Kapı damgaları (idempotent adayları) |
| $w$ | Kelime (üreteç dizisi) |
| $\cdot$ / `mulW` | Normalize edilmiş birleştirme |
| $\to$, $\to^*$ | Tek adım / çok adım yeniden yazma |

**Statü:** ★✅ çekirdek arşiv cebiri


## 14.3 Ağırlık fonksiyonu

Bir damganın ne kadar daralttığı, aralık oranıyla ölçülebilir. Ardışık damgalarda oranlar çarpılır, logaritmada toplanır — yani bir homomorfizma elde edilir.

### Kilit için sonuç

Durumdan bağımsız toplamsal bir karakter $\omega$ için $\kappa^2=\kappa$ bağıntısı $\omega(\kappa)=0$ sonucunu verir; bu elle atanmaz, **türetilir**. Ancak bu sonuç, bağımsız aralık uçlarından kurulan kapsama aralığının $[0,0]$ olmasını ya da fiziksel bir kilidin ilk uygulamada hiçbir maliyet üretmemesini gerektirmez. Üç nesne ayrıdır: **kesin karakter** (durumdan bağımsız, toplamsal), **kapsama aralığı** (bağımsız uçlardan kurulur; kesin karakter değeri $\omega(\kappa)=0$'ı geçerli biçimde kapsayan bir $\Omega_{\rm enc}(\kappa)$ için $0\in\Omega_{\rm enc}(\kappa)$ gerekir, ama aralığın $[0,0]$ olması gerekmez) ve **duruma bağlı fiziksel daralma maliyeti**. Örneğin $P(W)=\min(W,1)$ idempotenttir, ama $W=2$ durumunda ilk uygulama $\ln 2$ maliyet üretir, ikincisi üretmez. Bir matematiksel maliyet modeli şöyle yazılabilir — mühürlemenin fiziksel yasası olarak atanmış değildir:

$$C(T_2\circ T_1,s)=C(T_1,s)+C(T_2,T_1(s)),\qquad C(T,s)=\ln W(s)-\ln W(T(s)),\quad W>0$$

### 🔴 Karakter ≠ fiziksel kilit

$$\boxed{\;\text{Ağırlığın sıfır olması, kilidin FİZİKSEL OLARAK ETKİSİZ olduğu anlamına GELMEZ.}\;}$$

Bu yalnız, kilidin toplamsal karakterin çekirdeğinde olduğunu söyler. Kilit hâlâ sonraki bileşimleri değiştirebilir ve durum uzayını kabalaştırabilir.

**Oran yönü korunmalıdır:** ağırlık, "önceki genişlik / sonraki genişlik" yönünde tanımlanır; ters çevrilirse işaret bozulur.

Pozitif genişlikler için temel convention:

$$\boxed{\;\Omega(m)=\log\frac{W_{\rm before}}{W_{\rm after}}\;}$$

Ortak bir durum $s$'de **kesin karakter** bağımlılığı korur ve tam olarak toplamsaldır:

$$\boxed{\;\omega_{AB}(s)=\ln W_A(s)-\ln W_B(s)\;}\qquad \omega_{AB}(s)+\omega_{BC}(s)=\omega_{AC}(s)$$

Bağımsız uç değerlerden kurulan aralık ise kesin karakter değil, bir **kapsama aralığıdır** ($W_A$ "önce", $W_B$ "sonra"):

$$\boxed{\;\Omega_{\rm enc}(m)=\left[\log\frac{W_A^-}{W_B^+},\ \log\frac{W_A^+}{W_B^-}\right]\;}\qquad \Omega_{\rm enc}(uv)\subseteq\Omega_{\rm enc}(u)\oplus\Omega_{\rm enc}(v)$$

Örneğin $W_A(s)=W_B(s)=s$, $s\in[1,2]$ için ortak durumda $\log(W_A/W_B)=0$ iken kapsama aralığı $[-\log2,\ \log2]$'dir. Tam toplamsallık ve idempotentte sıfırlanma yalnız kesin karakter için geçerlidir; kapsama aralığı için yalnız, kesin değeri geçerli biçimde kapsayan bir aralıkta $0\in\Omega_{\rm enc}(\kappa)$ söylenebilir; bu kapsama sonucu duruma bağlı fiziksel maliyet aralığına otomatik taşınmaz. Logaritma için genişliklerin kesin pozitifliği gerekir.

Kilit etkisi ayrı bir idempotent temsil/projektör ile taşınabilir:

$$\Pi_\kappa:\mathcal B\to\mathcal B,\qquad \Pi_\kappa^2=\Pi_\kappa.$$

Böylece kesin karakterin idempotentte sıfırlanması ($\omega(\kappa)=0$) fiziksel lock etkisini ortadan kaldırmaz.

### Hesaplama notu

Aralık aritmetiği **kesin sayılarla** yapılmalıdır. Kayan nokta aritmetiğinde birleşme özelliği yuvarlamadan bozulur.

### Mühürleme maliyeti — tarihsel aday köprü

Tarihsel modelde kaynak sembolü $\Gamma$ olan niceliği, güncel zaman iskelesindeki $\Gamma$ ile karıştırmamak için burada $\Gamma_{\rm hist}$ ile yazalım:

$$\Gamma_{\rm hist}=\Gamma_0(1+\lambda D_+)^{-1},$$

$$C_s\propto\frac{1}{\Gamma_{\rm hist}}
\propto(1+\lambda D_+),$$

$$\nabla C_s=\Lambda\nabla\ln\chi_S \qquad (\Lambda \text{ sabit}).$$

Tarihsel nedensellik zinciri:

$$D_+\;\to\;\Gamma_{\rm hist}\downarrow
\;\to\;C_s\uparrow
\;\to\;\chi_S\neq1
\;\to\;\mathbf g_\chi$$

şeklindedir.

$$\boxed{\;\text{Bu zincir aday köprüdür; Bölüm 7.2'deki zaman iskelesini veya Bölüm 14'teki damga cebirini tanımlamaz.}\;}$$

$D_+$ ve $C_s$ güncel çekirdeğin primitive'leri değildir. Ayrıca kaynak notasyonundaki $\Gamma$ ile Bölüm 7.2'deki $\Gamma$'nın aynı fiziksel rolün iki adı mı, yoksa bağımsız nicelikler mi olduğu açık kalır. Bölüm 24.2'deki çift-sayım borcu bu blokla **çözülmüş sayılmaz**.

## 14.4 İki katmanlı arşiv

| Katman | Yapı | Özellik |
|---|---|---|
| **Ham arşiv** | Kayıtlar üzerinde serbest monoid | **Salt-ekleme**; tam sadakat |
| **Damga izdüşümü** | $M$'ye kaba projeksiyon | İdempotent kilitler burada |

$$\boxed{\;\text{Ham arşiv} \;\neq\; M.\;}$$

Kritik fark:

$$\kappa^2 = \kappa \quad\text{(damga monoidinde)} \qquad\qquad A + [r] + [r] \;\neq\; A + [r] \quad\text{(ham arşivde)}$$

**Olay kaynağı (provenance) çökertilmez.** Aynı damga iki kez basılsa bile, iki ayrı kayıt oluşur.

### Kayıt yapısı

$$r = \big(\mathrm{rid},\; \text{kenar},\; \text{damga},\; \text{içerik aralığı}\big)$$

- $\mathrm{rid}$ **tekildir** ve bir fiziksel parametre **değildir**
- Silme işlemleri operasyon kümesinde **yoktur**
- Arşiv sırası bir **kaynak sırasıdır**; fiziksel zaman değildir
- Cₘ-okuma zaman etiketi arşive **geriye sokulmaz**

Zaman etiketi bir **Cₘ-kaynak bilgisidir**; c⁺'ın kendi zaman koordinatı yoktur.

İyi-biçimli ham arşiv için iki temel formal invariant adayı:

$$\boxed{\;\mathrm{NoDup}(A.\mathrm{map}\;\mathrm{rid})\;}$$

ve append-only prefix/provenance düzeni:

$$\boxed{\;A\preceq A'\;}$$

şeklindedir. Birincisi kayıt kimliklerinin tekilliğini, ikincisi silme/geri-alma primitifi olmadan kaynak bilgisinin monoton genişlemesini ifade eder.


### Ham arşivin serbest-monoid realizasyonu

Raw provenance için uygun minimal yapı:

$$\mathcal A_{\rm raw}=\mathrm{FreeMonoid}(\mathrm{Record})$$

olarak yazılabilir. Damga izdüşümü:

$$\pi_{\rm stamp}:\mathcal A_{\rm raw}\to M$$

olay kayıtlarını stamp word'e kaba projekte eder. Bu projection bilgi kaybettirir; özellikle `rid`, payload Range ve event multiplicity monoid image'da korunmak zorunda değildir.

Silme operasyonları:

```text
erase, pop, undo ∉ Ops(Archive)
```

olarak dışarıda tutulur.

### İdeal / Rees-collapse uyarısı

Kilit içeren kelimeler cebirde bir ideal-benzeri sınıf oluşturabilir; fakat tüm kilit içeriğini tek bir absorbe sıfıra collapse etmek provenance bilgisini yok eder. Dolayısıyla “kilitli her şeyi tek zero class'a indir” yaklaşımı current formal programda kullanılmaz.

Bu ayrım, group completion veya quotient sonucunun fiziksel arşiv semantiği sanılmasını engeller.

### Arşiv sayısı ve monotonluk

Ham arşiv yalnız eklemeyle büyür. Buradan kesin bir sonuç çıkar: arşive bir kayıt eklendiğinde kayıt sayısı tam olarak bir artar.

$$N_{\rm arşiv}(n+1) \;\geq\; N_{\rm arşiv}(n)$$

Bu sonuç kayıtların **kaynak sırasında**, yani ekleme sırasında geçerlidir ve biçimsel olarak kanıtlanmıştır. Fiziksel zamana göre bir türev değildir; sürekli bir "arşiv büyüme hızı" bundan kendiliğinden çıkmaz. Entropi modellerinde kullanılan kayıt sayısı ise ayrı bir model niceliğidir ve arşiv sayısıyla otomatik olarak özdeşleştirilmez. Bir modelde doluluğun azalması arşivin silindiği anlamına gelmez.

Faz hafızasının kaynak sırasında monoton olduğu ilke ise ($R_\varphi(r_{n+1}) \geq R_\varphi(r_n)$) farklı bir statüdedir: fiziksel zaman yerine kaynak sırasının kullanılması kesindir, ama monotonluğun kendisi biçimsel olarak kanıtlanmış bir teorem değil, bir **mimari kuraldır**. Statüsü yazarın kararına bağlıdır.

## 14.5 "Tüm geçmiş mevcut"un doğru hâli

Kayıt kümesi üzerinde **statik bir uygunluk ilişkisi** — bir akış değil. Bu, zamansızlık ilkesini bozmadan arşiv sezgisini korur.

## 14.6 $q/\Sigma$ iki-katmanlı okuma

İki ayrı harita farklı bilgileri taşır:

$$q:\mathcal C_{\rm full}\to G_{\rm bare}$$

damga/provenance bilgisini unutarak çıplak phase transition'ı verir;

$$\Sigma:\mathcal C_{\rm full}\to M$$

transition'ın damga monoidindeki cebirsel görüntüsünü verir.

Çıplak katmanda ters yön:

$$\boxed{\;q(T_{ji})=q(T_{ij})^{-1}\;}$$

olarak temsil edilebilir. Buna karşılık damga monoidi grup değildir; genel olarak:

$$\Sigma(T_{ji})=\Sigma(T_{ij})^{-1}$$

yazılamaz.

Damgasız doğrudan kenarda semantic ve algebraic katman ayrı tutulur:

$$\boxed{\;\mathrm{emittedStamp}(T_{0+})=\texttt{None},\qquad \Sigma(T_{0+})=e\;}$$

Böylece:

$$\boxed{\;\text{NoStamp}\neq \text{NoTransition},\qquad \texttt{None}\neq\texttt{Some}(e)\;}$$

koruma kuralları korunur.

## 14.7 C-katmanı — transition semantiğinin ayrıştırılması

Formal modelde aşağıdaki alanların tek bir sembole sıkıştırılmaması gerekir:

$$\boxed{
\mathfrak C(T)=
(
Gate,\,
EdgeClass,\,
Direction,\,
StampClass,\,
StampEmission,\,
SealEffect,\,
ArchiveEffect,\,
CoordinationEffect,\,
ProjectionEffect
)
}$$

Bu ayrım şu özdeşlikleri engeller:

```text
faz ilişkisi ≠ yön
yön ≠ damga sınıfı
damga sınıfı ≠ damga emisyonu
damga emisyonu ≠ sealing
sealing ≠ archive mutation
archive mutation ≠ coordination/readout
```

Cₘ→c⁺ yönünde archive append ve c⁺→Cₘ yönünde read/project ayrımı, ontolojiyle uyumlu **formal adaydır**; yön semantiği direct kanon olarak ayrıca kilitlenmediyse theorem gibi yazılmaz.

---


## 14.8 Yol ilişkileri ve çevrim karakteri

Forgetful map için:

$$q:\mathcal C_{\rm full}\to G_{\rm bare}$$

ve:

$$q(T_{ji})=q(T_{ij})^{-1}$$

aksiyomu altında, ters yönlü path'ler için:

$$q(\gamma_-)=q(\gamma_+)^{-1}$$

ilişkisi **türetilmiş bir sonuç** olabilir; bağımsız fizik aksiyomu olarak çoğaltılmamalıdır.

Stamp map için aynı inverse yazılamaz:

$$\Sigma(\gamma_-)=\Sigma(\gamma_+)^{-1}$$

genel olarak anlamsızdır; çünkü $M$ grup değildir.

Bir çevrimde sıra-duyarsız toplamsal bilgi $\Omega$ karakteriyle özetlenebilir. Sıra-duyarlı içerik ise:

$$\rho:M\to\operatorname{End}(V)$$

gibi temsil ister. $\rho$'nun ilgili altsektörü invertible ise “holonomy” dili kullanılabilir; genel monoid için **ordered transport** daha güvenlidir.

Eğer bir Cₘ-projeksiyon modeli Schnakenberg-benzeri çevrim afinitesi tanımlarsa:

$$\mathcal A_{\rm cyc}\neq0$$

“mühürleme asimetrisi/şiddeti” için readout adayı olabilir; bu ifade **temel zamansız katmanda rate yasası değildir**.


## 14.9 Recording vs Sealing ayrımı


Arşivde iki kavram ayrıştırılmıştır:

| Kavram | Anlam |
|---|---|
| **Recording** | Cₘ-içi sürecin tarih taşıyan kalıcı iz üretmesi — korunabilirlik meselesi |
| **Sealing** | Kaydın geri alınamaz biçimde yazılması — tersinmezlik meselesi |

$$\boxed{\;\text{"Recoverable past imprint" ancak recording düzeyinde tanımlanabilir; sealing tek başına geçmişi geri getirmez.}\;}$$

Kritik hüküm: mühürleme (sealing) hem recording'i hem recoverability'yi zorunlu kılmaz. Cₘ kayıtları çoğu durumda kısmi ve seçicidir; kayıt yoğunluğu ≠ zaman üretim hızı.

## 14.10 Stateless universe — recoverable vs encoded history


Arşivdeki "stateless universe" kaydı: evrenin hâli geçmişi depolayan bir durum değildir; tarih çoklu kayıtlarda (izlerde) korumalıdır.

$$\boxed{\;\mathrm{state}(t) \neq \mathrm{stored\ history}\quad \text{ve}\quad R_\varphi(t+\Delta t)\in[R_\varphi(t),\; R_\varphi(t)+\Delta R_{\max}]}$$

"Recording hipotezi" (gözlemin kaydı otomatik olarak koruduğu) reddedilmiştir: "recording hypothesis rejected". Ayırt edici kavram çifti kayıtlıdır: **encoded history** (kayıt yalnızca saklanıyorsa) ↔ **recoverable history** (yapısal kalıntı aktif okunabiliyorsa). Evertophy'nin ileri iddiası ikincisidir ve kanıtlanmamıştır.

---

### Denklem seti — Ω — faz geçiş karakteri

**Ne işe yarar, neden gerekli?** Fazlar arası geçişin bileşim yasası: A→B ve B→C geçişleri A→C'yi vermeli.

$$\omega_{AB} + \omega_{BC} = \omega_{AC}\ \text{(kesin)} \qquad \Omega_{AB} \boxplus_B \Omega_{BC} = \Omega_{AC}\ \text{(bağımlı)} \qquad \Omega_{AC} \subseteq \Omega_{AB} \oplus \Omega_{BC}\ \text{(bağımsız kapsama)}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $\omega_{AB}(s)$ | Ortak durum $s$'de kesin skaler karakter: $\ln W_A(s) - \ln W_B(s)$ |
| $\Omega_{AB}$ | Aralık-değerli karakter |
| $\boxplus_B$ | Bağımlılık-korumalı birleşim |
| $\oplus$ | Bağımsız (Minkowski) toplam |

**Statü:** Naif aralık eşitliği ❌ · üç katman (kesin / bağımlı / kapsama) ✅


# BÖLÜM 15 — ÖLÇÜM VE OKUMA

## 15.1 Ölçüm Cₘ'ye aittir

$$\boxed{\;\text{DOĞRUDAN FİZİKSEL ÖLÇÜM YALNIZ Cₘ'DE MÜMKÜNDÜR.}\;}$$

## 15.1a Faz rolleri: içsel, kaynak ve gözlem fazı

Bir niceliğin fazlarla ilişkisini konuşurken üç farklı rol birbirine karıştırılmamalıdır. **İçsel faz**, niceliğin kendi dilinde tanımlı olduğu fazdır. **Kaynak faz**, bir etkinin geldiği fazdır. **Gözlem fazı** ise etkinin ölçüldüğü fazdır — ve ölçüm her zaman Cₘ'dedir.

Bu ayrım bir karışıklığı giderir: c⁺ kaynaklı bir etki Cₘ'de gözlendiğinde, gözlenen değer Cₘ'de bir değerdir; c⁺'ta çözünmüş olan hâlâ çözünmüş kalır. Bu ayrım tipli bir okuma yapısıyla biçimsel olarak kodlanmıştır. Okumanın **tipi** kuruludur; okumanın **yasası** — hangi c⁺ kaynağının Cₘ'de hangi değeri verdiği — aşağıda söylendiği gibi açık borçtur.

## 15.2 Okuma haritası — açık borç

Cₘ durumundan ölçülen niceliklere giden harita **tanımsızdır**.

$$\boxed{\;\text{Soru "okuma haritası nedir" DEĞİL, "onu TEKİL kılan ek ilke nedir"dir.}\;}$$

Çünkü böyle bir harita gözlemden tekil olarak çıkarılamaz: aynı gözlemsel sonucu farklı yapılar verebilir.

### Kuantum açık-sistem araçları

Kraus, Lindblad, Stinespring gibi araçlar bu harita için kullanılabilir.

$$\boxed{\;Bunlar OLASI Cₘ MODEL/İSKELESİDİR — ÇEKİRDEK ONTOLOJİ PRİMİTİFİ DEĞİLDİR.\;}$$

Mühürleme tanımı bu araçlara **indirgenemez**; mühürleme ontolojik, bu araçlar Cₘ-içi hesaplama dilidir.

Arşivde bulunan CPTP/Kraus modeli bu sınır içinde bir köprü adayıdır:

$$\mathcal E(\rho)=\sum_i K_i\rho K_i^\dagger,\qquad \sum_iK_i^\dagger K_i=I.$$

“Mühürleme = dolanıklık aktarımı” ve Cₘ projeksiyonundaki partial-trace kaybının tek yönlü geçmiş olarak yorumlanması, **hesaplanabilir model hipotezidir**; mühürlemenin tanımı veya c⁺ primitive'i değildir. Hamiltonian/Lindblad dili de yalnız Cₘ-içi etkin dinamik için adaydır. c₀'a 3+1 boyutlu Lagrangian/Hamiltonian yapı ithal etmez.

## 15.3 Ölçüm ve çöküş — model sınırı

Evertophy, ölçümü phase/readout/sealing diliyle yeniden yorumlamayı araştırabilir; ancak kuantum ölçüm probleminin çözüldüğü iddia edilmez. "Liminal rejim → Cₘ projection → sealing" zinciri **model/yorum adayıdır**.

Kuantum belirsizliğini doğrudan "Cₘ ekranının sonlu çözünürlüğü"ne eşitlemek current core değildir; böyle bir yorum ancak standart kuantum olasılıklarını ve Born-rule davranışını türetirse fiziksel bridge statüsü kazanabilir.

## 15.4 Mühürleme maliyeti

Mühürleme maliyeti, yenileme süresi ve çözünürlük gürültüsü arşivde kullanılan **kavramsal model değişkenleridir**; current ontology primitive'i değildir ve nicel tanımları henüz kapalı değildir.

---


## 15.5 Beş adımlı mühendislik ölçüm protokolü

*Not:* Tek port ya da tek bir faz farkı karşılıksızlığı kanıtlamaz; $S_{21}$ ve $S_{12}$ aynı normalizasyon ve koşullarda karşılaştırılmalıdır (17.1).


Deneysel köprüler için arşivde olgunlaştırılmış mühendislik protokolü:

| # | Adım | İçerik |
|---|---|---|
| 1 | Giriş fazı | (Φ, Ξ, X) → empedans/faz parametreleri; port/normalizasyon netleştirilir |
| 2 | Kuplaj | giriş–çıkış geçiş matrisi (CMT) |
| 3 | Asimetri | S₂₁/S₁₂ → χ_S; karşılıklılık kontrolü şart (Bölüm 17.1) |
| 4 | Güvenlik | achromaticity ∂X/∂E_probe = 0 (LHAASO kısıtlarıyla uyum); ayrık modellemede S-parametreleri ile doğrulama |
| 5 | Çıkış fazı | ivme eşlemi: g_eff = +c²∇lnZ_g / −Λ∇lnχ_S − (lnχ_S)∇Λ (taslak köprü) |

Aktif eşik modülasyonu aday mekanizması: ΔΦ(t) = Φ₀sin(ω_m t) tek porttan modülasyon → karşılıklılık kırılması; band-duraklı aralıklar tercih edilir (kaçak modları azaltır). Bu protokol öngörü değildir; test tasarımıdır.

## 15.6 Gözlemci ilkesinin fiziksel yeniden tanımı


Arşiv kilitli cümlesi:

$$\boxed{\;\text{Gözlemci bilinç değil, madde fazıdır (} C_m \text{).}\;}$$

Bölüm 1.4'teki çekirdek hükmün arşiv genişletmesi: tüm Cₘ süreçleri gözlemci etkisi yaratır; gözlem, Cₘ'de fiziksel kayıt ve readout üreten sistemlerin rolüdür. Bilinç kavramı bu hükme hiçbir şekilde gerekli değildir (bkz. Bölüm 24.8). Liminal rejim okumasıyla birlikte: ölçüm = liminal taşınımın Cₘ fazına zorunlu projeksiyonudur — bu bir model adayıdır, çekirdek değildir.

---

# BÖLÜM 16 — BİLGİ, ENTROPİ, KAYIT

## 16.1 Entropi özellik ailesi ve faz semantiği

Entropi $S(x)$ Faz-Parametre Matrisinde bir özellik ailesi olarak tutulabilir; fakat standart termodinamik entropi dili üç faza aynen taşınmaz.

| Faz | Güvenli yorum |
|---|---|
| **c₀** | Standart $dS/dt$ dili admissible değildir; pre-temporal structural order/potential ayrıca tanımlanmalıdır |
| **Cₘ** | Termodinamik/istatistiksel entropi ve entropy production fiziksel anlam taşır |
| **c⁺** | Atemporal archive/provenance yapısı termodinamik entropy evolution ile özdeş değildir |

Eski "potansiyel/akış/koherent-kilitli" tablosu yalnız pedagojik/model sezgisi olarak kullanılabilir.

## 16.2 Bilgi ve faz formatı

Bilgi "kaybolmaz" — faz formatı değişir.

$$\boxed{\;Bu bir TEOREM DEĞİL, bir YENİDEN YORUMDUR.\;}$$

Mikrodurum sayımı yapılmamış, standart kara delik entropisiyle ilişki kurulmamıştır.

## 16.3 Entropi türleri ayrıdır

| Tür | Ne |
|---|---|
| Kayıt entropisi | Provenance/registry modelinde tanımlanan aday sayım ölçüsü; ontolojik kök olduğu kanıtlanmış değildir |
| Termodinamik entropi | Cₘ içi izdüşüm |
| Bilgi-kuramsal entropi | Cₘ içi izdüşüm |

$$\boxed{\;\text{Bu üçü arasında HAM EŞİTLİK KURULMAMIŞTIR; biri diğerinin TANIMI değildir.}\;}$$

### Yönsel entropi zinciri — aday köprü

Arşivde şu yönsel okuma bulunur:

$$S_{C_m}\uparrow\;\Rightarrow\;\text{kümelenme/çekim readout'u},
\qquad
S_{c^+}\uparrow\;\Rightarrow\;\text{genişleme/DE readout'u}.$$

Bu kayıt **16.3'ün tanım ayrımını bozmaz**. Özellikle $S_{c^+}$ standart termodinamik entropy-production değişkeni olarak kilitlenmiş değildir ve $\uparrow$ işareti c⁺ içinde akan fiziksel zaman türevi anlamına gelmez. Zincir, iki yönelimin Cₘ'deki fenomenolojik/okuma eşlemesi için **aday köprü**dür; Çekim Kuvveti'nin (Postüla-0) tanımı değildir.

### Denklem seti — K6 entropi modeli ve $N$ ayrımı

**Ne işe yarar, neden gerekli?** Kayıt sayısı $N$ ile bir doluluk oranı $F$'den entropi türeten **model**.

$$S = k_B\,N\,\frac{F}{F_{\max} - F}, \qquad \frac{dS}{d\tau} = k_B\left[\frac{N' F}{F_{\max}-F} + \frac{N F_{\max} F'}{(F_{\max}-F)^2} - \frac{N F F_{\max}'}{(F_{\max}-F)^2}\right]$$

$$N_{\rm arşiv}(n+1) \geq N_{\rm arşiv}(n) \quad \text{(kaynak sırasında — fiziksel zaman türevi DEĞİL)}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $S$ | Model entropisi |
| $N$ | Kayıt sayısı |
| $F$, $F_{\max}$ | Doluluk ve üst sınırı |
| $N_{\rm arşiv}(n)$ | Salt-ekleme ham arşivin $n$-inci önek uzunluğu |
| $N_{\rm entropi}$ | K6 modelinin niceliği |

**Statü:** K6 MODEL · arşiv sayısı ayrık monotonluk ✅ · "$F'<0 \Rightarrow$ silme" ❌


## 16.4 🔴 Varlık ≠ kayıt

$$\boxed{\;\text{"Yalnız mühürlenmiş olan vardır" ONTOLOJİSİ ÇEKİRDEĞE GİRMEZ.}\;}$$

Kayıt ve mühürleme bir **kaynak/formal katmandır**. Bunlar varoluşun kendisiyle özdeşleştirilemez — özellikle c₀ zaman-öncesi **potansiyel** olduğu için, "mühürlenmemiş potansiyel gerçek değildir" ifadesi çerçeveyle çelişir.

## 16.5 Nesnel kayıt eşiği

Bir olayın gerçekleşmesi ile fiziksel kaydının oluşması aynı şey değildir. Nesnel kayıt için, bilginin yeterli sayıda bağımsız erişilebilirlik kazanması gerekir.

---


## 16.6 Registry entropisi — çift katman yapı


Arşivde registry/bilgi için iki katmanlı yapı önerilmiştir:

| Katman | Yapı | Koruma |
|---|---|---|
| **Global** | üniter evrim + Registry monotonluğu | bilgi korunur |
| **Yerel** | Kraus/CPTP: ρ′ = ΣᵢKᵢρKᵢ†, ΣKᵢ†Kᵢ = I | Cₘ-içi okuma modeli |

GKSL/Lindblad şablonu (Markov yaklaşımı altında genel form):

$$\frac{d\rho}{d\tau} = -\frac{i}{\hbar}[H(\Phi,\Xi),\rho] + \sum_k \gamma_k(\Phi)\left(L_k\rho L_k^\dagger - \tfrac12\{L_k^\dagger L_k,\rho\}\right)$$

$$\boxed{\;\text{Bu bir hesap şablonudur; } \{H, L_k, \gamma_k\} \text{ seçimi rezerve/açık borçtur — ontoloji primitive'i değildir.}\;}$$

"Global üniterlik + yerel Kraus" ikili yapısı, bilgi kaybının gözlemsel olduğunu söyler; kara delik bilgi paradoksuna bir yol açar ama çözüm değildir (Bölüm 0.3 hükmü).

## 16.7 Entropi oku türetimi — üç katman özeti


Zaman oku ile entropi arasındaki ilişki için arşivde üç katmanlı çalışma modeli korunur:

1. **Çekirdek katman:** zaman iskelesi dt = Γ·𝒢_Cm·dτ — fiziksel zaman Cₘ'de üretilir.
2. **Kayıt katmanı:** arşiv monotonluğu R_φ(r_{n+1}) ≥ R_φ(r_n) (kaynak sırasında — Bölüm 14.4 hükmüyle aynı).
3. **Entropi katmanı:** dS/dt ≥ 0 yalnızca Cₘ-içi termodinamik izdüşüm olarak.

$$\boxed{\;\text{Çekirdek oku, kayıt birikimi ve termodinamik entropi üretimi AYNI yasa değildir.}\;}$$

Aday modelde (hipotez): zamanın okunun kayıt protokolünden doğduğu önerilir; termodinamik ok yalnızca bu kaydın istatistiksel Cₘ-izdüşümünde görünür. Üç katman birbiriyle ilişkilendirilir (fiziksel zaman ≠ entropi ≠ arşiv sırası; 7.8) ve bu ilişki henüz gösterilmemiştir; ama birbirinin tanımı değildir — Bölüm 7.8 ve 16.3'teki ayrımın arşiv ifadesidir.

---

## 16.7a Entropi ve enerji: $U_x$ düzeyinde korunum
**Yazar hükmü:** Entropi, Cₘ'deki yapının c⁺'a çözünmüş hâlidir. Enerji yok olmaz; çözünen yapının hem kaydı hem enerji payı c⁺'ta mühürlenir.

$$\boxed{\;\text{Toplam enerji } U_x \text{ düzeyinde korunur; enerjinin bir kısmı Cₘ'de ölçülemez — bu pay c⁺'ta mühürlüdür.}\;}$$

Cₘ'de ölçülen enerji bu global bütçenin tamamı olmak zorunda değildir; ama kapalı Cₘ sistemlerinde doğrulanmış enerji-korunum sonuçları karşılanmalıdır. Bu hüküm ne her Cₘ ölçümünde enerjinin korunduğunu, ne de herhangi bir kapalı sistemde korunumun ihlal edildiğini iddia eder; yerel korunum, açık sistem alışverişi ve kozmolojik global enerji ayrı kapsamlardır.

Bu hükmün dört inceliği vardır:

- **Bir Noether korunumu değil, global bir muhasebe ilkesidir.** Cₘ'deki enerji korunumu Cₘ zamanındaki simetriden gelir; $U_x$ düzeyinde global bir zaman yoktur. Bu yüzden $U_x$ düzeyindeki korunum Cₘ fiziğinden türetilmiş değil, ontolojik bir postüladır ve "zaman yalnız Cₘ'de geçerlidir" hükmüyle çelişmez.
- **Üç ayrı tür.** Cₘ'de ölçülen enerji ($E_{C_m}$), $U_x$ düzeyindeki toplam muhasebe ($E_{U_x}^{\rm muhasebe}$) ve c⁺'taki mühürlü pay ($E_+^{\rm mühürlü}$) farklı tanım ve kullanım katmanlarına aittir; bu, değerlerinin her durumda farklı olduğu anlamına gelmez. Aralarındaki nicel harita, ortak değer uzayı ve aktarım yasası henüz kurulmamıştır.
- **Ölçümlerle uyum.** Kapalı sistemlerdeki ölçülmüş enerji korunumu, ölçüm hassasiyeti içinde **zorunlu bir dış koşuldur**. Ölçülemeyen payın kozmolojik ölçekte belirginleşmesi ise henüz hesaplanmamış bir beklentidir; genel görelilikte enerji korunumu kozmolojik ölçekte zaten global olarak tanımlı değildir.
- **Kapı yapısı.** Bir niceliğin Cₘ'ye özgü nicelikler listesinde yer almaması, onun başka fazlardaki içsel tanımını ya da belirli bir faz çifti için taşıma iznini belirlemez (13.1a). Enerjinin c⁺'taki içsel statüsü ve taşıma izni açıktır; c⁺'taki pay Cₘ-tipi enerji değil, c⁺'a özgü mühürlü bir biçimdir.

Biçimsel ayrım da korunur: arşiv sayısının ayrık monotonluğu, faz hafızasının monotonluğu ve termodinamik entropi artışı aynı teoremden çıkmaz (14, 7.8). Ham kayıt sayısının artması fiziksel entropi üretimi değildir. Yazar hükmü bunlar arasında ontolojik bir bağ kurar; hangi entropi ölçüsünün hangi mühürleme sürecine karşılık geldiğini gösteren nicel harita açıktır.

# BÖLÜM 17 — KANAL ASİMETRİSİ (ADAY KÖPRÜ)

## 17.1 Temel fikir

Bir ortamın iki yön arasında asimetrik davranması, saçılma parametreleri üzerinden ölçülebilir:

$$\chi_S \;\equiv\; \frac{|S_{21}|}{|S_{12}|}$$

Logaritmik ölçü ve türetilen alan:

$$\Xi = \ln\chi_S, \qquad \Phi_\chi = \Lambda\ln\chi_S, \qquad \mathbf{g}_\chi = -\Lambda\nabla\ln\chi_S-(\ln\chi_S)\nabla\Lambda \quad (\text{kısa biçim yalnız } \nabla\Lambda=0)$$

Simetri koşulu otomatiktir: $\chi_S = 1 \Rightarrow \Phi_\chi = 0$.

### Karşılıklılık notu

Bu ölçütün önemli bir sınırı vardır. Aynı port normalizasyonunda **karşılıklı** her sistemde ($S_{21} = S_{12} \neq 0$) oran özdeş olarak 1'dir; bunun için kayıpsızlık gerekmez, Onsager karşılıklılığı yeterlidir. Faz farkı $\arg S_{21} - \arg S_{12}$ de aynı koşulda özdeş olarak sıfırdır, yani otomatik bir yedek ölçüt değildir.

$$\boxed{\;\text{Karşılıklı sistem:}\quad \chi_S \equiv 1,\qquad \Delta\varphi \equiv 0\;}$$

Bu nedenle kanal asimetrisi, ancak **karşılıklılığı bozan** bir fiziksel sınıf, port yapılandırması ve referans düzlemi açıkça tanımlandığında anlamlı bir köprü adayıdır. Bu köprünün akıbeti yazarın kararına bırakılmıştır.


### Denklem seti — Kanal asimetrisi (Onsager)

**Ne işe yarar, neden gerekli?** Kanon, fazlar arası kanal asimetrisini $\chi_S$ ile ölçmeyi öneriyordu.

$$\chi_S = \frac{|S_{21}|}{|S_{12}|} \equiv 1 \ \text{(aynı port normalizasyonunda karşılıklı sistemde, } S_{21}=S_{12}\neq0\text{; kayıpsızlık şart değil — Onsager)} \qquad \Delta\varphi = \arg S_{21} - \arg S_{12}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $S_{21}$, $S_{12}$ | Saçılma matrisi ileri/geri genlikleri |
| $\chi_S$ | Genlik oranı |
| $\Delta\varphi$ | Faz farkı |

**Statü:** $\chi_S$ ❌ · $\Delta\varphi$ otomatik ikame ❌ · karşılıklılığı bozan sınıf ⏸ (yazar kararı)


### 17.1a İmpedans ve potansiyel köprü ailesi

Kanal asimetrisi hattı, yalnız $\chi_S$ tanımından ibaret değildir. Model düzeyinde şu zincir araştırılmıştır:

$$\chi_S=\frac{|S_{21}|}{|S_{12}|},\qquad
\Xi=\ln\chi_S$$

$$\Phi_\chi=\Lambda\,\Xi,\qquad
\mathbf g_\chi=-\nabla\Phi_\chi=-\Lambda\nabla\ln\chi_S-(\ln\chi_S)\nabla\Lambda \qquad (\chi_S>0;\ \text{kısa biçim } -\Lambda\nabla\ln\chi_S \text{ yalnız } \nabla\Lambda=0 \text{ dalında}).$$

Bazı CMT/impedance realizasyonlarında $Z_{\rm eff}$ veya benzeri bir etkin kanal büyüklüğü ile $\chi_S$ arasında bağ kurulabilir. Fakat:

$$\boxed{\;\chi_S\to Z_{\rm eff}\to\Phi_\chi\to \mathbf g_\chi\;}$$

zinciri **aday köprüdür**, ontolojik gravity yasası değildir.

Özellikle $\Lambda$ birden fazla faktörün çarpımıyla tanımlanıyorsa, yalnız çarpımın ölçülmesi faktörleri ayrı ayrı öngörmez. Bu durum ParamBudget/BridgeBudget altında fiyatlandırılır.

### Denklem seti — $Z_{\rm eff}$ — kanonik yönlü etkin empedans

**Ne işe yarar, neden gerekli?** KAP-03, K5v2 ve K12v2'nin hepsi $Z_{\rm eff}$ kullanıyor; bu niceliğin **kanonik tanımı** burada verilir.

$$Z_{{\rm eff},i}(\omega) \equiv Z_{0,i}\,\frac{1 + S_{ii}(\omega)}{1 - S_{ii}(\omega)}, \qquad \Phi_{\rm ch}^{(\pm)}(\mathbf{x},\omega) \equiv \lambda\ln\frac{Z_{\rm eff}^{(\pm)}(\mathbf{x},\omega)}{Z_{\rm ref}}$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $S_{ii}(\omega)$ | $i$ portunun yansıma katsayısı |
| $Z_{0,i}$ | Port referans empedansı |
| $\Phi_{\rm ch}^{(\pm)}$ | Kanal potansiyeli |
| $\lambda$, $Z_{\rm ref}$ | Ölçek ve referans |

**Statü:** Kayıtlı referans tanım (kaydedildi, tanımlılık koşulları incelendi) · fiziksel köprü ⏸


### 17.1b Operasyonel ölçüm protokolü — model testi

Kanal köprüsü test edilecekse örnek VNA/CMT protokolü:

1. İki yönlü saçılma ölçümüyle $S_{21}(\omega)$ ve $S_{12}(\omega)$ kaydedilir.
2. Aynı cihaz/kalibrasyon koşullarında $\chi_S(\omega)$ üretilir.
3. Reciprocal kontrol rejiminde $\chi_S\simeq1$ doğrulanır.
4. Aktif/nonreciprocal bileşen varsa bunun kaynağı ayrıca ölçülür; “asimetri gördük = gravity” çıkarımı yapılmaz.
5. $\Phi_\chi$ veya $\mathbf g_\chi$ bridge'i önceden preregister edilmiş band üretirse bağımsız veriyle karşılaştırılır.

Soft-kill: kanal asimetrisi fiziksel gravity readout'uyla bağımsız biçimde bağlanamıyorsa **köprü hattı kapanır**, core ontology değil.

### 17.1c CMT model iskelesi

Kanal asimetrisinin hesaplanabilir model dili olarak standart bağlı-mod biçimlerinden biri kullanılabilir. Bölüm 7.2'deki $\Gamma$ ile karışmaması için sönüm/kayıp matrisi burada $\Gamma_{\rm CMT}$ ile gösterilir:

$$S(\omega)=C+D\,[\,i(\omega I-\Omega)+\Gamma_{\rm CMT}\,]^{-1}K^{T}.$$

Bir rezonans çevresinde, seçilen port/mod normalizasyonuna bağlı yaklaşık asimetri okuması:

$$\chi\approx\frac{|d_2k_1|}{|d_1k_2|} \qquad (S=C+DRK^{\mathsf T},\ D=(d_1,d_2)^{\mathsf T},\ K=(k_1,k_2)^{\mathsf T}:\ S_{21}=C_{21}+d_2Rk_1,\ S_{12}=C_{12}+d_1Rk_2;\ \text{oran, doğrudan yol bileşenleri ihmal edilebildiğinde})$$

Kanal potansiyeli $\Phi_\chi=\Lambda\ln\chi_S$'de $\Lambda$ konuma bağlıysa $-\nabla\Phi_\chi=-\Lambda\nabla\ln\chi_S-(\ln\chi_S)\nabla\Lambda$ olur; son terim yalnız $\Lambda$ uzayda sabitse düşer.

ve karşılıklılık kırılması için operasyonel imza:

$$\boxed{\;S_{21}\neq S_{12}\;}$$

olarak izlenebilir. Tek-port etkin empedans okuması için:

$$Z_{{\rm eff},i}
=Z_{0,i}\frac{1+S_{ii}}{1-S_{ii}}.$$

$$\boxed{\;\text{CMT, kanal asimetrisinin hesaplanabilir MODEL DİLİDİR; ontolojik köprü adayının kendisi değildir.}\;}$$

Matris boyutları, port normalizasyonları ve $C,D,K,\Omega,\Gamma_{\rm CMT}$ konvansiyonları seçilen CMT gerçekleştirmesine bağlıdır. $S_{21}\neq S_{12}$ tek başına kütleçekim veya Evertophy doğrulaması sayılmaz.

## 17.2 🔴 Açık borçlar

$$\boxed{\;Bu hat ADAY KÖPRÜDÜR — kurulmuş bir türetim DEĞİLDİR.\;}$$

| Borç | İçerik |
|---|---|
| **Çarpan belirsizliği** | $\Lambda$ ifadesi yalnız **çarpımı** sabitler; çarpanlar serbest kalır |
| **Kaynak dışsallığı** | Ölçek katsayısı dış bir kaynaktan alınmıştır |
| **Asimetrinin kaynağı** | Karşılıklılık koşullarını sağlayan ortamlarda $S_{21}=S_{12}$'dir; pasiflik ve zamanla değişmezlik bunu tek başına garanti etmez (statik manyetik bias altındaki ferrit sistemler pasif ama karşılıklı değildir). Asimetrinin kütleçekimle bağı **kurulmamıştır** |

$$\boxed{\;\text{ÇARPIMI SABİTLEYİP ÇARPANLARI SERBEST BIRAKMA deseni: bilinmeyen KAPANMAZ, YER DEĞİŞTİRİR.}\;}$$

## 17.3 Yapısal benzerlik uyarısı

$$\boxed{\;\text{YAPISAL BENZERLİK, DOĞRULAMA DEĞİLDİR. Notasyon ödünç almak, SONUÇ İTHAL ETMEZ.}\;}$$

---


## 17.4 χ_S tanım seti (model adayı)

*Tek tanım otoritesi: Bölüm 17.1c; karşılıklılık sınırı için bkz. 17.1.*


Bölüm 17.1'deki tanımın arşivdeki tamamlanmış hâli:

$$\chi_S \equiv \frac{|S_{21}|}{|S_{12}|}, \qquad \Xi = \ln\chi_S, \qquad Z_{{\rm eff},i} = Z_{0,i}\frac{1+S_{ii}}{1-S_{ii}}$$

Rezonans çevresi tek-mod yaklaşık okuması: χ ≈ |d₂k₁|/|d₁k₂| (doğrudan yol bileşenleri ihmal edilebildiğinde; port/mod normalizasyonuna bağlı). CMT iskelesi Bölüm 17.1c'de verilmiştir.

## 17.5 Üç faktörlü ayrışım ve aralık-değeri formu

*Statü:* Mekanik × kuplaj × direnç ayrışımı bir model atamasıdır; bağımsız ölçüm ve faktör tanımı olmadan türetilmiş bir yasa değildir.


χ_S'in fiziksel kaynaklarının ayrışımı: χ_S = (mekanik asimetri) × (kuplaj asimetrisi) × (direnç/yükleme etkisi). Aralık-değeri formu:

$$\chi_S \in [\chi_S^-, \chi_S^+] \quad \text{ve} \quad \Lambda \text{ çarpımı sabitlenirken çarpanları serbest bırakmak yasaktır (Bölüm 17.2).}$$

Bölüm 21.6'nın düzeltilmiş hükmü burada da geçerlidir: aralık üzerinden türetim iddiası ancak köprü freeze edilmişse anlamlıdır.

## 17.6 Kanal potansiyeli


Φ_χ = Λ·lnχ_S tanımının potansiyel dilindeki okuması. Karşılıklılık bozulmadığında Φ_χ ≡ 0'dır; potansiyel ancak asimetri kaynağı fiziksel olarak tanımlandığında anlamlıdır (Bölüm 17.1 koruması). Φ_χ ile Bölüm 4.2'deki tarihsel Φ(x) sembolü özdeşleştirilmez.

## 17.7 Nonreciprocity için zorunlu koşullar


Bölüm 8.8'deki mekanizma sınıflarının bu hattın yerel ifadesi: karşılıklılık koşullarını sağlayan (manyetik bias ya da zamanla modülasyon içermeyen) doğrusal ortamda S₂₁ = S₁₂ olur; pasiflik tek başına bunu garanti etmez.$\chi_S \neq 1$ aktif bir eleman gerektirmez; karşılıklılığı bozan somut bir fiziksel sınıf (ör. statik manyetik bias) yeterlidir. "Asimetri gördük = gravity" çıkarımı yasaktır (Bölüm 17.1b).

## 17.8 Nedensellik tersine çevirme ilkesi


Arşiv aday ilkesi: bir kanalda gözlenen yönsel asimetri, kaynağı "nedenselliğin zayıflaması" değil, kanalın yapısal önceliklerinin izdüşümüdür. Yön okuması kaynağa değil taşıyıcıya atıfta bulunur. Bu ilke model düzeyindedir; ontolojik bir nedensellik yorumu eklemez.

## 17.9 χ_S = 137 hipotezi — statü ve kırmızı bayrak kaydı


Arşivde χ_S'in ince yapı sabitiyle ilişkilendirilmesi denenmiştir. Kayıtlı statü:

$$\boxed{\;\chi_S \approx 137 \text{ hipotezi fit-türetim ayrımı çözülmeden kanona alınmaz.}\;}$$

| Kırmızı bayrak | Neden |
|---|---|
| Kaynak dışsallığı | Λ ölçek katsayısı dışarıdan alınmıştır |
| Çarpan belirsizliği | çarpım sabit, çarpanlar serbest |
| Asimetri yokluğu | karşılıklı sistemde χ_S ≡ 1 — hipotezin test edilebilir örneği tanımsız |

Bu hipotez sayaç üretmez; ön-kayıtlı bir köprü testine dönüşmedikçe AÇIK BORÇ olarak kalır.

---

# BÖLÜM 18 — KUANTUM OLGULARI

## 18.0 Kuantum davranışı ve faz rejim – eşik sınırı

Atom-altı düzey, c⁺ ile Cₘ arasındaki **faz rejim – eşik sınırında** bulunur — tıpkı $v=c$ sınırındaki ışık gibi. Dalga–parçacık ikiliği, ölçüm problemi ve kuantum davranışının zamanla tutarsız görünmesi bu sınırın davranışları olarak okunur: zaman kavramı c⁺ ile Cₘ arasında belirsizleşir, ölçüm ise her zaman Cₘ'de gerçekleşir.

Bu bir **okumadır**; kuantum mekaniğinin ölçülmüş öngörülerine dokunmaz. Örnek olarak **nötrino salınımı** — nötrinoların yolculuk sırasında tür değiştirmesi — sağlam biçimde ölçülmüş bir fenomendir ve faz eşiği sınırında bulunma okumasına adaydır. Nötrinoların ışıktan hızlı gittiğini öne süren 2011 ölçümü bir ölçüm hatası olarak geri çekilmiştir; Evertophy bu sonuca dayanmaz. Bu okumanın fiziksel bir açıklamaya dönüşmesi için Born olasılıkları, girişim, Bell korelasyonları, bağlamsallık ve sinyalsizlik aynı modelde geri kazanılmalıdır; bu açıktır.

## 18.1 Dolanıklık

$$\boxed{\;c^+ \text{ BİR İLETİŞİM KANALI DEĞİLDİR.}\;}$$

Bu, sinyalleme yasağını koruyan kritik kısıttır. Ve dürüst kayıt: Evertophy dolanıklığı **açıklamaz**; bir okuma çerçevesi önerir.

## 18.2 Faz sözlüğü

Aşağıdaki eşlemeler **tarihsel/kavramsal analoji veya model adaylarıdır** — çekirdek ontoloji değildir ve türetim değildir:

| Olgu | Faz okuması |
|---|---|
| Spin | Yapı düğümünün Cₘ üzerindeki durum etiketi |
| Pauli dışlama | Kayıt protokolünde adres çakışması engeli |
| Kuantum Zeno | Sürekli ölçüm mühürleme ritmini dondurur |
| Tünelleme | Kaydın gevşemesi, bariyerin aşılması, yeniden mühürlenme |
| Gecikmeli seçim | Mühürleme kararının zaman indeksinden bağımsız tutarlılığı |
| Belirsizlik | Cₘ okumasının sonlu çözünürlüğü |

$$\boxed{\;\text{Hiçbiri standart kuantum mekaniğinden FARKLI bir ÖNGÖRÜ üretmez.}\;}$$

## 18.3 QFT'nin statüsü

$$\boxed{\;\text{QFT, Evertophy'nin ALTERNATİFİ DEĞİL, Cₘ fazındaki ETKİN HESAP LİMİTİDİR.}\;}$$

### Yapısal ayrım kuralı

$$\boxed{\;\text{Ana metin SAF FAZ-ONTOLOJİSİDİR. QFT araçları, Cₘ hesaplarını ÇEVİREN bir EK KATMANDIR.}\;}$$

QFT parametrelerinin ilkece faz-bağımlı olabileceği önerilir; bu bağımlılıkların formu bilinmemektedir.

## 18.4 Vakumdan madde üretimi

Değişen arka planda parçacık üretimi hesapları **verili bir metrik** varsayar. Evertophy'de geometri Cₘ çıktısıdır.

$$\boxed{\;\text{Bu araçlar Cₘ İÇİNDE kullanılabilir; c}_0 \to C_m \text{ geçişine UYGULANAMAZ.}\;}$$

## 18.5 Laboratuvar analogları

Bose-Einstein yoğuşması ve süperakışkanlık, **toplu/koherent davranışın** örnekleridir ve **c₀'ın tek-yapı sezgisi** için kullanılır.

$$\boxed{\;\text{Her ikisi de c}_0 \text{ toplu davranış analojisidir. Süperakışkan} \to c^+ \text{ eşlemesi KULLANILMAZ.}\;}$$

Bunun nedeni: c⁺'ın ayırt edici özelliği koherans değil, **Cₘ madde desteğinin çözülmesidir**.

---


## 18.6 Dolanıklıkta yazma koruması (write-protection)


Arşivdeki aday okuma: dolanıklık, c⁺-aktif "write-protected correlation store" olarak modellenir.

| Kavram | Evertophy okuması |
|---|---|
| Mühürleme | yazma (write) |
| Restore | okuma (read) |
| Dolanıklık | c⁺-aktif, write-protected korelasyon deposu |
| Sinyalleme | restore aileleri nedeniyle engelli |

"Uzak korelasyonlar restore edilebilir ama değiştirilemez" cümlesi model adayıdır; sinyalleme yasağıyla uyumludur ama ondan türetilmiş değildir.

## 18.7 Jitter = bilgi taşıyıcı adayı


Planck-ölçekli jitter Δt ~ 10⁻⁴⁴ s'in bilgi taşıyıcısı olabileceği önerisi arşivde korunur:

$$\Delta t \sim \sqrt{\frac{G\hbar}{c^5}} \sim 10^{-44}\ \mathrm{s}$$

Statü: arşivdeki notlar (jitter bütçesi üst sınırı ~10⁻⁴⁴ s (zaman ölçeği; karşılık gelen frekans ~10⁴⁴ s⁻¹)) bilgi-kapasite kaydı olarak tutulur; jitter'in gerçekten bu nitelikte olduğu gösterilmemiştir ve CMT doğrusallaşması altında kendiliğinden ortadan kalkar.

## 18.8 Commit/rollback ontolojisi


Kuantum süperpozisyon için commit/rollback (onay/geri-al) dili: süperpozisyon "onaylanmamış tasarım alanı", ölçüm "commit" işlemidir.

$$\boxed{\;\text{Superposition = onaylanmamış taslak alanı; measurement = commit. Rollback sonrası Cₘ'de gerçekleşmez.}\;}$$

Bu bir model adayıdır — hesaplama dili ithalidir, ontolojik ilan değildir.

## 18.9 Entanglement swapping — zincirleme dolanıklık


Dolanıklık değişiminin arşiv okuması: "onay zinciri" (chain of approvals). Bell ölçümü aracı olmadan korelasyon aktarılamaz; bu okuma sinyalleme yasağıyla uyumludur, onu aşmaz. C⁺ = ağ, EPR = kısa devre, dolanıklık = write-protected korelasyon olarak işlenen analoji ailesi tamamı model düzeyindedir.

## 18.10 Üç aşamalı iç-içe çift yarık — fiziksel model


Ara katmanlı çift yarık kurulumu için arşivdeki fiziksel model: φ_b düzeyi c⁺'ya bağlanır; girişim örüntüsü dΦ(x) korelasyonundan doğar. Zamansızlık çözümü aday ifadesi: "c⁺ kalıcıdır; Cₘ zamanı türetilmiştir; süperpozisyon faz içi kalıcılıktır." Bu, ertelenmiş seçim deneylerinin çerçeve içi okumasıdır — türetim değil, yorum adayıdır ve Born kuralını türetmez.

## 18.11 Kuantum belirsizliği = render gürültüsü okuması


Belirsizlik ilkesinin "Cₘ okumasının sonlu çözünürlük gürültüsü" olarak okunması adayı, Bölüm 15.3'teki kısıtla aynı statüdedir: standart olasılıkları ve Born kuralını türetmedikçe fiziksel köprü sayılmaz. "Δx·Δp ≥ ℏ/2, σ_x σ_p ≥ ℏ/2" kayıtları ifade edilmiş hâl olarak korunur.

## 18.12 Kuantum yorumlarıyla karşılaştırma notu


| Yorum | Evertophy ile ilişki |
|---|---|
| **Kopenhag** | Ölçüm vurgusu paralel; "gözlemci" ontolojik sınıf değil (Bölüm 15.6) |
| **Çoklu-dünyalar** | Arşiv/şube dili c⁺ ile karıştırılmaz; c⁺ çoklu-dünya değildir |
| **Pilot dalga (Bohm)** | Gizli değişken programı çekirdeğe ithal edilmez |
| **QBism** | Yetersiz kaynak desteği nedeniyle ayrı başlık açılmamıştır; not düzeyinde korunur |
| **RQM** | Etkileşim-merkezli ölçüm dili paralel (Bölüm 7.11d) |

$$\boxed{\;\text{Evertophy hiçbir yorumu seçmez; ölçümü faz/readout/sealing diliyle yeniden konumlandırır (Bölüm 15.3).}\;}$$

---

# BÖLÜM 19 — TOPOLOJİ

## 19.1 Güncel topoloji

$$\boxed{\;\text{Tam çift yönlü üçgen: } c_0 \leftrightarrow C_m,\; C_m \leftrightarrow c^+,\; c_0 \leftrightarrow c^+\;}$$

Cₘ epistemik merkezdir; topolojik zorunlu aracı değildir.

## 19.1a Tam üçgen boyuttan bağımsızdır

Faz kapılarının tam üçgen oluşturması bir **tip** özelliğidir; belirli bir geometriye bağlı değildir. Bunu bir karşı-örnek netleştirir: yalnız bir doğru üzerine yerleşen kuyular bir zincir oluşturur ve tam üçgen veremez; ama bir çember üzerinde, örneğin $V(\theta) = -A\cos 3\theta$ gibi bir potansiyel, tek boyutta tam üçgen verir. Dolayısıyla "tam üçgen için en az iki boyut gerekir" genellemesi yanlıştır ve geri çekilmiştir.

İki boyutlu gerçeklemeler **model** düzeyindedir. İdeal eşkenar Gauss peyzajında kuyu genişliği $\sigma$ arttıkça yapı üç rejimden geçer: tam üçgen, merkez-yıldız ve tek düğüm. Rejim eşikleri analitik olarak bilinir:

$$\sigma^* = \frac{1}{\sqrt2}, \qquad \sigma_{\rm fold} \approx 0.7391346294$$

Bu sonuçlar çekirdeğin değil, modelin sonuçlarıdır. Okuma uzayının Öklid yapısı bir Cₘ temsilidir; c₀ ya da c⁺'a Öklid yapı atfetmez. Disk gerçeklemesinin "kanonik" ya da "tek" olduğu iddiası da geri çekilmiştir.

### Denklem seti — Faz topolojisi — Morse peyzajı ve tam üçgen

**Ne işe yarar, neden gerekli?** Üç faz (c₀, Cₘ, c⁺) arasındaki geçişlerin **tam bir üçgen** (her faz diğer ikisine bağlı, K3) oluşturduğu kanondur. Soru: bu yapı bir potansiyel peyzajında nasıl gerçeklenir, kaç boyut gerekir?

$$\chi = m - s + M \quad (\text{disk: } 3 - 3 + 1 = 1;\ S^1: 3 - 3 = 0)$$

$$V(\theta) = -A\cos 3\theta,\ \theta \in S^1 \quad \text{(karşı-örnek)}$$

$$V(\mathbf{x}) = -A\sum_{i=1}^{3}\exp\!\Big(-\frac{|\mathbf{x}-\mathbf{v}_i|^2}{2\sigma^2}\Big),\qquad \mathbf{v}_1 = (0,1),\ \mathbf{v}_{2,3} = \big(\mp\tfrac{\sqrt3}{2}, -\tfrac12\big) \quad \text{(ideal eşkenar Gauss modeli — tam gövde, DD F09)}$$

$$H(0) = \frac{3A(2\sigma^2 - 1)}{2\sigma^4}\,e^{-1/2\sigma^2}\,I \;\Rightarrow\; \sigma^* = \tfrac{1}{\sqrt2},\qquad \sigma_{\rm fold} \approx 0.7391346294$$

| $\sigma$ rejimi | $(m,s,M)$ | Komşuluk grafı |
|---|---|---|
| $0 < \sigma < 1/\sqrt2$ | (3, 3, 1) | $K_3$ |
| $1/\sqrt2 < \sigma < \sigma_{\rm fold}$ | (4, 3, 0) | $K_{1,3}$ |
| $\sigma > \sigma_{\rm fold}$ | (1, 0, 0) | tek düğüm |

**Semboller**

| Sembol | Anlam |
|---|---|
| $V$ | Okuma uzayındaki potansiyel |
| $(m, s, M)$ | Minimum, eyer, maksimum sayısı |
| $\chi$ | Euler karakteristiği |
| $K_3$, $K_{1,3}$ | Tam üçgen; bir merkez + üç kol |
| $\sigma$ | Gauss kuyularının genişliği |
| $A$ | Kuyu derinliği ($A > 0$) |

**Statü:** Tipli kapı K3 ★ · S¹ / disk / Gauss MODEL · ideal Gauss rejimleri ✅ MODEL · tam aralık sertifikası 🟡 · "$d_{\min}=2$", disk kanonikliği, Morse-7 ❌


## 19.2 Ek topolojik yapılar ithal edilmez

$$\boxed{\;\text{Ek boyut, torsiyon yapıları, Chern-Simons terimleri, süpersimetri, çoklu evren — HİÇBİRİ çekirdeğe ithal EDİLMEZ.}\;}$$

Bunlar gerekiyorsa **ayrıca gerekçelendirilmeli** ve parametre bedeli açıkça sayılmalıdır.

## 19.3 Bilinen yapısal kısıt

Tek bağımsız çevrimli bir yapıda, temsillerin imgesi devirli — dolayısıyla değişmeli — olur. Bu, değişmesiz bir ayar grubunun bütününün çıplak çevrimden üretilemeyeceği anlamına gelir. Buna karşılık tek çevrime üniter bir holonomi **atanabilir**: her üniter $U$ için $\rho(n)=U^n$ bir temsildir. Örneğin $U_{jk}=\omega^{jk}/\sqrt3$ ($\omega=e^{2\pi i/3}$, $j,k=0,1,2$) üniterdir ve faz değişmezi $J=\operatorname{Im}(U_{00}U_{11}U_{01}^*U_{10}^*)=\sqrt3/18\neq0$'dır. Doğru hüküm şudur: **çıplak faz topolojisi, belirli CKM/PMNS karışım değerlerini tek başına seçmez; bu seçim için ek fiziksel yapı gerekir.** Tek çevrim holonomisi yaklaşımı bir alternatif olarak açıktır ve fiziksel türetim bekler.

$$\boxed{\;\text{Bu bir YAPISAL KISITTIR — ek yapı ithal edilirse PARAMETRE BEDELİ doğar.}\;}$$

## 19.4 Sıra duyarlılığı

Çevrim boyunca biriken etki iki farklı nesneyle ölçülebilir: sıra-duyarsız bir skaler karakter, ve sıra-duyarlı bir sıralı taşıma. Abelyenleşme sıra bilgisini **siler**.

Damgalar tersinir olmadığından "holonomi" adı yalnız tersinir sektöre ayrılır; genel durum **sıralı taşıma**dır.

## 19.5 Çıplak üçgenin homolojisi

Eğer üç kenarlı yapı yalnız boundary graph olarak alınırsa:

$$V=3,\qquad E=3,\qquad \beta_1=E-V+1=1$$

ve:

$$\boxed{\;H_1\cong\mathbb Z,\qquad \pi_1\simeq\mathbb Z\;}$$

olur. Tek üreteçli temel grubun her temsilinin imgesi devirlidir; bu nedenle çıplak tek çevrim, değişmesiz bir ayar yapısını kendiliğinden üretmez ve belirli karışım değerlerini seçmez. Tek çevrime üniter bir holonomi atamak ise mümkündür (19.3).

Eğer üçgen bir 2-simplex olarak **doldurulursa**:

$$\boxed{\;H_1=0\;}$$

olur ve çevrim programının topolojik anlamı değişir. Bu nedenle "boundary mi, filled simplex mi?" sorusu ayrı formal karardır; full üç kenarın ontolojik varlığını değiştirmez.

## 19.6 Torsiyon ve ek yapı maliyeti

Çıplak boundary üçgeninde $H_1\cong\mathbb Z$ torsiyonsuzdur. Dolayısıyla:

$$W^k=I$$

gibi bir $\mathbb Z_k$ koşulu topolojiden bedelsiz çıkmaz; ek hücre/bağıntı/temsil yapısı ithal eder ve ParamBudget/BridgeBudget maliyeti doğurur.

## 19.7 Karakter ve sıra-duyarlı temsil

Sıra-duyarsız additive bilgi, abelianized karakter ile tutulabilir. Sıra-duyarlı içerik için:

$$\rho:M\to \operatorname{End}(V)$$

gibi bir temsil gerekir. $\rho(M)$ invertible bir altsektördeyse holonomy dili kullanılabilir; genel monoid etkisi için "ordered transport" daha doğru terimdir.

---

# BÖLÜM 20 — STANDART MODEL VE GENEL GÖRELİLİK

## 20.1 Hedef ve mevcut durum

Hedef: SM sabitlerini keyfî girdiler olmaktan çıkarıp faz yapısının çözümleri hâline getirmek.

$$\boxed{\;\text{Hiçbir SM sabiti için TÜRETİLMİŞ bir sayı ya da dar aralık ÜRETİLMEMİŞTİR.}\;}$$

## 20.2 🔴 Mekanizma ataması ≠ türetim

$$\boxed{\;\text{"Bu sabit şu faz olayına karşılık gelir" demek, o olayın sayıyı ÜRETTİĞİNİ göstermez.}\;}$$

Bu ayrım korunmazsa çerçeve, hiçbir şey öngörmeden her şeyi "açıklamış" görünür.

## 20.3 İki farklı problem

| Problem | Soru |
|---|---|
| **A — Mutlak değer** | Neden tam olarak bu sayı? |
| **B — Dinamik** | Bu nicelik koşullarla nasıl değişir? |

$$\boxed{\;\text{Evertophy şu an YALNIZ B'de ilerlemiştir.}\;}$$

## 20.4 Üç makine programı

Amaç: **az girdi → çok gözlenebilir**.

| Makine | Zincir | Hedef |
|---|---|---|
| **1 — Kinetik** | $X$, kenarlar → ayar kinetik katsayıları → kuplajlar | Ayar sektörü |
| **2 — Potansiyel** | $X$, kenarlar → etkin potansiyel → skaler sektör | Higgs benzeri nicelikler |
| **3 — Yukawa** | $X$, kenarlar → Yukawa yapıları → kütleler ve karışımlar | Fermiyon sektörü |

### 🔴 Hedef değer ≠ öngörü

$$\boxed{\;\text{Bir HEDEF DEĞERİ yazmak, onu ÖNGÖRMEK DEĞİLDİR.}\;}$$

Gözlemsel bir değeri "ulaşılacak hedef" olarak listelemek meşrudur; onu "öngörü" diye sunmak **değildir**. Asıl soru her zaman şudur: *neden bu değer?*

### Kill-testler

| Makine | Kill koşulu |
|---|---|
| 1 | Elektrozayıf tutarlılık ilişkileri ağaç düzeyinde geri üretilemezse |
| 1 | Kuplaj koşusunun bilinen katsayıları geri üretilemezse |
| 3 | Karışım matrisi serbest fit edilirse — gizlice parametre olarak geri girer |

### CKM ve tek-çevrim holonomisi

$$\boxed{\;\text{Çıplak faz topolojisi belirli CKM/PMNS değerlerini seçmez; tek çevrim holonomisi bir alternatiftir ve fiziksel türetim bekler (19.3).}\;}$$

Yaşayan hipotez göreli-sektör yapısıdır; ama serbest fit edilirse parametre bütçesi ihlal edilir.

### Makine ayrıntıları — yalnız program hedefi

Kinetik makine için araştırma zinciri:

$$X,\Delta \longrightarrow \{Z_B,Z_W,Z_G\}\longrightarrow\{\alpha_{\rm EM},\sin^2\theta_W,\alpha_s\}$$

olarak yazılabilir. Örneğin:

$$\sin^2\theta_W \stackrel{\rm aday}{=} \frac{Z_W}{Z_W+Z_B}$$

bir **aday parametrizasyondur**; gözlenen değeri yerine koymak türetim değildir. Aynı şekilde güçlü sektör için yalnız $\alpha_s$'nin azalması yetmez; bilinen perturbatif koşu katsayısının ilgili limitte geri kazanılması gerekir.

Skaler makine:

$$X,\Delta \longrightarrow V_{\rm eff}\longrightarrow\{v,m_H/v,\Gamma_{\rm vac}\}$$

ve Yukawa makinesi:

$$X,\Delta\longrightarrow\{Y_u,Y_d,Y_e,Y_\nu\}\longrightarrow\{\text{kütleler, CKM, PMNS}\}$$

şeklinde program hedefleridir. Bunlar güncel sayısal öngörü listesine girmez.


### Üç-minimum etkin potansiyel kaydı — aday

Tarihsel geliştirme kayıtlarında üç faz değerini etkin minimumlar olarak temsil eden model adayı:

$$V(C)=\beta(C-C_0)^2(C-C_m)^2(C-C_+)^2,$$

$$\Box C+V'(C)=J_{\rm int}$$

şeklindedir.

Bu denklem **fundamental phase ontology değildir**. Buradaki $C$ etkin order-parameter alanı olarak okunur; $\Box$ kullanımı Cₘ-effective field realizasyonuna aittir ve c₀/c⁺'a metrik veya tetrad sokmaz. $J_{\rm int}$, $\beta$ ve $C_i$ eşlemeleri türetilmeden bu form prediction üretmez.

## 20.4a Üç makinenin daha keskin kill-testleri

### Makine 1 — kinetik / gauge sektörü

Araştırma zinciri:

$$X,\Delta
\longrightarrow
\{Z_B,Z_W,Z_G\}
\longrightarrow
\{\alpha_{\rm EM},\sin^2\theta_W,\alpha_s\}.$$

Örnek aday parametrizasyon:

$$\sin^2\theta_W
\stackrel{\rm aday}{=}
\frac{Z_W}{Z_W+Z_B}.$$

Bu formun değeri, ölçülmüş $\sin^2\theta_W$'yi yerine koymak değil, **neden belirli bir $Z_W/Z_B$ oranının zorunlu çıktığını** gösterebilirse vardır.

Arşivde Makine-1 için kullanılan benchmark hedeflerinden biri:

$$\sin^2\theta_W^{\rm eff}(M_Z)\approx0.23149(13)$$

olarak kayıtlıdır. Bu sayı burada yalnız **ölçülmüş hedef/benchmark** statüsündedir:

$$\boxed{\;\text{measured benchmark}\neq\text{Evertophy prediction}\;}$$

Yayın veya sayısal karşılaştırma öncesinde kullanılan **scheme, convention ve dış kaynak** ayrıca doğrulanmalıdır.

Elektrozayıf minimum consistency hedeflerinden biri:

$$\rho_{\rm EW}
=
\frac{m_W^2}{m_Z^2\cos^2\theta_W}
\simeq1$$

ağaç-düzeyi limitinin geri kazanılmasıdır. Nötral kütle matrisi yapısı ve custodial consistency türetilemezse “elektrozayıf türetim tamamlandı” denmez.

Güçlü sektörde yalnız “$\alpha_s$ enerjiyle azalır” demek yetersizdir; perturbatif limitte bilinen bir-loop yapı:

$$b_0=11-\frac{2}{3}n_f$$

gibi katsayıların doğru effective limitten geri kazanılması gerekir.

### Makine 2 — etkin potansiyel / skaler sektör

Program:

$$X,\Delta\longrightarrow V_{\rm eff}
\longrightarrow
\{v,m_H/v,\Gamma_{\rm vac},\ldots\}.$$

Measured ratio veya coupling'i hedef olarak listelemek meşrudur; **target value prediction değildir**. Free potential function eklemek de sonsuz functional freedom anlamına gelebileceği için BridgeBudget'a yazılır.

### Makine 3 — Yukawa / flavor sektörü

Program:

$$X,\Delta
\longrightarrow
\{Y_u,Y_d,Y_e,Y_\nu\}
\longrightarrow
\{\text{kütleler},CKM,PMNS\}.$$

Tek phase-triangle çevriminin CKM'yi non-Abelian holonomy olarak otomatik üretmesi dışlanır. Yaşayan formal aday, iki sektörün göreli taşımasıdır:

$$V_{\rm mix}\stackrel{\rm aday}{=}H_u^\dagger H_d.$$

Ancak $H_u$ ve $H_d$ bağımsız serbest fit edilirse karışım matrisi gizlice input olarak geri girer. CP ihlali için yalnız determinant fazı yeterli değildir; Jarlskog-tipi invariant structure ayrıca geri kazanılmalıdır.

### Strong-CP notu

Bir exponential suppression parametresi ekleyerek $\theta_{\rm QCD}$'yi küçük yapmak, suppression scale serbestse fine-tuning'i başka sembole taşır. Güçlü çözüm, yeni tuning eklemek yerine yapısal/topolojik zorunluluk üretmelidir. Bu **program hedefidir**, mevcut çözüm değildir.

## 20.5 GR ile ilişki

GR **yanlış değildir** — Cₘ'nin etkin dilidir. Ama:

$$\boxed{\;\text{Evertophy'nin kullandığı eylem, TEMEL EYLEM DEĞİLDİR — Cₘ'nin ETKİN eylemidir.}\;}$$

## 20.6 Geri kazanılması gerekenler

| Hedef | Durum |
|---|---|
| Newton limiti, zayıf alan | Skaler-tensör dili üzerinden erişilebilir |
| FRW kozmolojisi | Erişilebilir |
| Kuantum formalizmi | Köprü yok |
| Ayar yapısı | Köprü yok; yapısal kısıt var |
| İkinci yasa | Kısmen kurulmuş |

## 20.7 Aktif olmayan türetim hatları

Nötrino kütleleri, baryon asimetrisi, tam Yukawa matrisleri ve mutlak fermiyon kütleleri için bugün **aktif ve doğal bir türetim köprüsü kurulmuş değildir**. Bu nedenle bunlar current numerical derivation programının merkezinde değildir.

Bu ifade kalıcı bir ontolojik yasak değildir; yeni bir köprü ancak ParamBudget/BridgeBudget bedeli ve bağımsız kill-testleriyle açılabilir.

---


## 20.8 Elektron = plazma bulutu modeli (tarihsel)


Erken katmanda elektronun "plazma bulutu" olarak ele alınması denenmiştir. Güncel çekirdekte parçacıklar Cₘ okuma projeksiyonlarıdır (Bölüm 10.3); bu model geri getirilmez. Kayıt, arşivin model çeşitliliğini göstermesi amacıyla korunur.

## 20.9 Proton kütlesi (QCD) — literatür sınıflaması kaydı


Proton kütlesinin büyük kısmı QCD dinamiklerinden gelir; Higgs mekanizmasının kuark kütleleri üzerinden doğrudan katkısı küçüktür. Kesin yüzdeler ayrıştırma yöntemine bağlıdır ve kaynak gösterilmeden kullanılmaz. Bu, çerçeve dışı bir literatür kaydıdır:

$$\boxed{\;\text{Kütle çoğunlukla dinamiktir; bu gerçek, Evertophy'nin kütle türetimini yapmış olduğu anlamına gelmez.}\;}$$

Lattice-QCD hesaplamalarının miktarın kendisi olduğu vurgulanır; proton kütlesi lattice QCD'den öngörülmüştür — çerçevenin henüz yapamadığı işin ölçütüdür, değil yapılmış işin.

## 20.10 "Doku düğümü" ve SU(3) türetimi sorusu


Renk hapsinin faz-kısıt diliyle okunması (Bölüm 25.8) güçlü adaydır; ancak SU(3) gauge yapısının kendisinin faz topolojisinden türetilip türetilemeyeceği açıktır. "Doku düğümü" terimi arşivde bu soruyu adlandırmak için kullanılmıştır; ontolojik terim değildir.

## 20.11 Üç nesil ve kütle hiyerarşisi oranı sorusu


Üç nesil yapısı ve kütle hiyerarşisinin (yukarıdan aşağıya ~10⁵⁵-10¹⁷ mertebeleri) faz yapısından türetilip türetilemeyeceği sorusu açıktır. Farklı yoğunluk seviyeleri için değişen faktörler önerisi (1, 20, 1836; 1, ~200, 3500) tablo kaydı olarak korunur — sayısal eşleşme türetim değildir.

## 20.12 QED süreç genliği uyum sorusu


Feynman diyagramlarının çerçeve içi yeniden okunmasının, ölçülmüş süreç genlikleriyle uyum koşulu altında yapılabilip yapılamayacağı sorusu açıktır. Bu soru, Makine programının (Bölüm 20.4) kapanmamış uçlarından biridir.

---

# BÖLÜM 21 — AMPİRİK DURUM VE DENETİM

## 21.1 Kapatılmış hat

Çerçevenin bir dönem en güçlü ampirik iddiası, farklı fiziksel alanlardan gelen verilerin yüzdelik hizalama yoluyla karşılaştırılmasıydı. Çok yüksek korelasyon değerleri elde edilmişti.

**Bu hat, iç denetimle kalıcı olarak kapatılmıştır.**

### Üç kök hata

| # | Hata | Onarılabilir mi |
|---|---|---|
| 1 | Veri zamana göre değil değere göre sıralanmış | Evet |
| 2 | **Fiziksel ortak anahtar yok** | **Hayır — yapısal** |
| 3 | Permütasyon testi yanlış soruyu test etmiş | Evet |

### Yapısal sonuç

Sıralama/pseudo-pairing işlemi, fiziksel ortak anahtar yokken bile güçlü görsel/korelasyon yapısı üretebilir. Bu nedenle yüksek korelasyon **tek başına** ortak gizli fiziksel koordinat kanıtı değildir.

Denetimde düzeltilmiş null/permutation koşusu ilgili iddiayı desteklememiştir. Arşiv-transfer kaydında düzeltilmiş koşu için $p\approx0.530$ (FAIL) raporlanır; bu sayı **archive-reported** statüsündedir ve raw-run provenance ile bağımsız son teyit bekler. Yapısal sonuç değişmez: çok-alanlı Xa/Xz/Xt hattı **ampirik kanıt statüsünden kalıcı olarak çıkarılmıştır**.

### Dil yasağı

$$\boxed{\;\text{Bu hat için "kanıtlandı", "kilitli", yüksek-sigma ifadeleri KULLANILAMAZ. Emekli sabitler GERİ GETİRİLEMEZ.}\;}$$

## 21.2 Yön değişikliği

$$\boxed{\;\text{"Veride korelasyon ARA" DEĞİL — "ARALIK TÜRET, sonra KARŞILAŞTIR".}\;}$$

Ve beş adımlı protokol:

| # | Adım |
|---|---|
| 1 | Verisi olan, birimli, tek hedef nicelik seç |
| 2 | Zinciri yaz ve **serbest parametreleri say** |
| 3 | Aralığı türet — önselden dar |
| 4 | **ÖN-KAYIT yap — veriye bakmadan** |
| 5 | Karşılaştır |

Kapanan hat tam da dördüncü adımda kaybetti.

### Şu anki birincil doğrulama sahası

$$\boxed{\;\text{Birincil aktif saha, çoklu-alan korelasyonu DEĞİL; "aralık türet, sonra karşılaştır" protokolleridir.}\;}$$

Nükleer bağlanma enerjisi zarf modülasyonu bu protokolün ilk somut uygulama adayıdır (Bölüm 22).

## 21.3 Veri kökeni mühürlenmelidir

$$\boxed{\;\text{"Önceden mühürledik" TEK BAŞINA YETERSİZDİR. VERİ SOYAĞACI da mühürlenmelidir.}\;}$$

Mühürlenecekler: öngörüyü üreten parametreleri belirleyen kayıtlar · hedef seçimi · veri sürümü · varsa ayrılmış test kümesi.

Aksi hâlde "kör görünen" ama aslında kör olmayan bir test elde edilir.

## 21.4 Mevcut ampirik varlıklar

Elde olanlar Evertophy **üzerine kısıtlardır**: zayıf alan testleri, atomik saat karşılaştırmaları, kütleçekim sabiti değişim sınırları, kozmolojik spektroskopi.

$$\boxed{\;\text{Hiçbiri Evertophy'nin ÖNGÖRÜSÜ DEĞİLDİR.}\;}$$

## 21.5 Yanlışlama araçları

### Hızlı-red eşikleri

Bir iddia şu durumlarda **derhal reddedilir**:

- Türetilen aralık, gözlem aralığıyla kesişmiyorsa
- Kör testte istatistiksel anlamlılık sağlanamıyorsa
- Bilinen yapıyı (ölçülmüş kabuk konumları gibi) silen ya da kaydıran bir sonuç veriyorsa
- Veri görüldükten sonra bir katsayı eklenmişse
- Aktif bir kısıt ihlal ediliyorsa

### FAIL-FAST S1 — arşivden çıkarılmış aday protokol

Aşağıdaki eşikler ontoloji postülası veya Evertophy öngörüsü değildir; gelecekte ön-kayıtlanacak model koşuları için **metodolojik aday** olarak korunur:

| Denetim | Aday karar kuralı |
|---|---|
| Arka plan uyumu | $\chi^2_{\rm red}\le1.2$ kabul bölgesi; $1.2$–$1.5$ uyarı; $>1.5$ sert red |
| Yapı büyümesi | $\Delta\chi^2_{\rm growth}\le0$ beklenir |
| Stabilite | ghost / gradyan / tachyon patolojisi → anında red |
| Etkin Planck kütlesi | $M_*^2\le0$ → red |
| Saat / sabit çapraz denetimi | $\Delta\alpha$ ile uyumsuzluk → red |
| Pencere kararlılığı | pencereler arası $\Delta\chi^2\le3$; $>5$ sert fren |
| Serbestlik maliyeti | yeni parametre başına iyileşme $<2$ ise şişme uyarısı |
| EFT yorumu | $\alpha_M$ türetilmeyip serbest bırakılıyorsa GR-sonrası eşik sinyali sayılır |
| Güçlü alan | EHT/GW sonucu “ufuk” değil, doğrulandığı kapsamda “ufuk-yakını” diliyle raporlanır |

Bu sayılar ön-kayıtlanmadan kanonik eşik değildir. Aynı nedenle arşivdeki $r_{\rm global}<0.5$ eşiği de **metodolojik adaydır**; veri görüldükten sonra kurtarma sınırı olarak kullanılamaz.

Üç gözlem protokolü araştırma programında saklanır: çok-prob eşzamanlılık (BAO/$f\sigma_8$/mercek residual kırılmalarının aynı $z$ çevresinde kümelenmesi), faz-duvarı sigmoid biçiminin pürüzsüz CPL'den ayrılması ve maskelenmiş yerellik. Bunlar **öngörü değil, falsification-bridge tasarımlarıdır**; Bölüm 0.4'teki altı koşul sağlanmadan $0/10$ sayacını değiştirmez.

### Wide-Kanon optimizasyon uyarısı — model notu

Çok-modlu bir posterior tek başına patoloji veya modelin yanlışlığı değildir. Patoloji hükmü; tanımlanamazlık, dal-seçimi, veri sonrası optimizasyon, kararsızlık veya fiziksel olarak kabul edilemez modlar gibi ek ölçütler gerektirir. Bu not, “en iyi modu seçip raporlama” yetkisi vermez; dal alışverişi yasağı ve worst-case raporlama aynen geçerlidir.

### Kesişim ölçüsü

Öngörü ve gözlem aralıklarının örtüşme oranı bir ölçüt olarak kullanılabilir.

$$\boxed{\;\text{Bu ölçüt bir MODEL KURTARMA aracı DEĞİL, yanlışlamanın parçasıdır.}\;}$$

### En kötü durum raporlaması

$$\boxed{\;\text{EN İYİ DURUMU raporlamak YASAKTIR. Uyum, EN KÖTÜ DURUM üzerinden raporlanır.}\;}$$

Yeni parametre başına uyum iyileşmesi belirli bir eşiğin altındaysa, model **serbestlik satın alıyordur**.

### Kill-switch aileleri

| Aile | Örnek |
|---|---|
| **Ontoloji** | $U_0$'ın dördüncü faz gibi kullanılması → red |
| **Ontoloji** | c⁺'a doğrudan metrik atfedilmesi → sert çelişki |
| **Notasyon** | Tarihsel çekirdeğin güncel $X$ yerine kullanılması → red |
| **Veri** | Veri sızıntısı → yayın kill |
| **Öngörü** | Kesişim ölçüsü sürekli düşük → öngörü reddi |
| **Aşırı uyum** | Aralık şişirme → kill |
| **Köprü** | Köprü hattı desteklenmezse → yumuşak kill |
| **Araç** | Bir aracın kendi çıktısını kanon ilan etmesi → çıktı reddi |

---


## 21.6 Aralık kesişim ölçüsü ve kalibrasyon disiplini

İki aralığın örtüşmesini nicelleştirmek için bir IOM-benzeri ölçü kullanılabilir:

$$\mathrm{IOM}(B_{\rm pred},B_{\rm obs})
=
\frac{|B_{\rm pred}\cap B_{\rm obs}|}
{|B_{\rm pred}\cup B_{\rm obs}|}$$

uygun bir measure seçimi altında.

Bu sayı **evrensel fizik yasası değildir**. Arşivde farklı koşularda 0.5/0.6/0.8 gibi pratik veya taslak eşikler görülür; ayrıca tarihsel kozmolojik-fit standardında $\mathrm{IOM}\ge0.7$ ve $\chi^2_{range}\le1.2$ **kilitli koşu eşiği** olarak kaydedilmiştir. Bu 0.7 değeri evrensel ontoloji sabiti değildir; final eşik veri tipine, hata modeline ve preregister edilmiş test protokolüne göre kalibre edilmelidir.

Temel anlam değişmez:

- **Sert red yalnız bantlar gerçekten ayrık olduğunda** verilir: $B_{\rm pred}\cap B_{\rm obs}=\varnothing$. $\mathrm{IOM}=0$ tek başına ayrıklık göstermez: sıfır genişlikli bir öngörü $[P,P]$ gözlem bandının içindeyse $\mathrm{IOM}$ yine 0 çıkar, ama öngörü doğrudur. Bu yüzden IOM yalnız pozitif genişlikli bantlar için tanısal bir skordur; red ölçütü değildir. *(Önceki sürümdeki "IOM = 0 ise reddedilir" ifadesi bu nedenle düzeltilmiştir.)*
- yüksek IOM: yalnız uyum gösterir; doğrulama değildir.
- prediction band'ı sonradan genişleterek IOM artırmak **overfit**'tir.

### Denklem seti — Yanlışlama ölçütü — IOM ve boş kesişim

**Ne işe yarar, neden gerekli?** Bir öngörü bandı gözlem bandıyla karşılaştırıldığında modelin **reddedilip reddedilmeyeceğini** belirler.

$$\text{Sert red} \iff B_{\rm pred} \cap B_{\rm obs} = \varnothing$$

**Semboller**

| Sembol | Anlam |
|---|---|
| IOM | Aralık örtüşme ölçüsü (genişlik tabanlı Jaccard) |
| $B_{\rm pred}$, $B_{\rm obs}$ | Öngörü ve gözlem bantları |
| $[P,P]$ | Sıfır-genişlikli (nokta) aralık |

**Statü:** IOM ile sert red ❌ · sert red yalnız boş kesişimde ★✅


## 21.7 Worst-case uyum ve serbestlik maliyeti

Range-valued model yalnız “en iyi nokta” üzerinden raporlanmamalıdır. Uyum, preregister edilen bandın **en kötü admissible** davranışıyla da değerlendirilir.

Bir $\chi^2$ veya likelihood metriğinde yeni parametre eklenmesi küçük bir iyileşme sağlıyorsa, iyileşme model serbestliğinin maliyetini aşmak zorundadır. Arşivde kullanılan “yeni parametre başına $\Delta\chi^2$” heuristikleri **metodolojik adaydır**, evrensel eşik değildir.

### Denklem seti — KAP-09 — aile reddi ve aralık $\chi^2$

**Ne işe yarar, neden gerekli?** Bir model ailesinin ne zaman reddedileceğini belirler: tek bir üyenin başarısızlığı mı yeterli, yoksa en iyi üyenin bile başarısız olması mı gerekir?

$$\chi^2(\theta) = \sum_i\left[\frac{y_i - f_i(\theta)}{\sigma_i}\right]^2, \qquad \text{aile reddi} \iff \inf_{\theta\in\Theta}\chi^2(\theta) > T, \qquad d\big(y, [l,h]\big) = \max(l - y,\ 0,\ y - h)$$

**Semboller**

| Sembol | Anlam |
|---|---|
| $\theta$, $\Theta$ | Ortak parametre vektörü ve izinli kümesi |
| $T$ | Eşik |
| $d$ | Noktanın banda en yakın uzaklığı |

**Statü:** Aile reddinde inf kuralı ✅ · sup kuralı ❌


### Aile reddi ile en kötü uyum

Bir model ailesinde tek bir parametre seçiminin başarısızlığı, bütün ailenin başarısızlığı değildir. **En iyi uyum**, ailenin tümüyle reddedilip reddedilemeyeceği için; **en kötü uyum**, parametre belirsizliği karşısındaki sağlamlık için önemlidir. İkisi birlikte raporlanabilir, ama birbirinin yerine geçmez; 21.5'teki en kötü uyum disiplini, aile reddi ölçütünü bozmaz. İstatistiksel olarak anlamlı sonuç bulunmaması otomatik çürütme değildir; veriyle uyum da "öngörü doğrudur" değil, **"belirtilen testte dışlanmadı"** olarak yazılır.

## 21.8 Kill-switch sınıfları

| Sınıf | Ne öldürür | Örnek |
|---|---|---|
| Ontology hard-kill | Çekirdek type ihlali | $U_0$'ı dördüncü faz yapmak; c⁺'a metric atamak |
| Bridge soft-kill | Köprü hattı | $\chi_S$ gravity ile bağlanmazsa kanal köprüsü kapanır |
| Data kill | Testin geçerliliği | veri sızıntısı / yanlış lineage |
| Method kill | İstatistik protokolü | yanlış null, pseudo-pairing |
| Overfit kill | Prediction iddiası | data-sonrası band şişirme / katsayı ekleme |
| Publication kill | Claim statüsü | kör olmayan sonucu blind prediction diye sunmak |
| Tool/AI kill | Provenance | aracın kendi üretimini “kanıt” ilan etmesi |

Kill-switch core ontology'yi her başarısız bridge ile yok etmez; **hangi katmanın reddedildiğini** açıkça belirtir.

## 21.9 Hata sınıfları — F / C / R

Kill-switch sonuçları aynı epistemik ağırlıkta değildir:

| Sınıf | Anlam | Sonuç |
|---|---|---|
| **F — Fatal** | Çekirdek programı durduran yapısal hata | İlgili temel yapı kapanmadan program ilerlemez |
| **C — Correctable** | Katsayı, limit, ölçek veya benzeri onarılabilir hata | Revizyon yapılır; program devam eder |
| **R — Retractable** | Belirli realizasyon/pencere/rota geri çekilir | Teori otomatik olarak ölmez; rota bilgisi üretilir |

Tarihsel F sınıfı dört çekirdek örnekle kaydedilmiştir: aynı varsayımdan doğrudan çelişki; gerekçesiz nedensellik ihlali; temel kavramın matematiksel olarak tanımsız kalması; geri-çekme/fail-fast mekanizmasının kendisinin işlememesi. Bu liste **her başarısız deneyin F olduğu** anlamına gelmez.

\[
\boxed{\text{FAIL-FAST}\neq\text{FAIL-TOTAL}}
\]

Eski Xa/Xz/Xt ampirik hattının geri çekilmesi ve belirli bridge testlerinin başarısızlığı, aksi ayrıca gösterilmedikçe **Class R** düzeyinde okunur. Bir R başarısızlığı çekirdek ontolojinin deneysel doğrulandığı anlamına da gelmez.


## 21.10 Zaman serisi kanıt protokolü v0.5

Zaman serisi analizinde kayıtlı protokol dört aşamalıdır: normalizasyon → rezidüel çıkarımı → çapraz-korelasyon → beyaz-gürültü testi. Bir kayıt-mühürleme imzasının bu protokolle nasıl sınanacağı açık bir araştırma sorusudur; protokol için sayısal eşikler henüz kaynakta tanımlanmamıştır.

## 21.11 H(z) gerçek Pantheon+ analizi — Evertophy vs ΛCDM

Kaynakta kayıtlı tarihsel bir koşu, Evertophy okumasını ΛCDM ile $H(z)$ verisi üzerinden karşılaştırmıştır: $\chi^2_{\min}=204.7$ ($\gamma=+0.328$, $n=300$), $\chi^2/\text{dof}=0.685$, $\Delta\chi^2=+2.7$ — yani bu koşuda Evertophy lehine bir üstünlük yoktur. Kayıt kendi proxy uyarılarını taşır. Pantheon+ doğrudan bir $H(z)$ tablosu değil, Tip Ia süpernova uzaklık verisidir; doğrudan karşılaştırma için yeniden kurma adımı ve tam kovaryans gerekir. Bu karşılaştırmanın ön-kayıtlı biçimde yenilenmesi açık bir araştırma görevidir. Sayaç 0/10.

## 21.12 Üçlü CDF Q-Align ve φ-manifold PCA testi


Üçlü CDF (X, z, t) Q-Align korelasyonu ve Φ-manifold PCA testinin koşuları arşivde korunur. Bütünüyle anonimleştirilmiş meta-koşularda bile anlamlı sapmaların gözlendiği raporlanır; ancak Bölüm 21.1'in yapısal hatası (fiziksel ortak anahtar yokluğu) bu hatları da sınırlar. Tüm koşular denetim borcuna tabidir — kanıt statüsü yoktur.

## 21.13 Null model testleri — C1–C5 ve genişletmeler


| Test | İçerik |
|---|---|
| C1 | zamana bağlı ağırlık |
| C2 | 3-bileşen rastgele doku |
| C3 | sabit faz farkı |
| C4 | düz evren (a(t) = H₀t) |
| C5 | sabit ses hızı |

Hiçbir null model Evertophy'yi reddetmez; ama hiçbiri onu desteklemez de. Null setinin görevi, "beklenen başarısızlıkları" önceden tanımlamaktır. Genişletme null'ları (shuffled-frequency, deterministic-phase, noise-only, constant-seed) arşivde tam listelenmiştir.

## 21.14 Destruction test seti D1–D5


| Test | Kırılganlık |
|---|---|
| D1 | parametre kaldırma |
| D2 | sabit değiştirme |
| D3 | fizik bozma |
| D4 | gürültü enjeksiyonu |
| D5 | şema değişimi |

D-setinin amacı: başarının fizikten mi, sayısal ayarlamadan mı geldiğini ayırt etmek. Bir bulgunun D-testlerinden geçmemesi, onun öngörü değil fit olduğunu gösterir.

## 21.15 Histerezis ve refresh-rate falsifikasyon protokolü


Faz-geçişinde beklenen histerezis / refresh-rate imzaları için tasarlanmış testler arşivde korunur: forward/reverse ramp, dwell-time denemeleri, frekans-sweep histerezisi. Bu testler öngörü değildir; köprü hattı desteklenirse uygulanacak protokollerdir.

## 21.16 Non-metricity histerezis testi


Weibel/connection anizotropisi (k_∥ vs k_⊥) ve non-metricity kaynaklı histerezis izlerinin aranması tasarımı. Kozmik Manyetizma Fizik Merkezi bulgularının (evrensel manyetik alanlar için ~100 kpc minimum ölçek) bağlam olarak işlendiği kayıtlıdır.

## 21.17 Gözlemsel anomali kataloğu ve 5-anomali stres testi

Kaynakta kayıtlı beş stres testi alanı: $z>10$ erken galaksiler, Hubble gerilimi, Axis of Evil, karanlık madde – MOND tartışması ve Little Red Dots. Bunlar Evertophy'nin sınanmak istediği alanlardır; hiçbiri için bir Evertophy açıklaması ya da öngörüsü kurulmuş değildir. Hubble gerilimi için çerçevenin önceki iddiası üç kez geri çekilmiştir.

## 21.18 Cosmic birefringence — framework metodoloji notu

Kozmik çift kırılma için kayıtlı not yalnız yöntemseldir: faz belirsizliği ve morfoloji. Gözlemsel açı değerleri ve anlamlılık düzeyleri doğrudan makale atfıyla desteklenene kadar bu belgede kullanılmaz. Sinyalin Evertophy okumasıyla ilişkisi açık bir araştırma sorusudur.

## 21.19 IPW signature test card (preregistered)


Faz içi dalgalar (IPW) hattının ön-kayıtlı test kartı: X_T spektral ayrışma imzası için parametre uzayı (A, ω, φ, FWHM, ρ) tanımlıdır; koşul başarısızlığı durumunda hat kapanır. Ön-kayıt, bu hattın kanıt statüsü kazanmasının tek yoludur.

## 21.20 BEC / süper-atom laboratuvar paketi — üç yanlışlanabilir öngörü


| Öngörü | Gözlem | Zaman penceresi | Statü |
|---|---|---|---|
| Gauss dışı ön-buzlanma imzası | 2D gazda | 1–5 yıl | Açık |
| Faz-duvarı sigmoid vs CPL ayrışması | kozmik | 5–10 yıl | Açık |
| Çok-prob eşzamanlılık (BAO/fσ₈/mercek) | kozmik | 10–15 yıl | Açık |

Hiçbiri henüz 0/10 → 1/10 kapısının altı koşulunu sağlamamıştır (Bölüm 0.4).

## 21.21 Laboratuvar protokol taslağı v0.1 ve faz-seçici pencere


Mikrodalga/atomik-fizik kavşak hatları için tasarım kayıtları: malzeme kayıpları, kalibrasyon, karşılıklılık kontrolleri, faz-seçici filtre pencereleri. Bütünü test tasarımıdır; deneysel sonuç değildir.

## 21.22 Optik saat instabilitesi kanalı (Yb/Sr)


Al+ ile ~10⁻¹⁸ mertebesinde kesirli frekans belirsizliği raporları bağlam olarak korunur; çerçevenin kendi saat-karşılaştırma protokolü buradan doğrudan sayı almaz — dış kısıt olarak kullanılır.

## 21.23 Veri seti kilitleri — AME2020 / Pantheon+ / frekans oranları


Kullanılan dış veri setleri için arşiv kilit kayıtları: AME2020 (Bölüm 22.5'teki Strict Blind Lineage ile birlikte), Pantheon+ (Bölüm 21.11), optik frekans oranları (Bölüm 21.22).

$$\boxed{\;\text{Bir veri setinin aynı anda hem kalibrasyon hem kör doğrulama kaynağı olması yasaktır (Bölüm 22.5).}\;}$$

---

## 21.24 Arşivdeki sayısal okumalar

Arşivde yirmiyi aşkın sayısal okuma bulunur — örneğin kararlılık adaları ve $10^{40}$, $10^{120}$ mertebesindeki büyük sayılar. Bunların hiçbiri ön-kayıtlı, ayırt edici bir öngörü değildir; envanteri ve her birinin statüsü V24 rolling master'da (§686) tutulur. Bir sayısal okumanın öngörü sayılması için ayırt edici olması, kill koşuluyla önceden kaydedilmesi ve kaynak türetiminin gösterilmesi gerekir. Sayaç 0/10.

# BÖLÜM 22 — NÜKLEER KÖPRÜ PROTOKOLÜ

Bu bölüm, "aralık türet sonra karşılaştır" protokolünün ilk somut uygulama tasarımını anlatır.

## 22.1 Hedef

Nükleer bağlanma yapısındaki **kabuk gücü modülasyonu**. Yani: kabukların *nerede* olduğu değil, *ne kadar güçlü* oldukları ve bu gücün kütleyle nasıl değiştiği.


## 22.1a Nükleer köprü zinciri — koşullu yapısal aday

Nükleer programın hedef zinciri, ayrı fundamental $X_A$ varlığı gerektirmeden bir domain readout ile yazılabilir:

$$[X_A]\equiv[\Pi_A(X)]$$

ve:

$$[X_A],[\Delta_{ij}]
\longrightarrow
[Z_G]
\longrightarrow
[\alpha_s(Q)]
\longrightarrow
\mathcal F_{\rm nuc}
\longrightarrow
[\Delta_{\rm shell}]_{\rm pred}.$$

Bu zincirde her ok **türetilmesi gereken bridge**'dir. Zincirin yazılmış olması prediction değildir. Özellikle $X_A$, audit-failed eski $X_a$ korelasyon değişkeninin yeniden kanonikleştirilmesi değildir; yalnız current one-$X$ ontology içinde atomik/nükleer context projection notasyonudur.

Protocol architecture conditional olarak kurulabilirken temel-den-nükleere türetim açık kalır.

## 22.2 İki katmanlı ansatz

$$[\Delta_{\rm kabuk}]_{\rm ET} \;=\; [\mu_A] \;\odot\; [\Delta_{\rm kabuk}]_{\rm yapı}$$

| Katman | Kim sağlıyor |
|---|---|
| $[\Delta_{\rm kabuk}]_{\rm yapı}$ | **Kabuk modeli** — konumlar, sihirli sayılar |
| $[\mu_A]$ | **Evertophy** — zarf modülasyonu |

$$\boxed{\;\text{Evertophy kabuk KONUMLARINI İCAT ETMEZ — ZARFI MODÜLE EDER.}\;}$$

## 22.3 Dört rota

| Rota | Yöntem | Öncelik |
|---|---|---|
| **α** | **Oranlar** — normalizasyon iptali + sıralama haritası + sıfır-kalibrasyon + mühürlü ön-kayıt | **Birincil** |
| β | Tek-çapa | İkincil |
| γ | Mutlak normalizasyon + doğrudan köprü fonksiyonu | Üçüncül |
| δ | Kalıntı analizi | Yardımcı |

**α'nın seçilme gerekçesi:** oran testi normalizasyondan arınmıştır; en temiz kesişim testini verir ve köprü fonksiyonuna en az bağımlıdır.

## 22.4 Kill koşulları

| Koşul | Sonuç |
|---|---|
| Öngörü–gözlem kesişimi boş | Yanlışlandı |
| Bilinen kabukları siliyor ya da kaydırıyor | **Yapı-koruma kill'i** |
| Veriden sonra kütle-bağımlı katsayı eklenmiş | **Parametre bütçesi kill'i** |
| Aktif bir kısıt ihlal ediliyor | Kill |
| Ayar aralığı nükleer veriye yeniden fit ediliyor | **Kör-projeksiyon kill'i** |

## 22.5 Veri soyağacı kilidi — Strict Blind Lineage

Mühürlenmesi gerekenler: bridge girdileri · parametre üretim kayıtları · hedef seçimi · veri sürümü · eğitim/kalibrasyon varsa kullanılan alt küme · kör hold-out kümesi · freeze zamanı.

$$\boxed{\;\text{"Önceden mühürledik" TEK BAŞINA YETMEZ.}\;}$$

Temel bağımsızlık kısıtı:

$$\boxed{
D_{\rm derivation}\cap D_{\rm blind}=\varnothing
}
$$

ve eğer bir bridge calibration parametresi gerekiyorsa:

$$\boxed{
\theta_{\rm bridge}\ \text{kör veri açılmadan ÖNCE freeze edilir}
}
$$

Üç metodolojik seviye ayrılır:

1. **En güçlü:** non-target/fundamental girdilerden prediction band türetilir; nükleer target verisi calibration'a girmez.
2. **Kabul edilebilir:** yalnız preregister edilmiş training subset kullanılır; bridge freeze edilir; strict hold-out ile test edilir.
3. **Prediction değildir:** full target dataset üzerinde fit edilip aynı dataset üzerinde başarı raporlanır.

Bu kural, AME2020 veya başka bir veri setinin aynı anda hem calibration hem blind doğrulama kaynağı olarak kullanılmasını engeller.

## 22.6 Statü

Bu hat, nükleer köprü programında **koşullu yapısal aday** olarak izlenir.

$$\boxed{\;\text{PROTOKOL MİMARİSİ KAPALI} \;/\; \text{TEMEL-DEN-NÜKLEERE TÜRETİM AÇIK}\;}$$

Bu nükleer köprü hattı **kanonik sayısal öngörü değildir**; sayaç $0/10$ olarak kalır.

Yani: *nasıl test edileceği* belirlidir; *ne öngörüleceği* henüz türetilmemiştir.

## 22.7 Uzak hedeflerin kullanımı

Henüz sentezlenmemiş ağır çekirdek bölgeleri, **ilk kör koşuda ana hedef yapılmaz**. Önce ölçülmüş kapanma bölgelerinde sınanır.

---


## 22.8 Genişletilmiş yarı-ampirik kütle formülü ve kabuk terimi düzeltmeleri


Arşivdeki yarı-ampirik form (E_B0 taban + FM çift-katman kabuk düzeltmesi + βX/ρΩ ilişkileri) Bölüm 22'nin yapısal aday katmanıdır. Kritik korumalar Bölüm 12.4'ten değişmez:

$$\boxed{\;\text{Evertophy zarfı modüle eder; kabuk konumlarını icat etmez; FM düzeltmesi dış fizik kalibrasyonudur.}\;}$$

Bu blokta [mod 33] doluluk-unsur katkısı, [mod 5] düzeltmesi, konuşan term ve δ_surf katmanları arşiv kaydı olarak korunur; hiçbiri öngörü sayılmaz.

## 22.9 κ_i(Φ, s) genişletilmiş form (∇²Φ dahil)


Kabuk modülasyonu parametrizasyonunun arşiv formu:

$$\kappa_i(\Phi, s) = \kappa_i^{(0)} + \kappa_i^{(1)}\,\frac{\Phi}{\Phi_{\rm ref}} + \kappa_i^{(2)}\,\frac{\nabla^2\Phi}{\Phi_{\rm ref}/L_{\rm ref}^2} + \kappa_i^{(3)}\,s$$

Burada Φ faz skaleri, s yapı parametresi, L_ref referans uzunluğudur. ∇²Φ dahil terim, yerel kütleçekimsel ortamın kabuk üzerindeki etkisini parametreleştirir. Tüm κᵢ katsayıları serbest parametredir; freeze edilmedikçe türetim iddiası yoktur.

## 22.10 Υ(Z,N;Φ) tam formu ve E_B boxed kaydı


Modüle bağlanma enerjisinin arşiv formu:

$$E_B(Z, N; \Phi) = E_B^{(0)}(Z, N)\cdot\left[1 + \Upsilon(Z, N; \Phi)\right], \qquad \Upsilon = \sum_i \kappa_i(\Phi, s)\,f_i(Z, N)$$

$$\boxed{\;E_B\ \text{boxed kaydı, katsayılar freeze edilmeden öngörü statüsü taşımaz.}\;}$$

Bu kayıt, Bölüm 22.6'daki statü hükmünün ("protokol mimarisi kapalı / temel-den-nükleere türetim açık") arşivdeki somut parametrizasyonudur.

---

# BÖLÜM 23 — YÖNTEM ONTOLOJİSİ

## 23.1 Bağlam ve risk

Çerçeve, tek bir araştırmacı tarafından, çok sayıda yapay zekâ sistemi araç olarak kullanılarak geliştirilmiştir. Bu ortamın en büyük riski **kendi kendini onaylayan bir döngüye** girmektir.

## 23.2 Çelişkili çoklu-sistem mimarisi

Birden fazla sistem eşzamanlı çalıştırılır ve bilgi **kasıtlı olarak bölümlendirilir**. Hiçbir sistem resmin tamamını görmez. *(Bu, maraton öncesi Değnek Ambarı yöntemidir. 23–26 Eylül maratonunda ise her turun bütün çıktıları tek bir metinde tüm katılımcılara verildi; ortak çıktıları gören sistemlerin mutabakatı bütünüyle bağımsız doğrulama sayılmaz.)* Araştırmacı tek entegratör olarak kalır.

### Kaynak ayrıştırma kuralı

$$\boxed{\;\text{Tüm üretim, MİMAR KAYNAĞI ve ARAÇ ÜRETİMİ blokları hâlinde AYRIŞTIRILIR.}\;}$$

Bu bir format tercihi değil, **epistemik/provenance güvenlik duvarıdır**. Bir araç kendi üretimini kanıt olarak sunamaz.

### Bilinen sınır

$$\boxed{\;\text{Çoklu sistem MUTABAKATI, BAĞIMSIZ KANIT DEĞİLDİR.}\;}$$

Sistemler benzer eğitim dağılımlarından geldiği için aynı yanlışa aynı anda kayabilirler. Kapatılan ampirik hat bunun somut örneğidir.

## 23.3 Doğrulama standardı

Geçerli bir doğrulama şunları içerir: açık türetim adımları · sembolik/hesaplamalı çıktı · yeniden üretilebilir hesap · kontrol edilmiş denklem izi. Ve iki fiziksel kontrol zorunludur:

**Ölçek kontrolü.** Çıkan sayı fiziksel olarak erişilebilir bir aralıkta mı?

**Konvansiyon kontrolü.** Sonuç, keyfî bir tanım seçiminin fonksiyonu mu?

$$\boxed{\;\text{ARİTMETİK DOĞRULAMA, FİZİKSEL DOĞRULAMA DEĞİLDİR.}\;}$$

## 23.4 Sayı sınıflandırması

| Sınıf | Ne |
|---|---|
| **Postüle** | Dış kaynağı da türetimi de yok |
| **Dış ölçüm** | Veriden alınmış |
| **Uyum/fit** | Veriye uydurulmuş |
| **Dal-içi türetim** | Bir model dalı içinde çıkarılmış |
| **Çerçeve çıktısı** | Ontolojiden türetilmiş |

Postülden türeyen bir sayı, dış ölçümden türeyene göre **epistemik olarak zayıftır**.

## 23.5 Parametre bütçesi

$$\boxed{\;\text{SERBEST GİRDİ SAYISI} \;<\; \text{ÖNGÖRÜLEN GÖZLENEBİLİR SAYISI}\;}$$

Bu, tekrar eden bir hata desenine karşıdır: bir **çarpımın** sabitlenip **çarpanların** serbest bırakılması.

### Fonksiyonel serbestlik

$$D_{\rm model} = N_{\rm skaler} + N_{\rm fonksiyonel} + N_{\rm hiper}$$

Serbest fonksiyonlar sonsuz serbestlik derecesi taşır; sonlu bir bazda parametrize edilerek fiyatlandırılmalıdır.

### Gerekli ama yeterli değil

$$\boxed{\;ab = 6 \text{ bilmek, } a \text{ ve } b \text{'yi ÖNGÖRMEK DEĞİLDİR.}\;}$$

Parametre bütçesi **gerekli bir filtredir**; tanımlanabilirlik ve dejenerelik ayrıca ele alınmalıdır.

### Köprü bütçesi (BridgeBudget)

Core ontolojiden gözlenebilir niceliğe giden bridge'ler de ayrı fiyatlandırılır:

| Serbestlik türü | Örnek |
|---|---|
| **Sürekli** | yeni ayarlanabilir katsayı |
| **Fonksiyonel** | serbest map/fonksiyon biçimi |
| **Yapısal** | yeni eşleme, sıra, seçim veya topology varsayımı |

Bir modelde $N_{\rm free}<N_{\rm obs}$ sağlansa bile serbest bridge fonksiyonu veya yapısal seçim prediction'ı fiilen geri alabilir.

$$\boxed{\;\text{ParamBudget geçmek} \;\nRightarrow\; \text{predictive closure.}\;}$$

## 23.6 Numeroloji ve yön hatası

| Risk | Ne |
|---|---|
| **Numeroloji** | Sayının kaynağı belirsiz |
| **Yön hatası** | Kaynağı belli ama **girdi** olarak girip **çıktı** diye sunuluyor |

İkincisi daha sinsidir. Ve bir uyarı işareti: fizikte çok yaygın bir sayıya rastlamanın önsel olasılığı yüksektir; eşleşmenin bilgi içeriği düşüktür.

## 23.7 Öldürme testi kültürü

$$\boxed{\;\text{YANLIŞ VARLIK} \;\neq\; \text{AÇIK BORÇ}\;}$$

Bir teorinin en tehlikeli hâli açık deliği değil, **kapalı sandığı yanlış hükmüdür**.

## 23.8 Dal alışverişi yasağı

Alternatif modeller **önceden** listelenir ve mühürlenir. Veriye bakıp en uyumlu dalı seçmek yasaktır.

## 23.9 Dil disiplini

Yasak: *"kanıtlandı"*, *"fiziksel yasa"*, *"tamamlanmış teori"*, *"çözüldü"*. Yerine: *"kuruludur"*, *"adaydır"*, *"açıktır"*, *"yapısal olarak dışlanır"*.

$$\boxed{\;\text{Dil gevşerse muhasebe gevşer.}\;}$$

## 23.10 Formal doğrulama katmanı

Çerçevenin ontolojik kısıtları Lean tabanlı formal paketlerde tip düzeyinde kodlanmıştır. Maraton öncesi proje envanterinde:

$$\boxed{\;66\ \text{legacy} + 53\ \text{V03} = 119\ \text{theorem declaration}\;}$$

bulunur. Kaynak arşivde bir koşuda temiz `lake build`, başka bir bağımsız araç koşusunda ise **119 teorem bildirimi ve eksik bırakılmış kanıt bulunmadığı** raporlanmıştır. Aynı atıf disiplini `stamp.py` sayımları ile $G_{\rm univ}(M)\simeq F_2$ ve $K(M)\simeq\mathbb Z^2$ araç teyitleri için de geçerlidir: bunlar kaynak koşularında raporlanmıştır; bu çalışma içinde ikinci kez yürütülmüş sayılmaz. Bu sürüm sonuçları kaynak-koşusu atfıyla kaydeder; ilgili ZIP/Lean/Python kaynakları burada yeniden çalıştırılmadığı için rapor “yerel bağımsız yeniden doğrulama” diye yükseltilmez. Bu sayı **fiziksel doğrulama sayısı değildir**.

23–26 Eylül 2026 maratonunun sonunda envanter şudur:

$$\boxed{\;46\ \text{üretim} + 223\ \text{arşiv} = 269\ \text{teorem/lemma bildirimi}\;}$$

Arşiv kısmı 66 eski, 53 V03 ve 104 V24 bildirimini içerir; üretim kısmı ise eski arayüzlerden yalıtılmış, tek kanonik çekirdektir. Hiçbir bildirimde eksik bırakılmış kanıt yoktur ("0 axiom" projenin kendi bildirimleri için bir sayımdır; Lean'in mantıksal temelinde hiç varsayım bulunmadığı anlamına gelmez) ve üretim çekirdeğinin eski arayüzlerden yalıtılmışlığı düşmanca test vakalarıyla ayrıca sınanmıştır. Bu sayı bir **biçimsel envanterdir**, fiziksel doğrulama sayısı değildir. Ayrıca iki aracın ya da iki yapay zekânın aynı sonuca varması, bağımsız yürütme kaydı yoksa bir tekrar-üretim değil, yalnız görüş uyumudur.

Formal kayıtlar beş sınıfta ayrılmalıdır:

| Sınıf | Anlam |
|---|---|
| **SPEC** | Tanım/aksiyomdan doğrudan gelen spesifikasyon sonucu |
| **DERIVED** | Genel tanımlardan türetilmiş theorem |
| **FINITE-CHECK** | Sonlu exhaustive tarama/sanity-check |
| **PHYS-BRIDGE** | Formal yapı ile fizik arasında ek bridge isteyen sonuç |
| **POLICY** | Muhasebe/metodoloji invariantı |

$$\boxed{\;\text{Bir FORMAL TEOREM, bir FİZİK TEOREMİ DEĞİLDİR.}\;}$$

### Açık formal borçlar

- rewrite/normalizer için genel birleşme ve global konfluans zinciri — **kapandı** (biçimsel olarak kanıtlandı; 14.2). Kalan biçimsel borçlar: arşiv–Σ entegrasyonu, kayıt kimliği tekliği ve iyi-biçimli arşiv, $X$-lifi ve köprü bütçesi, metrik yeniden inşa arayüzü, bağımsız sağlayıcıda derleme;
- integer surrogate'tan $I(\mathbb Q)$ / Real interval yapısına geçiş;
- kesin karakter $\omega$ ile kapsama aralığı $\Omega_{\rm enc}$'nin biçimsel tip olarak ayrılması;
- yön semantiğinin Archive–$\Sigma$ entegrasyonu;
- `rid` benzersizliği ve `WellFormedArchive`;
- $c_0\leftrightarrow c^+$ X-fiber yapısının ParamBudget/BridgeBudget muhasebesi;
- `U0_bidirectional := false` rezervinin ontolojik meta-katmanla uyumlu biçimde korunması;
- bağımsız dış derleme/replication.

Formal paket current ontology'nin type-consistency'sini sınar; GR/QFT recovery, alan denklemleri ve doğanın doğru teorisi olma iddiasını kanıtlamaz.


### 23.10a Double-Sealing — arşiv bütünlüğü protokolü

AI/format geçişlerinde denklemlerin yalnız render edilmiş görünümünü saklamak yeterli değildir. Arşiv metodolojisinde bir denklem kaydı mümkün olduğunda iki temsille korunur:

\[
S(E)=\{Skeleton(E)\in R_{\rm raw},\;Rendered(E)\in R_{\rm vis}\}.
\]

Bu **fizik postülası değildir**; denklem/provenance bozulmasını azaltan arşiv protokolüdür. Özellikle encoding onarımlarında ham/LaTeX iskeleti ile görünür temsil çapraz kontrol edilmeden toplu karakter mutasyonu yapılmamalıdır.

### 23.10b V24 teknik sonuçlarının ontoloji statüsü

- **Cₘ Zero-Vacuum Local Mass Lemma (§509.4):** koşullu skaler-tensör/EFT teknik sonucudur; model katmanında tutulur, çekirdek ontolojiye otomatik yükseltilmez.
- **Z-operatörü \(Z:\Phi\to T\):** tarihsel kinematik-dualite ailesinde tanımlanmıştır; eski \(d(x)/Z(x)\) notasyonuyla senkronu açık olduğundan güncel \(X\) tanımına primitive olarak eklenmez.
- **\(X_{\rm state}\to X_{\rm domain}\to X_{\rm read}\) katman şeması:** güncel Bölüm 4.5 “okuma yüzleri” ile doğrudan özdeşleştirilmez; aralarındaki eşleme açık düzenleme borcudur.
- **\(\Pi_{+\to m}\) ve “via \(c_0\) zorunlu” tarihsel hükmü:** tam çift yönlü üçgen kanonuyla uyumlaştırılmadan güncel geçiş yasası sayılmaz; mimar kararı bekler.

## 23.11 Tarihsel hatlar ve neden bırakıldıkları

| Hat | Neden |
|---|---|
| Lojistik skaler çekirdek | Bir modeldi; ontolojik $X$ değildi |
| Sayısal $U_0$ okumaları | $U_0$'ı Cₘ niceliğine indirgiyordu |
| Çok-alanlı korelasyon hattı | Yapısal artefakt |
| Çıplak faz topolojisinden belirli CKM/PMNS değerlerinin seçimi | Ek fiziksel seçim yapısı olmadan değerler belirlenmez; tek çevrim holonomisi açık bir alternatiftir (19.3) |
| Zincir topolojisi | Tam üçgenle değiştirildi |
| Nokta-fizik yasağı dili | $[P,P]$ meşrudur |
| Sıfır Enerji / Düz Evren hattı | Raf kararı; güncel çekirdeğin çözülmüş sonucu değildir |
| Lagrangian MHTML kaydı | Kurtarma/provenance notu; dış fazlara eylem yazma yetkisi vermez |

Bu kayıtlar silinmez; **neden bırakıldıklarıyla** saklanır.

## 23.12 Eşsesli kavramlar için belge sınırı

Başka çalışmalarda geçen “çıplak iskelet” benzeri terimler, buradaki c₀ “iskelet” analojisiyle aynı kavram değildir. Ortak sözcük, farklı belge ailelerine ait kavramları anlam bakımından birleştirme yetkisi vermez.

---


## 23.18 DISCARD grubu — kayıt ve gerekçe disiplini


Dışlanan öneriler silinmez; reddedilme gerekçeleriyle korunur (yöntem: "eksi kayıt disiplini"). Eleme gerekçeleri META TABLO 2'deki gibi bir sınıflandırmayla tutulur: kapsam dışı, yetersiz kaynak, tekilleştirme, çelişki.

## 23.19 Araç kaynaklı epistemik riskler (yapay zekâ yanılgıları dahil)


| Risk | Önlem |
|---|---|
| Halüsinasyon kaynaklı içerik | kaynak-etiketi zorunlu; doğrulanamayan içerik belgeye girmez |
| Aynı yanlışa ortak kayma | görünürlük ledger'ı; çapraz denetim |
| Araç çıktısını kanıt ilan etme | kaynak ayrıştırma kuralı (Bölüm 23.2) |
| Sayısal uydurma | EK H provenance kaydı; dış kıyas yeniden doğrulanmadan kullanılmaz |

## 23.20 Minimum Safe Claim / Son Hüküm çıktı protokolü


Her çalışma koşusunun çıktısı için asgari güvenli iddia formatı: kanonik olmayan içerik "STATÜ + KAYNAK + KORUMA" üçlüsüyle taşınır; koruma cümlesi olmayan içerik belgeye girmez. Bu protokol monografinin hazırlık sürümlerinde kanonik olmayan bölümlere uygulanmıştı; yayın metninde güven düzeyi doğrudan cümlede belirtilir.

## 23.21 Dual-Render ve LODO doğrulama protokolü


Double-Sealing'in (23.10a) çalışma katmanı uzantısı: her denklem ham iskelet + görünür render ile saklanır; LODO (leave-one-dataset-out) doğrulaması veri setleri arası taşma kontrolü için tanımlıdır.

# BÖLÜM 24 — SINIRLAR VE AÇIK SORULAR

## 24.1 Altı kritik soru

| # | Soru |
|---|---|
| **1** | Faz sektörlerinin durum-uzayı ayrışımı nedir? |
| **2** | Fazların alan-uzayındaki konumları nerededir? |
| **3** | Kütleçekim kuplajının karakteristik ölçeği nedir? |
| **4** | Okuma haritasını **tekil kılan ek ilke** nedir? |
| **5** | Faz sayısı ve dağılımın gerekçesi nedir? |
| **6** | Cₘ neden zayıf-kuplaj sabit noktasıdır? |

**Ve merkezî boşluk:**

$$\boxed{\;X \;\longrightarrow\; \{\text{fiziksel fonksiyonlar}\} \quad \text{ZİNCİRİ YAZILMAMIŞTIR.}\;}$$

### Dördüncü sorunun biçimsel yeri

Dördüncü sorunun neden zor olduğu kesin olarak gösterilmiştir. Tip kuralları, aralık güvenliği, sabit uç noktalar, monotonluk ve iyi-tanımlılık — bunların hepsi birlikte bile $X$'ten fiziksel niceliğe giden köprüyü **tekil olarak seçmez**; iki farklı köprü bu koşulların tamamını sağlayabilir. Sonlu bir oyuncak modelde bu Lean'de, sürekli durumda ise analitik karşı-örneklerle gösterilmiştir.

$$\boxed{\;\text{Tip} + \text{aralık} + \text{iyi-tanımlılık} \;\nRightarrow\; \text{tekil köprü}\;}$$

Sonuç açıktır: okuma haritasını tekil kılacak olan bir **fiziksel seçim ilkesi** ve gözlemdir. Zayıf alanda, sabit katsayılı bir yanıt operatörü için doğrusal yanıt koşullu olarak türetilebilir; ama $X$'ten kaynak, katsayı ve sınır verisine giden kurucu harita açıktır. Merkezî boşluk artık yalnız "yazılmamış" değil, **nerede durduğu belirlenmiş** bir boşluktur. Genel fiziksel seçici, dondurulmuş açık borçtur (EK K.1).

### Denklem seti — Köprü tekil-olmama ve ayırt edici ilkeler

**Ne işe yarar, neden gerekli?** $X$'ten Cₘ'deki fiziksel niceliklere giden **köprü** ($J_X$ / $\mathcal{E}_\phi$) Evertophy'nin gözlemle temas noktası. Soru: tip ve iyi-tanımlılık kuralları bu köprüyü **tek başına seçebilir mi?**

$$B_1(x) = x, \qquad B_2(x) = x + \tfrac{x(1-x)}{2} \quad (B_2' = \tfrac32 - x > 0) \qquad B_1(\tfrac12) = \tfrac12 \neq \tfrac58 = B_2(\tfrac12)$$

$$\operatorname{diam} B(I_x) \leq \frac{L_x}{1-q}\operatorname{diam} I_x \ \text{(büzülme)}, \qquad \leq \frac{L_x}{\mu}\operatorname{diam} I_x \ \text{(varyasyonel)}$$

| Ayırt edici ilke | $B_1$ | $B_2$ | Hüküm |
|---|---|---|---|
| Toplamsal süperpozisyon $B(x{+}y) = B(x) + B(y)$ | ✓ | ✗ | ✅ **tekil seçer** (Cauchy + monotonluk) |
| Çarpımsal bileşim | ✓ | ✗ | 🟡 $x^p$ ailesine indirger |
| Yansıma simetrisi | ✓ | ✗ | 🟡 tekil değil |
| "Varyasyon ilkesi tek başına seçer" çıkarımı | — | — | ❌ Çıkarım başarısız: $J_1=\int_0^1 \tfrac12 B'^2\,dx \to B_1=x$ ve $J_2=\int_0^1 (\tfrac12 B'^2-B)\,dx \to B_2=\tfrac32x-\tfrac12x^2$; ikisi de kesin konveks ve tek çözümlüdür. Varyasyonel yöntem matematiksel olarak başarılı bir alternatiftir; hangi eylemin fiziksel olduğu açıktır |
| Sonlu kalibrasyon | — | — | ❌ DD'nin $B_\varepsilon$ karşı-örneği |
| Korunum tek başına | — | — | ❌ toz ve radyasyon aynı süreklilik denklemini sağlar |

**Semboller**

| Sembol | Anlam |
|---|---|
| $A_{\min}$ | Dondurulmuş minimal aksiyomlar: A1 tip · A2 Range güvenliği · A3 sabit uç noktalar · A4 monotonluk · A5 tek çıktı |
| $B_1, B_2, B_\varepsilon$ | Aday köprüler |
| $q$, $L_x$, $\mu$ | Büzülme sabiti, Lipschitz sabiti, güçlü konvekslik |

**Statü:** No-go ✅ · sonlu seçici OYUNCAK · genel fiziksel seçici ⏸


### Denklem seti — Fiziksel köprü adayları — A / B / C ve seçim zinciri

**Ne işe yarar, neden gerekli?** Köprünün tip kurallarıyla seçilemediği gösterilmiştir (24.1). Bu set, **hangi fiziksel ilkelerin** serbestliği ne kadar daralttığını ve nerede ampirik kalibrasyonun kaçınılmaz olduğunu kurar.

$$\textbf{A:}\ G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4}\,T_{\mu\nu}[J_X] \qquad \textbf{B:}\ S = \int\!\sqrt{-g}\Big[\tfrac{M^2}{2}F(\chi)R - \tfrac12 K(\chi)(\nabla\chi)^2 - V(\chi)\Big] + S_m[A^2 g]$$

$$\textbf{C (DD CANDIDATE-01):}\ -\nabla\!\cdot\!(Z\nabla\phi) + \mu^2\phi + 4\pi G\rho = 0,\qquad \phi_{\rm dış} = -C\,\frac{e^{-m r}}{r},\ \ m = \frac{\mu}{\sqrt{Z}}\ \ (\text{sabit } Z > 0)$$

kaynaksız bölgede sabit $Z$ için denklem $\nabla^2\phi = (\mu^2/Z)\phi$ olur; sönüm $m = \mu/\sqrt{Z}$'dir. Önceki $e^{-\mu r}$ yazımı yalnız $Z = 1$'de doğrudur. $Q$ terslemesi **$m$'yi** verir; $Z$ bilinmiyorsa oran $\mu$ ile $Z$'yi ayrı belirlemez. Einstein denkleminde fiziksel birimlerle $8\pi G/c^4$ (c = 1 biriminde $8\pi G$).

$$Q(m) = e^{-m(r_2 - r_1)}\,\frac{1 + m r_2}{1 + m r_1},\ \ 0 < r_1 < r_2,\ m > 0\ \ (\text{kesin azalan},\ Q(0) = 1,\ Q(\infty) = 0) \;\Rightarrow\; m \in \big[Q^{-1}(Q^+),\ Q^{-1}(Q^-)\big],\ \ 0 < Q^- \leq Q^+ < 1$$

**Seçim zinciri:**

| İlke | Sabitlediği | Kalan serbestlik |
|---|---|---|
| Lovelock teoremi | Geometri tarafı — **varsayımlarla**: 4B, yalnız metrikten, yerel/doğal, simetrik, ıraksaksız ve metrik türevlerinde ikinci mertebe ⇒ $aG_{\mu\nu} + bg_{\mu\nu}$ | Tümü $J_X$'te |
| P1 — kovaryans + korunum | $T$'nin keyfi olmaması | Korunumlu her tensör |
| P2 — varyasyonel köken (Hilbert tensörü) | Korunumu kabukta otomatik kılar | $F, K, V, A$ |
| P3 — **global kısıtlı alt-sınıf**: $F \equiv 1$, $K \equiv 1$, $A \equiv 1$ | $G_{\rm eff}$ sabitliği; madde bağlaşımı | **yalnız $V(\chi)$** — yalnız bu global kabulle |
| P3′ — **yerel donmuş-GR eşleşmesi**: $F(\chi_0) = 1$, $F'(\chi_0) = 0$, $A(\chi_0) = 1$, $A'(\chi_0) = 0$, $V'(\chi_0) = 0$, $V(\chi_0) \propto \Lambda M_{\rm Pl}^2$ (normalizasyona bağlı) | Yalnız $\chi_0$ çevresindeki eşleşme | $F, K, A$ **global fonksiyon serbestliği kapanmaz**; $A'(\chi_0) = 0$ tek başına "yalnız $V$" sonucunu vermez |


| $J_X$ bileşeni | Statü |
|---|---|
| Sabit-katsayılı zayıf-alan **yanıt operatörü** | ✅ DERIVED-CONDITIONAL |
| $X \to (\rho, Z, \mu,$ sınır verisi$)$ kurucu haritası | ⏸ AÇIK |
| Güçlü alan | ⏸ AÇIK |
| $V(\chi)$ (kısıtlı P3 modelinde) | 📏 Ampirik kalibrasyon ($\dot G/G$, PPN $\gamma$, $w(z)$) |

**Semboller**

| Sembol | Anlam |
|---|---|
| $G_{\mu\nu}$, $\Lambda$ | Einstein tensörü, kozmolojik sabit |
| $T_{\mu\nu}[J_X]$ | $X$'ten gelen kaynağın enerji-momentum tensörü |
| $\chi = \pi_\chi(X)$ | Skaler izdüşüm |
| $F, K, V, A$ | Skaler-tensör kuramının serbest fonksiyonları |
| $Z$, $\mu$ | Ekranlı-Poisson katsayı alanı ve ekranlama kütlesi |
| $Q(m)$ | İki yarıçaptaki alan oranı; $m = \mu/\sqrt{Z}$ sönüm parametresi |

**Statü:** A: KÖPRÜ (standart taban) · B: MODEL (global P3 alt-sınıfı) · C: MODEL (test yatağı) · zayıf-alan yanıtı DERIVED-CONDITIONAL · genel $J_X$ ⏸


## 24.2 Diğer açık sorular

Dondurulmuş açık borç listesi EK K.1'dedir; aşağıdaki sorular onunla birlikte okunur.

Metrik-doğuş haritaları · potansiyel yapısının faz sayısıyla uyumu · tercihli çerçeve riski · iki saat sorunu · global korunum yasaları · pertürbasyon ve stabilite kriterleri · $X$'in argüman ailesi · ayar gruplarının kökeni · **$\Gamma/\mathcal G_{C_m}$ çift-sayım borcu:** eski $C_s$ köprülerinde hem $\Gamma\sim1/C_s$ hem $\mathcal G_{C_m}\sim1/C_s$ okunursa $dt/d\lambda\sim1/C_s^2$ çıkar; iki faktörün bağımsız fiziksel roller mi yoksa aynı rolün iki temsili mi olduğu açık kalır.

**Rezerve başlıkların semantiği:** SYNTAX ↔ $U_x$ ↔ $X$ ilişkisinin tipi · faz rejim – eşik sınırının genişliği ve $X$ ile bağı · Faz Çöküşü ile Faz Yırtılmasının tam tanımları (Bölüm 25).

**Global seviye açık soruları:** global okların matematiksel tipi (faz kapısı olmadıkları bilinir) · $U_x$'in ontolojik tipi (kapsama mı, üyelik mi) · $U_+$ için işlev cümlesi ve genelleşmiş doğuş kuralı · $\mathrm{CycleSeed} \dashrightarrow \mathrm{Genesis}$ bağı · devre indeksinin zaman-dışı tanımı.

## 24.3 Bilinçli olarak açık bırakılanlar

$$\boxed{\;X\text{'in tam matematiksel gerçekleştirmesi BİLİNÇLİ OLARAK AÇIKTIR.}\;}$$

$U_0$'ın ön-katman iç yapısının tam karakterizasyonu ve $X$'in **nihai matematiksel tipi / kapanış yasası / özellik-aileleri ortak değişim yasası** aynı kategoridedir. Buna karşılık $X$'in kavramsal rolü güncel çekirdekte açıktır: tek, dinamik, faz/aralık/bağlam-duyarlı üst çözücüdür. Açık bırakılan şey kavramsal anlamı değil, matematiksel gerçekleştirmesidir.

## 24.4 Yasak yorumlar — toplu liste

### Global seviye
$U_0$, $U_x$, $U_+$ faz **değildir** ve faz üçgenine yerleştirilmez · $U_+$ beşinci düğüm, $c^+$, $X$ ya da gelecek **değildir** · $U_+$ "son durak/ölüm" **değildir** · global kutuplar **eşik değildir** · global oklar **faz kapısı değildir**, faza değil **bütüne** bağlanır · global çift yönlülük matematiksel tersinirlik **değildir** · global devre bir **zaman akışı ya da zorunlu periyodik çevrim değildir** · $U_0 : c_0 :: U_+ : c^+$ eşlemesi **kurulmaz** · Big Yırtılma standart terminal Big Rip ile **özdeşleştirilmez** · $U_0 \leftrightarrow U_+$ doğrudan ilişkisi hakkında **hüküm verilmez** · global seviyede metrik, tetrad, hız ya da süre **yazılmaz**.

### $U_0$
Faz değildir · kapı uç noktası değildir · c₀ alt türü değildir · topolojik delik değildir · lif değildir · metafizik varlık değildir · sayısal kütle değeriyle özdeşleştirilemez · $u(0)$ ile karıştırılamaz.

### c₀
Zamansal başlangıç anı değildir · zaman "durmuş" değil, **yoktur** · tarihsel aşırı-somut tanımlar (tam Planck doygunluğu, durağanlık kilidi, sıfır-diferansiyel motor) güncel çekirdek değildir.

### c⁺
Vakum **değildir** · gelecek **değildir** · iletişim kanalı **değildir** · Cₘ madde desteği çözülür · Cₘ metrik uzunluğu/süresi/hızı aynen taşınmaz · Cₘ-tipi maddesel/rest-mass taşıyıcı madde varsayılmaz · tarihsel K2 `Dim.mass` kaydı güncel c⁺-yerel kütle gözlenebiliri sayılmaz · ışık-üstü madde **değildir** · olay ufkuyla sert özdeşliği **kurulmamıştır**.

### $X$
Çekim Kuvveti değildir · kütleçekim değildir · metrik değildir · tek skaler değildir · lojistik fonksiyon değildir · matris satırı değildir · özelliklerin ortalaması değildir · $[0,1]$ ile sınırlı değildir · bölünmez · yalnız izinlilik filtresi değildir · yalnız çözüm-sonrası readout katmanı değildir · faz-aşırı statüsü yalnız boyutsuzluktan türemez.

### Aralık formalizmi
"Noktasal fizik yasaktır" dili **kullanılmaz** · $[P,P]$ meşrudur ve özel bir mekanizma gerektirmez · aralık-değerli olmak zamanla değişken olmak değildir.

### Topoloji ve cebir
Zincir topolojisi güncel değildir · karışım-simpleks modeli zorunlu değildir · $U_0$ topolojik merkez yapılmaz · ek topolojik yapılar ithal edilmez · birim ile "damga yok" tip düzeyinde özdeşleştirilmez · grup tamamlaması fiziksel tersinirlik anlamına gelmez.

### Genel
**Harita konumu ≠ faz üyeliği** · $U_x$ dördüncü faz veya $X$'in başka adı değildir · boyutsuzluk geçiş için yeterli değildir · yapısal benzerlik doğrulama değildir · mekanizma ataması türetim değildir · aritmetik doğrulama fiziksel doğrulama değildir · formal teorem fizik teoremi değildir · varlık kayda indirgenmez.

## 24.5 Çerçevenin kendi hakkındaki hükmü

$$\boxed{\;\text{Evertophy şu anda TAMAMLANMIŞ BİR TEORİ DEĞİL, TEORİ OLMAYA HAZIRLANMIŞ BİR YAPIDIR.}\;}$$

---


## 24.6 X(x) rejimler arası geçiş sürekliliği sorusu


X'in farklı faz/rejimler arasında geçişte sürekli davranıp davranmadığı sorusu açıktır. Arşivdeki discontinuous limit riski kaydı korunur: aday bir X tipi seçilirken geçişlerde süreksizlik üretip üretmediği ayrıca sınamalıdır. Bu, X'in "tam matematiksel gerçekleştirmesi açık" kararının (Bölüm 24.3) somut uçlarından biridir.

## 24.7 m_Ξ efektif kütle sayısal değeri sorusu


Faz-bağımlı propagatör kütlesi m_Ξ için sayısal değer önerisi arşivde bulunur; ancak değer freeze edilmemiştir. EK H disiplini gereği freeze edilmemiş sayı bu belgeye girmez.

## 24.8 Bilinç — temkinli işaret (rezerv çerçeve kaydı)


Arşivdeki kayıt tek cümleyle korunur: bilinç kavramı çerçevede yer almaz; "uzak hedef" olarak işaretlenmiştir.

$$\boxed{\;\text{Bilinç Evertophy'nin konusu değildir; gözlemci Cₘ-içi fiziksel sistemdir (Bölüm 15.6).}\;}$$

## 24.9 Hamiltonian formülasyonunun reddedilme gerekçesi (c₀'daki durum)


c₀'da Hamiltonian formülasyonu reddedilir; gerekçe Cₘ'deki yapının c₀'a ithal edilmesi yasağıdır (Bölüm 15.2). "dt = 0" dili pedagojik kısaltma olarak kalır (Bölüm 3.2); Hamiltonian'ın kendisi c₀'daki durumun tanımı değildir.

---

# BÖLÜM 25 — REZERVE ONTOLOJİK BAŞLIKLAR VE MEKANİZMA ADAYLARI

Bu bölüm, çerçevede **açılmış ama kapatılmamış** başlıkları taşır. Hepsi kayıtlıdır; ancak bazılarında **ad, ayrım kuralı veya ontolojide yer alma kararı** mimar düzeyinde sabitlenmiş olabilir. Buna karşılık burada açık olarak işaretlenen başlıkların **tam ontolojik semantiği ve/veya mekanizması henüz kapanmamıştır**. Rezerve ontolojik başlık, mekanizma adayı ve tamamlanmış kanon aynı statü değildir:

$$\boxed{\;\text{REZERVE ONTOLOJİK BAŞLIK} \;\neq\; \text{MEKANİZMA / DÜŞÜNCE DENEYİ ADAYI}\;}$$

| Sınıf | Ne | Kim açar |
|---|---|---|
| **Rezerve ontolojik başlık** | Çerçeveye ekleneceği kararlaşmış, ama tam semantiği yazılmamış yapı | Yalnız mimar |
| **Mekanizma adayı** | Bir olguyu çerçeve diliyle okuma denemesi | Çalışma katmanı; ayrı türetim ve ön-kayıt gerektirir |

İkisi aynı statüde değildir ve karıştırılmamalıdır.

---

## 25.1 Faz rejim – eşik sınırı — rezerve ontolojik başlık

$$\boxed{\;\textbf{KANONİK AD: FAZ REJİM – EŞİK SINIRI}\;}$$

Üçgenin her kenarı için bir **faz rejim – eşik sınırı** ontolojik başlığı rezerve edilmiştir. Ad çift bileşenlidir çünkü rezerve edilen yapı, rejim sınırı ile geçiş eşiği arasındaki ilişkiyi birlikte ifade etmek üzere ayrılmıştır. Bu kayıt, sınırın nihai matematiksel tipini veya fiziksel kalınlığını önceden belirlemez.

### 🔴 Temsil ile fiziksel genişlik ayrımı

$$\boxed{\;\text{Faz rejim – eşik sınırı, ontoloji gösteriminde keskin bir çizgi yerine SINIR BANDI olarak TEMSİL EDİLİR.}\;}$$

Bu bir **gösterim kararıdır**, fiziksel bir hüküm değil:

$$\text{"band gösterimi kullanılır"} \;\neq\; \text{"fiziksel geçiş sonlu genişlikli banttır"}$$

$$\boxed{\;\text{Bandın fiziksel genişliğinin sıfırdan farklı olup olmadığı ve matematiksel profili HENÜZ TÜRETİLMEMİŞTİR.}\;}$$

$$\boxed{\;\text{KANONİK OLAN: başlığın ontolojide rezerve edilmesi ve sınır/bant gösteriminin kullanılmasıdır.}\;}$$

$$\boxed{\;\text{AÇIK OLAN: sınırın nihai matematiksel tipi, fiziksel genişliği ve mikrofiziksel profili.}\;}$$

**Karıştırılmamalı:** Bölüm 12.1'deki eşik kanallarının geçişli karakteri, o kanallar için yazılmış **ayrı bir model ifadesidir**; buradaki gösterim kararının fiziksel kanıtı sayılmaz.

**Ne olmadığı — dört koruma:**

| Değildir | Neden |
|---|---|
| **Yeni bir faz değildir** | Faz sayısı üçtür |
| **Yeni bir kapı değildir** | Üç kenar zaten tanımlı |
| **Üçgen topolojisini değiştirmez** | Tam çift yönlü üçgen korunur |
| **Yeni bir düğüm değildir** | Grafta nokta eklemez |

**Amacı:** insan-okunabilirliği, ontolojik sağlamlaştırma ve **sınır fenomenlerinin yerleştirilmesi**. Eşik geçişlerinin sigmoid karakteri (Bölüm 12.1) ve liminal rejim (Bölüm 15.3) bu bandın içinde konumlanır.

### 🔴 Terminoloji kuralı — kilitli

Çalışma sırasında bu yapıya, kolay hatırlanması için gündelik bir anahtar kelime kullanılmıştır. O kelime **yalnız bir hatırlatıcıdır**; ontolojik bir terim değildir ve çağrışımları çerçeveye ait değildir.

$$\boxed{\;\text{Gündelik anahtar kelime AKADEMİK METNE ve BU BELGEYE GİRMEZ. Tek geçerli ad: FAZ REJİM – EŞİK SINIRI.}\;}$$

Bu bir üslup tercihi değildir: gündelik kelimenin taşıdığı ara-durum/bekleme çağrışımları, bandın ontolojik içeriğiyle (rejim sınırı + geçiş eşiği) örtüşmez ve yanlış okumaya açıktır.

**Birleşik açık-borç kaydı:** sınırın nihai matematiksel tipi; fiziksel genişliğinin sıfırdan farklı olup olmadığı ve neye bağlı olduğu; mikrofiziksel profili; $X$ ile ilişkisi; üç kenarda aynı mı yoksa farklı mı davrandığı.

---

## 25.2 SYNTAX — rezerve ontolojik başlık

SYNTAX, hangi konfigürasyonların **fiziksel olarak geçerli** olduğunu belirleyen kural sistemi olarak düşünülmüştür.

$$\text{GEÇERLİ / GEÇERSİZ durum} \qquad \text{izinli / izinsiz faz-geçiş konfigürasyonu}$$

**Ne olmadığı:** yeni bir faz değildir · yeni bir fiziksel nesne değildir · bir kuvvet ya da alan değildir.

### 🔴 En kritik açık nokta

$$\boxed{\;\text{SYNTAX} \;\leftrightarrow\; U_x \;\leftrightarrow\; X(x) \quad \text{ilişkisinin TAM TİPİ AÇIKTIR.}\;}$$

Üç olasılık kayıtlıdır ve hiçbiri seçilmemiştir:

| Olasılık | İçerik |
|---|---|
| (a) | SYNTAX, $U_x$'in **yerine** geçer |
| (b) | SYNTAX, $U_x$'in **içinde** bir katmandır |
| (c) | SYNTAX, $U_x$'in **üstünde** ayrı bir rol alır |

### Seçeneklerin mimari maliyeti — bağımlılık analizi

Üç seçenek **tarihsel karar uzayını** kaydeder; hiçbiri elenmemiştir. Ancak iki seviyeli mimari kurulduktan sonra maliyetleri eşit değildir:

$$\boxed{\;\text{(a) seçeneği, } U_x\text{'in Dinamik Evren rolünün YENİDEN TANIMLANMASINI gerektirir — en yüksek yeniden-yazım maliyeti.}\;}$$

Nedeni kategoriktir: $U_x$ global ontolojide bir **evren yapısıdır**; SYNTAX ise bir **kural sistemidir**. Programlama diliyle: *bir programın çalışan durumu* ile *o dilin grameri* aynı nesne değildir. Bu bir karar değil, **bağımlılık analizidir**.

### Aday ayrım — kanon değil

| Nesne | Aday tanım |
|---|---|
| **SYNTAX** | Hangi yapı veya konfigürasyonların geçerlilik koşullarını taşıyabileceğini sınırlayan **admissibility / consistency rule structure** |
| **$X$** | Verilmiş tam faz/rejim/bağlam durumunda hangi rejim/değerin çözüldüğünü belirleyen **given-state resolver** |

Bu aday ayrımda **SYNTAX'ın zorunlu olarak durumdan bağımsız, context-free veya değişmez bir gramer olduğu varsayılmaz**. Uygulanabilir kısıtların faz/rejim bağlamına göre farklılaşması açık tutulur.

Satranç benzetmesiyle: SYNTAX geçerlilik kurallarıdır; $X$ ise mevcut tahtayı ve geçerli bağlamı okuyup o durumda hangi hamlelerin/çıktıların fiilen izinli olduğunu çözen motordur. Rok, şah durumu veya geçerken alma gibi kuralların uygulanmasının mevcut duruma bağlı olabilmesi, **kural yapısı** ile **durum çözücüsünün** aynı nesne olmasını gerektirmez. **Bu ayrım kanon değildir**; kararı kolaylaştıran bir adaydır.

Bu sınır netleşmelidir — $X$ zaten "hangi değerlerin izinli olduğunu çözen" nesnedir (Bölüm 4.1), dolayısıyla iki kavramın çakışma riski vardır.

**Açık karar borcu:** SYNTAX'ın nihai ontolojik/formal kategorisi — ayrı bir varlık mı, kural yapısı mı, yoksa $X$'in uymak zorunda olduğu meta-kısıt ailesi mi olduğu — mimar kararı ve sonraki formalizasyonla kapanacaktır.

$$\boxed{\;\text{V24 yazımında bu ilişki ÇÖZÜLMÜŞ KABUL EDİLMEZ.}\;}$$

---

## 25.3 Faz Çöküşü — rezerve ontolojik başlık

Ayrı bir ontolojik fenomen olarak ayrılmıştır.

$$\boxed{\;\text{Faz Çöküşü} \;\neq\; \text{sıradan faz geçişi}\;}$$

Sıradan geçiş, kapı üzerinden gerçekleşen ve damga üretebilen bir olaydır (Bölüm 13). Faz Çöküşü bununla **eş anlamlı kabul edilmez**.

**Ayrıntıları mimarda rezervedir.** Bu belge mekanizma uydurmaz; başlığı ve ayrım kuralını kaydeder.

---

## 25.4 Faz Yırtılması — rezerve ontolojik başlık

Faz Çöküşü'nden ayrı ve bağımsız bir başlıktır.

$$\boxed{\;\text{Faz Yırtılması} \;\neq\; \text{Faz Çöküşü} \qquad\qquad \text{Faz Yırtılması} \;\neq\; \text{yeni faz ya da kapı}\;}$$

**Eşsesli terim uyarısı:** Bu başlık, global seviyedeki **Big Yırtılma** ile (Bölüm 2.8) **aynı şey değildir**. Biri faz seviyesinde bir fenomen, öteki global evren seviyesinde bir doğuş olayıdır. Ortak sözcük, anlam birleştirme yetkisi vermez.

**Olası fenomenolojik köprü:** Renk hapsi altında akı tüpünün kopması (bkz. 25.7). Ancak:

$$\boxed{\;\text{Renk akı tüpünün kopması} \;\neq\; \text{Faz Yırtılması}\;}$$

Bu yalnız bir köprü adayıdır; kimlik değildir.

---

## 25.5 Massive Void — rezerve ontolojik türetim

Büyük kozmik boşlukların farklı dalga boylarıyla gözlenmesi ve bu bölgelerde yeni yıldız oluşumu.

### 🔴 Provenance ayrımı zorunlu

Arşivde bu konuda **daha eski bir anlatım** bulunur. Yeni türetim onun tekrarı değildir.

$$\boxed{\;\text{Eski Massive Void anlatımı} \;\neq\; \text{yeni ontolojik türetim}\;}$$

İki kayıt birbirine karıştırılmaz; yeni türetim kendi gerekçesiyle kurulur.

**Ayrıntıları mimarda rezervedir.**

---

## 25.6 Pauli dışlama ↔ faz rejim – eşik sınırı davranışı — yüksek öncelikli mekanizma adayı

Pauli dışlama ilkesinin, faz sınırındaki fenomen davranışıyla ilişkilendirilmesi.

**Olası araştırma zinciri:**

$$\text{faz rejim – eşik sınırı} \;\rightarrow\; \text{erişilebilir durum uzayının kısıtlanması} \;\rightarrow\; \text{çift işgal yasağı} \;\rightarrow\; \text{Pauli fenomenolojisi}$$

### Üç bilimsel eşik

Bu hattın analoji olmaktan çıkıp mekanizma sayılabilmesi için:

| # | Eşik |
|---|---|
| **1** | Pauli sonucu **baştan varsayılmadan** çıkmalı |
| **2** | Antisimetri, spin-$\tfrac{1}{2}$ ve özdeş fermiyon yapısıyla **uyuşmalı** |
| **3** | Yeni ya da önceden belirlenmiş bir **gözlemsel davranış** üretmeli |

Üçü sağlanmadan bu hat **analoji düzeyindedir**.

---

## 25.7 Kara delik vakumunda $c^+ \to C_m$ — düşünce deneyi

Bir kara deliğin, kütleçekim etkisiyle bulunduğu ortamdaki $c^+$ yapısını madde fazına indirip indirmediği.

$$c^+_{\rm yerel} \;\xrightarrow[\text{güçlü çekim / faz eşiği}]{} \; C_m$$

$$\boxed{\;\text{Kara delik maddeyi YOKTAN ÜRETMEZ; } c^+ \text{ içeriğinin } C_m \text{'ye geçişini KATALİZLİYOR olabilir.}\;}$$

**Olası gözlemsel imza — artık (residual) aranır:**

$$L_{\rm gözlenen} \;>\; L_{\rm akresyon,max} + L_{\rm spin,max} + L_{\rm depo,max}$$

Daha güçlü imza, çevrede yeterli baryonik kaynak yokken yeni $C_m$ maddesinin ortaya çıkması olurdu.

**Statü:** kanon değildir, düşünce deneyi hattıdır. Ve bu imzalar **öngörü değildir** — bir öngörü olabilmesi için 0/10 → 1/10 kapısının altı koşulunu (Bölüm 0.4) sağlaması gerekir.

---

## 25.8 Renk hapsi ↔ faz limiti / SYNTAX — güçlü türetim adayı

Kuark hapsi, akı tüpünün gerilmesi, kopması ve çift üretimi zinciri.

**İki olası çerçeve rolü:**

| Faz | Rol |
|---|---|
| $c_0$ | $C_m$ konfigürasyonunun **sürdürülebilirlik limiti** |
| $c^+$ | Yeni $C_m$ durum erişimi — **çift üretimi** tarafı |

**SYNTAX okuması (aday):**

$$\text{serbest renk durumu} = \text{GEÇERSİZ} \qquad\qquad \text{renk-nötr hadron} = \text{GEÇERLİ}$$

**Uyarı:** Bu, Bölüm 18.4'teki kısıtla birlikte okunmalıdır — vakumdan çift üretimi hesapları **verili bir metrik** varsayar ve dış fazlara uygulanamaz. Zincirin $C_m$ içinde kalan kısmı meşrudur.

---

## 25.9 Görsel yardımcı katmanlar — düşünce deneyi

| Katman | İçerik | Koruma |
|---|---|---|
| **Dalga boyu faktörü** | Faz rejimlerinin $\lambda$, $\nu$, $E$ ile farklı gözlem bantlarında nasıl göründüğü | Resmi denklem değil; görsel/yorum katmanı |
| **Kara delik eşik faktörü** | *"Her yoğun yapı kara delik değildir"* ayrımının eşik mantığıyla gösterimi | **Evrensel bir sabit değildir**; ayrıntıları mimarda rezerve |

**Hız bandı notu:** Kanonik görselde $C_m$ altında bir hız bandı gösterimi düşünülmektedir. Buradaki hız **yerel laboratuvar hızı değildir**; çerçevenin kozmolojik referansına göre değerlendirilen parametredir. Laboratuvar hızının sıfır olması bir c₀ üyeliği **sayılmaz** (Bölüm 3.7).

---

## 25.10 Faz sızması ve eski zaman-sınırı kayıtları — hizalama borcu

Arşivde faz sızması, sınır rejiminde $\Delta t \approx 0$ görünümü ve faz-uyumsuz ölçüm üzerine eski kayıtlar bulunur (bkz. Bölüm 18.6).

$$\boxed{\;\text{Eski arşiv girdisi} \;\neq\; \text{yeni faz rejim – eşik sınırı çalışması}\;}$$

Bu kayıtların 25.1'deki sınır diliyle yeniden hizalanması gerekir; ama iki katman **ayrı tutulmalıdır** — eski anlatımın terimleri yeni bandın tanımı sayılmaz.

---

## 25.11 Bu bölümün statü özeti

| Başlık | Sınıf | Statü |
|---|---|---|
| **Faz rejim – eşik sınırı** | Rezerve ontolojik | Başlığın ontolojide rezervasyonu + sınır/bant gösterim kararı sabit; nihai tip, fiziksel genişlik ve mikrofiziksel profil açık |
| SYNTAX | Rezerve ontolojik | $U_x$/$X$ ilişkisi **açık** |
| Faz Çöküşü | Rezerve ontolojik | Ayrıntı mimarda |
| Faz Yırtılması | Rezerve ontolojik | Ayrıntı mimarda |
| Massive Void | Rezerve ontolojik türetim | Provenance ayrımı zorunlu |
| Pauli ↔ faz rejim – eşik sınırı | Mekanizma adayı | **Yüksek öncelikli**; üç eşik |
| Kara delik $c^+ \to C_m$ | Düşünce deneyi | Kanon değil |
| Renk hapsi ↔ SYNTAX | Türetim adayı | Güçlü |
| Görsel katmanlar | Düşünce deneyi | Denklem değil |
| Faz sızması hizalaması | Hizalama borcu | Katman ayrımı zorunlu |

$$\boxed{\;\text{Bu bölümdeki HİÇBİR madde, ayrı türetim ve ön-kayıt olmadan ÖNGÖRÜ sayılmaz. Sayaç } \mathbf{0/10}.\;}$$

**minor6 senkron guard:** V24 whole-file denetiminden taşınan metodoloji/provenance kayıtları, Bölüm 25'teki rezerve başlıkların statüsünü yükseltmez; SYNTAX, Phase-Boundary ve $\Pi_{+\to m}$ uyumu mimar kararı beklemeye devam eder.

---


## 25.12 Residual Field formalizmi (v0.1 aksiyom seti → v0.4 parametrik model)


Faz Skarı'nın (Bölüm 7.9) alan-teorisi gerçekleşmesi olarak geliştirilmiş parametrik model ailesi. Arşivdeki gelişim hattı: v0.1 genel kurallar → v0.2 Lorentz koruması ve klasik limit → v0.3 süreklilik sınırı → v0.4 F(ρ)Z(Φ,ρ) parametrik model.

$$\boxed{\;\text{Bu blok } X \text{'i skalerleştirmez; zaman-dışı fazlara Cₘ zamanı taşımaz; çekirdek yasa değildir.}\;}$$

## 25.13 IPW — faz içi dalgalar (Intra-Phase Waves) modeli


Tek faz içindeki dalga benzeri modların (IPW) çerçeve içi modeli; ön-kayıtlı test kartı Bölüm 21.19'dadır. "Bir sonraki heyecan verici pencere" dili arşiv notudur; statü taşımaz.

### IPW toy model — X_T spektral ayrışma

Tek-cisim toy modelinde X_T için spektral ayrışma imzasının taraması; koşul seti Bölüm 21.19'da.

## 25.14 Kinematik dualite postülası — tam form ve Z-operatörü köbrüsü


Arşivdeki tarihsel dualite (Bölüm 4.2 kaydıyla aynı kaynak) burada tam biçimde korunur:

$$\Phi(c^+, C_m, c_0) = \Tau(z^+, z_m, z_0)$$

karşı-faz formu Φ·e^{+iπ} = Τ·e^{−iπ} ile birlikte. Z-operatörü (Z: Φ → T) tarihsel kinematik-dualite ailesindedir; güncel X tanımına primitive olarak eklenmez (Bölüm 23.10b hükmüyle aynı).

## 25.15 Üç metrik rejim ayrışması — g(0) / g(m) / g(+)


Üç faz için üç metrik okumasının ayrıştırılması önerisi: g(0) c₀ okuması (admissible değil — Bölüm 9.3), g(m) Cₘ metriği (tek meşru alan), g(+) c⁺ okuması (admissible değil). Ayrışma önerisi notasyon tasarımıdır; dış fazlara metrik geri getirmez.

## 25.16 X(x) ≈ ln(a) kozmoloji köprüsü


Hubble genişlemesi ile X arasında aday köprü: X(x) ≈ ln(a) ve genelleştirilmiş formları. Kozmolojik veriyle temas noktası Bölüm 21.11'deki uyum-düzeyi kontrolüdür; köprü kanon değildir.

## 25.17 Krylov doygunluğu ↔ X → 1 eşlemesi


Kuantum evreminin Krylov altuzayı doygunluğunun X'in uç rejimiyle eşlenmesi önerisi. Aday köprüdür; sayısal doğrulama açıktır.

## 25.18 Global üniterlik + yerel Kraus aksiyom seti


Bölüm 16.6'daki çift katman yapının aksiyom ifadesi. Model katmanıdır; ontoloji primitive'i değildir.

## 25.19 Işık = consistency constraint okuması


c'nin Cₘ tutarlılık kısıtı olarak okunmasının (Bölüm 3.3) arşiv genişletmesi: ışık-hızı sınırı bir madde hızı yasağı olarak değil, bilgi işleme/kayıt/çözünürlük limiti olarak işlenir. Bu okuma çekirdek hükümle uyumludur; ek mekanizma eklemez.

## 25.20 Yapısal çözülme — sabit drift senaryosu


Çerçevenin yapılarının (celestial, nuclear) uzun vadede çözülme senaryosu: orbital decay → unstable → decompose zinciri. Senaryo tasarımıdır; gözlemsel taahhüt değildir.

## 25.21 Evrenin sonu — iki senaryo kaydı


Arşivdeki dört aşamalı anlatı (düzenli son → kademeli çözülme → sabit-durma → sonsuz seyreltme) güncel iki-kutup diliyle (Bölüm 2.8) hizalanmıştır: iki senaryo global kutuplara bağlanır. Eskatolojik okuma yasaktır (Bölüm 2.6).

## 25.22 Kozmik süper atom iddiası


Evrenin "süper-atom" olarak okunması iddiası; BEC/süper-atom analoji ailesinin kozmik uç örneğidir. Analoji düzeyindedir; literal kimlik kurulmamıştır.

## 25.23 Tercüme matrisi — Cₘ ↔ dış faz okuma dönüşümü


Dış faz kavramlarının Cₘ okumasına çevrildiği çalışma matrisi: kayıt/ölçüm/vakum/faz-sınırı terimlerinin iki katman arasında taşınma kuralları. Bölüm 13.1a'daki "taşıma ≠ okuma" hükmünün çalışma aracıdır.

## 25.24 Faz iletkenliği


Fazlar arası etki aktarımının "iletkenlik" diliyle modellenmesi önerisi. Elektrik iletkenliği notasyonu ödünç alınır; yapısal benzerlik doğrulama değildir (Bölüm 17.3).

## 25.25 Faz senkronizasyon mekanizması


c₀↔c⁺ X-koordinasyonunun (Bölüm 13.6) evremsel gerçekleşmesi olarak senkronizasyon mekanizması adayı. Mekanizma yazılmamıştır; başlık program kaydıdır.

## 25.26 Evren çekirdeği — üç senaryo hesabı


Evrensel çekirdek ölçeği için arşivdeki üç hesap senaryosu (CMB-kilitli, CMB+MPC, CMB+SN) ve iç tutarlılık penceresi (~10⁴⁷ ışık yılı). Senaryolar Bölüm 2.10'un hesap gövdesidir; sayısal sonuçlar EK H disiplinindedir.

## 25.27 Dinamik çekim şablonu


Görelilikçi yıldız modellerinde dinamik çekim için kullanılan şablon kayıtları (Özel Görelilik Mestel yıldızı; Genel Görelilik yıldız modelleri; rotation, frame dragging). Bağlam kaydıdır; Evertophy türetimi değildir.

## 25.28 Kara delik çekirdeği öngörüleri


Kara delik çekirdeği için arşiv öngörü kayıtları (shadow imzaları, evrensel Boyer-Lindquist ölçekleri). Sıfır Planck Boşluğu ve Kütle–Hacim doğru orantısı EK H.4'teki gibi tarihsel proje iddiası statüsündedir — türetilmemiş hüküm kanon değildir.

## 25.29 Redshift konumlandırması


Kozmik redshift'in faz haritasındaki konumlandırılması kaydı. Bölüm 11.7'deki redshift köprü satırıyla aynı statüdedir.

## 25.31 Evertophy periyodik cetveli / Mendelev tarzı domain çizelgesi


Faz-parametre matrisinin (Bölüm 5) domain çizelgesi düzeyindeki sunum önerisi. Gösterim aracıdır; ontolojik içerik eklemez.

## 25.32 Frekans dönüşümü düşünce deneyi


Frekans/enerji ölçeklerinin faz okumaları arasında dönüştürülmesi düşünce deneyi; Bölüm 25.9'daki dalga boyu faktörü katmanıyla aynı ailededir.

---

# BÖLÜM 26 — FENOMENLER, AÇIK PROBLEMLER VE EVERTOPHY'NİN ADAY OKUMALARI


Bu bölüm, yerleşik fiziksel fenomenleri, kuramsal açık problemleri ve Evertophy'nin bunlara ilişkin aday okumalarını bir başlık haritasında birlikte sunar. Bir başlığın burada yer alması, modern bilimin o fenomeni açıklayamadığı ya da Evertophy'nin onu çözdüğü anlamına gelmez; her satır kendi kaynak ve türetim statüsüyle değerlendirilir.

$$\boxed{\;\text{Her okuma "adaydır"; hiçbiri "çözdü" değildir. Bu bölümün tamamı Bölüm 0.3 ve 23.9 dil disiplinine tabidir.}\;}$$

Bu bölümdeki her satır bir **okumadır, açıklama değildir.** Modern bilimin ölçtüğü fenomen olduğu gibi kabul edilir; Evertophy'nin önerdiği okuma o ölçümün üzerine ayrı bir katman olarak konur ve sınanmaya adaydır (bkz. Yazardan Okuyucuya). Bir okumanın bu listede yer alması, onun nicel olarak türetildiği ya da doğrulandığı anlamına gelmez. Bölüm, yerleşik fenomenleri (ölçülmüş ama açıklaması tartışmalı) ve kuramsal açık problemleri birlikte listeler; her satırın statüsü ayrıdır. Bu bölüm sayaca hiçbir katkı yapmaz:

$$\boxed{\;\text{Kanonik sayısal öngörü sayacı: } 0/10\;}$$

## 26.1 Kozmolojik fenomenler

| Fenomen | Aday okuma | Statü |
|---|---|---|
| Karanlık madde / rotasyon eğrileri | c⁺'ın kümelenmiş Cₘ tezahürü (Bölüm 11.2) | Aday — nicel türetim yok |
| Karanlık enerji / fantom sınırı | c⁺'ın seyrelmiş Cₘ tezahürü | Aday (Bölüm 11.9) |
| Hubble gerilimi | ölçek-bağımlı etkin gravity readout adayı | Aday — yalnız köprü yanlışlama programı (Bölüm 11.7). Çerçevenin önceki Hubble iddiası **üç kez geri çekilmiştir** (V24 rolling master §538.3) |
| S8/σ8 gerilimi | köprü falsification programı satırı | Aday |
| Çekirdek-halo / küçük ölçek krizleri | c⁺ kümelenme rejiminin Cₘ okuması | Aday |
| MOND ve değiştirilmiş kütleçekim | paradigmalar arası köprü bağlamı | Bağlam |
| Kozmolojik sabit problemi | c⁺ payının Cₘ okumasıyla ilişki adayı | Aday |
| Karanlık akı (dark flow) | c⁺ yöneliminin Cₘ izdüşümü olarak okunabilir | Bağlam |
| Kozmik birefringence | kalibrasyon açıklanana dek bağlam | Bağlam (Bölüm 21.18) |
| Big Yırtılma senaryosu | global seviye doğuş olayı (Bölüm 2.8) — eşsesli terim uyarısı geçerli | Kanonik çerçeve, fiziksel senaryo değil |

## 26.2 Erken evren ve başlangıç fenomenleri

| Fenomen | Aday okuma |
|---|---|
| Big Bang tekilliği / enflasyon öncesi | $U_0$ sınırındaki kritik eşik + birlikte doğuş (Bölüm 2.4) |
| Ufuk problemi | birlikte türetimin doğal sonucu olarak okunmaya aday |
| Düzlük problemi | başlangıç koşullarının U₀ kaynaklı okuması — aday |
| Monopol problemi | faz yapısının gauge-doğuşu kısıtı olarak okunmaya aday |
| Baryogenez | açık borç (Bölüm 20.7) |

## 26.3 Kuantum fenomenler

| Fenomen | Aday okuma |
|---|---|
| Ölçüm problemi | liminal rejim → Cₘ projeksiyon → mühürleme (Bölüm 15.3) |
| Dolanıklık | c⁺ write-protected korelasyon (Bölüm 18.6) — sinyal kanalı değil |
| Hartman etkisi | faz-eşiği bölgesinde naif transit-time dilinin yetersizliği (EK D) |
| Ertelenmiş seçim | mühürleme kararının zaman indeksinden bağımsız tutarlılığı (Bölüm 18.10) |
| Zaman kristalleri | Cₘ içi periyodik yapı — faz dilinde yeniden okunabilir; aday |

## 26.4 Standart Model fenomenleri

| Fenomen | Aday okuma / statü |
|---|---|
| İnce ayar | aralık formalizminin motivasyonu; açıklama değil |
| Hiyerarşi problemi | açık borç |
| Strong-CP | program hedefi (Bölüm 20.4a) |
| Nötrino kütlesi/salınımı | açık borç (Bölüm 20.7) |
| Renk hapsi | güçlü türetim adayı (Bölüm 25.8) |
| Kütle kökeni / Higgs | Makine 2 hedefi; türetim yok |

## 26.5 Kütleçekim–kuantum kesişimi

| Fenomen | Aday okuma / statü |
|---|---|
| Kuantum kütleçekim | çerçevenin merkezî boşluğu; çözüm iddiası yok |
| Planck ölçeği | c₀ rejimi ile ilişki adayı; nicel köprü yok |
| Kara delik bilgi paradoksu | çözülmedi (Bölüm 0.3); kayıt/arşiv dili yeniden okuma sunar |
| Hawking/Unruh | bağlam; termal izdüşüm literatürü |
| Wheeler–DeWitt zamansızlığı | faz ayrımıyla okuma (Bölüm 7.11e) |

## 26.6 Zaman fenomenleri

| Fenomen | Aday okuma |
|---|---|
| Zamanın oku | aday okuma: damga birikimiyle ilişkilendirilir (Bölüm 3.5, 16.7) |
| Emergent zaman literatürü | karşılaştırma haritası (Bölüm 7.11) |

## 26.7 Yoğun madde ve laboratuvar fenomenleri

| Fenomen | Aday okuma |
|---|---|
| Yüksek sıcaklık süperiletkenliği | toplu davranış analojisi ailesi; literal değil |
| Casimir etkisi | vakum Cₘ-içi alan durumudur; c⁺ değildir (Bölüm 3.4) |
| Schwinger etkisi | analoji kaydı (EK D) |
| BEC / süper-akışkan | c₀ tek-yapı sezgisi (Bölüm 3.2, 18.5) |

## 26.8 Gözlem kanalları ve veri pencereleri

CMB anizotropileri · BAO · 21-cm kozmolojisi · Pantheon+ · optik saat instabilite verileri (Yb/Sr) · AME2020 kütle tabloları — tamamı Bölüm 21'deki denetim disiplinine tabi dış veri kanallarıdır; hiçbiri Evertophy öngörüsü değildir.

## 26.9 Nadir / tekil anomali kayıtları

Pioneer/flyby anomalileri · non-metricity imzaları (Bölüm 21.16) · Shapiro gecikmesi ölçümleri (Bölüm 8.9). Hepsi "açıklanamayan fenomen envanteri" kaydıdır; çerçeve bunlara bakış açısı önerir, hüküm vermez.

---

# BÖLÜM 27 — TEMEL DENKLEMLER VE KÖPRÜ FORMALİZMİ (ADAY ENVANTERİ)


Bu bölüm, arşivdeki köprü denklemi ailesini isim düzeyinde envantere alır. EK C çekirdek koruma kayıtlarının genişletmesidir; sayısal sonuç içermez.

Bir denklemin bu bölümde yer alması, onun aynı güvenle söylendiği anlamına gelmez. Bu yüzden bölüm iki katmana ayrılır: doğrulanmış yapısal denklemler (27.A) ve kapsamı ve varsayımları açıkça yazılmış model ve köprü denklemleri (27.B). Arşivden gelen tarihsel ve aday envanter ile model aileleri V24 rolling master'da tutulur.

## 27.A Doğrulanmış yapısal denklemler

Bu denklemler çerçevenin **yapısal tutarlılığını** kurar; fizik öngörüsü değildir.

| Denklem | Ne söyler | Kanıt türü |
|---|---|---|
| $g = E^{\mathsf T}\eta E,\quad \det g = -(\det E)^2$ | Cebirsel nondejenerasyon koşulu; metriğin yalnız Cₘ'de izinli olması **ayrı bir faz postülasıdır** (Bölüm 9) | Sembolik — iki bağımsız hesap motoru |
| $w\cdot w = w \iff w \in \{e,\ \kappa_{0m},\ \kappa_{+m}\}$ | Damga cebirinin idempotentleri; birleşme, sonlanma, tek normal form ve konfluans da kanıtlı (Bölüm 14) | Biçimsel (Lean) |
| $x\in[a,b],\ y\in[c,d] \Rightarrow xy \in [\min(ac,ad,bc,bd),\ \max(ac,ad,bc,bd)]$ | Aralık hesabının güvenilirliği; toplama, negatif, kesişim ve sıfır-dışlama da kanıtlı (6.4a) | Biçimsel (Lean) |
| $q \text{ kapı-kilitli} \iff q \text{ en fazla bir fazda içsel olarak tanımlı}$ | Cₘ'ye özgü niceliklerin hiçbir kapıdan taşınamaması (13.1a) | Biçimsel (Lean) |
| $\text{Tip}+\text{aralık}+\text{iyi-tanımlılık} \nRightarrow \text{tekil köprü}$ | $B_1(x)=x$ ile $B_2(x)=x+\tfrac{x(1-x)}{2}$ aynı koşulları sağlar (24.1) | Biçimsel (sonlu) + analitik (sürekli) |
| $N_{\rm arşiv}(n+1) = N_{\rm arşiv}(n) + 1$ | Arşiv sayısının ayrık monotonluğu; fiziksel zaman türevi değildir (Bölüm 14) | Biçimsel (Lean) |
| $\text{Sert red} \iff B_{\rm pred}\cap B_{\rm obs}=\varnothing$ | Yanlışlama ölçütü; uyum ölçüsü tek başına red nedeni değildir (21.6) | Biçimsel (Lean) |

## 27.B Kapsamı yazılmış model ve köprü denklemleri

Bu denklemler kendi varsayımları içinde doğrudur; çekirdeğe terfi ettirilmez.

| Denklem | Kapsam ve varsayım | Statü |
|---|---|---|
| $\int \mathcal G_{\rm FS}\,d\lambda \ge \theta_{\min},\quad \Delta t_{\min} = \hbar\theta_{\min}/\Delta E$ | Yalnız kuantum-Cₘ; saf durum, üniter evrim, $\Delta E>0$; bir hız sınırıdır (7.4) | Köprü |
| $G_{\mu\nu}+\Lambda g_{\mu\nu} = \frac{8\pi G}{c^4}\,T_{\mu\nu}[J_X]$ | Standart Cₘ karşılaştırma tabanı; $J_X$ açık borçtur | Köprü |
| $-\nabla\cdot(Z\nabla\phi)+\mu^2\phi+4\pi G\rho=0,\quad m=\mu/\sqrt{Z}$ | Sabit $Z>0$ ve uygun sınır/koersivite koşulları; $\mu=0$ saf-Neumann durumunda ek ortalama koşulu gerekir | Model — zayıf-alan test yatağı |
| $Q(m) = e^{-m(r_2-r_1)}\,\frac{1+mr_2}{1+mr_1}$ | $0<r_1<r_2$, $m>0$; kesin azalan, ters problem $m$'yi verir ($\mu=m\sqrt Z$ yalnız $Z$ biliniyorsa) | Model |
| $\sigma^* = 1/\sqrt2,\quad \sigma_{\rm fold}\approx 0.7391346294$ | İdeal eşkenar Gauss peyzajının rejim eşikleri (19.1a) | Model |
| Matematiksel $z\to\pm\infty$ uçlarında $w\to-1 \iff (X_{\min}>0 \lor p=0)\wedge(X_{\max}<1 \lor q=0)$ | Lojistik okuma modeli; $s>0$, $p,q$ sonlu; kaynak türetimi açık. Fiziksel alan $z>-1$, fiziksel gelecek $z\to-1^+$ (11.9) | Model |
| $\chi_S \equiv 1,\quad \Delta\varphi \equiv 0$ (karşılıklı sistem) | Aynı port normalizasyonu, $S_{21}=S_{12}\neq0$ (17.1) | Sınır sonucu |
| $|A_{\rm loop}| = \dfrac{\pi|k|\delta^2\omega}{\lambda^2+\omega^2}$ | Gevşemeli doğrusal yanıt modeli, kalıcı periyodik rejim; $1/\omega$ biçimi yalnız $\omega\gg\lambda$ | Model |
| $\Delta_{0m}\,\Delta_{+m} = \dfrac{d\ln F}{d\tau}$ | Zincir kuralından gelen özdeşlik; fiziksel iddia olan kazanç ilişkisi $\Delta_{0+} = G\,\Delta_{+m}$ ayrıdır | Özdeşlik ✅ / kazanç model |
| $\ln\dfrac{Z(\tau)}{Z(\tau_0)} = -\displaystyle\int_{\tau_0}^{\tau}\eta(u)\,[F(u)-F^*(u)]\,du$ | Sürüklenme empedansı modeli; $\alpha^{-1}\propto Z_{\rm drift}$ ($\xi=1$) tanımsal | Model |

# EK A — KAVRAM SÖZLÜĞÜ

| Kavram | Tanım |
|---|---|
| **Çekim Kuvveti (Force of Attraction)** | Temel ontolojik postüla; faz-bağımsız kısıt koheransı. Dört kuvvet onun ölçeğe, kütle miktarına ve faza göre izdüşümleridir. "Kütleçekim" ile karıştırılmaz |
| **Kütleçekim (Gravitation)** | Çekim Kuvveti'nin Cₘ'deki metrik izdüşümü; genel göreliliğin konusu |
| **Kısıt koheransı** | Üç fazın izinli konfigürasyonlarının birbiriyle uyumlu olma zorunluluğu; metrik gerektirmez |
| **Tutuklu / serbest c⁺** | c⁺'ın maddeyle kümelenmiş (karanlık madde) ve madde baskısından uzak serbest (karanlık enerji) durumları |
| **Liminal** | $v=c$ sınırında bulunma; ışığın durumu. c⁺ üyeliği değildir |
| **$U_0$** | Üç fazı aynı kuruluşta birlikte oluşturan ön-katman / mutlak üretici kaynak; faz değildir |
| **$U_x$** | Dinamik Evren — üç fazın birlikte gerçekleştiği global yapı; dördüncü faz veya $X$ değildir |
| **$U_+$** | Mutlak Çözünme — global çözünme kutbu; faz değildir, $c^+$ değildir |
| **Global evren seviyesi** | $U_0$, $U_x$, $U_+$ katmanı; faz seviyesinden ayrıdır |
| **Sessizlik ilkesi** | Temsili olmayan yerde Evertophy hüküm vermez |
| **Faz rejim – eşik sınırı** | Kenarlardaki geçiş bandı; yeni faz, kapı ya da düğüm değildir |
| **SYNTAX** | Geçerli konfigürasyonları belirleyen kural sistemi adayı; $U_x$/$X$ ilişkisi açık |
| **Rezerve ontolojik başlık** | Eklenmesi kararlaşmış, semantiği yazılmamış yapı |
| **Big Yırtılma** | Global $U_x$'in $U_+$ sınırındaki kritik eşiği aşmasıyla gerçekleşen doğuş olayı; terminal Big Rip değildir |
| **c₀** | Zaman-öncesi potansiyel/çekirdek faz; farklılaşma çözülür |
| **Cₘ** | Farklılaşmış madde fazı; ölçümün ve fiziksel zamanın tek evi |
| **c⁺** | Zaman-dışı üst/arşiv/koordinasyon fazı; Cₘ madde desteği çözülür |
| **$X(x)$** | Dinamik üst çözücü; faz rejimini ve izinli değerleri çözer |
| **Postüla-0** | Çekim Kuvveti'nin (Force of Attraction) temel ontolojik postüla olması |
| **Aralık formalizmi** | Fiziksel niceliklerin aralık-değerli yazılması |
| **Kapı** | Faz geçiş imkânı; çift yönlü |
| **Damga** | Geçişte basılan kayıt; tek yönlü |
| **Mühürleme** | Kaydın geri alınamaz yazılması |
| **Faz hafızası** | Eşik istatistiğinin monoton birikimi |
| **Faz-parametre matrisi** | ÖzellikAilesi × Faz → Aralık veya ⊥ |
| **Eşik (liminal) rejim** | Cₘ'ye tam projekte olmamış ara durum |
| **Parametre bütçesi** | Serbest girdi < öngörülen çıktı kuralı |
| **Kesişim ölçüsü** | Öngörü ve gözlem aralıklarının örtüşme oranı |

# EK B — SEMBOL LİSTESİ

| Sembol | Anlam |
|---|---|
| $U_0$ | Mutlak Çekirdek — global doygunluk kutbu / ön-katman |
| $U_x$ | Dinamik Evren — global seviye nesnesi ($\neq X(x)$) |
| $U_+$ | Mutlak Çözünme — global çözünme kutbu |
| $\mathcal{L}_{\rm çöküş},\ \mathcal{L}_{\rm seyrelme}$ | İki global limit |
| $U_x$ | Üçlü faz sisteminin bütünsel gösterimi |
| $c_0,\, C_m,\, c^+$ | Üç faz |
| $X(x)$ | Dinamik üst çözücü |
| $\Theta_{\rm domain}$ | Alan-özgü parametreler |
| $\rho_{C_m}$ | Cₘ durum tanımlayıcısı |
| $\mathcal{G}_{C_m}$ | Değişim normu |
| $\tau_0,\, \tilde\Gamma$ | Zaman üretim ölçeği ve boyutsuz katsayı |
| $\tau$ | Sıralama parametresi |
| $g_{\mu\nu}$ | Metrik (yalnız Cₘ) |
| $E^A{}_\mu$ | Tetrad (yalnız Cₘ) |
| $\mathcal{E}_m^{(0)},\, \mathcal{E}_m^{(+)}$ | Metrik-doğuş haritaları |
| $G_{\rm eff}$ | Etkin kütleçekim kuplajı (model) |
| $S_c$ | Duyarlılık katsayısı |
| $\Delta X_{\rm acc/pred/obs}$ | Kabul / öngörü / gözlem aralıkları |
| $M$ | Damga monoidi |
| $s,\, s'$ | Serbest damga üreteçleri |
| $\kappa_{0m},\, \kappa_{+m}$ | Kilit damgaları |
| $\mathrm{rid}$ | Kayıt kimliği |
| $\chi_S$ | Kanal asimetrisi (aday köprü) |
| $R_\phi$ | Faz hafızası kaydı |
| $\bot$ | O fazda kabul edilemez |
| $\texttt{None}$ | Damga üretilmedi ($\text{NoStamp} \neq \text{NoTransition}$) |
| $[P,P]$ | Sıfır genişlikli geçerli aralık |

# EK C — TEMEL DENKLEM VE KORUMA KAYITLARI

Bu ek, aynı denklem sembolünün farklı katmanlarda farklı anlamlara kaymasını önlemek için hazırlanmıştır. `CORE`, `formal aday` ve `model` ayrımı metin içinde açıkça belirtilir.

**Köken / ön-katman:**
$$U_0 \rightsquigarrow \{c_0,\, C_m,\, c^+\}_{\text{eş zamanlı — aynı kuruluşta birlikte}}, \qquad U_0 \notin \mathrm{Obj}(\mathcal{C}_{\rm faz})$$

**Sistem bütünü — kaynaklı kanon / semantiği kısmen açık:**
$$U_0\leftrightarrow[c_0\rightleftarrows C_m\rightleftarrows c^+]\equiv U_x,\qquad U_x\equiv\{c_0,C_m,c^+\}_{\rm sistem\ bütünü}$$

Buradaki zincir yazımı tarihsel kaynak ifadesini korur; güncel kapı topolojisi aşağıdaki tam çift yönlü üçgendir. $U_0\leftrightarrow U_x$ ilişkisinin tam anlamı açık borçtur.

**Faz topolojisi:**
$$c_0 \leftrightarrow C_m, \qquad C_m \leftrightarrow c^+, \qquad c_0 \leftrightarrow c^+$$

**Kinematik üyelik bandı:**
$$0<v<c \;\neq\; \text{laboratuvar-koordinat hızı},\qquad v_{\rm lab}=0 \;\not\Rightarrow\; c_0$$

**Çift-limit Core tohumu — mekanizma V24'e rezerve:**
$$\mathrm{DoubleLimit}_{\rm core}
=
\{\mathrm{collapse/saturation\ limit},\ \mathrm{dilution/closed\ loop\ limit}\}$$
$$\mathrm{DoubleLimit}_{\rm core}\nRightarrow(c_0\to U_0)\ \text{ordinary phase transition}$$

**Çözücü determinizmi:**
$$S_1=S_2 \Longrightarrow X(S_1)=X(S_2)$$

**Faz-bağımlı arity:**
$$X_\phi=X_\phi(x;\theta_1,\ldots,\theta_{n_\phi}),\qquad n_\phi\ \text{faz/rejime göre değişebilir}$$

**Faz-aşırı taşıyıcılık:**
$$\mathrm{MetaCrossPermission}(X)=\text{true},\qquad
\mathrm{MetaCrossPermission}(X)=\text{true},\qquad
\mathrm{MetaCrossPermission}\neq\mathrm{TransportPermission}$$

**Matris mimarisi:**
$$\mathrm{PropertyFamily}\times\mathrm{Phase}\longrightarrow \mathrm{Range}\ \text{veya}\ \bot$$

**Aralık formalizmi:**
$$P\in[P^-,P^+],\qquad [P,P]\ \text{geçerlidir},\qquad
\mathrm{Range\mbox{-}valued}\nRightarrow\mathrm{time\mbox{-}variable}$$

**Zaman — çekirdek iskele:**
$$dt=\Gamma\,\mathcal G_{C_m}\,d\tau,\qquad \tau\neq\text{fundamental physical time}$$

**Zaman — model realizasyonu örneği:**
$$dt=\tau_0\tilde\Gamma\,\mathcal G_{C_m}\,d\lambda,\qquad
\mathcal G_{C_m}\stackrel{\rm model}{=}\left\|\frac{d\rho_{C_m}}{d\lambda}\right\|$$

**Akromatiklik / Cₘ okuma kısıtı:**
$$\left.\frac{\partial X}{\partial E_{\rm probe}}\right|_{\mathcal S}=0,\qquad
\left.\frac{\partial\Gamma}{\partial E_{\rm probe}}\right|_{\mathcal S}=0$$

**Metric domain:**
$$\mathrm{Dom}(g_{\mu\nu})=C_m$$

**c₀ sınırı:**
$$\lim_{C_m\to c_0}g_{\mu\nu}^{(C_m\text{-readout})}\to0\ \ (\text{koşullu tarihsel model; türetim yok}),\qquad
g_{\mu\nu}\big|_{c_0}=\bot$$

**c⁺ sınırı:**
$$\mathrm{supp}_{C_m}(\mathrm{matter})\to\varnothing,\qquad
g_{\mu\nu}^{(C_m)}\to\bot$$

**İki farklı madde geçişi:**
$$C_m\to c_0:\ \text{toplu tek-yapı limiti}$$
$$C_m\to c^+:\ \text{Cₘ madde desteği çözülmesi}$$

**İzinlilik — genel form:**
$$(X,\Theta_{ij})\in\mathcal D_{ij}^{\rm adm}
\Longleftrightarrow
\mathcal A_{ij}(X,\Theta_{ij})=1$$

**Mühürleme ve Range korunumu:**
$$\mathrm{Seal}([p^-,p^+])=(\mathrm{rid},\,\mathrm{edge},\,\mathrm{stamp},\,[p^-,p^+])$$

**Damga monoidi:**
$$M=\langle s,s',\kappa_{0m},\kappa_{+m}\mid
\kappa_{0m}^2=\kappa_{0m},\;
\kappa_{+m}^2=\kappa_{+m}\rangle$$

**İdempotent sınıflandırması:**
$$\mathrm{Idem}(M)=\{e,\kappa_{0m},\kappa_{+m}\}$$

**Koşullu grup tamamlamaları:**
$$G_{\rm univ}(M)\cong F_2,\qquad K(M)\cong\mathbb Z^2$$

**Omega convention:**
$$\Omega(m)=\log\frac{W_{\rm before}}{W_{\rm after}}$$

**Kesin karakter ve kapsama aralığı:**
$$\omega_{AB}(s)=\ln W_A(s)-\ln W_B(s),\qquad \Omega_{\rm enc}(m)=
\left[
\log\frac{W_A^-}{W_B^+},
\log\frac{W_A^+}{W_B^-}
\right]$$

**Idempotent karakter sonucu:**
$$\omega(\kappa)=0,\qquad 0\in\Omega_{\rm enc}(\kappa)\ \ (\omega(\kappa)\text{'yı geçerli biçimde kapsayan aralık için})$$

**Fiziksel lock operatörü:**
$$\Pi_\kappa:\mathcal B\to\mathcal B,\qquad \Pi_\kappa^2=\Pi_\kappa$$

**Ham arşiv sadakati:**
$$A+[r]+[r]\neq A+[r]$$

**Arşiv iyi-biçimlilik adayları:**
$$\mathrm{NoDup}(A.\mathrm{map}\;\mathrm{rid}),\qquad A\preceq A'$$

**Damga semantiği:**
$$\mathrm{emittedStamp}(T_{0+})=\texttt{None},\qquad \Sigma(T_{0+})=e$$

**Çıplak geçiş:**
$$q(T_{ji})=q(T_{ij})^{-1}$$

**c₀↔c⁺ koordinasyon ilişkisi — formal aday:**
$$\mathcal R^X_{0+}\subseteq\mathcal X_0\times\mathcal X_+$$

**c₀↔c⁺ span/fiber — formal aday:**
$$\mathcal X_0\xleftarrow{p_0}\mathfrak F^X_{0+}\xrightarrow{p_+}\mathcal X_+$$

**Boundary triangle — topology:**
$$V=3,\qquad E=3,\qquad \beta_1=1,\qquad H_1\cong\mathbb Z$$

**Filled triangle özel durumu:**
$$H_1=0$$

**Nükleer köprü adayı:**
$$[\Delta_{\rm kabuk}]_{\rm ET}=[\mu_A]\odot[\Delta_{\rm kabuk}]_{\rm yapı}$$

**ParamBudget:**
$$N_{\rm serbest}<N_{\rm gözlenebilir}$$

**Model-complexity bookkeeping:**
$$D_{\rm model}=N_{\rm skaler}+N_{\rm fonksiyonel}+N_{\rm hiper}$$

**Strict Blind Lineage:**
$$D_{\rm derivation}\cap D_{\rm blind}=\varnothing,\qquad
\theta_{\rm bridge}\ \text{blind data açılmadan önce freeze edilir}$$

**Global evren devresi:**
$$U_0 \;\leftrightarrow\; U_x \;\leftrightarrow\; U_+, \qquad U_0,\,U_x,\,U_+ \notin \{c_0,\,C_m,\,c^+\}$$

**İki doğuş olayı:**
$$U_x\text{, } U_0 \text{ sınırındaki kritik eşiği aşar} \Rightarrow \text{Big Bang}, \qquad U_x\text{, } U_+ \text{ sınırındaki kritik eşiği aşar} \Rightarrow \text{Big Yırtılma}, \qquad \text{her iki durumda } \Rightarrow U_x$$

**Doğuş ≠ devre:**
$$\mathrm{Genesis} = U_0 \rightsquigarrow \{c_0,C_m,c^+\}_{\text{eş zamanlı — aynı kuruluşta birlikte}}, \qquad \mathrm{CycleSeed} = \{\mathcal{L}_{\rm çöküş}, \mathcal{L}_{\rm seyrelme}\}$$

**Global koruma:**
$$\text{Devre indeksi} \neq t, \qquad U_0 : c_0 \;\not::\; U_+ : c^+$$

**Ampirik kill condition:**
$$\Delta X_{\rm pred}\cap\Delta X_{\rm obs}=\varnothing
\Longrightarrow \text{prediction rejected}$$


## EK C.1 BÖLÜM 27 aday envanteriyle senkronizasyon notu


Bölüm 27'deki envanter, bu ekin koruma kayıtlarının aday ailesini listeler. Bir denklemin Bölüm 27'de adı geçmesi, EK C'deki çekirdek statüsüne yükseldiği anlamına gelmez. Statü, ilgili gövde bölümündeki damga ile belirlenir.

---

# EK D — DÜŞÜNCE DENEYLERİ VE ANALOJİLER

Aşağıdakiler **kavramsal araçlardır**. Hiçbiri kanıt ya da türetim değildir.

## Enformasyonel sıkıştırma

c₀'da bir durum tam ve farklılaşmamış bir bütündür. Cₘ'ye geçişte bu bütün **çözülerek okunur**: sonlu çözünürlükte, ayrık nesneler hâlinde. Bu, Cₘ ölçümünün neden sonlu çözünürlüklü olduğunun sezgisel resmidir.

## Gösterge paneli

Cₘ, gerçekliğin **okunabilir yüzeyidir**. Bir panel motorun kendisi değildir; motorun okunabilir hâlidir. Ama panel olmadan motor hakkında hiçbir şey söylenemez.

## Sinema perdesi

Perdede görülen hareket perdenin kendisinde değildir; ardışık karelerin okunmasından doğar. Zaman da böyledir: "akan" bir şey değil, **birikimden doğan** bir okuma.

## Değnek ambarı

Çalışma yönteminin adı. Birden fazla bağımsız aracın birbirini denetleyerek çalıştığı bir düzen. Hiçbiri tek başına yetkili değildir; değer **çaprazlamadan** gelir.

## Toplu davranış

Bose-Einstein yoğuşması ve süperakışkanlık, ayrık nesnelerin toplu bir bütün gibi davranmasının laboratuvarda erişilebilir örnekleridir. Her ikisi de **c₀'ın tek-yapı sezgisi** içindir.

## Çözücü çağrısı

$X$, bir değer değil, bir **çözümleme çağrısının sonucudur**: bağlamı alır, o bağlamda geçerli olanı döndürür. Yalnızca bir programlama analojisidir.


## Ay / enformasyonel çözünürlük analojisi

Tarihsel “Ay analojisi”, fazlar arası readout sırasında tam ontolojik durum ile Cₘ'nin sonlu okuma kapasitesini ayırmak için kullanılmıştır. Analojinin güvenli özü şudur: **bir kaynağın tam durumu ile ondan alınan Cₘ-projeksiyonu aynı bilgi tipi değildir**. Bu, fiziksel veri sıkıştırmasının kanıtı veya özel bir bit sayısı türetimi değildir.

## Hartman etkisi

Standart fizik açısından Hartman etkisi, opak tunneling barrier'larda group-delay saturation olgusudur. Evertophy'de yalnız şu düşünce deneyini motive eder: phase-threshold bölgesinde naif Cₘ transit-time dili yetersiz olabilir.

$$\boxed{\;\text{Hartman saturation} \neq \text{transit time literally zero} \neq \text{FTL signalling proof.}\;}$$

## Schwinger etkisi

Schwinger pair production güçlü dış alan enerjisinden parçacık-çifti üretimidir. Evertophy için “matter readout emergence” analojisi olabilir; ancak:

$$\boxed{\;\text{Schwinger effect} \neq c^+\to C_m \text{ ontolojik geçişinin kanıtı.}\;}$$

Enerji “hiçlikten” gelmez.

## Kara delik düşünce deneyi

Kara delik ≡ c₀ yazarın ontolojik tanımıdır; olay ufku ile faz sınırının birebir özdeşliği ise kurulmuş değildir. Current core:

```text
horizon = Cₘ causal/geometric structure
c₀ = pre-temporal collective core phase
```

ayrımını korur.

## Arşiv / kütüphane analojisi

Bir arşivde kayıtların birlikte erişilebilir olması, arşivin kendi “akan zamanına” sahip olduğunu göstermez. Bu analog, c⁺'ta provenance order ile physical time'ın ayrılmasını sezgisel olarak anlatır.

## Tarihsel işlemleme analojileri

**Registry Saturation**, ısı ölümü yerine arşiv doygunluğu düşüncesini anlatan bir yorumdur; termodinamik sonuç veya c⁺ yasası değildir. **IPW, processing jitter, frame-rate** ve **Gearbox/vites** dili, Cₘ readout'undaki sonlu işlemleme/örnekleme sezgisini taşır; $H_0$ için “vites debisi” kanonik öngörüsü üretmez. “c⁺ Ağ/İskelet” ve “tutuklu/serbest doku” ifadeleri de tarihsel anlatı yüzleridir; c⁺'ın güncel tanımının yerine geçmez.

## Değnek Ambarı — dört katmanlı yöntem notu

Tarihsel anlatıda Değnek Ambarı dört ayrı koruma katmanı taşır: fizik denetimi, metodoloji denetimi, AI-kayma riski ve etik/bilinç kilidi. Bu katmanlar çalışma disiplinidir; fiziksel faz veya ontolojik primitive değildir.


## Uydu-elektron düşünce deneyi zinciri


Uydu–elektron düşünce deneyleri zinciri: (1) yörünge elektronu — saf uzay ortamında elektronun çok uzun süre davranışı; (2) evrensel Planck yoğunluğu projeksiyonu. Zincirin amacı c₀'ın laboratuvar-uzay ilişkisini sezdirmektir; ölçüm önerisi değildir.

## Vakum deneyi düşünce egzersizi


Mükemmel vakumda (kozmik veya laboratuvar) sürecin nasıl okunacağı egzersizi: vakum Cₘ-içi alan durumudur (Bölüm 3.4); vakum yokluğu c₀'ı kanıtlamaz. Egzersiz, "boşluğun faz okumasının" sınırlarını hatırlatır.

## BEC süper-atom ve süpersıvı helyum-4 analog tablosu


| Laboratuvar sistemi | c₀ analojisine katkı |
|---|---|
| BEC süper-atom | toplu tek-yapı davranışı |
| Süpersıvı He-4 | sürtünmesiz kolektif akış |

Her ikisi de Bölüm 3.2'deki analoji ailesinin örnekleridir; literal kimlik değildir.

## Frekans dönüşümü düşünce deneyi

Bölüm 25.32'deki kaydın analoji düzeyindeki ifadesi.

## "Yumuşak düğmeden ani anahtara" — faz rejim–eşik sınırı analojisi


Sınır bandının davranışını sezdiren gündelik analoji: yumuşak düğme (gradual) ile ani anahtar (threshold) arasındaki geçiş. Analojidir; Bölüm 25.1'deki terminoloji kilidi burada da geçerlidir — gündelik anahtar kelime akademik metne girmez.

---

# EK E — EPİSTEMİK DÜZEN

## Kim neyi belirler

| Kaynak | Yetki |
|---|---|
| **Doğrudan mimar açıklaması** | Kanon — kaynak kod statüsü |
| **Güncel çekirdek** | Yürürlükteki ontoloji |
| **Güncel formal kanon** | Doğrulanmış formal sonuç |
| **Uyumlu formal aday** | Onaya tabi |
| **Tarihsel arşiv** | Korunur, karıştırılmaz |
| **Araç yorumu** | Taslak |

$$\boxed{\;\text{Yöntem kuralları ARAÇLARI bağlar, MİMARI bağlamaz.}\;}$$

Bir kural "yeni kanonik içerik üretme" diyorsa, bu **araçlara** yöneliktir.

## Doğrudan kanon maddeleri

Aşağıdakiler mimarın doğrudan ontolojik girdileridir ve araç yorumuyla değiştirilemez:

- $U_0$'ın üç fazı **eş zamanlı** — aynı kuruluşta birlikte — oluşturması
- **Tam çift yönlü üçgen** topolojisi
- $c^+ \equiv$ karanlık madde $\equiv$ karanlık enerji **iç ontolojik kimliği**
- c⁺'ın **kapalı devre** olması ve gerekçesinin **önce akademik sınır** olması
- **Faz-parametre matrisi yönteminin** çekirdek statüsü
- $[P,P]$'nin geçerli bir aralık olması
- **Global evren seviyesinin varlığı** ($U_0$, $U_x$, $U_+$) ve faz seviyesinden ayrılığı
- **$U_+$ — Mutlak Çözünme**; Big Yırtılma, $U_+$ sınırındaki kritik eşikle ilişkilidir
- **Dinamik evrenin son bulabilir ya da bulmayabilir olması**
- **Sessizlik ilkesi**
- **Kanonik render'ın çekirdek yapı statüsü** (EK J)

## Yenilik nasıl işler

Sonraki kayıt, öncekini geçersiz kılmaz — **üstüne yazar** ve eskisi neden bırakıldığıyla saklanır. Bir çerçevenin öğrenme tarihi, mevcut hâli kadar bilgilendiricidir.

## Araç hizalama özeti

Bu monografiyle çalışan her araç şu dört şeyi bilmelidir:

1. **Üstünlük sırası** yukarıdaki tablodadır; bir aracın kendi çıktısı en alttadır.
2. **Tarihsel içerik korunur ama güncel çekirdeğe karıştırılmaz.**
3. **Mekanizma ataması türetim değildir**; bir eşleme yazmak bir sayı üretmez.
4. **Sayaç $0/10$'dur** ve altı koşul birden sağlanmadan hareket etmez.

---


# EK F — BİÇİMSEL MİMARİ VE UYGULAMA DURUMU

## Katmanlar

Biçimsel çekirdeğin amacı bütün fiziksel içeriği tek bir yapıya sıkıştırmak değil, anlamsal sınıfları tür düzeyinde ayırmaktır.

```text
Köken / Meta:
    U₀
    Uₓ = üçlü faz sisteminin bütünsel gösterimi

Ontoloji:
    Faz = {c₀, Cₘ, c⁺}
    X = üst çözücü

Kapılar:
    tam çift yönlü üçgen

Geçiş:
    Kenar sınıfı + yön + kabul edilebilirlik

Damga:
    Damga sınıfı + damga üretimi + monoid M

Arşiv:
    ham kaynak kayıtları + yalnız-eklemeli sıra

Koordinasyon:
    c₀↔c⁺ X-ilişkisi / lif adayı

Okuma:
    Cₘ gözlenebilirleri

Yöntem:
    Parametre Bütçesi + Köprü Bütçesi + önkayıt
```

## Asgari tür iskeleti

Aşağıdaki şema bir uygulama yönelimidir; ontolojinin nihai programlama dili değildir.

```lean
inductive Phase
  | c0
  | cm
  | cp

inductive TemporalRole
  | preEmergent
  | physicalTime
  | atemporalRecord

inductive EdgeClass
  | e0m
  | emp
  | e0p

inductive ArchiveEffect
  | noMutation
  | append
  | readProject

inductive CoordEffect
  | none
  | xCoord

structure TransitionSemantics where
  src : Phase
  dst : Phase
  edge : EdgeClass
  stampEmission : Option Stamp
  archiveEffect : ArchiveEffect
  coordEffect : CoordEffect
```

`U₀`, `Uₓ` ve `X`, `Phase` türünün kurucusu değildir. `Uₓ`, üç `Phase` kurucusunun sistem-bütünü düzeyindeki gösterimidir; yeni bir dördüncü constructor eklemez.

## Biçimsel kapanış öncelikleri

1. Normalleştirici/yeniden-yazım sistemi için bütün yolların aynı normal biçimde buluşması (konfluans) — **kapandı** (14.2).
2. Genel birleşmelilik — **kapandı** (14.2).
3. İdempotent sınıflandırması — **kapandı** (14.2); kalan yalnız paket bütünleştirmesi.
4. $I(\mathbb Q)$/gerçel sayılar için tam aralık karakteri.
5. Arşiv `rid` benzersizliği ve yalnız-eklemeli değişmezler.
6. $q/\Sigma$/Arşiv yön anlambiliminin bütünleştirilmesi.
7. $X$ koordinasyon ilişkisi/lifi için asgari tür ve Parametre Bütçesi muhasebesi.
8. Cₘ metrik yeniden-kurma arayüzlerinin biçimsel türü.

## Teorem sayısının yorumu

Önceki envanterde raporlanan 119 teorem bildirimi (tarihsel envanter; güncel envanter $269 = 46$ üretim $+ 223$ arşiv, 23.10), biçimsel tanım ve değişmezlerin makine tarafından kontrol edilen kısmını gösterir. Bu sayı:

- 119 bağımsız fizik yasası,
- 119 deneysel başarı,
- Evertophy'nin doğrulanması

anlamına gelmez.


## Güncel biçimsel statü

**Biçimsel / üretim çekirdeği — kapalı:** Faz ile global düğüm ayrımı · $U_x$'in kutup olmaması · faz-indeksli değer tipi · metriğin yalnız Cₘ'de izinliliği · nicelik türü ≠ boyut · içsel / kaynak / gözlem faz rolleri · tipli Cₘ okuma arayüzü · kapı ≠ taşıma izni · Cₘ-yalnız kapı-kilidi · kapı-kilidi ⟺ en fazla bir içsel faz · arşiv sayısının ekleme monotonluğu · olay türü ve iz politikası ayrımları · damga cebirinin birleşme, sonlanma, tek normal form, konfluans ve idempotent sınıflandırması · köprünün sonlu modelde tekil olmayışı.

**Biçimsel aday / açık:** fiziksel okuma yasası · genel köprü seçicisi · $X$-lifi gerçeklemesi · metrik yeniden inşa · tam genel, genişletilmiş ve bağımlılık izlemeli aralık hesabı · üretim dışı yol ve kategori adayları.

## Typed ontology genişletmesi — Phase/GlobalNode, Gate/GlobalRel, Ux ∉ Pole


Biçimsel öneri: iki ontolojik seviye tür düzeyinde ayrılır — `Phase` (c₀, Cₘ, c⁺) ve `GlobalNode` (U₀, Uₓ, U₊); kapılar `Gate`, global oklar `GlobalRel` türündedir ve `Ux ∉ Pole` invariant'ı tip düzeyinde zorlanır. Üretim çekirdeğinde **kapalı** olanlar: faz ile global düğüm ayrımı, $U_x$'in kutup olmaması, faz-indeksli değer tipi, metriğin Cₘ'ye özgülüğü, nicelik türü ≠ boyut, kapı ≠ taşıma izni, faz rolleri ve kapı-kilidi. Üretim dışında ve **açık** olanlar: global ilişkilerin tam cebiri, yol-groupoid genişletmesi, fiziksel köprü seçicisi, $X$-lifi ve metrik yeniden inşa.

## Değer türleri — CmOnlyValue, MetricAdmissible, QuantityKind/Dimension

**Statü: biçimsel — kapalı (üretim çekirdeği).** Tür ailesi: Cₘ'ye özgü niceliklerin `CmOnlyValue` ile damgalanması, metriğin `MetricAdmissible` koşulu, nicelik türü ile boyut etiketinin ayrıştırılması (Bölüm 5.3a'nın biçimsel karşılığı).

## Köprü tipleri — BridgeSpec, CmReadoutBridge, Bridge Non-Uniqueness

**Statü: tekil-olmama biçimsel olarak kapalı; genel seçici açık.** Kanıtlanmış tekillik-olmayışı sonucunun (Bölüm 24.1) biçimsel ifadesi: birden fazla `BridgeSpec` aynı tip ve iyi-tanımlılık koşullarını sağlayabilir; bu yüzden köprü seçimi gözlem gerektirir.

## Kapı tiplemesi — Typed Gate, GateRelated ≠ TransportPermission

**Statü: biçimsel — kapalı (üretim çekirdeği).** Bölüm 13.1a'nın biçimsel karşılığı: `GateRelated(c0, cp)` doğruyken bu, nicelik taşıma izni vermez; taşıma izni ayrı bir `phase-license` türündedir.

## Yol cebiri — ordinary category / path-groupoid ve staged non-scalar X + ξ projections

Bölüm 13.2'nin biçimsel arka planı: geçişlerin ordinary category'de kompoze edilmesi, çıplak katmanda tersinir yol cebiri (path-groupoid), damga katmanında monoid (grup değil). Skaler-olmayan X için kenara özgü okuma projeksiyonları ξ_ij.

---

# EK G — TARİHSEL OKUMALAR

Bu ek, yayın çekirdeğinin dışına alınmıştır; içeriği V24 rolling master'da (§688) korunur.

# EK H — SAYISAL VE ÖNGÖRÜ KAYDI

Bu ek, yayın çekirdeğinin dışına alınmıştır; içeriği V24 rolling master'da (§688) korunur. Arşivdeki sayısal okumaların hiçbiri ön-kayıtlı öngörü değildir (21.24).

# EK I — MAKİNE-OKUNABİLİR ONTOLOJİ İSKELETİ

Bu ek fizik postülası değildir; anlam kaymasını azaltmak için önerilen **normatif olmayan makine-okunabilir ayna** katmanıdır. Çelişki hâlinde normatif kaynak her zaman ana düzyazı çekirdektir: **ana düzyazı çekirdek > makine-okunabilir ayna**.

```yaml
origin:
  U0:
    phase_object: false
    gate_endpoint: false
    co_genesis: [c0, Cm, cp]          # eş zamanlı: aynı kuruluşta birlikte
    external_physical_clock: false

system:
  Ux:
    phase_object: false
    phase_constructor: false
    system_whole_of: [c0, Cm, cp]
    identical_to_X: false
    identical_to_U0: false
    full_semantics: open_debt

phases:
  c0:
    temporal_role: pre_emergent
    metric_admissible: false
    matter_role: collective_single_structure_limit
  Cm:
    temporal_role: physical_time
    metric_admissible: true
    matter_role: differentiated
    direct_measurement: true
  cp:
    temporal_role: atemporal_record
    metric_admissible: false
    matter_role: Cm_support_dissolved
    dark_sector_identity: [DM, DE]
    c_beyond_Cm_regime: true
    matter_structure_outside_0_v_c: not_preserved
    physical_time_admissible: false
    Cm_time_support: dissolved
    temporal_record: sealed
    dark_matter_readout: clustered_cp
    dark_energy_readout: expansion_associated_cp   # yazar: "genişlemeyi sürdüren c⁺"; genişleme Cₘ'de okunan görünümdür, c⁺'a içsel zaman atfetmez
    identity_implies_equal_readout_densities: false
    intrinsic_Cm_speed: inadmissible

force_of_attraction:
  status: core_postulate
  ontology: phase_independent_constraint_coherence
  projections: [gravitation, strong, weak, electromagnetism]
  gravitation_is: Cm_metric_projection
  term_lock: "Force of Attraction != Gravitation"
  repulsion_and_charge: deferred

meta_coordination:
  X: MetaCrossPermission        # genel, kesin; fiziksel taşıma değildir; TransportPermission ayrıdır
  c0_cp_specific_relation: formal_candidate   # §13.6

global_nodes:
  U0:    {role: pole, phase_object: false}
  Ux:    {role: global_node, pole: false, phase_object: false}
  Uplus: {role: pole, phase_object: false}

absence:
  c0: undefined0
  cp: dissolvedPlus
  epistemic: MissingData        # ontolojik yokluk değildir

black_hole_identity: c0          # yazar tanımı; nicel ve gözlemsel köprü açık

gate_lock:
  Cm_only_not_transportable: [time, space3, metric, intrinsic_speed, c_bound, rest_mass]
  readout_of_cp_sourced_effects: allowed

range:
  point_as_degenerate_band: true

topology:
  gates:
    - [c0, Cm]
    - [Cm, cp]
    - [c0, cp]
  bidirectional: true

cycle_seed:
  double_limit_core: true
  ordinary_phase_transition_to_U0: false
  full_mechanism_reserved_for: V24
```

Örnek ontoloji geriye-dönük uyumluluk testleri:

```text
assert U0 not in Phase
assert Ux not in Phase
assert Ux != U0
assert Ux != X
assert gateRelated(c0,cp)
assert physicalTime(c0) == false
assert physicalTime(Cm) == true
assert physicalTime(cp) == false
assert metricAllowed(c0) == false
assert metricAllowed(Cm) == true
assert metricAllowed(cp) == false
assert MetaCrossPermission(X) == true
assert MetaCrossPermission != TransportPermission
assert Range(P,P) is valid
assert NoStamp != NoTransition
```

Bu testler fiziksel kanıt değildir; **ontoloji uyumluluk korumasıdır**.


## EK I.1 Typed-ontology alanlarının iskelete yansıtılması


Aşağıdaki YAML iskelet, EK F'deki aday tür ailesinin makine-okunabilir karşılığının genişletilmesi önerisidir; normatif değildir:

```yaml
value_types:
  CmOnlyValue: true        # zaman, metrik, durgun kütle
  MetricAdmissible: "phi == cm"
bridge:
  non_unique: true         # BridgeSpec ailesi
  selection: "physical + observation"
gate:
  related_implies_transport: false
global:
  Ux_not_pole: true
```

---

# EK J — KANONİK RENDER (ÇEKİRDEK GÖRSEL YAPI)

Bu ek, çerçevenin kanonik görselini ve kaynak kodunu taşır. Görsel bir illüstrasyon değil, **çekirdek yapının kendisidir**: sonraki sürümlerde ayrıntılar değişebilir, yapı değişmez.

## J.1 Görselin okunuşu

| Öğe | Ontolojik anlam |
|---|---|
| Sol kırmızı daire — $U_0$ (Mutlak Çekirdek) | Global doygunluk kutbu |
| Sol süslü parantez | Global seviye ile faz sisteminin sınırı |
| Siyah çerçeve — üstte $U_x$, altta *Dinamik Evren* | Üç fazın birlikte gerçekleştiği global yapı |
| Üç kalın siyah nokta | Faz düğümleri: $c_0$, $C_m$, $c^+$ |
| Üç çift yönlü ok — $\Delta_{0m}$, $\Delta_{0+}$, $\Delta_{+m}$ | Tam çift yönlü üçgen: üç kapı |
| Sağ süslü parantez | Aynı sınır, çözünme tarafı |
| Sağ kırmızı daire — $U_+$ (Mutlak Çözünme) | Global çözünme kutbu |
| Kalın dış oklar | **Bütünle ilişki** (doğuş / limit) — faz kapısı değildir |

## J.2 Değişmez çekirdek öğeler

1. **İki seviye:** dış kutuplar ($U_0$, $U_+$) ve iç faz sistemi ($U_x$)
2. **Simetri:** $U_0$ solda, $U_+$ sağda, eşit görsel ağırlıkta
3. **Tam çift yönlü üçgen** ve üç etiketli kenar
4. **Köşelerde kalın siyah nokta** — faz düğümünü sınır bandından ayırır
5. **Dış okların parantezde bitmesi** — hiçbir faz noktasına değmez
6. **Çerçevenin $U_x$ / Dinamik Evren olarak etiketlenmesi**

## J.3 Değişebilecek ayrıntılar

Etiket metinleri ve alt başlıklar · renk tonları ve font büyüklükleri · koordinat ince ayarı · yardımcı katmanlar (faz rejim – eşik sınırı gösterimi, $C_m$ altında hız bandı, dalga boyu faktörü, kara delik eşik faktörü).

## J.4 Semantik korumalar

$$\boxed{\;\leftrightarrow \text{ sembolü global seviyede TERSİNİR OPERATÖR iddia etmez.}\;}$$

Soldan sağa okuma bir süreç izlenimi verir; **devre bir zaman akışı değildir** (Bölüm 2.8). Görselde faz düğümleri ile global kutuplar **aynı grafik sınıfında değildir**: düğümler siyah nokta, kutuplar kırmızı dairedir — bu ayrım korunmalıdır.

## J.5 Kanonik LaTeX / TikZ kaynak kodu

```latex
\documentclass[border=15pt]{standalone}

\usepackage{tikz}
\usepackage{amsmath}

\usetikzlibrary{
    decorations.pathreplacing,
    calligraphy
}

\begin{document}

\begin{tikzpicture}[>=stealth, thick]

    % ============================================================
    % SOL TARAF: U_0 — Mutlak Çekirdek
    % ============================================================
    \node[
        align=center,
        circle,
        draw=red!70,
        fill=red!5,
        inner sep=5pt,
        very thick
    ] (u0) at (-7, 2.25) {
        \Large $U_0$ \\
        \footnotesize (Mutlak Çekirdek)
    };


    % ============================================================
    % U_x — DİNAMİK EVREN ÇERÇEVESİ
    % ============================================================
    \draw[very thick]
        (-4.15, -0.75)
        rectangle
        (6.15, 5.35);

    % U_x etiketi — üst kenarın ortasında
    \node[
        fill=white,
        inner sep=4pt
    ] at (1.00, 5.35) {
        \Large $U_x$
    };

    % Dinamik Evren etiketi — alt kenarın ortasında
    \node[
        fill=white,
        inner sep=4pt
    ] at (1.00, -0.75) {
        \large Dinamik Evren
    };


    % ============================================================
    % EVERTOPHY FAZ HİYERARŞİSİ
    % Noktalar ve etiketler AYRI tanımlanır
    % Böylece köşe noktalarındaki kalın siyah noktalar görünür olur
    % ============================================================

    % Üçgen köşe koordinatları
    \coordinate (pc0)    at (1, 4.5);
    \coordinate (pcm)    at (-3, 0);
    \coordinate (pcplus) at (5, 0);

    % Köşe noktalarındaki kalın siyah noktalar
    \filldraw[black] (pc0)    circle (4.2pt);
    \filldraw[black] (pcm)    circle (4.2pt);
    \filldraw[black] (pcplus) circle (4.2pt);

    % Etiketler (noktalardan biraz ayrı yerleştirilir)
    \node[align=center, above=10pt] at (pc0) {
        \Large $c_0$ \\
        \footnotesize (Potansiyel)
    };

    \node[align=center, below=10pt] at (pcm) {
        \Large $C_m$ \\
        \footnotesize (Madde/Zaman)
    };

    \node[align=center, below=10pt] at (pcplus) {
        \Large $c^+$ \\
        \footnotesize (Üst-Faz / Koordinasyon)
    };


    % ============================================================
    % ÜÇGEN BAĞLANTILARI
    % Üç kapı da çift yönlü
    % ============================================================

    % C_m <-> c_0
    \draw[<->]
        (pcm)
        --
        node[midway, above left=2pt] {$\Delta_{0m}$}
        (pc0);

    % c^+ <-> c_0
    \draw[<->]
        (pcplus)
        --
        node[midway, above right=2pt] {$\Delta_{0+}$}
        (pc0);

    % C_m <-> c^+
    \draw[<->]
        (pcm)
        --
        node[midway, below=4pt] {$\Delta_{+m}$}
        (pcplus);


    % ============================================================
    % SAĞ TARAF: U_+ — Mutlak Çözünme
    % ============================================================
    \node[
        align=center,
        circle,
        draw=red!70,
        fill=red!5,
        inner sep=5pt,
        very thick
    ] (uplus) at (10, 2.25) {
        \Large $U_+$ \\
        \footnotesize (Mutlak Çözünme)
    };


    % ============================================================
    % KAPSAYICI SÜSLÜ PARANTEZLER
    % ============================================================

    % Sol parantez
    \draw[
        decorate,
        decoration={
            calligraphic brace,
            amplitude=15pt
        },
        ultra thick,
        gray
    ]
        (-4.5, -0.8)
        --
        (-4.5, 5.4);

    % Sağ parantez
    \draw[
        decorate,
        decoration={
            calligraphic brace,
            amplitude=15pt,
            mirror
        },
        ultra thick,
        gray
    ]
        (6.5, -0.8)
        --
        (6.5, 5.4);


    % ============================================================
    % U_0 <-> U_x / FAZ SİSTEMİ
    % ============================================================
    \draw[<->, ultra thick]
        (u0)
        --
        (-4.5, 2.25);


    % ============================================================
    % U_x / FAZ SİSTEMİ <-> U_+
    % ============================================================
    \draw[<->, ultra thick]
        (6.5, 2.25)
        --
        (uplus);

\end{tikzpicture}

\end{document}
```

---

# EK K — AÇIK BORÇLAR VE BEKLEYEN KARARLAR

## K.1 Dondurulmuş açık borçlar

Bunlar tarih değil, ontolojinin bugünkü gerçek sınırlarıdır:

- **Genel fiziksel seçici** — $X$'ten fiziksel niceliğe giden köprüyü tekil kılan ilke ($J_X$, $\mathcal E_\phi$).
- **Çekim Kuvveti'nin izdüşüm işleminin biçimsel tanımı** ($\Pi$) ve **üç faz dengesinin denklemi**.
- **İtmenin ve yükün izdüşüm biçimi** (elektromanyetizma), güçlü ve zayıf kuvvetin izdüşüm anlatımı.
- **c⁺'tan karanlık madde ve karanlık enerjiye** nicel mekanizma.
- **Entropi ile mühürleme arasındaki nicel harita.**
- $v$'nin **üyelik okuması** $\mathcal R_v$ ve c⁺'ın c-ötesiliğinin **matematiksel temsili**.
- $X$'in kesin tipi ve fiziksel izdüşümü · fiziksel okuma yasası · ontolojiden metriğin yeniden inşası.
- Faz sayısının ilkel mi türetilmiş mi olduğu · $U_x$'in yapısal tipi ve global devre yasaları.
- Standart Model, Yukawa ve QCD köprüleri · ön-kayıtlı ampirik öngörü.

- Etkin 3+1 metrikten genel göreliliğin gözlemsel sonuçlarının **geri kazanılması**.
- Kuantum okumasında Born olasılıkları, girişim, Bell korelasyonları, bağlamsallık ve sinyalsizliğin geri kazanılması.
- $X$ için genel **algoritmik yakınsama** güvencesi.
- Ham arşiv birleşiminde kayıt kimliği tekilliği; damga yönü ile Cₘ → c⁺ mühürleme ilişkisi.

- Kara delik ≡ c₀ kimliğinin nicel ve gözlemsel haritası: olay ufku–faz sınırı ilişkisi, kütle kanalının eşik ve geçiş yasası.

Kısmen kurulu olanlar: tam aralık hesabı · değişkenleri bağımlı ters problemler · bazı model ailelerinin kaynak türetimi · tam Morse aralık sertifikası.

$$\boxed{\;\text{AÇIK} \;\neq\; \text{BAŞARISIZ}\;}$$

## K.2 Yazarın kararını bekleyenler

Kapanan kararlar: Cₘ'nin temel uzayı düz üç boyutlu Öklid uzayıdır, zaman emergenttir (9.2a); yayın paketi Çekirdek Ontoloji, V24'ün son sürümü ve maraton final derlemesinden oluşur; kara delik ile c₀ fazı ontolojik olarak özdeştir (3.2).


- Arşiv sayısının ham arşivin kayıt sayısı olarak tanımlanıp tanımlanmayacağı · faz hafızası monotonluğunun mimari kural olarak kabulü.
- SYNTAX ile $U_x$ arasındaki ilişkinin tipi.
- Kanal asimetrisi köprüsünün akıbeti · bazı model ailelerinin kaynak metninin teyidi.

## K.3 Güven sınıfları

Bu belgede her ifadenin hangi güvenle söylendiği cümlede belirtilir: **kanon** (yazarın onayladığı hüküm) · **yazar hükmü** (yazarın doğrudan açıklaması) · **biçimsel olarak kanıtlanmış** (kodlanmış sistem kapsamında) · **model** (kendi varsayımları içinde doğru) · **köprü** (çekirdek ile gözlem arasında bağlantı adayı) · **açık** · **emekli**.

# KAPANIŞ

Evertophy, gerçekliğin **iki ontolojik seviyeden** oluştuğunu öne süren bir çerçevedir: içeride üç fazın kurduğu dinamik evren, dışarıda o evrenin iki uç koşulu. Fazlar arasında tam çift yönlü bir üçgen, hepsinin üstünde tek bir dinamik üst çözücü, ve hepsinden önce numarasız bir öncül — Çekim Kuvveti'nin temel ontolojik postüla olması.

Bu belge, çerçevenin **ontolojik iskeletini** eksiksiz ortaya koymayı amaçladı. Tam kanıt gövdelerini içermez; biçimsel kanıtların sonuçlarını ve kaynağını özetler. Asıl sunduğu, kavramsal düzendir.

Beş şey açıkça söylenmelidir.

**Birincisi:** Çerçeve matematiksel olarak eksiktir. $X$'ten fiziksel fonksiyonlara giden merkezî zincir yazılmamıştır. Bu eksiklik gizlenmemiş, çerçevenin kendi muhasebesinde kayıtlı tutulmuştur. Ve $X$'in tam matematiksel gerçekleştirmesi **bilinçli olarak açık bırakılmıştır**.

**İkincisi:** Çerçevenin hiçbir aktif ampirik kanıt iddiası yoktur. Bir dönem en güçlü sayılan hat, **iç denetimle** kapatılmıştır. Bu kapanışın kendisi, çerçevenin en güvenilir davranışıdır: bir iddiayı dışarıdan bir hakem değil, kendi protokolü çürütmüştür.

**Üçüncüsü:** Global seviye yeni ve en az tanımlanmış katmandır. $U_+$'ın işlev cümlesi, global okların matematiksel tipi ve devre bağı açıktır. Ve iki kutup arasındaki doğrudan ilişki hakkında çerçeve bilinçli olarak **sessiz kalır** — çünkü temsili olmayan bir şey hakkında hüküm vermek, gözlem ve deney çizgisinden çıkmak olurdu.

**Dördüncüsü:** Çerçevenin bugünkü değeri, ürettiği sayılarda değil, **kurduğu düzende ve koyduğu yasaklarda**dır. Bir çerçeve ne kadar çok şeyi açıklarsa değil, ne kadar net biçimde **yanlışlanabilir hâle gelirse** o kadar değerlidir.

**Beşincisi:** Bu metindeki biçimsel sonuçlar kodlanmış sistem kapsamında geçerlidir; metnin bütünü çapraz denetimden geçmiştir, ama çapraz denetim bir kanıt değildir. Denetim, iskeletin tip ve cebir düzeyinde tutarlı olduğunu gösterdi, otuzu aşkın iddiayı ayıkladı ve merkezî açığın yerini kesinleştirdi. Denetimden geçmek doğru olmak demek değildir; ama nerede yanılabileceğini bilmek, doğruya giden yolun ilk adımıdır.

Evertophy şu anda bu ölçüde tamamlanmış bir teori değil, **Her Şeyin Teorisi hedefi taşıyan bir ontoloji ve fizik araştırma programıdır**. Bu sürümün iç statüsü **Kararlı Kapanış Adayı / Güncel Çekirdek Referansı**dır: doğrudan mimar revizyonuna açıktır ve V24 devre mekanizması gibi rezerve katmanlar henüz kapanmış değildir.

---

*Uğur Yılmaz · Bağımsız Araştırmacı · İstanbul · `ugur@data24k.com`*

*Bu sürüm, çoklu-sistem çapraz denetim yöntemiyle hazırlanmış; pozitif düzeltme setleri ve negatif kısıt setleri birlikte uygulanarak tek tutarlı çekirdek hâline getirilmiştir.*


---

\[
\boxed{0/10}
\]

