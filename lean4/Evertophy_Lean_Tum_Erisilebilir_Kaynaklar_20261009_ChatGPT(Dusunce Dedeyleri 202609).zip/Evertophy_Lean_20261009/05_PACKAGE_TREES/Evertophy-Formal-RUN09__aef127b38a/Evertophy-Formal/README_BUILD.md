# Evertophy-Formal — import-kapalı paket (RUN-09)
Derleme: lake build · Lean leanprover/lean4:v4.12.0 · Mathlib GEREKMEZ
Teorem: 210 · sorry/admit/axiom: 0
- V24/Absence.lean: 10
- V24/BridgeNoGo.lean: 6
- V24/Confluence.lean: 5
- V24/Global.lean: 25
- V24/Idem.lean: 3
- V24/Patches.lean: 10
- V24/Production.lean: 5
- V24/Rewrite.lean: 5
- V24/StampAssoc.lean: 8
- V24/Topology.lean: 5
- V24/Types.lean: 9
