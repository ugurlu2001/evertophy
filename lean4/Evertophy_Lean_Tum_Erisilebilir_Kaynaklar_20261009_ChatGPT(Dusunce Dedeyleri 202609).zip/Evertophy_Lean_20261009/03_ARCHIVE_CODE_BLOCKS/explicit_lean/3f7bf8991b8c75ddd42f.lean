theorem ledger_counts :
    count .formalCore = 8 ∧ count .model = 4 ∧ count .bridge = 3 ∧ count .retired = 6 ∧ count .openItem = 5
