theorem normalize_is_irred : ∀ w : Word, Irred (normalize w)
  | [] => trivial
  | g :: w => by
    rw [normalize_cons]
    have ih
