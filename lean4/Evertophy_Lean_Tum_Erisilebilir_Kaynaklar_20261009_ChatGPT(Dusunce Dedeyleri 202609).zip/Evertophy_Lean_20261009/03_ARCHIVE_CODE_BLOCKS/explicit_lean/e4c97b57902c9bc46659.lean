theorem chain_ok_low  : adjacent .c0 .Cm = true
