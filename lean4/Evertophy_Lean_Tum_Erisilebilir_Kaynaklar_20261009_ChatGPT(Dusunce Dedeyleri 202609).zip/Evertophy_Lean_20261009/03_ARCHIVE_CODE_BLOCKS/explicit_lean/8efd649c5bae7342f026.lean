theorem omega_k0m_zero (Ω : OmegaHom) : Ω.map [Gen.k0m] = Ivl.zero
