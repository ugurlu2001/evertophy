theorem U0_arrow_is_one_way : U0_bidirectional = false
