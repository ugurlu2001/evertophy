theorem c0_is_undefined {α : Type} (v : CmOnlyValue α .c0) : v = .undefined0
