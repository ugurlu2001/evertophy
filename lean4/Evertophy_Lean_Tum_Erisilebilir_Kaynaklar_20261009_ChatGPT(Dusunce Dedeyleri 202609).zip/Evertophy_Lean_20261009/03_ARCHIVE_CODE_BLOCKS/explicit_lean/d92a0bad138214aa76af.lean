theorem U0_not_phase : isPhase (.pole .U0) = false
