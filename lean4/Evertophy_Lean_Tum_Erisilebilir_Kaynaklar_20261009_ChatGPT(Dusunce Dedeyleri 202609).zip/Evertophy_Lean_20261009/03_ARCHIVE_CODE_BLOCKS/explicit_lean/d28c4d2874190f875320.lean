theorem disk_morse   : chi2 3 3 1 = 1
