theorem eta_clock_dimensionless : Dim.div Dim.freq Dim.freq = MD 0
