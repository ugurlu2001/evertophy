theorem count_reservedCore : countBy .reservedCore = 5
