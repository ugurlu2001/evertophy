theorem euler_circle_zero_disk_one : chi1 3 3 = 0 ∧ chi2 3 3 0 ≠ 1
