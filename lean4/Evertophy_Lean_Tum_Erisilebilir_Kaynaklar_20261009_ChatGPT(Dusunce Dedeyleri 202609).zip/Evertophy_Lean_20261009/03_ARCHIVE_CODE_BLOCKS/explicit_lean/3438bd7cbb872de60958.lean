theorem legacy_adjacent_conflicts :
    adjacent .c0 .cp = false ∧ gateRelated .c0 .cp = true
