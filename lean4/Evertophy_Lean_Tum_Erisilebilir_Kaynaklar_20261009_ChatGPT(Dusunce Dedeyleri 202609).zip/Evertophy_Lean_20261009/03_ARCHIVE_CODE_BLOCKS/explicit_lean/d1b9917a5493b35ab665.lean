theorem transport_is_not_readout :
    TransportPermission .physTime .cp .Cm = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true
