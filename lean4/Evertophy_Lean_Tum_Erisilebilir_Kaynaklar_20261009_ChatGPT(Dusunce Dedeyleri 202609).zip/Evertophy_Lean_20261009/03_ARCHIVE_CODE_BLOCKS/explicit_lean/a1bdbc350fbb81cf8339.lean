theorem normalize_irred : ∀ w : Word, Irred w → normalize w = w
  | [], _ => rfl
  | [g], _ => by rw [normalize_cons]; rfl
  | g :: h :: t, hw => by
    have ih
