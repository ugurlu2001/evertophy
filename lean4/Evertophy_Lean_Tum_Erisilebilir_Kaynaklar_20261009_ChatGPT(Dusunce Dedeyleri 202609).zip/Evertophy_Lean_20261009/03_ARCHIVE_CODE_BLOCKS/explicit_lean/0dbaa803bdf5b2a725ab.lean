theorem curvature_undefined_cp : argAvailable .cp .curvature = false
