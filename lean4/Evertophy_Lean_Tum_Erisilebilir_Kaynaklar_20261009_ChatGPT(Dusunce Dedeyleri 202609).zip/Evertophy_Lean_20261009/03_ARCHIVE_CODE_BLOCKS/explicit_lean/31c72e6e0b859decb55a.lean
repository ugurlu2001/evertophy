theorem no_commutativity : mulW [Gen.s] [Gen.s'] ≠ mulW [Gen.s'] [Gen.s]
