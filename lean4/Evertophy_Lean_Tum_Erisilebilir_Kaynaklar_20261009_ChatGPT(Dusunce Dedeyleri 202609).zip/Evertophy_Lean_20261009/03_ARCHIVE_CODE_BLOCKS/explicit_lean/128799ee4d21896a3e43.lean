theorem variable_arity_consistent :
    ∀ p : Phase, (argsOf p).all (argAvailable p) = true
