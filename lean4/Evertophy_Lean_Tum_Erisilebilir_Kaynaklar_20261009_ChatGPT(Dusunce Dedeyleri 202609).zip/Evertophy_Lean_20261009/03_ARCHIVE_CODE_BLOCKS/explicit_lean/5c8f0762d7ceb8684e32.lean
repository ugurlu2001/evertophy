theorem step_cons_lift (g : Gen) {a b : Word} (h : Step a b) : Step (g :: a) (g :: b)
