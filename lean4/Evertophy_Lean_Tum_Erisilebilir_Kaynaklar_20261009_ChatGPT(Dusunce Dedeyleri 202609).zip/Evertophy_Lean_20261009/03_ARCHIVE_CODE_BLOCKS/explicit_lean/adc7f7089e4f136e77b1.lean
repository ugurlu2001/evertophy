theorem outer_never_defined : ∀ s : CmStructure,
    cellOf .c0 s ≠ .defined ∧ cellOf .cp s ≠ .defined
