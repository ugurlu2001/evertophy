theorem no_absorption_L : mulW [Gen.k0m] [Gen.s] ≠ [Gen.k0m]
