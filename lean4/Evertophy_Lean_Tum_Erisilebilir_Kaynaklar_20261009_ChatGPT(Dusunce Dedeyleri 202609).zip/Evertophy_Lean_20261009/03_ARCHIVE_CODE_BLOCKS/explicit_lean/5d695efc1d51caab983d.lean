theorem star_preserves_normalize {a b : Word} (h : Star a b) : normalize a = normalize b
