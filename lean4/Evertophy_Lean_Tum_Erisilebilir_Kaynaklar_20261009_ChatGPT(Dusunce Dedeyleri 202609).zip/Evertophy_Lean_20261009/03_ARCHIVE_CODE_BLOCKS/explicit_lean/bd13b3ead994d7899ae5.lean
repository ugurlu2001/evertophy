theorem closure_hbar_over_E_is_time : Dim.div hbarD energyD = Dim.time
