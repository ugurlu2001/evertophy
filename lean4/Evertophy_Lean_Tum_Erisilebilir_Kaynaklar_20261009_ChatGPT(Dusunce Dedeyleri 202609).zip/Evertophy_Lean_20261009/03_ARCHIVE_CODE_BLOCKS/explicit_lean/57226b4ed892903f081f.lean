theorem X_universal_Cm : carriable .Cm Dim.one = true
