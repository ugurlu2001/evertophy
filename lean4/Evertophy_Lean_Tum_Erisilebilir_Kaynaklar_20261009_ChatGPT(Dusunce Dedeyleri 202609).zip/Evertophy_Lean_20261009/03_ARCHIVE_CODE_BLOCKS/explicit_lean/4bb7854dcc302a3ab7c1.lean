theorem push_irred (acc : Word) : ∀ (g : Gen) (rest : Word), Irred (g :: rest) →
    (∃ t, List.foldr step acc (g :: rest) = g :: t) ∧
    acc.length + rest.length + 1 ≤ (List.foldr step acc (g :: rest)).length + 1
  | g, [], _ => by
    show (∃ t, step g acc = g :: t) ∧ _ ≤ (step g acc).length + 1
    cases acc with
    | nil => exact ⟨⟨[], rfl⟩, by simp [step]⟩
    | cons h t =>
      rw [step_cons]
      by_cases hc : (g.isKappa && g == h) = true
      · rw [if_pos hc]
        have : g = h
