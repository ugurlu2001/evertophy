theorem reasons_differ   : AbsenceReason.PreAdmissible ≠ AbsenceReason.Dissolved
