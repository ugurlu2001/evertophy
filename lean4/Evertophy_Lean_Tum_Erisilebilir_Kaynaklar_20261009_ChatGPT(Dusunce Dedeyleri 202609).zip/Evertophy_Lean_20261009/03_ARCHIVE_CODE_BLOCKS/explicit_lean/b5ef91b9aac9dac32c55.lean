theorem norm_k0_triple : normalize [Gen.k0m, Gen.k0m, Gen.k0m] = [Gen.k0m]
