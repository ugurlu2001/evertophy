theorem len2_not_idem_k0kp : mulW [Gen.k0m, Gen.kpm] [Gen.k0m, Gen.kpm] ≠ [Gen.k0m, Gen.kpm]
