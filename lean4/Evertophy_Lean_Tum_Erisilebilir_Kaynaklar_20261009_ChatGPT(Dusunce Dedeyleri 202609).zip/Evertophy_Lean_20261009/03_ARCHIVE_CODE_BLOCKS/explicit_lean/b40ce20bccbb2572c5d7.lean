theorem single_normal (g : Gen) : isNormal [g] = true
