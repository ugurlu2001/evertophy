theorem Cm_all_ok    : admissible .Cm .cmRestMass = true ∧ admissible .Cm .physTime = true
