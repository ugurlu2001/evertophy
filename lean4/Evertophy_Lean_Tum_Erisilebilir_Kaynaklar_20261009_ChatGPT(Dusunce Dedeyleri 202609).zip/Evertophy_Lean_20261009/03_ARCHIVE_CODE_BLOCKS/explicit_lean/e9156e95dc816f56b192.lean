theorem tri_edge_no_time            : crossable_c0_cp Dim.time = false
