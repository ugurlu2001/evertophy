theorem K2prime_keeps_time : carriableV24 .cp Dim.time = carriable .cp Dim.time
