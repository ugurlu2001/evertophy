private theorem mul_between_right {a b x : Int} (y : Int) (h1 : a ≤ x) (h2 : x ≤ b) :
    min (a*y) (b*y) ≤ x*y ∧ x*y ≤ max (a*y) (b*y)
