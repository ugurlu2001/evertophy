theorem zero_band_not_invertible (b : Band) (h : b.mem 0) : ¬ ZeroExcluded b
