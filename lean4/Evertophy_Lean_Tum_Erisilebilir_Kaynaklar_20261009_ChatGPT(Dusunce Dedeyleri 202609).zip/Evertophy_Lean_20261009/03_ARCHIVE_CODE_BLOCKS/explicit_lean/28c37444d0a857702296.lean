theorem oneD_is_chain  : adj1D 0 2 = false
