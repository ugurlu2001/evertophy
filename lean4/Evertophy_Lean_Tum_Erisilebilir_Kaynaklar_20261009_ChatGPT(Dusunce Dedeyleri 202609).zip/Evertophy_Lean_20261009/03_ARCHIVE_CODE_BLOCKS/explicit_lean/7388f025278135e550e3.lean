theorem F_old_form_violates : Dim.div (MD 0) (MD (-2)) = MD 2
