theorem K2_conflict_recorded : carriable .cp Dim.mass = true ∧ matterSupportV24 .cp = false
theorem K2prime_cp_mass      : carriableV24 .cp Dim.mass = false
theorem K2prime_keeps_time   : carriableV24 .cp Dim.time = carriable .cp Dim.time
