theorem B1_additive : Additive B1
