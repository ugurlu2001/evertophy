theorem count_open         : countBy .open_        = 3
