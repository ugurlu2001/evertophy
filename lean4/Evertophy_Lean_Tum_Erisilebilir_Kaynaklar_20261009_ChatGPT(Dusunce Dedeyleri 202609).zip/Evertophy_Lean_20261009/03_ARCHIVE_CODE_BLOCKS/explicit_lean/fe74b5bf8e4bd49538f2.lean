theorem normalize_cons (g : Gen) (w : Word) : normalize (g :: w) = step g (normalize w)
