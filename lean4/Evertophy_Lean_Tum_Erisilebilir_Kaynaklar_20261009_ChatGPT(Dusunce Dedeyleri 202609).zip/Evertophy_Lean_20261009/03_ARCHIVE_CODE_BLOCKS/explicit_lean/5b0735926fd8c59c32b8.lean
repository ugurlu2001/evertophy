theorem traceS_not_derived_from_dissolution :
    TPS1.policy .dissolution ⟨.cp⟩ ≠ TPS2.policy .dissolution ⟨.cp⟩
