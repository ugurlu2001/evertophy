theorem gate_c0_cp_open  : gateRelated .c0 .cp = true
