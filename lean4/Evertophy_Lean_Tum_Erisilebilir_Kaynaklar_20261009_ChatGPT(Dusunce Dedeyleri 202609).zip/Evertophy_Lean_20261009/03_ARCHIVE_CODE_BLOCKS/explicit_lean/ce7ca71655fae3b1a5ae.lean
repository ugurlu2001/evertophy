theorem neg_sound {a : Band} {x : Int} (hx : a.mem x) : a.neg.mem (-x)
