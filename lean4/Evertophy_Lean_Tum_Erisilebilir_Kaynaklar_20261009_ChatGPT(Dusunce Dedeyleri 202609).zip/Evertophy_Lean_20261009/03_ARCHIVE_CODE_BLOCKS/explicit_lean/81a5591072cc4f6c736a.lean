theorem gate_symm : ∀ a b, GateRelated a b = GateRelated b a
