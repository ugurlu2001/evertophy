theorem gamma_wrong : Dim.mul (Dim.mul Dim.one Dim.freq) Dim.time = Dim.one
