theorem tri_edge_only_dimensionless : crossable_c0_cp Dim.one  = true
