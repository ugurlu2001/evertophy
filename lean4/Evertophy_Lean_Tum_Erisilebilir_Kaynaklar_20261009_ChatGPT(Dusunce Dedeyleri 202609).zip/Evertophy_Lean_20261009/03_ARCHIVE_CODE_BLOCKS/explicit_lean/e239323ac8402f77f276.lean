theorem U0_derives_all_three :
    derivedFromU0 .c0 = true ∧ derivedFromU0 .Cm = true ∧ derivedFromU0 .cp = true
