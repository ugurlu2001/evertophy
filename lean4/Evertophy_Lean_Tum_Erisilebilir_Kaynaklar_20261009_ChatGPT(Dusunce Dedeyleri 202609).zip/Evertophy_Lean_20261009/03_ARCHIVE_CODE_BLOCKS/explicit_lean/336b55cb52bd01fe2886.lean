theorem cm_only_gate_locked : ∀ q a b, CmOnlyKind q = true → TransportPermission q a b = false
theorem only_labels_cross : TransportPermission .xCoord .c0 .cp = true ∧ TransportPermission .dimMassLabel .c0 .cp = true
theorem gate_lock_does_not_block_readout : TransportPermission .physTime .cp .Cm = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true
