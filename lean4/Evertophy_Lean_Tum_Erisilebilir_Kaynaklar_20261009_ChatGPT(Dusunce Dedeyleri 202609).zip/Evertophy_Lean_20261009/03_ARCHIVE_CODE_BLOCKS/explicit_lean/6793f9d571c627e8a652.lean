theorem sigma_T0m_stamps : stampOf .c0 .Cm = some Gen.k0m
