theorem counts_sum_to_total :
    countBy .resolved + countBy .transferred + countBy .reservedCore
  + countBy .open_ + countBy .retired = debtRegistry.length
