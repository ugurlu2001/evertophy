theorem point_inside_not_rejected (p : Int) (b : Band) (h : b.mem p) :
    (Band.inter ⟨p, p, Int.le_refl p⟩ b).isSome = true
