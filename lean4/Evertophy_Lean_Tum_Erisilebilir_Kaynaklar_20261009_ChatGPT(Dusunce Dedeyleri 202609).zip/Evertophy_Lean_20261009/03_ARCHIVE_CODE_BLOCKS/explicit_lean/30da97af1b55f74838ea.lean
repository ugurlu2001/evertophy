theorem dimensioned_blocked : crossesPhaseGate .dimensioned = false
