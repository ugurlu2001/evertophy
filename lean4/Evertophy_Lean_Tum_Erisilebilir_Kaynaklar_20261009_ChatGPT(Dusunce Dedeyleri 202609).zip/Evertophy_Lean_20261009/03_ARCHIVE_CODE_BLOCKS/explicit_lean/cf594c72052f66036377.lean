theorem gate_symmetric_1 : gateRelated .c0 .Cm = gateRelated .Cm .c0
