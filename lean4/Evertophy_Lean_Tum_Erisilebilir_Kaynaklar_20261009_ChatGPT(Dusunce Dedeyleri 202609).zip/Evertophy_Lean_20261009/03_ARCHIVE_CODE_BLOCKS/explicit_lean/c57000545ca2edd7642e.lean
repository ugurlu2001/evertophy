theorem church_rosser {w a b : Word} (ha : Star w a) (hb : Star w b) :
    ∃ c, Star a c ∧ Star b c
