theorem superposition_selects_unique :
  ∀ B : Fin 3 → Nat, Admissible B → Additive B → B = B1
