theorem morse_disk : eulerMorse 3 3 1 = 1
