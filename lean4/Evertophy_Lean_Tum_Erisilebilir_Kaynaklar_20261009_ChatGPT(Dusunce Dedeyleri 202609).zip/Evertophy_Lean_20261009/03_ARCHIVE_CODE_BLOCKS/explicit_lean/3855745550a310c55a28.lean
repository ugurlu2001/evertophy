theorem K2_as_label_only : NativeOK .dimMassLabel .cp = true ∧ NativeOK .cmRestMass .cp = false
