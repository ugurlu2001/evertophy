theorem time_confined_c0 : carriable .c0 Dim.time = false
