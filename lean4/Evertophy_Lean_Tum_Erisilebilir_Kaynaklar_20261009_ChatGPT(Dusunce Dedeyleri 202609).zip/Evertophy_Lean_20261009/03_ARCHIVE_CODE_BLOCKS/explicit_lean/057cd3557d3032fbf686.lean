theorem foldr_normalize (acc : Word) : ∀ x : Word,
    List.foldr step acc (normalize x) = List.foldr step acc x
  | [] => rfl
  | g :: rest => by
    rw [normalize_cons, foldr_step_comm, foldr_normalize acc rest]; rfl

/-- 🎯 GENEL BİRLEŞME: ∀ a b c — sonlu tarama değil, tüm kelimeler. -/
theorem mulW_assoc (a b c : Word) : mulW (mulW a b) c = mulW a (mulW b c)
