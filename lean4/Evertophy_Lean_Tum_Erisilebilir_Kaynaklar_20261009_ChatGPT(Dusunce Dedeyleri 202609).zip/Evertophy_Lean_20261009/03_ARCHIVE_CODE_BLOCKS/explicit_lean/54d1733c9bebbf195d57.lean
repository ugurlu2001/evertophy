theorem gate_cp_c0_open  : gateRelated .cp .c0 = true
