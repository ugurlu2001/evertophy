theorem cp_no_rest_mass : admissible .cp .cmRestMass = false
