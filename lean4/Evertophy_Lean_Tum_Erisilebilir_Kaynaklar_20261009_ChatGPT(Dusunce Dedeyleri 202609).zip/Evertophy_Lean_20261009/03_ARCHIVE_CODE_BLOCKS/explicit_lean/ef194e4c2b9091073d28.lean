theorem Ux_not_phase : isPhase (.pole .Ux) = false
