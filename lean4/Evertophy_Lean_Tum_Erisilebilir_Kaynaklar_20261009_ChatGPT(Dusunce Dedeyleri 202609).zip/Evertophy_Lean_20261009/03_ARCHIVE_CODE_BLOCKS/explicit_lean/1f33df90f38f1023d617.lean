theorem step_decreases {a b : Word} (h : Step a b) : b.length < a.length
