theorem gate_full_K3 : GateRelated .c0 .Cm ∧ GateRelated .Cm .cp ∧ GateRelated .c0 .cp
