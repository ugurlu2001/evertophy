theorem Cm_has_no_onto_absence : ontoAbsenceOf .Cm = none
