theorem chain_no_skip_bwd : adjacent .cp .c0 = false
