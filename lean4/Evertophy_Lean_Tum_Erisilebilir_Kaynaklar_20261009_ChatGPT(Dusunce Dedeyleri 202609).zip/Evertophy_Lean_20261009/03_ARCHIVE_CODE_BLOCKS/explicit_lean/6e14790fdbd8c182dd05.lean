theorem transport_separate_from_gate :
    GateRelated .c0 .cp = true ∧ TransportPermission .physTime .c0 .cp = false
