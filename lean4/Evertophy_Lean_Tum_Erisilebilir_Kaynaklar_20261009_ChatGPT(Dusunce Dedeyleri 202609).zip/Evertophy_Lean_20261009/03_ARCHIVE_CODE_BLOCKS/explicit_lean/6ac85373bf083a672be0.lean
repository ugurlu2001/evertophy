theorem dissolved_does_not_fix_trace :
    cmTimeValue .cp = .absent .Dissolved ∧ P1.policy .cp ≠ P2.policy .cp
