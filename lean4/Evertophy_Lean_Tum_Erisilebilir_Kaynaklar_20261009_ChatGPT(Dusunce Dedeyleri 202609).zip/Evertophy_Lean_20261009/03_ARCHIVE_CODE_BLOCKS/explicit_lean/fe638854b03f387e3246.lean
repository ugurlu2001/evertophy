theorem sealRec_preserves_band (rid : Nat) (b : Ivl) (st : Gen) :
    (sealRec rid b st).payload = b
