theorem trace_not_derived_from_dissolution :
    TP1.policy .dissolution .cp ≠ TP2.policy .dissolution .cp
