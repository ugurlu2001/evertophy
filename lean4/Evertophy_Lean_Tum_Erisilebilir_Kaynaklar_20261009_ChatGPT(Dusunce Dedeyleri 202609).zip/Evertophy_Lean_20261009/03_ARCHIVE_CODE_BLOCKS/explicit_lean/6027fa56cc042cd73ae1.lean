theorem legacy_metricOK_values_agree :
    ∀ p : Phase, (V24.metricOK p = true) ↔ MetricAdmissible p
