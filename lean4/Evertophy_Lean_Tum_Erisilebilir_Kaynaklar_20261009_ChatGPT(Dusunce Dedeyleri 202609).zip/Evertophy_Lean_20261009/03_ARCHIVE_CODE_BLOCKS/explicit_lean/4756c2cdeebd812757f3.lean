theorem U0_generates_all : generatedByU0 .c0 ∧ generatedByU0 .Cm ∧ generatedByU0 .cp
