theorem K2_cp_len  : carriable .cp Dim.len  = false
