theorem assoc_sample_1 :
    mulW (mulW [Gen.s] [Gen.k0m]) [Gen.k0m] = mulW [Gen.s] (mulW [Gen.k0m] [Gen.k0m])
