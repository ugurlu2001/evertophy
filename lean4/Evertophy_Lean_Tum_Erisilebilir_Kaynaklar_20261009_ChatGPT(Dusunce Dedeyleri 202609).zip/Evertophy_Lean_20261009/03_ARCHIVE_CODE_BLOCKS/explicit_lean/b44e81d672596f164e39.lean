theorem nil_normal : isNormal [] = true
