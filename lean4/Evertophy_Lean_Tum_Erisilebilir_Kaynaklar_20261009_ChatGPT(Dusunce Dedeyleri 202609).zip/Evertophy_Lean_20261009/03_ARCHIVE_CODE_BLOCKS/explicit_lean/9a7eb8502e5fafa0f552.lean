theorem ofInt_preserves (b : Band) : (BandG.ofInt b).lo = b.lo ∧ (BandG.ofInt b).hi = b.hi
