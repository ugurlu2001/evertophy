theorem density_undefined_c0   : argAvailable .c0 .density   = false
