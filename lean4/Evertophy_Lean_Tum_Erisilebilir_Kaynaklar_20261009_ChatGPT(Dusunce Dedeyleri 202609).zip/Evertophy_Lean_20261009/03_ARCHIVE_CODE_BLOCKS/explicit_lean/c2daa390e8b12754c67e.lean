theorem norm_kpm_idem : normalize [Gen.kpm, Gen.kpm] = [Gen.kpm]
