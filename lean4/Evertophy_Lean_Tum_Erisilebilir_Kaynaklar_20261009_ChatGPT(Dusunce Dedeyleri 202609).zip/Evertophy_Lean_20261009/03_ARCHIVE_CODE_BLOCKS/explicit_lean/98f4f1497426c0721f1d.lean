theorem domain_cannot : canProduceKutu4 .domain = false
