theorem morse_rejects_no_interior_max : eulerMorse 3 3 0 ≠ 1
