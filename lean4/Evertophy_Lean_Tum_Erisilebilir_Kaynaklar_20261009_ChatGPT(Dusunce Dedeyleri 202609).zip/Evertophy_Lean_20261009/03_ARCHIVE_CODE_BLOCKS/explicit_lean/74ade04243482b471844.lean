theorem tri_edge_no_len             : crossable_c0_cp Dim.len  = false
