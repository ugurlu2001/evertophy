theorem cp_dissolved     : cmTimeValue .cp = .absent .Dissolved
