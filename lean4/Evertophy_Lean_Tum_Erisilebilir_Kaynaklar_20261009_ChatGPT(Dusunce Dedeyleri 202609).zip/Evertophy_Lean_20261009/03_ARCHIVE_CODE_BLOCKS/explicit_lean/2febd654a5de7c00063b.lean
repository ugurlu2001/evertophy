theorem time_confined_cp : carriable .cp Dim.time = false
