theorem reserved_core_count : reservedCount = 5
