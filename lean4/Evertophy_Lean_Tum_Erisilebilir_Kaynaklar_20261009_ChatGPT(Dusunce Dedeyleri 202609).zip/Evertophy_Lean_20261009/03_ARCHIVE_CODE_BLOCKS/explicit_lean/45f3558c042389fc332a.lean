theorem clock_same_c0_cp : clockOf .c0 = clockOf .cp
