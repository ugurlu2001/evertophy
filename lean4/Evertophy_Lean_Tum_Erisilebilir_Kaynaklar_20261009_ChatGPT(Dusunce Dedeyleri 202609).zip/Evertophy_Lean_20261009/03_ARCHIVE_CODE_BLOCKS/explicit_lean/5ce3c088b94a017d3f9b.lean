theorem M_not_cancellative :
    mulW [Gen.k0m] [Gen.k0m] = mulW [] [Gen.k0m] ∧ [Gen.k0m] ≠ ([] : Word)
