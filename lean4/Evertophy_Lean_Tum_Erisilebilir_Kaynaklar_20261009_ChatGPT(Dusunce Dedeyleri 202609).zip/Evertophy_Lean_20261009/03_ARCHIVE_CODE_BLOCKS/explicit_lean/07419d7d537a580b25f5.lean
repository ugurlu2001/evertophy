theorem K1_c0_mass : carriable .c0 Dim.mass = false
