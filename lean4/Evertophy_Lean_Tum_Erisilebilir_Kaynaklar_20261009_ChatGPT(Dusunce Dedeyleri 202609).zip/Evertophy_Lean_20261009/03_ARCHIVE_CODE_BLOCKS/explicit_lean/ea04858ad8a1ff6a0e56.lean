theorem B1_admissible : Admissible B1
