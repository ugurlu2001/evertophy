theorem no_gate_Up_cp : gate (.pole .Up) (.phase .cp) = false
