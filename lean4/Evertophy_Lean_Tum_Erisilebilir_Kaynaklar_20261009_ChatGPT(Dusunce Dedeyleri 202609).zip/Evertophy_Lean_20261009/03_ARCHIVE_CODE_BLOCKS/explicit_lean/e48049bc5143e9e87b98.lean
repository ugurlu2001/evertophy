theorem bridge_nonunique
    (S O : Type)
    [Nonempty S]
    (o0 o1 : O)
    (h : o0 ≠ o1) :
    ∃ B0 B1 : S → O, B0 ≠ B1 := by
  ...
