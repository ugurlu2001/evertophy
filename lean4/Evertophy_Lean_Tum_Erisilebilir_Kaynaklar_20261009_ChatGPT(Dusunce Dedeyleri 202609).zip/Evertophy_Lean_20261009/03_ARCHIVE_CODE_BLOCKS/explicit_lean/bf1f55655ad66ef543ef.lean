theorem observed_cp_is_dissolved {α : Type} (src : SourcePhase) (v : CmReadout α ⟨src, ⟨.cp⟩⟩) :
    v = CmOnlyValue.dissolvedPlus
