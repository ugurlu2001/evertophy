theorem zero_add (A : Ivl) : Ivl.zero.add A = A
