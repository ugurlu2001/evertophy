structure CmReadoutBridgeR (Ctx Out) where
  bridge : (p : Phase) → Ctx → CmOnlyValue Out p
theorem reasons_preserved : B.bridge .c0 c = .undefined0 ∧ B.bridge .cp c = .dissolvedPlus
