theorem only_labels_cross : TransportPermission .xCoord .c0 .cp = true ∧
    TransportPermission .dimMassLabel .c0 .cp = true
