theorem trole_differs_c0_cp : troleOf .c0 ≠ troleOf .cp
