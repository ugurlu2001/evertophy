theorem norm_produces_normal_mix :
    isNormal (normalize [Gen.k0m, Gen.k0m, Gen.s, Gen.kpm, Gen.kpm]) = true
