theorem K2_conflict_recorded :
    carriable .cp Dim.mass = true ∧ matterSupportV24 .cp = false
