theorem only_X_crosses      : crossesPhaseGate .xCoordinate = true
