theorem gate_symmetric_3 : gateRelated .c0 .cp = gateRelated .cp .c0
