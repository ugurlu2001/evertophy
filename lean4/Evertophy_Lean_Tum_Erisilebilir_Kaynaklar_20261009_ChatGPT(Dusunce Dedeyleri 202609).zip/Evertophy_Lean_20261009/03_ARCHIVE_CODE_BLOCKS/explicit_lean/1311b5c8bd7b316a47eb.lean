theorem unique_normal_form {w a b : Word} (ha : Star w a) (hb : Star w b)
    (ia : Irred a) (ib : Irred b) : a = b
