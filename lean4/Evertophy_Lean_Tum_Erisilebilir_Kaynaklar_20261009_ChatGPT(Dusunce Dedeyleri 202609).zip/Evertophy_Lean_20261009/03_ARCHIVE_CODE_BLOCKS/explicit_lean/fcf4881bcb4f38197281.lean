theorem three_idempotents_len1 :
    mulW [Gen.k0m] [Gen.k0m] = [Gen.k0m] ∧
    mulW [Gen.kpm] [Gen.kpm] = [Gen.kpm] ∧
    mulW [Gen.s] [Gen.s] ≠ [Gen.s] ∧
    mulW [Gen.s'] [Gen.s'] ≠ [Gen.s']
