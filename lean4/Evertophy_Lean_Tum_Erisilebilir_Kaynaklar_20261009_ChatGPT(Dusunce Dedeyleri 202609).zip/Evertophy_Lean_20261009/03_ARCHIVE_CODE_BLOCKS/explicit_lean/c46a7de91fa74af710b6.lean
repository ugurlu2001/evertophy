theorem plain_dimensionless_blocked : crossesPhaseGate .ordinaryDimensionless = false
