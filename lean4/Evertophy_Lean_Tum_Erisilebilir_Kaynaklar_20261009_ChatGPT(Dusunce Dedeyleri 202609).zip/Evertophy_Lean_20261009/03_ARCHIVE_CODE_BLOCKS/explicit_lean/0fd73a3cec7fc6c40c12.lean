theorem mul_len_junction_collapse :
    lenAfterMul [Gen.s, Gen.k0m] [Gen.k0m, Gen.s] = 3
