theorem chain_no_skip_fwd : adjacent .c0 .cp = false
