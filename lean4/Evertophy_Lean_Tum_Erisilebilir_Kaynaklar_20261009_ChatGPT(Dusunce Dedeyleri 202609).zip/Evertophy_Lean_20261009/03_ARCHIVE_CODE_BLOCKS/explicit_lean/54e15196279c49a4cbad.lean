theorem empty_native_locked_without_witness :
    GateLocked (fun _ => false) ∧ ∀ a : Phase, ((fun _ : Phase => false) a = true → False)
