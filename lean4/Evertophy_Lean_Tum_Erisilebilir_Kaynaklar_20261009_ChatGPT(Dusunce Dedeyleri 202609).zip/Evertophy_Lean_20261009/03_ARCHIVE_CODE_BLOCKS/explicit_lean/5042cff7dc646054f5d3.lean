theorem gate_lock_does_not_block_readout :
    TransportPermission .physTime .cp .Cm = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true
