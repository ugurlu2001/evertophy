theorem no_absorption_R : mulW [Gen.s] [Gen.k0m] ≠ [Gen.k0m]
