theorem B2_admissible : Admissible B2
