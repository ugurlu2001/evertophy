theorem K2_as_dimLabel : admissible .cp (.dimLabel Dim.mass) = true
