theorem len2_not_idem_k0s : mulW [Gen.k0m, Gen.s] [Gen.k0m, Gen.s] ≠ [Gen.k0m, Gen.s]
