theorem add_comm (A B : Ivl) : A.add B = B.add A
