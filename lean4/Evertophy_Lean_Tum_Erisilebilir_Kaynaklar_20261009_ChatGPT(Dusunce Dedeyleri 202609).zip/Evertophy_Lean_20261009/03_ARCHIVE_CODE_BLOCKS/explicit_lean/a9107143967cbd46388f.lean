theorem op_cp_none : hasDifferentialOp .cp = false
