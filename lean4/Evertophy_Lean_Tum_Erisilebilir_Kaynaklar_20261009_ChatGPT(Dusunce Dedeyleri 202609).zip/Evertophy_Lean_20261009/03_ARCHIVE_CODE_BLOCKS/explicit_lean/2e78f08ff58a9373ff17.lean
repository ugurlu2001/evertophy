theorem normalize_idem (w : Word) : normalize (normalize w) = normalize w
