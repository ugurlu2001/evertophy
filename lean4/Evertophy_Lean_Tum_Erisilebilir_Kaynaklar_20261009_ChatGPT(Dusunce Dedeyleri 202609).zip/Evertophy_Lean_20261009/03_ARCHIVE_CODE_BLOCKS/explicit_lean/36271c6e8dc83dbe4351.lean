theorem bridge_non_uniqueness :
    ∃ Ba Bb : Fin 3 → Nat, Ba ≠ Bb ∧ Admissible Ba ∧ Admissible Bb
