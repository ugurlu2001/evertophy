theorem omega_kappa_is_zero : Omega_char_kappa = Ivl.zero
