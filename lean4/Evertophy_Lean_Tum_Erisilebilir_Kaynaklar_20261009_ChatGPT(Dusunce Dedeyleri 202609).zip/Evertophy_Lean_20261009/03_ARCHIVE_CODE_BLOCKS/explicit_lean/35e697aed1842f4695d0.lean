theorem c0_no_time   : admissible .c0 .physTime = false
