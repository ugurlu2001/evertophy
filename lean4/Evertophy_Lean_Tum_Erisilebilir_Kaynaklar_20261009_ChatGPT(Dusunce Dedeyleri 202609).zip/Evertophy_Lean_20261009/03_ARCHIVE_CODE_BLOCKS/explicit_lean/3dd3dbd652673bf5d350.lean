theorem archive_faithful (A : Archive) (r : Record) :
    (append A r).length = A.length + 1
