theorem legacy_map_complete : legacyMap.length = 6
