theorem metric_only_Cm : MetricAdmissible .Cm ∧ ¬ MetricAdmissible .c0 ∧ ¬ MetricAdmissible .cp
