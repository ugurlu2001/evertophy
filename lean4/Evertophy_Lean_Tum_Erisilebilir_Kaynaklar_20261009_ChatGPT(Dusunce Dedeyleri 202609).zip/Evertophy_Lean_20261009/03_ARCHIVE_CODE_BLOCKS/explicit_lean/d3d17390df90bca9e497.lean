theorem K2prime_cp_mass : carriableV24 .cp Dim.mass = false
