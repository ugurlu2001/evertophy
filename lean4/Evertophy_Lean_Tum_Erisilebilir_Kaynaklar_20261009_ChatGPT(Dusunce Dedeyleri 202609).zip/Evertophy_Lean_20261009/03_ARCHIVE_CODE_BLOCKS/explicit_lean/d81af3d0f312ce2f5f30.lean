structure BridgeSpec (Ctx Out) where admissible; bridge; existsUnique
structure CmReadoutBridge (Ctx Out) extends BridgeSpec Ctx Out where
  isCm : Ctx → Bool
  cmTyped : ∀ c, isCm c = false → bridge c = none
