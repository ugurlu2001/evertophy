theorem empty_ne_zero_band : Band.inter ⟨0, 1, by decide⟩ ⟨2, 3, by decide⟩ = none ∧
    (Band.inter ⟨0, 0, by decide⟩ ⟨0, 0, by decide⟩).isSome = true
