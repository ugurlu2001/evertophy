theorem assoc_sample_3 :
    mulW (mulW [Gen.k0m, Gen.s] [Gen.s', Gen.kpm]) [Gen.kpm, Gen.s]
  = mulW [Gen.k0m, Gen.s] (mulW [Gen.s', Gen.kpm] [Gen.kpm, Gen.s])
