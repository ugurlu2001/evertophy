theorem ledger_names_unique : (ledger.map Prod.fst).Nodup
