theorem omega_dimensionless : Dim.div (MD 0) (Dim.mul (MD 2) (MD (-2))) = MD 0
