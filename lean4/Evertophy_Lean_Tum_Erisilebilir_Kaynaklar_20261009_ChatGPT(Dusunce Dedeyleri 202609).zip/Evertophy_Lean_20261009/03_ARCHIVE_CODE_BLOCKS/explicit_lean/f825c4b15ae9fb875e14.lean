theorem toy_midpoint_selector (B : Fin 3 → Nat) (_h0 : B 0 = 0) (h2 : B 2 = 2)
    (hadd : B 1 + B 1 = B 2) : B 1 = 1
