theorem len2_not_idem_ss : mulW [Gen.s, Gen.s] [Gen.s, Gen.s] ≠ [Gen.s, Gen.s]
