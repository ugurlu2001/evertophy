theorem still_zero : canonicalPredictions = 0
