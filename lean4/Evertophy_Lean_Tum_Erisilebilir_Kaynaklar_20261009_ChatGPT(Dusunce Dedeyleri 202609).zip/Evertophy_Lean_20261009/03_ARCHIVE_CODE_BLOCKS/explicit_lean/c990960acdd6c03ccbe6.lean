theorem triangle_full_c0cp : related .c0 .cp = true
