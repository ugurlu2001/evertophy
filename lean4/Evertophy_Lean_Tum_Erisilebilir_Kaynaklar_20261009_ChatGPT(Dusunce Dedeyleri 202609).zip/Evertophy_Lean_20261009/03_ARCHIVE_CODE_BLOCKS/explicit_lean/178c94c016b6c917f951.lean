theorem no_gate_U0_c0 : gate (.pole .U0) (.phase .c0) = false
