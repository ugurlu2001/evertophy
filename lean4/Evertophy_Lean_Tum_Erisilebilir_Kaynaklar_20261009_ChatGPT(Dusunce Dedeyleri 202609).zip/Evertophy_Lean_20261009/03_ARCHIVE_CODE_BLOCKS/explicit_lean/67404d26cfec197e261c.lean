theorem iom_width_blind : overlapWidth ⟨1,1⟩ ⟨0,2⟩ = 0 ∧ intersects ⟨1,1⟩ ⟨0,2⟩ = true
theorem point_inside_passes (p lo hi) (h1 : lo ≤ p) (h2 : p ≤ hi) : intersects ⟨p,p⟩ ⟨lo,hi⟩ = true
