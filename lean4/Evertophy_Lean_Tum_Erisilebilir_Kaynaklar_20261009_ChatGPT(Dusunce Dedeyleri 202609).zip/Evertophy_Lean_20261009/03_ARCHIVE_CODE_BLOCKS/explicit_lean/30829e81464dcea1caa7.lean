theorem K2_reconciled :
    admissible .cp (.dimLabel Dim.mass) = true ∧ admissible .cp .cmRestMass = false
