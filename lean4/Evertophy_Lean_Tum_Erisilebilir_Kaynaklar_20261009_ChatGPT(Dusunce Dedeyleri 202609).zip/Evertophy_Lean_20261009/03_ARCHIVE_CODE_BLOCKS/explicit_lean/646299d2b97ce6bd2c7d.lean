theorem step_idem : ∀ g : Gen, g.isKappa = true → ∀ Z : Word, step g (step g Z) = step g Z
