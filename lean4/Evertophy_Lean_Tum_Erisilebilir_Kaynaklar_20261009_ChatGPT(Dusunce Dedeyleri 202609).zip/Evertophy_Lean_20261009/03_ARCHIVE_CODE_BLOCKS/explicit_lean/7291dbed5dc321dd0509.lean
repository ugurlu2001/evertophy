theorem inter_sound {a b : Band} {x : Int} (ha : a.mem x) (hb : b.mem x) :
    ∃ c, a.inter b = some c ∧ c.mem x
