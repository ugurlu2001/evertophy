theorem N_archive_append_mono {α : Type} (log : List α) (r : α) :
    N_archive log ≤ N_archive (log ++ [r])
