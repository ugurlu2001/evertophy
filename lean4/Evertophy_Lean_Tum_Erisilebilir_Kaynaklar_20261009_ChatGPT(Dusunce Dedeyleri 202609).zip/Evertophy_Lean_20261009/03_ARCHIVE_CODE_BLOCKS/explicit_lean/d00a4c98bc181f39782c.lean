theorem gate_locked_iff_at_most_one (nat : Phase → Bool) :
    GateLocked nat ↔ AtMostOneNative nat
