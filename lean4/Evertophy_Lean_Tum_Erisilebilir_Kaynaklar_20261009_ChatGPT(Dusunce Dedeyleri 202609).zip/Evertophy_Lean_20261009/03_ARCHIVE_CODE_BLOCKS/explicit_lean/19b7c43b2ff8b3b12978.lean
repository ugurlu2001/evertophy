theorem idempotent_iff (w : Word) :
    mulW w w = w ↔ (w = [] ∨ w = [Gen.k0m] ∨ w = [Gen.kpm])
