theorem transport_is_gen (q : QuantityKind) (a b : Phase) :
    TransportPermission q a b = TransportGen (NativeOK q) a b
