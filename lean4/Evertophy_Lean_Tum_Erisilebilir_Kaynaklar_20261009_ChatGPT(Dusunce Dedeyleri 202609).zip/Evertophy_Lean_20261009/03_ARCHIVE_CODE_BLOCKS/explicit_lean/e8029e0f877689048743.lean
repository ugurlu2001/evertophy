theorem transition_chain_preserved :
    adjacent .c0 .cp = false ∧ adjacent .cp .c0 = false
