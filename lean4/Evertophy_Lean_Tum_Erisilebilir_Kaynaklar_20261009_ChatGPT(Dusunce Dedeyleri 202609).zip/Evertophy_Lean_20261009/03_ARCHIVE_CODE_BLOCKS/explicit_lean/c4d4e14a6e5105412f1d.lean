theorem add_assoc (A B C : Ivl) :
    (A.add B).add C = A.add (B.add C)
