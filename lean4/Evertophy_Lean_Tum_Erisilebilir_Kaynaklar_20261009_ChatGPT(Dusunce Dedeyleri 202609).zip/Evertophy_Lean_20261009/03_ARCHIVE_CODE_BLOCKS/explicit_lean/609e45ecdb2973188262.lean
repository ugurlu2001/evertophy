theorem s'_not_idempotent : mulW [Gen.s'] [Gen.s'] ≠ [Gen.s']
