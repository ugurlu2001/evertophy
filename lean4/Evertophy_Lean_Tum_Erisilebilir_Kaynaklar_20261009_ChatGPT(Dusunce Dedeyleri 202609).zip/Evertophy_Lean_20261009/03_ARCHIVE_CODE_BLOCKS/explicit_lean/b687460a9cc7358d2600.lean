theorem N_archive_strict {α : Type} (log : List α) (r : α) :
    N_archive (log ++ [r]) = N_archive log + 1
