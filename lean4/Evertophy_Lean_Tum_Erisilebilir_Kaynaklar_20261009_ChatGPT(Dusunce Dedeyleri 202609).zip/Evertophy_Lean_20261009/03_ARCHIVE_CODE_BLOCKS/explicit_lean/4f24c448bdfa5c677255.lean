theorem quantum_threshold_mismatch : arcD ≠ hbarD
