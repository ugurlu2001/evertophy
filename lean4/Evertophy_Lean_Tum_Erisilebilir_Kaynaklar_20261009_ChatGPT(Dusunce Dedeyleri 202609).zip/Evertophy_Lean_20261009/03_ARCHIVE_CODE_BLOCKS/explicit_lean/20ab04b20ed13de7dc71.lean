theorem norm_nil : normalize [] = []
