theorem c_boundary_only_Cm   : cellOf .Cm .cBoundary = .defined ∧
    cellOf .c0 .cBoundary ≠ .defined ∧ cellOf .cp .cBoundary ≠ .defined
