theorem mulW_assoc (a b c : Word) : mulW (mulW a b) c = mulW a (mulW b c)
