theorem cp_source_Cm_readout_present {α : Type} (a : α) :
    ∃ v, readoutAtCm a ⟨.cp⟩ = CmOnlyValue.presentCm v
