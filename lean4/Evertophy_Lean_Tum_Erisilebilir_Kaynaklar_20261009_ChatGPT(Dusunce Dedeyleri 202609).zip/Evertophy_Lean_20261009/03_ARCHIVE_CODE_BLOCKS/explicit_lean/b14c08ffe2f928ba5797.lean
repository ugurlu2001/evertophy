theorem source_is_not_native_license :
    (⟨.cp, .Cm⟩ : Event).source = .cp ∧ NativeOK .physTime .cp = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true
