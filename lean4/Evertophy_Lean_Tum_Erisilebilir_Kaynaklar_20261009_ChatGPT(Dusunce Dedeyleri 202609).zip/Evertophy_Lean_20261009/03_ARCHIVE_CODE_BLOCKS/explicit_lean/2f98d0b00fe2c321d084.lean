import Core.GateLockChar
