theorem x_meta_crosses_all_gates : ∀ a b, GateRelated a b = true → MetaCrossPermission a b = true
