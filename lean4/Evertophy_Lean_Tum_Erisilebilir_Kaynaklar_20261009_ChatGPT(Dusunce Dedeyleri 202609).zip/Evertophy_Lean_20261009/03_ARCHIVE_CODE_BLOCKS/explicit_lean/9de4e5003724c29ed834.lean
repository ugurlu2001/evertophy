theorem state_can     : canProduceKutu4 .state  = true
