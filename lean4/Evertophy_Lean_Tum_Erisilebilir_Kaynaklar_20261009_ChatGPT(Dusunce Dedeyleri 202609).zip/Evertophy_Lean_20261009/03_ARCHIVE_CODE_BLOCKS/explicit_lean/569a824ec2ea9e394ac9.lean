theorem bridge_silent_outside {S R : Type} (B : BridgeSpec S R) (s : S)
    (h : B.phaseOf s = .c0) : B.bridge s = none
