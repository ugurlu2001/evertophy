theorem registry_size : debtRegistry.length = 14
