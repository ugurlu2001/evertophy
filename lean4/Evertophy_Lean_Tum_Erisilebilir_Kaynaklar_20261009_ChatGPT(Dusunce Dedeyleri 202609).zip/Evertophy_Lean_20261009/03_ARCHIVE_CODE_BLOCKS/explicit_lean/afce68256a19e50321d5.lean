theorem normalize_eq_foldr : ∀ w : Word, normalize w = List.foldr step [] w
  | [] => rfl
  | g :: w => by rw [normalize_cons, normalize_eq_foldr w]; rfl

/-- κ eylemi idempotenttir. -/
theorem step_idem : ∀ g : Gen, g.isKappa = true → ∀ Z : Word, step g (step g Z) = step g Z
