theorem no_torsion_gate : mulW [Gen.s, Gen.s, Gen.s, Gen.s] [] ≠ [Gen.k0m]
