theorem EF_term1 : Dim.div (MD 0) (MD 0) = MD 0
