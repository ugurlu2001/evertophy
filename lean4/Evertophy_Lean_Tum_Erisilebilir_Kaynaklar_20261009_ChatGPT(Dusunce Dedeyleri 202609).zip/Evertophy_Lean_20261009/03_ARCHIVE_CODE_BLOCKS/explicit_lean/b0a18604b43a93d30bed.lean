theorem count_retired      : countBy .retired      = 1
