theorem K2_cp_time : carriable .cp Dim.time = false
