theorem circle_morse : chi1 3 3 = 0
