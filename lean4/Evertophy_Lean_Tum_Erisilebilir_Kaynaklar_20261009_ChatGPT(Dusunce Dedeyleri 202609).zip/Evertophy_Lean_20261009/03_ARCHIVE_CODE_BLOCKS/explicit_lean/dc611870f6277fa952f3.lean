theorem Cm_lemma_corr : Dim.mul (MD (-2)) (MD 4) = MD 2
