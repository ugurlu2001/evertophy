theorem transferred_not_resolved : transferredCount = 2
