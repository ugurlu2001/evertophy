theorem invariant_everywhere : ∀ p : Phase, argAvailable p .invariantRatio = true
