theorem mul_len_lower_bound_k0 :
    lenAfterMul [Gen.k0m, Gen.s] [Gen.k0m, Gen.s] = 4
