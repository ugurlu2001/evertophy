theorem chain_ok_high : adjacent .Cm .cp = true
