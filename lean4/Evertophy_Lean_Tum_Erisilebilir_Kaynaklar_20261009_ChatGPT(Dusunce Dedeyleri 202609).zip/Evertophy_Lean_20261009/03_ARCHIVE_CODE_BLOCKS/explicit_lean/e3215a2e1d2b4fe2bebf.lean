theorem norm_produces_normal_k0 : isNormal (normalize [Gen.k0m, Gen.k0m]) = true
