theorem dt_dimensional : Dim.mul (Dim.mul Dim.time Dim.freq) Dim.time = Dim.time
