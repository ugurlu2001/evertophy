theorem pair_has_witness_but_not_locked :
    ¬ GateLocked (natPair .c0 .Cm)
