theorem Cm_is_present {α : Type} (v : CmOnlyValue α .Cm) : ∃ a, v = .presentCm a
