theorem meta_cross_not_physical_transport :
    MetaCrossPermission .c0 .cp = true ∧ TransportPermission .physTime .c0 .cp = false
