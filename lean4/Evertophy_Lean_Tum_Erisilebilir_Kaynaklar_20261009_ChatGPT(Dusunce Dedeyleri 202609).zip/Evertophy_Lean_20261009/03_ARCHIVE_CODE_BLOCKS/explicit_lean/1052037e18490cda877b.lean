theorem triangle_complete :
    related .c0 .cp = true ∧ related .Cm .cp = true ∧ related .c0 .Cm = true
