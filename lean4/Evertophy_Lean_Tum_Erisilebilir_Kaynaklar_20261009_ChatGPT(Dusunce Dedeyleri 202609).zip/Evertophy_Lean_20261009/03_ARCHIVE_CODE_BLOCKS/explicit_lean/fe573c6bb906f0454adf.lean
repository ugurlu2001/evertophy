theorem foldr_step_comm (acc : Word) (g : Gen) : ∀ n : Word,
    List.foldr step acc (step g n) = step g (List.foldr step acc n)
  | [] => rfl
  | h :: t => by
    rw [step_cons]
    by_cases hc : (g.isKappa && g == h) = true
    · rw [if_pos hc]
      show step h (List.foldr step acc t) = step g (step h (List.foldr step acc t))
      cases g <;> cases h <;> simp (config
