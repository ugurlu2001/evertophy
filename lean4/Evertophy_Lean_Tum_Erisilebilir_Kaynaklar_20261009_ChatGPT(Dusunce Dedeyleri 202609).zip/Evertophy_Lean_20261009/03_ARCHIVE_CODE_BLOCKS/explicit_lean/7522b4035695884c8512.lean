theorem kappap_idempotent : mulW [Gen.kpm] [Gen.kpm] = [Gen.kpm]
