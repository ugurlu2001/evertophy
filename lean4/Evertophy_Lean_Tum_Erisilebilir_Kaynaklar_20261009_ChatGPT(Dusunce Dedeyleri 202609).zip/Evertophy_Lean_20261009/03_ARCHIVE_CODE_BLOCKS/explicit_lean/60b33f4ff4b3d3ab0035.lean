theorem Up_not_phase : isPhase (.pole .Up) = false
