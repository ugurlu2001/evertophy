theorem norm_k0_idem : normalize [Gen.k0m, Gen.k0m] = [Gen.k0m]
