theorem EF_term2 : Dim.mul (MD 2) (Dim.mul (MD (-1)) (MD (-1))) = MD 0
