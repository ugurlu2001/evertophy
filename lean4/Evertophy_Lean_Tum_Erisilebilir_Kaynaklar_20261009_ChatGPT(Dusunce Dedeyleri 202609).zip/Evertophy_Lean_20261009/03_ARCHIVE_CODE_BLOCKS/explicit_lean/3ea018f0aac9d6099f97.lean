theorem time_lives_in_Cm : carriable .Cm Dim.time = true
