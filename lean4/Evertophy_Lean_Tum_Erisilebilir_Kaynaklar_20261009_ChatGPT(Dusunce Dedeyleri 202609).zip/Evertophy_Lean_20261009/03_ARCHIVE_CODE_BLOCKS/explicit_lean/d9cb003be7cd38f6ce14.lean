theorem s_not_idempotent : mulW [Gen.s] [Gen.s] ≠ [Gen.s]
