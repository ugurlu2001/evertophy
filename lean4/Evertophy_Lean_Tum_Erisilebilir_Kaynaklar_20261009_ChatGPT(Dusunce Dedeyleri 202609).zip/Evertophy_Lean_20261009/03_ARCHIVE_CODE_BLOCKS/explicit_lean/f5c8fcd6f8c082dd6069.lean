theorem c0_preadmissible : cmTimeValue .c0 = .absent .PreAdmissible
