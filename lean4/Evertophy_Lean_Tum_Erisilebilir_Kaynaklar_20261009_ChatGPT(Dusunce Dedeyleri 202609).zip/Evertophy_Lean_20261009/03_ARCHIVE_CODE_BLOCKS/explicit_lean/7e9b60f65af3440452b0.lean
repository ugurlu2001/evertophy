theorem two_absences_distinct : cellOf .c0 .physTime ≠ cellOf .cp .physTime
