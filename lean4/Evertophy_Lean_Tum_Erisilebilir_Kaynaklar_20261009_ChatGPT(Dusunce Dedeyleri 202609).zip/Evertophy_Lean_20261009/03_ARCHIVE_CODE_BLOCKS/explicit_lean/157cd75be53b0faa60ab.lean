theorem degenerate_rejected : validReadout ⟨false, true⟩ = false
