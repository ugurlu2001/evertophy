theorem posInf_is_present : ∃ v, unboundedCm = .presentCm v
