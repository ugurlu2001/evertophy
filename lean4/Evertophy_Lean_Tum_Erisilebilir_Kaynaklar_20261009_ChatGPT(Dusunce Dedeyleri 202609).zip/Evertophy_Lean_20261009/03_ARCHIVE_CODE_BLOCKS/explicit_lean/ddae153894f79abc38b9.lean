theorem legacy_GlobalPole_superseded :
    (V24.GlobalPole.Ux = V24.GlobalPole.Ux) ∧ isPole .Ux = false
