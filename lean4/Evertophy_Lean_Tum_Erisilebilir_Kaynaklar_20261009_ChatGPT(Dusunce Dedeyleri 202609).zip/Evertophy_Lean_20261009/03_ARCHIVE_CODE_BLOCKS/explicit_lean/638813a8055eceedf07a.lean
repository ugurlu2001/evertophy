theorem omega_kpm_zero (Ω : OmegaHom) : Ω.map [Gen.kpm] = Ivl.zero
