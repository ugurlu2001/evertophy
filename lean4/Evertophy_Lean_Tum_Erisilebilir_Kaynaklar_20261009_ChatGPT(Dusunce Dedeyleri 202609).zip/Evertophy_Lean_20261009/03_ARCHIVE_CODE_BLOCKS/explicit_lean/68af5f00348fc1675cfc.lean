theorem star_to_normalize : ∀ w : Word, Star w (normalize w)
  | [] => Star.refl _
  | g :: w => by
    have h1 : Star (g :: w) (g :: normalize w)
