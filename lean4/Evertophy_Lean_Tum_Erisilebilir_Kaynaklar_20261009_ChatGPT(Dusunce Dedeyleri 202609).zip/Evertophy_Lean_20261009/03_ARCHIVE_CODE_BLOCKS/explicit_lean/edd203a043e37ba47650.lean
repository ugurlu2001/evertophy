theorem K2prime_Cm_mass : carriableV24 .Cm Dim.mass = true
