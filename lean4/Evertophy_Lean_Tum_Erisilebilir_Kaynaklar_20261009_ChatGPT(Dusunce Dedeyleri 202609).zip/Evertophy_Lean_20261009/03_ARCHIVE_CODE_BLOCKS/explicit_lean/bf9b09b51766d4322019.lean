theorem cp_is_dissolved {α : Type} (v : CmOnlyValue α .cp) : v = .dissolvedPlus
