theorem exactly_two_onto_absences :
    ∀ a : OntoAbsence, a = .preAdmissible ∨ a = .dissolved
