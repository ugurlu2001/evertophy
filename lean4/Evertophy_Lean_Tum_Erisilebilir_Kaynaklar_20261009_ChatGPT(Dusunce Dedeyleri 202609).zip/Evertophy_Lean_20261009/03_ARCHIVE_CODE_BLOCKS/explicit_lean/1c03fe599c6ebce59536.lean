theorem strict_discrete_unique (B : Fin 3 → Nat) (h : StrictAdmissible B) : B 1 = 1
