theorem trace_uses_eventkind :
    TP2.policy .dissolution .cp ≠ TP2.policy .sealing .cp
