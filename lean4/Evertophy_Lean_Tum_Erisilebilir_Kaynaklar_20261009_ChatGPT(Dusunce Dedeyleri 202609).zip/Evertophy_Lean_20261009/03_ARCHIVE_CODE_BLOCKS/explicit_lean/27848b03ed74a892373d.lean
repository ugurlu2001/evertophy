theorem poles_are_U0_Uplus : isPole .U0 = true ∧ isPole .Uplus = true
