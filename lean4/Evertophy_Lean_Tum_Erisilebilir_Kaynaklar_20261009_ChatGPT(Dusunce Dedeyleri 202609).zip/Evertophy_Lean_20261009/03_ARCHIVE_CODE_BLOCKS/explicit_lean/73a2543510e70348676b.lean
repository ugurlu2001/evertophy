theorem sigma_T0p_is_identity : stampOf .c0 .cp = none
