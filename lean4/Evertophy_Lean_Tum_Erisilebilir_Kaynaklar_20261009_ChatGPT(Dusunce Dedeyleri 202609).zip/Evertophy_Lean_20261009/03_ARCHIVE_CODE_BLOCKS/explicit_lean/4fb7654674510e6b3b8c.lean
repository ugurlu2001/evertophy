theorem mul_sound {a b : Band} {x y : Int} (hx : a.mem x) (hy : b.mem y) :
    cmin a b ≤ x*y ∧ x*y ≤ cmax a b
