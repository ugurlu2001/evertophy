theorem circle_is_K3  : adjCircle 0 1 = true ∧ adjCircle 1 2 = true ∧ adjCircle 0 2 = true
