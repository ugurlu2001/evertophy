theorem crossable_implies_not_dimensioned :
    crossesPhaseGate CarrierKind.dimensioned = false
