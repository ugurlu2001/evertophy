theorem B2_not_additive : ¬ Additive B2
