theorem c0_time_undefined    : cellOf .c0 .physTime  = .absent .undefined0
