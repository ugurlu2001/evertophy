theorem gate_irrefl : ∀ a, GateRelated a a = false
