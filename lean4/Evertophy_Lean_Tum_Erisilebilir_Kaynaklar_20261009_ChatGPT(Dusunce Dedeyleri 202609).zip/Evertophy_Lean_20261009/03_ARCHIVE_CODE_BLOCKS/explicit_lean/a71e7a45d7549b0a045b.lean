theorem density_undefined_cp   : argAvailable .cp .density   = false
