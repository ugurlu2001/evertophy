theorem op_c0_none : hasDifferentialOp .c0 = false
