theorem cp_time_dissolved    : cellOf .cp .physTime  = .absent .dissolvedPlus
