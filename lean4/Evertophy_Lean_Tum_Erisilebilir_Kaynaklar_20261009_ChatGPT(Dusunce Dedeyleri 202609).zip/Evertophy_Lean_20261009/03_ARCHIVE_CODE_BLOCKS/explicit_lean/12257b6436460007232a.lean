theorem Cm_time_defined      : cellOf .Cm .physTime  = .defined
