theorem sealRec_does_not_collapse :
    (sealRec 1 (Ivl.mk 0 5) Gen.k0m).payload ≠ Ivl.zero
