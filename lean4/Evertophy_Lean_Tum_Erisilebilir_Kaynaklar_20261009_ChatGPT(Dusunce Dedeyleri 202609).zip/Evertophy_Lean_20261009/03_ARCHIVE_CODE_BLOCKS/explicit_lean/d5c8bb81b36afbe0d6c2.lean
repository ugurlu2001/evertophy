theorem never_native_locked (nat : Phase → Bool) (h : ∀ x, nat x = false) :
    ∀ a b, TransportGen nat a b = false
