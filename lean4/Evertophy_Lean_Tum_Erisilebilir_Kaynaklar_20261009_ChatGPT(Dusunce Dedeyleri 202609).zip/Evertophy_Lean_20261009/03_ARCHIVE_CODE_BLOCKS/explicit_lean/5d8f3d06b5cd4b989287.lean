theorem all_native_crosses (nat : Phase → Bool) (h : ∀ x, nat x = true) :
    ∀ a b, TransportGen nat a b = GateRelated a b
