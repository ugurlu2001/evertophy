theorem c0_euclid_undefined  : cellOf .c0 .euclid3D  = .absent .undefined0
