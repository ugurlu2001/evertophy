theorem singleton_in_exampleBand : Intersects (⟨1, 1, by decide⟩ : Band Int) exampleBand
