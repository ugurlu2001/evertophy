theorem cm_only_gate_locked : ∀ (q : QuantityKind) (a b : Phase),
    CmOnlyKind q = true → TransportPermission q a b = false
