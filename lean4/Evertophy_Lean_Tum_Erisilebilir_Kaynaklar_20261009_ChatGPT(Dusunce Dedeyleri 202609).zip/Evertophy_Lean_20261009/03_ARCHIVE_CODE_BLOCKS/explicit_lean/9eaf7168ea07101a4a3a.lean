theorem iom_width_blind :
    overlapWidth ⟨1,1⟩ ⟨0,2⟩ = 0 ∧ intersects ⟨1,1⟩ ⟨0,2⟩ = true
