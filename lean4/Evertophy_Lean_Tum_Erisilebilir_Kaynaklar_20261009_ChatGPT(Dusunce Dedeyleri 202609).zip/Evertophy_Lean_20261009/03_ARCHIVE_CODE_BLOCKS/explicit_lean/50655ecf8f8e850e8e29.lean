theorem Band.mul_sound {a b : Band} {x y : Int} (hx : a.mem x) (hy : b.mem y) : (a.mul b).mem (x*y)
