theorem metric_only_Cm : MetricAdmissible .Cm = true ∧ MetricAdmissible .c0 = false ∧ MetricAdmissible .cp = false
