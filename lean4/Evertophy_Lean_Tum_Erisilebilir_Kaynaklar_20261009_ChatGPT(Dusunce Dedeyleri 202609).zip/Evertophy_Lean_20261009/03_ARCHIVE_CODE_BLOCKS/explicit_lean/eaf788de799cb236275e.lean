theorem idempotent_forces_zero (K : Ivl) (h : K.add K = K) : K = Ivl.zero
