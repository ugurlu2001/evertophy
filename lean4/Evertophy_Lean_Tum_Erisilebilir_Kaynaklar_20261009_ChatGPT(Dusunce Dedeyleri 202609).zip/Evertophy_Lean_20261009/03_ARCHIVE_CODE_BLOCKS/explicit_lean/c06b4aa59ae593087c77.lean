theorem posInf_is_present : ∃ b, qslUnbounded = .presentCm b
