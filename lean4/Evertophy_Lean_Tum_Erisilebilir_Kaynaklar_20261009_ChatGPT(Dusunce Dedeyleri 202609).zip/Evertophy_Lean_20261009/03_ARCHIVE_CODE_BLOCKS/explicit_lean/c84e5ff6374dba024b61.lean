theorem K1_c0_len  : carriable .c0 Dim.len  = false
