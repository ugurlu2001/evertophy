theorem tri_edge_no_mass            : crossable_c0_cp Dim.mass = false
