theorem x_crosses_every_gate : ∀ a b, GateRelated a b = true → TransportPermission .xCoord a b = true
