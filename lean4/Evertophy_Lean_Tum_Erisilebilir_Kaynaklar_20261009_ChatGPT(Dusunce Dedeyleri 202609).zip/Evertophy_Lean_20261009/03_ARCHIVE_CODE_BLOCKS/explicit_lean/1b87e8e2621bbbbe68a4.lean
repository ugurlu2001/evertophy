theorem point_inside_passes (p lo hi : Int) (h1 : lo ≤ p) (h2 : p ≤ hi) :
    intersects ⟨p,p⟩ ⟨lo,hi⟩ = true
