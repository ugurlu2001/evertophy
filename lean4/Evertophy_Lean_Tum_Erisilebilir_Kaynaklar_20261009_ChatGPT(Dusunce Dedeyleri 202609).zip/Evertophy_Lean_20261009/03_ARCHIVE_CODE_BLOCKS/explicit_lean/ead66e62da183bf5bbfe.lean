structure Event where source : Phase; observed : Phase
theorem cp_sourced_Cm_readable : CmReadoutDefined ⟨.cp, .Cm⟩ = true
theorem source_is_not_native_license : ... NativeOK .physTime .cp = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true
