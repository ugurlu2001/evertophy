theorem piStamp_collapses_repeats :
    piStamp [⟨1, Ivl.mk 0 2, Gen.k0m, true⟩, ⟨2, Ivl.mk 0 3, Gen.k0m, true⟩] = [Gen.k0m]
