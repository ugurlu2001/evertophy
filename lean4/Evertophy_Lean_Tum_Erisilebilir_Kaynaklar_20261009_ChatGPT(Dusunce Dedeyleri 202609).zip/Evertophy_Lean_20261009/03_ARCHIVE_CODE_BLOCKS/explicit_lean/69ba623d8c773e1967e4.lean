theorem add_sound {a b : Band} {x y : Int} (hx : a.mem x) (hy : b.mem y) : (a.add b).mem (x + y)
