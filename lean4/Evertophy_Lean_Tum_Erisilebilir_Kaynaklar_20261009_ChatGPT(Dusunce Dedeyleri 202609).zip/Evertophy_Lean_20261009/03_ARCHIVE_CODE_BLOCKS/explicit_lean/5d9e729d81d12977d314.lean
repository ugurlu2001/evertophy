theorem count_transferred  : countBy .transferred  = 2
