theorem Up_ne_cp : (Entity.pole .Up) ≠ (Entity.phase .cp)
