theorem A_does_not_entail_uniqueness :
    ¬ (∀ Ba Bb : Fin 3 → Nat, Admissible Ba → Admissible Bb → Ba = Bb)
