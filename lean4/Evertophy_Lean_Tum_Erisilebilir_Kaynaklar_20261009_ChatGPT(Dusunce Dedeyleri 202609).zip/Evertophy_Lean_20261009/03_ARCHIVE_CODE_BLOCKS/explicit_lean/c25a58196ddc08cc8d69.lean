theorem cp_dissolved {α : Type} (v : CmOnlyValue α .cp) : v = .dissolvedPlus
