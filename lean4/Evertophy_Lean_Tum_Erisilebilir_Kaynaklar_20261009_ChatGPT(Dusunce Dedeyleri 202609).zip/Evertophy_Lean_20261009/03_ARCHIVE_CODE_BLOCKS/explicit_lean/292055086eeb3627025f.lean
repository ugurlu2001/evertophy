theorem step_cons (g h : Gen) (t : Word) :
    step g (h :: t) = if (g.isKappa && g == h) = true then h :: t else g :: h :: t
