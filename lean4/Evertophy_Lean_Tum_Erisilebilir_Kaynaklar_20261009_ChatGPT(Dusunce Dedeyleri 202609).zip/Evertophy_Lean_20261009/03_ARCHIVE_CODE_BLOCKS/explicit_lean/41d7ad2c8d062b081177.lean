theorem X_universal_cp : carriable .cp Dim.one = true
