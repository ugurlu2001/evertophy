theorem arc_dimensionless : arcD = Dim.one
