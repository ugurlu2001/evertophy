theorem sigma_Tp0_is_identity : stampOf .cp .c0 = none
