theorem mul_len_lower_bound_sk :
    lenAfterMul [Gen.s, Gen.k0m] [Gen.s, Gen.k0m] = 4
