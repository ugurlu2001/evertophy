theorem B1_ne_B2 : B1 ≠ B2
