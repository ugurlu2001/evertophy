theorem archive_not_idempotent (A : Archive) (r : Record) :
    (append (append A r) r).length ≠ (append A r).length
