theorem four_global_directions :
    arrowEnds .genesis = (.U0,.Ux) ∧ arrowEnds .collapseLimit = (.Ux,.U0) ∧
    arrowEnds .dissolutionLimit = (.Ux,.Up) ∧ arrowEnds .reformation = (.Up,.Ux)
