theorem Cm_lemma_main : Dim.div (MD 2) (Dim.mul (MD 0) (MD 0)) = MD 2
