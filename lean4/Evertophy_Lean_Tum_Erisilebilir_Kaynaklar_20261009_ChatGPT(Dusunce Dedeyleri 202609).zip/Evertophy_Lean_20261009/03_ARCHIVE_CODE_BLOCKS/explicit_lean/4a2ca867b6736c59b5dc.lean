theorem F_dimensionless_ok : Dim.div (MD 0) (MD 0) = MD 0
