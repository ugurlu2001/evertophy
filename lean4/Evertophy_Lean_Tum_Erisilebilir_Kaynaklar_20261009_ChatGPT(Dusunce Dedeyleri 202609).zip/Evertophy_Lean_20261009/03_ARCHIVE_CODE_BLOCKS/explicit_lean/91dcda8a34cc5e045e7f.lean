theorem unit_left  (a : Word) : mulW [] a = normalize a
