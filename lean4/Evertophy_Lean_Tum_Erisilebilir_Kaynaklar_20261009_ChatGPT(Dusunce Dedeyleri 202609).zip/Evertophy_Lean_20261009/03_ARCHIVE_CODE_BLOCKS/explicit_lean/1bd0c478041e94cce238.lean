theorem Cm_has_physical_time : temporalRole .Cm = .physicalTime
