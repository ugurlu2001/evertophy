theorem disjoint_rejected : intersects ⟨0,1⟩ ⟨2,3⟩ = false
