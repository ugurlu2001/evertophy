theorem cp_sourced_Cm_readable : CmReadoutDefined ⟨.cp, .Cm⟩ = true
