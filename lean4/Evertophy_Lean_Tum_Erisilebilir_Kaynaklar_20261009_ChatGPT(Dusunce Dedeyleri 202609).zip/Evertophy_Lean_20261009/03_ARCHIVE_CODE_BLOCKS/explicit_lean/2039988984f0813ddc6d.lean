theorem omega_kappa_forced (Ω : OmegaHom) (k : Gen) (hidem : mulW [k] [k] = [k]) :
    Ω.map [k] = Ivl.zero
