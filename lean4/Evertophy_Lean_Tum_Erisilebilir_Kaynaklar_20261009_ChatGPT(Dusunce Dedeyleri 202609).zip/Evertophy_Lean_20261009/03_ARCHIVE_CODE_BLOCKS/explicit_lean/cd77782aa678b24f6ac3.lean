theorem dt_normalized : Dim.mul (Dim.mul (Dim.mul Dim.time Dim.one) Dim.freq) Dim.time = Dim.time
