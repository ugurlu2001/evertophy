theorem char_zero_does_not_kill_lock (Ω : OmegaHom) (L : LockEffect)
    (h : lockIsNontrivial L) : Ω.map [Gen.k0m] = Ivl.zero ∧ lockIsNontrivial L
