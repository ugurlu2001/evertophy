theorem gate_symmetric_2 : gateRelated .Cm .cp = gateRelated .cp .Cm
