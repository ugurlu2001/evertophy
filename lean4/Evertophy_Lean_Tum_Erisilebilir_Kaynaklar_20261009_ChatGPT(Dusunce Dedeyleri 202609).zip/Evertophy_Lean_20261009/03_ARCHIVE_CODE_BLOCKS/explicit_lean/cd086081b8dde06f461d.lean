theorem single_native_locked (nat : Phase → Bool) (p : Phase) (h : ∀ x, nat x = true → x = p) :
    ∀ a b, TransportGen nat a b = false
