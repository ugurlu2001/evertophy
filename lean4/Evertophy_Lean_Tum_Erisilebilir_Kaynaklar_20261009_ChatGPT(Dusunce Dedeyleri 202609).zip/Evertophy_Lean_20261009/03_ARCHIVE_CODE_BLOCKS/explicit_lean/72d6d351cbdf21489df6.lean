theorem pair_transport_c0_Cm :
    TransportGen (natPair .c0 .Cm) .c0 .Cm = true ∧ TransportGen (natPair .c0 .Cm) .c0 .cp = false ∧
    TransportGen (natPair .c0 .Cm) .Cm .cp = false
