theorem op_Cm_yes  : hasDifferentialOp .Cm = true
