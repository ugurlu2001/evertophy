theorem twoD_triangle  : adj2D 0 1 = true ∧ adj2D 1 2 = true ∧ adj2D 0 2 = true
