theorem reasons_preserved {C O : Type} (B : CmReadoutBridgeR C O) (c : C) :
    B.bridge .c0 c = .undefined0 ∧ B.bridge .cp c = .dissolvedPlus
