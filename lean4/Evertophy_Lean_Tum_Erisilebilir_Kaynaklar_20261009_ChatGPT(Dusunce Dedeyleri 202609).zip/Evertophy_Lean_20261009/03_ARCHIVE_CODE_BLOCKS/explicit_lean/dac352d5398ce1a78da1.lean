theorem q_inverse_is_reverse : ∀ a b : Ph, qBare a b = qBare b a
