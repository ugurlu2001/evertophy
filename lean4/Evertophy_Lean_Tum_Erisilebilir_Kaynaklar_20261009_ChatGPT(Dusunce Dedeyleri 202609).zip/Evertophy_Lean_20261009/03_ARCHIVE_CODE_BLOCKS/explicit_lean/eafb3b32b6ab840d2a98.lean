theorem add_zero (A : Ivl) : A.add Ivl.zero = A
