theorem K1_c0_time : carriable .c0 Dim.time = false
