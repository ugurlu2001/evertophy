theorem count_resolved     : countBy .resolved     = 3
