theorem legacy_K2_scoped :
    carriable .cp Dim.mass = true ∧ admissible .cp .cmRestMass = false
