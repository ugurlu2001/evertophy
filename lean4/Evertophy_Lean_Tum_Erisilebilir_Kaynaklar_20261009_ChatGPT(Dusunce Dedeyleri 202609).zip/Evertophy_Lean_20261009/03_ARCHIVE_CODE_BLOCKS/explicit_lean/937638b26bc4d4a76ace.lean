theorem Ux_not_pole : isPole .Ux = false
