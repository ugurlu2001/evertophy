theorem star_cons_lift (g : Gen) {a b : Word} (h : Star a b) : Star (g :: a) (g :: b)
