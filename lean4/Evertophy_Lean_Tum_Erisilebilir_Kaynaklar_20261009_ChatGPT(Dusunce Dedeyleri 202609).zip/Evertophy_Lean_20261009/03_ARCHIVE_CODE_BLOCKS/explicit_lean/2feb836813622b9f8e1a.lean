theorem assoc_sample_2 :
    mulW (mulW [Gen.k0m] [Gen.k0m]) [Gen.k0m] = mulW [Gen.k0m] (mulW [Gen.k0m] [Gen.k0m])
