theorem resolve_is_admissible
  (S : State) :
  ResolveX S ∈ Syntax S
