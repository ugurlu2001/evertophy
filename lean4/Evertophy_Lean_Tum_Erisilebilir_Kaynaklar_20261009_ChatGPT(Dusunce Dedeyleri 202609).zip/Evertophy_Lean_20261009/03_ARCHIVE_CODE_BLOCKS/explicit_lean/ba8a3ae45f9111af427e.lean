theorem absence_ne_noEvent (a : Absence) : CellV.absent a ≠ CellV.noEvent
