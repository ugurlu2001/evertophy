theorem missing_data_not_absence :
    ontoAbsenceOf .Cm = none ∧ EpistemicStatus.missingData ≠ EpistemicStatus.observed
