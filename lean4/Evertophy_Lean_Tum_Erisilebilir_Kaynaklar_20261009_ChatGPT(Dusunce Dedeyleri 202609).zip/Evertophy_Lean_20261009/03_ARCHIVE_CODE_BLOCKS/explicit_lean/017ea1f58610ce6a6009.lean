theorem oneD_neighbours: adj1D 0 1 = true ∧ adj1D 1 2 = true
