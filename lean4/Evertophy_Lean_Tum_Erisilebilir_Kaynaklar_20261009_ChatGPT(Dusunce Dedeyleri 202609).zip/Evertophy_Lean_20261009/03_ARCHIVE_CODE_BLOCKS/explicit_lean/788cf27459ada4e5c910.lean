theorem len2_not_idem_sk0 : mulW [Gen.s, Gen.k0m] [Gen.s, Gen.k0m] ≠ [Gen.s, Gen.k0m]
