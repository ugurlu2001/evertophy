theorem kappa0_idempotent : mulW [Gen.k0m] [Gen.k0m] = [Gen.k0m]
