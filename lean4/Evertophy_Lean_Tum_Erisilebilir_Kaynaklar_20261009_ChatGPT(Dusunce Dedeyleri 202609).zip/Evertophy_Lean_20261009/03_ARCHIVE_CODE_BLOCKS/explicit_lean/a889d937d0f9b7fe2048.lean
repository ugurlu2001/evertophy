theorem K1_c0_one  : carriable .c0 Dim.one  = true
