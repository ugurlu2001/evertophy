theorem point_in_band_intersects {α : Type} [LE α] (p : α) (hp : p ≤ p) (b : Band α)
    (h1 : b.lo ≤ p) (h2 : p ≤ b.hi) : Intersects ⟨p, p, hp⟩ b
