theorem cp_euclid_dissolved  : cellOf .cp .euclid3D  = .absent .dissolvedPlus
