theorem iom_zero_over_zero : unionWidth ⟨1,1⟩ ⟨1,1⟩ = 0
