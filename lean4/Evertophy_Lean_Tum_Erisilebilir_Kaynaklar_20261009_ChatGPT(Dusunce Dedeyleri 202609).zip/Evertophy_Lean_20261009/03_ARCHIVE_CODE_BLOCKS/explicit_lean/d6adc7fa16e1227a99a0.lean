theorem cp_no_speed  : admissible .cp .intrinsicSpeed = false
