theorem X_universal_c0 : carriable .c0 Dim.one = true
