theorem curvature_undefined_c0 : argAvailable .c0 .curvature = false
theorem density_undefined_cp   : argAvailable .cp .density   = false
theorem variable_arity_consistent : ∀ p, (argsOf p).all (argAvailable p) = true
