theorem triangle_symmetric : ∀ a b : Ph, related a b = related b a
