theorem star_trans {a b c : Word} (h1 : Star a b) (h2 : Star b c) : Star a c
