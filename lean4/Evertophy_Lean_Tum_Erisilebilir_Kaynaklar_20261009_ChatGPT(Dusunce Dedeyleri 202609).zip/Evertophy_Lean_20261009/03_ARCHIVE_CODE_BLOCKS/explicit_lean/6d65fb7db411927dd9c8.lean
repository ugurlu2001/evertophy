theorem line_not_K3   : adjLine 0 2 = false
