theorem step_preserves_normalize {a b : Word} (h : Step a b) : normalize a = normalize b
