theorem A0_dimensionless : Dim.mul (MD 1) (MD (-1)) = MD 0
