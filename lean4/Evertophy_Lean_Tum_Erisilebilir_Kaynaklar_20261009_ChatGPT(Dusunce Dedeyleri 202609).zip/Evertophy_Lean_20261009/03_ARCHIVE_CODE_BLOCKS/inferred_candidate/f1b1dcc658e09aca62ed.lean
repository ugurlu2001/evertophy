-- Objects
inductive Phase | c0 | Cm | cp
inductive GlobalNode | U0 | Ux | Up   -- Ux dynamic, not Pole
inductive Absence | undefined0 | dissolvedPlus
inductive PhaseValue (α) | present (Band α) | absent Absence | noEvent

-- Morphisms
def Gate : Phase → Phase → Prop          -- typed relation, dimension-independent
def GlobalRel : GlobalNode → GlobalNode → Prop

-- Resolver (staged, non-scalar)
structure ValidContext ...
def ResolveX : ValidContext → Σ φ : Phase, ResolvedState φ
def π_k : ResolvedState φ → Band ℝ        -- scalar projections only

-- Phase license (Cm-only)
def cellOf : Phase → CmStructure → PhaseValue α
  | .Cm, _ => present ...
  | .c0, _ => absent .undefined0
  | .cp, _ => absent .dissolvedPlus

-- BridgeSpec (phase-safe by construction)
structure BridgeSpec (State Readout) where
  phaseOf : State → Phase
  bridge  : State → Option Readout
  phaseSafe : ∀ s, phaseOf s ≠ .Cm → bridge s = none
