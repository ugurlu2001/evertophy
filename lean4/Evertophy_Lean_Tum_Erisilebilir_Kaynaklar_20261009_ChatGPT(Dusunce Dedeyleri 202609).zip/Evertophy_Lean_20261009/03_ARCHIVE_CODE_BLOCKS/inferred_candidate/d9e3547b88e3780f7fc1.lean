-- Objects
inductive Phase | c0 | Cm | cp
inductive AbsenceReason | UndefinedC0 | DissolvedCp | NotApplicable | MissingData
inductive PhaseValue (α) | present (Band α) | absent AbsenceReason

-- Morphisms (ordinary category)
def Gate : Phase → Phase → Prop          -- typed relation, K3 possible
def GlobalRel : GlobalNode → GlobalNode → Prop

-- Phase-indexed value (dependent)
def cellOf (Q : CmStructure) : Phase → PhaseValue α
  | .Cm => present (Band ...)
  | .c0 => absent .UndefinedC0
  | .cp => absent .DissolvedCp

-- Why not the same bottom?
-- There is no isomorphism / natural isomorphism that identifies
--   absent UndefinedC0   ≃   absent DissolvedCp
-- because the constructors are distinct and the phase-license table
-- treats them differently (archive TracePolicy may attach only to
-- DissolvedCp by separate axiom, never by constructor equality).
-- In the path-groupoid of Gate, paths that would “identify” the two
-- absences do not exist; they live in different fibres of the
-- fibration PhaseValue → Phase.
