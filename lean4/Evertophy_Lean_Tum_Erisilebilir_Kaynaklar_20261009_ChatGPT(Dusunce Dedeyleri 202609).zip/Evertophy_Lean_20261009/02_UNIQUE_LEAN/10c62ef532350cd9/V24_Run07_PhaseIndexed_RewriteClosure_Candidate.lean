/-!
RUN-07 candidate patch.
UNCOMPILED in this sandbox.
Hedef:
  1) Present'i yalnız Cm fazına kilitlemek.
  2) Band payload'ını doğrudan taşımak.
  3) Rewrite CR için eksik lemma hedeflerini sabitlemek.
-/

universe u
namespace V24Run07

inductive Phase | c0 | Cm | cp
  deriving DecidableEq, Repr

structure Band (α : Type u) [LE α] where
  lo : α
  hi : α
  valid : lo ≤ hi

inductive CmOnlyValue (α : Type u) : Phase → Type u
  | undefined0    : CmOnlyValue α .c0
  | presentCm     : α → CmOnlyValue α .Cm
  | dissolvedPlus : CmOnlyValue α .cp

abbrev CmOnlyBand (α : Type u) [LE α] (p : Phase) :=
  CmOnlyValue (Band α) p

/-!
Rewrite_Tur6 için Tur08 görevleri:

theorem normalize_reachable (w : Word) :
  Star w (normalize w) := ...

theorem normalize_is_irred (w : Word) :
  Irred (normalize w) := ...

theorem confluence {w a b : Word}
    (ha : Star w a) (hb : Star w b) :
    ∃ c, Star a c ∧ Star b c := ...

theorem idempotent_iff (w : Word) :
    mulW w w = w ↔
      w = [] ∨ w = [Gen.kappa0m] ∨ w = [Gen.kappaPlusm] := ...
-/

end V24Run07
