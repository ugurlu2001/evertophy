/-!
RUN-06 candidate — phase-indexed absence + Range payload + bridge separation.
UNCOMPILED in this sandbox.
-/

universe u

namespace V24Run06

inductive Phase
  | c0 | Cm | cp
  deriving DecidableEq, Repr

structure Band (α : Type u) [LE α] where
  lo : α
  hi : α
  valid : lo ≤ hi

inductive CmOnlyValue (α : Type u) : Phase → Type u
  | undefined0    : CmOnlyValue α .c0
  | presentCm     : α → CmOnlyValue α .Cm
  | dissolvedPlus : CmOnlyValue α .cp

abbrev CmOnlyBand (α : Type u) [LE α] (p : Phase) :=
  CmOnlyValue (Band α) p

inductive TraceStatus
  | noTrace
  | retained
  deriving DecidableEq, Repr

structure TracePolicy (EventKind : Type u) where
  status : EventKind → Phase → TraceStatus

structure CmReadoutBridgeSpec (CmState Readout : Type u) where
  bridge : CmState → Readout

inductive GlobalPole
  | U0 | Up
  deriving DecidableEq, Repr

inductive GlobalNode
  | pole (p : GlobalPole)
  | Ux
  deriving DecidableEq, Repr

end V24Run06
