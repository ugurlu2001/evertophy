/-!
RUN-05 candidate — PHASE PRESENCE / RANGE TYPE
UNCOMPILED IN THIS SANDBOX.
Amaç: c0 "undefined" ile c+ "dissolved" yokluk nedenlerini ayırmak.
-/

universe u

namespace V24Run05

inductive Phase
  | c0 | Cm | cp
  deriving DecidableEq, Repr

structure Band (α : Type u) [LE α] where
  lo : α
  hi : α
  valid : lo ≤ hi

/-- Cm-only bir yapının üç fazdaki neden-damgalı durumu.
    Nümerik yokluk [0,0] ile temsil EDİLMEZ. -/
inductive PhasePresence (α : Type u) : Phase → Type u
  | undefinedC0 : PhasePresence α .c0
  | presentCm   : α → PhasePresence α .Cm
  | dissolvedCp : PhasePresence α .cp

/-- Sayısal fizik niceliği için faz-değer tipi. -/
abbrev PhaseBand (α : Type u) [LE α] (p : Phase) :=
  PhasePresence (Band α) p

/-- Sebep bilgisini istemeyen dış katman için forgetful projection.
    Core semantik bunu kullanarak c0/c+ nedenlerini EŞİTLEMEMELİ. -/
def PhasePresence.toOption {α : Type u} {p : Phase} :
    PhasePresence α p → Option α
  | .undefinedC0 => none
  | .presentCm x => some x
  | .dissolvedCp => none

inductive CmPrimitive
  | physicalTime
  | physical3Space
  | euclideanFlat3
  | causalLimitC
  | intrinsicSpeed
  | cmMetric
  deriving DecidableEq, Repr

/-
Önerilen sonraki teoremler (Lean-capable bacağa görev):

1. PhysicalTime:
   c0 -> undefinedC0
   Cm -> presentCm Band
   cp -> dissolvedCp.

2. Aynısı causalLimitC / intrinsicSpeed / cmMetric / euclideanFlat3.

3. GlobalPole = U0 | Up;
   GlobalNode = U0 | Ux | Up.

4. `presentCm` constructor'ı type gereği c0/cp için kurulamasın.

5. Band invalid `lo > hi` type constructor'ından geçemesin.

6. Core c_lim point-range [c,c] ise,
   model projection derivative theorem ayrı Cm model module'ünde yazılsın.
-/

end V24Run05
