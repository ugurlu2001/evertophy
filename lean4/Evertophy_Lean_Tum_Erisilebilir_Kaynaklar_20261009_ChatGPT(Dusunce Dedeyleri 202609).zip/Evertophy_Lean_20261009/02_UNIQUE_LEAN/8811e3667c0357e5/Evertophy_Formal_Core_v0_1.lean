/-
Evertophy Formal Core v0.1 — Lean 4 skeleton
Date: 2026-09-13
Status: ARCHIVAL / CROSS-AI REVIEW DRAFT

Important runtime note:
This file was generated in a container where Lean/lake is not installed, so it has NOT been type-checked here.
It is intentionally written using only Lean core-style definitions where possible.
Purpose: convert Evertophy core constraints into proof-assistant-testable lemmas.
-/

namespace Evertophy

/- ============================================================
   1. Phase ontology: c0 ⇄ Cm ⇄ c+
   ============================================================ -/

inductive Phase where
  | c0
  | Cm
  | cp
  deriving DecidableEq, Repr

inductive DimMode where
  | dimensionless      -- c0: ordinary dimensional degrees are not available as Cm readout dimensions
  | emergentSharp      -- Cm: ordinary measured dimensions/time emerge sharply enough for physics
  | dilutedThin        -- c+: dimension concept becomes thinned/diluted, like time
  deriving DecidableEq, Repr

inductive TimeMode where
  | zero               -- dt = 0 / no emergent Cm time readout
  | emergent           -- Cm time readout exists
  | diluted            -- time-like readout is thinned/diluted
  deriving DecidableEq, Repr

def dimMode : Phase -> DimMode
  | Phase.c0 => DimMode.dimensionless
  | Phase.Cm => DimMode.emergentSharp
  | Phase.cp => DimMode.dilutedThin

def timeMode : Phase -> TimeMode
  | Phase.c0 => TimeMode.zero
  | Phase.Cm => TimeMode.emergent
  | Phase.cp => TimeMode.diluted

theorem c0_dimensionless : dimMode Phase.c0 = DimMode.dimensionless := rfl

theorem cp_dimension_diluted : dimMode Phase.cp = DimMode.dilutedThin := rfl

theorem c0_time_zero : timeMode Phase.c0 = TimeMode.zero := rfl

theorem Cm_time_emergent : timeMode Phase.Cm = TimeMode.emergent := rfl

theorem cp_time_diluted : timeMode Phase.cp = TimeMode.diluted := rfl

/- Canonical adjacency: c0 ⇄ Cm ⇄ cp. No direct c0 ⇄ cp edge. -/
def adjacent : Phase -> Phase -> Bool
  | Phase.c0, Phase.Cm => true
  | Phase.Cm, Phase.c0 => true
  | Phase.Cm, Phase.cp => true
  | Phase.cp, Phase.Cm => true
  | _, _ => false

theorem canonical_c0_Cm_edge : adjacent Phase.c0 Phase.Cm = true := rfl

theorem canonical_Cm_cp_edge : adjacent Phase.Cm Phase.cp = true := rfl

theorem no_direct_c0_cp_edge : adjacent Phase.c0 Phase.cp = false := rfl

theorem no_direct_cp_c0_edge : adjacent Phase.cp Phase.c0 = false := rfl

/- ============================================================
   2. X layers: X_state -> X_domain -> X_read
   ============================================================ -/

inductive XLayer where
  | state
  | domain
  | read
  deriving DecidableEq, Repr

inductive ClaimStrength where
  | canonical
  | branch
  | scaffold
  | openNote
  | discard
  deriving DecidableEq, Repr

/- A layer is allowed to carry core derivation only at X_state / field-level.
   X_domain and X_read can be valid phenomenology/readout but cannot by themselves be Kutu-4 core output.
-/
def coreDerivationEligible : XLayer -> Bool
  | XLayer.state => true
  | XLayer.domain => false
  | XLayer.read => false

theorem X_state_can_be_core_eligible : coreDerivationEligible XLayer.state = true := rfl

theorem X_domain_not_core_eligible : coreDerivationEligible XLayer.domain = false := rfl

theorem X_read_not_core_eligible : coreDerivationEligible XLayer.read = false := rfl

/- ============================================================
   3. Range Formalism as abstract set semantics
   ============================================================ -/

structure Band (α : Type u) where
  inBand : α -> Prop

def Intersects (A B : Band α) : Prop :=
  ∃ x : α, A.inBand x ∧ B.inBand x

def SubsetBand (A B : Band α) : Prop :=
  ∀ x : α, A.inBand x -> B.inBand x

def ProperSubsetBand (A B : Band α) : Prop :=
  SubsetBand A B ∧ ∃ x : α, B.inBand x ∧ ¬ A.inBand x

def Falsified (pred obs : Band α) : Prop :=
  ¬ Intersects pred obs

theorem range_falsification_rule (pred obs : Band α) :
  Falsified pred obs ↔ ¬ Intersects pred obs := Iff.rfl

/- Typed bands prevent the D-1 category error: obs-vs-obs tension is not theory falsification. -/
inductive BandKind where
  | acc
  | pred
  | obs
  deriving DecidableEq, Repr

structure TypedBand (α : Type u) where
  kind : BandKind
  band : Band α

def validFalsificationPair (A B : TypedBand α) : Bool :=
  match A.kind, B.kind with
  | BandKind.pred, BandKind.obs => true
  | BandKind.obs, BandKind.pred => true
  | _, _ => false

variable (dummyBand : Band Unit)

def dummyObs1 : TypedBand Unit := { kind := BandKind.obs, band := dummyBand }
def dummyObs2 : TypedBand Unit := { kind := BandKind.obs, band := dummyBand }
def dummyPred : TypedBand Unit := { kind := BandKind.pred, band := dummyBand }

theorem obs_obs_is_not_valid_falsification_pair :
  validFalsificationPair (dummyObs1 dummyBand) (dummyObs2 dummyBand) = false := rfl

theorem pred_obs_is_valid_falsification_pair :
  validFalsificationPair (dummyPred dummyBand) (dummyObs1 dummyBand) = true := rfl

/- ============================================================
   4. Kutu classification and non-vacuous prediction bands
   ============================================================ -/

inductive SourceKind where
  | postulate       -- Kutu-0
  | externalObs     -- Kutu-1
  | fitPosterior    -- Kutu-2
  | branchDerived   -- Kutu-3
  | coreDerived     -- Kutu-4 candidate source
  | readoutIdentity -- tautological/readout identity
  deriving DecidableEq, Repr

structure CandidateClaim (α : Type u) where
  source : SourceKind
  acc : Band α
  pred : Band α
  obs : Band α
  pred_within_acc : SubsetBand pred acc
  pred_nonvacuous : ProperSubsetBand pred acc

def Kutu4 (c : CandidateClaim α) : Prop :=
  c.source = SourceKind.coreDerived ∧ Intersects c.pred c.obs

/- Readout identities are not Kutu-4 by source classification. -/
theorem readout_identity_not_core_source (c : CandidateClaim α) :
  c.source = SourceKind.readoutIdentity -> ¬ (c.source = SourceKind.coreDerived) := by
  intro h
  rw [h]
  intro impossible
  cases impossible

/- ============================================================
   5. Asymmetric kill-test semantics
   ============================================================ -/

inductive EMBranch where
  | activeCoupled     -- S_alpha ~ O(1), killed by tight bound
  | silentPlateau     -- S_alpha ~ 0 / [c,c] branch: not falsified, but no positive prediction
  deriving DecidableEq, Repr

def killedBySmallSBound : EMBranch -> Bool
  | EMBranch.activeCoupled => true
  | EMBranch.silentPlateau => false

def positivePredictionBySmallSBound : EMBranch -> Bool
  | EMBranch.activeCoupled => false
  | EMBranch.silentPlateau => false

theorem active_EM_branch_killed_by_bound :
  killedBySmallSBound EMBranch.activeCoupled = true := rfl

theorem silent_EM_branch_not_killed_by_bound :
  killedBySmallSBound EMBranch.silentPlateau = false := rfl

theorem silent_EM_branch_no_positive_prediction_from_bound :
  positivePredictionBySmallSBound EMBranch.silentPlateau = false := rfl

/- ============================================================
   6. Sector hierarchy: must be derived, not assigned
   ============================================================ -/

inductive Sector where
  | gravity
  | alphaEM
  | muMassRatio
  deriving DecidableEq, Repr

structure SensitivityPattern where
  sensitivityOrder : Sector -> Nat
  derivedFromXState : Bool

/- If not derived from X_state, the pattern is an assignment, not a Kutu-4 output. -/
def sectorHierarchyEligibleForKutu4 (p : SensitivityPattern) : Bool :=
  p.derivedFromXState

theorem assigned_sector_hierarchy_not_kutu4 (f : Sector -> Nat) :
  sectorHierarchyEligibleForKutu4 { sensitivityOrder := f, derivedFromXState := false } = false := rfl

end Evertophy
