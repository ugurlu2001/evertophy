/- Run06 candidate, NOT COMPILED in this environment.
   No external imports. This is a type interface, not a physical derivation.
   Ordered-field arithmetic and enclosure proofs remain separate tasks. -/
namespace Run06

inductive Phase | c0 | Cm | cp deriving DecidableEq, Repr
inductive GlobalNode | U0 | Ux | Up deriving DecidableEq, Repr
inductive Pole | U0 | Up deriving DecidableEq, Repr

structure Band (α : Type) [LE α] where
  lo : α
  hi : α
  valid : lo ≤ hi

inductive NativeValue (α : Type) [LE α] : Phase → Type
  | preUndefined : NativeValue α .c0
  | present (b : Band α) : NativeValue α .Cm
  | postDissolved : NativeValue α .cp

-- Measurement knowledge is not ontological absence.
inductive Knowledge (α : Type)
  | missing
  | known (value : α)

def nativeBand {α : Type} [LE α] {p : Phase} :
    NativeValue α p → Option (Band α)
  | .preUndefined => none
  | .present b => some b
  | .postDissolved => none

theorem native_c0_silent {α : Type} [LE α] (v : NativeValue α .c0) :
    nativeBand v = none := by
  cases v
  rfl

theorem native_cp_silent {α : Type} [LE α] (v : NativeValue α .cp) :
    nativeBand v = none := by
  cases v
  rfl

-- Native silence does not forbid an outer source affecting a Cm observation.
structure CmReadout (Source α : Type) [LE α] where
  observe : Source → Band α

-- Declarative specification: laws below are obligations, not derived theorems.
structure BridgeSpec (X Y : Type) where
  admissible : X → Prop
  equation : X → Y → Prop
  solve : X → Y
  sound : ∀ x, admissible x → equation x (solve x)
  unique : ∀ x y, admissible x → equation x y → y = solve x

-- Minimal finite non-uniqueness witness, not the stronger smooth report example.
def bridgeA : Bool → Bool := fun x => x
def bridgeB : Bool → Bool := fun x => !x
theorem bridges_differ : bridgeA false ≠ bridgeB false := by decide

end Run06
