import Lake
open Lake DSL

package «evertophy» where
  leanOptions := #[⟨`autoImplicit, false⟩]

-- ÇEKİRDEK: Mathlib bağımlılığı YOK. CI hızlı çalışır (~saniyeler).
lean_lib «Evertophy» where
  roots := #[`Evertophy.Phase, `Evertophy.Quantity, `Evertophy.Range,
             `Evertophy.Time, `Evertophy.Consistency]

lean_lib «Claude» where
  roots := #[`Claude.Sonnet]

lean_lib «V03» where
  roots := #[`V03.StampSpec, `V03.Interval, `V03.Archive, `V03.QSigma, `V03.Omega, `V03.Assoc]

lean_lib «V24» where
  roots := #[`V24.Global, `V24.StampAssoc, `V24.Patches, `V24.Topology, `V24.Absence, `V24.Rewrite, `V24.Types, `V24.Confluence, `V24.Idem, `V24.Production, `V24.BridgeNoGo, `V24.Ledger, `V24.Quarantine]

/-- ÜRETİM: varsayılan hedef, eski API içermez. -/
@[default_target]
lean_lib «Core» where
  roots := #[`Core.Production, `Core.Extended, `Core.Roles, `Core.GateLock]
