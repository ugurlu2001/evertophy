import Lake
open Lake DSL

package «evertophy» where
  leanOptions := #[⟨`autoImplicit, false⟩]

-- ÇEKİRDEK: Mathlib bağımlılığı YOK. CI hızlı çalışır (~saniyeler).
lean_lib «Evertophy» where
  roots := #[`Evertophy.Phase, `Evertophy.Quantity, `Evertophy.Range,
             `Evertophy.Time, `Evertophy.Consistency]

lean_lib «Claude» where
  roots := #[`Claude.Sonnet]

@[default_target]
lean_lib «V03» where
  roots := #[`V03.StampSpec, `V03.Interval, `V03.Archive, `V03.QSigma, `V03.Omega, `V03.Assoc]
