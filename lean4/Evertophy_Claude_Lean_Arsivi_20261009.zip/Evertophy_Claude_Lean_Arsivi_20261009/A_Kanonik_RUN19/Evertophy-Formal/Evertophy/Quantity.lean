import Evertophy.Phase
/-! Faz-etiketli, boyutlu, BANT değerli nicelik (K3) -/
namespace Evertophy

structure Qty (p : Phase) (d : Dim) where
  lo : Float
  hi : Float
deriving Repr

namespace Qty
def width {p : Phase} {d : Dim} (x : Qty p d) : Float := x.hi - x.lo
def isPoint {p : Phase} {d : Dim} (x : Qty p d) : Bool := x.lo == x.hi
def pt {p : Phase} {d : Dim} (v : Float) : Qty p d := Qty.mk v v
def band {p : Phase} {d : Dim} (a b : Float) : Qty p d := Qty.mk a b
end Qty

def qmul {p : Phase} {a b : Dim} (x : Qty p a) (y : Qty p b) : Qty p (Dim.mul a b) :=
  Qty.mk (x.lo * y.lo) (x.hi * y.hi)
def qdiv {p : Phase} {a b : Dim} (x : Qty p a) (y : Qty p b) : Qty p (Dim.div a b) :=
  Qty.mk (x.lo / y.hi) (x.hi / y.lo)
def qadd {p : Phase} {d : Dim} (x y : Qty p d) : Qty p d := Qty.mk (x.lo+y.lo) (x.hi+y.hi)
def qsub {p : Phase} {d : Dim} (x y : Qty p d) : Qty p d := Qty.mk (x.lo-y.hi) (x.hi-y.lo)

/-- Okuma haritası — 4. kritik soru, REZERVE. Tip düzeyinde varlığı ŞART. -/
structure ReadoutMap (src dst : Phase) where
  adjacentOK : adjacent src dst = true

def transport {src dst : Phase} {d : Dim}
    (_m : ReadoutMap src dst) (x : Qty src d) (_h : carriable dst d = true) : Qty dst d :=
  Qty.mk x.lo x.hi

end Evertophy
