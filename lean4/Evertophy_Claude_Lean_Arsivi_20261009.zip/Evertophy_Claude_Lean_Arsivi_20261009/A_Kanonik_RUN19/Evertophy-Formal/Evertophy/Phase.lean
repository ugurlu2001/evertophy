/-! Faz ontolojisi: c₀ ⇄ Cₘ ⇄ c⁺ + K1/K2 boyut geçerliliği -/
namespace Evertophy

inductive Phase where | c0 | Cm | cp
deriving DecidableEq, Repr

/-- Kanonik zincir. Doğrudan c₀↔c⁺ YOK. -/
def adjacent : Phase → Phase → Bool
  | .c0, .Cm => true | .Cm, .c0 => true
  | .Cm, .cp => true | .cp, .Cm => true
  | _, _ => false

theorem chain_no_skip_fwd : adjacent .c0 .cp = false := by decide
theorem chain_no_skip_bwd : adjacent .cp .c0 = false := by decide
theorem chain_ok_low  : adjacent .c0 .Cm = true := by decide
theorem chain_ok_high : adjacent .Cm .cp = true := by decide

structure Dim where
  M : Int
  L : Int
  T : Int
deriving DecidableEq, Repr

namespace Dim
def mul (a b : Dim) : Dim := Dim.mk (a.M+b.M) (a.L+b.L) (a.T+b.T)
def div (a b : Dim) : Dim := Dim.mk (a.M-b.M) (a.L-b.L) (a.T-b.T)
def one  : Dim := Dim.mk 0 0 0
def mass : Dim := Dim.mk 1 0 0
def len  : Dim := Dim.mk 0 1 0
def time : Dim := Dim.mk 0 0 1
def freq : Dim := Dim.mk 0 0 (-1)
end Dim

/-- K1: c₀'da hiçbir temel boyut tanımlı değil.
    K2: c⁺'da L ve T seyrelmiş; M kalır (mutlak yokluk DEĞİL). -/
def actM : Phase → Bool | .c0 => false | .Cm => true | .cp => true
def actL : Phase → Bool | .c0 => false | .Cm => true | .cp => false
def actT : Phase → Bool | .c0 => false | .Cm => true | .cp => false

def carriable (p : Phase) (d : Dim) : Bool :=
  (actM p || d.M == 0) && (actL p || d.L == 0) && (actT p || d.T == 0)

-- K1
theorem K1_c0_time : carriable .c0 Dim.time = false := by decide
theorem K1_c0_len  : carriable .c0 Dim.len  = false := by decide
theorem K1_c0_mass : carriable .c0 Dim.mass = false := by decide
theorem K1_c0_one  : carriable .c0 Dim.one  = true  := by decide
-- K2
theorem K2_cp_time : carriable .cp Dim.time = false := by decide
theorem K2_cp_len  : carriable .cp Dim.len  = false := by decide
theorem K2_cp_mass : carriable .cp Dim.mass = true  := by decide



/-! ═══════════════════════════════════════════════════════════
    ÜÇGEN FAZ TOPOLOJİSİ  (Uğur onayı, 2026/09/14)
    KRİTİK: Ontoloji ve denklemler DEĞİŞMEDİ. Değişen, GÖSTERİMDİR.
    Bu yüzden hiçbir teorem silinmez — İKİ AYRI İLİŞKİ tanımlanır.
    ═══════════════════════════════════════════════════════════ -/

/-- (1) TÜRETİM: U₀ üç fazı EŞ ZAMANLI türetir. Sıralı değil, eşzamanlı. -/
def derivedFromU0 : Phase → Bool
  | .c0 => true | .Cm => true | .cp => true

theorem U0_derives_all_three :
    derivedFromU0 .c0 = true ∧ derivedFromU0 .Cm = true ∧ derivedFromU0 .cp = true :=
  ⟨rfl, rfl, rfl⟩

/-- U₀ oku TEK YÖNLÜ tutulur (Fable uyarısı, Uğur notu).
    Çift yönlü olsaydı U₀ dördüncü AKTİF sektör olurdu — ve U₀ Kutu-0 (POSTÜLE).
    NOT: Uğur'da rezerve kalan detaylar bu kaydı ileride değiştirebilir. -/
def U0_bidirectional : Bool := false
theorem U0_arrow_is_one_way : U0_bidirectional = false := by decide

/-- (2) ONTOLOJİK İLİŞKİ (üçgen): üç faz karşılıklı ilişkilidir.
    Bu bir GEÇİŞ KANALI değil, bir ilişki gösterimidir. -/
def related : Phase → Phase → Bool
  | .c0, .Cm => true | .Cm, .c0 => true
  | .Cm, .cp => true | .cp, .Cm => true
  | .c0, .cp => true | .cp, .c0 => true   -- ← ÜÇÜNCÜ KENAR
  | _, _ => false

theorem triangle_complete :
    related .c0 .cp = true ∧ related .Cm .cp = true ∧ related .c0 .Cm = true :=
  ⟨rfl, rfl, rfl⟩

/-- (3) GEÇİŞ KANALI (`adjacent`) DEĞİŞMEDİ — zincir korunur.
    Ontoloji/denklem düzeyinde hiçbir şey değişmediği için bu teorem AYAKTA. -/
theorem transition_chain_preserved :
    adjacent .c0 .cp = false ∧ adjacent .cp .c0 = false := ⟨rfl, rfl⟩

/-- (4) BOYUTSAL KISIT: c₀↔c⁺ ilişkisinden YALNIZ boyutsuz nicelik geçer.
    K1 (c₀ hiçbir boyut) ∩ K2 (c⁺ yalnız kütle) = yalnız boyutsuz. -/
def crossable_c0_cp (d : Dim) : Bool := carriable .c0 d && carriable .cp d
theorem tri_edge_only_dimensionless : crossable_c0_cp Dim.one  = true  := by decide
theorem tri_edge_no_mass            : crossable_c0_cp Dim.mass = false := by decide
theorem tri_edge_no_len             : crossable_c0_cp Dim.len  = false := by decide
theorem tri_edge_no_time            : crossable_c0_cp Dim.time = false := by decide

-- SONUÇ: X boyutsuz olduğu için üçgenin her kenarından geçebilir;
-- madde, enerji ve zaman geçemez. Üçgen, FAZ-BİLGİSİ ilişkisidir.

end Evertophy

/-! ═══════════════════════════════════════════════════════════
    CANON-CONSISTENCY-PATCH (minor19) — Uğur onayı 2026/09/16
    Kilitli cümle: "Geçişler TAM ÇİFT YÖNLÜDÜR. Tersinirlik faz
    kapısında değil, MÜHÜRLEME EYLEMİNDE yaşanır.
    Kapı çift yönlü, damga tek yönlü."
    ═══════════════════════════════════════════════════════════ -/
namespace Evertophy

/-- P0-1: KANONİK GEÇİŞ — üç kenarın TAMAMI çift yönlü. -/
def gateRelated : Phase → Phase → Bool
  | .c0, .Cm => true | .Cm, .c0 => true
  | .Cm, .cp => true | .cp, .Cm => true
  | .c0, .cp => true | .cp, .c0 => true
  | _, _ => false

theorem gate_c0_cp_open  : gateRelated .c0 .cp = true := by decide
theorem gate_cp_c0_open  : gateRelated .cp .c0 = true := by decide
theorem gate_symmetric_1 : gateRelated .c0 .Cm = gateRelated .Cm .c0 := by decide
theorem gate_symmetric_2 : gateRelated .Cm .cp = gateRelated .cp .Cm := by decide
theorem gate_symmetric_3 : gateRelated .c0 .cp = gateRelated .cp .c0 := by decide

/-- `adjacent` LEGACY/DEPRECATED — eski operasyonel model. Silinmez, taşınır. -/
def adjacent_LEGACY : Phase → Phase → Bool := adjacent

/-- P0-3: X-TAŞIYICI GUARD. Boyutsuzluk GEREKLİ ama YETERLİ DEĞİL. -/
inductive CarrierKind | xCoordinate | ordinaryDimensionless | dimensioned
deriving DecidableEq, Repr

def isXCoordinate : CarrierKind → Bool
  | .xCoordinate => true | _ => false

def crossesPhaseGate : CarrierKind → Bool
  | .xCoordinate => true
  | .ordinaryDimensionless => false   -- boyutsuz AMA pasaportsuz
  | .dimensioned => false

theorem only_X_crosses      : crossesPhaseGate .xCoordinate = true := by decide
theorem plain_dimensionless_blocked : crossesPhaseGate .ordinaryDimensionless = false := by decide
theorem dimensioned_blocked : crossesPhaseGate .dimensioned = false := by decide
/-- crossable ⟹ dimensioned DEĞİL (GEREKLİ koşul); tersi GEÇERSİZ. -/
theorem crossable_implies_not_dimensioned :
    crossesPhaseGate CarrierKind.dimensioned = false := by decide

/-- P0-2: U₀ meta-provenance — kapı DEĞİL. -/
def generatedByU0 : Phase → Bool
  | .c0 => true | .Cm => true | .cp => true
theorem U0_generates_all : generatedByU0 .c0 ∧ generatedByU0 .Cm ∧ generatedByU0 .cp :=
  ⟨rfl, rfl, rfl⟩

/-- P1-5: İKİ FARKLI zamansızlık türü. -/
inductive TemporalRole | preEmergent | physicalTime | atemporalRecord
deriving DecidableEq, Repr

def temporalRole : Phase → TemporalRole
  | .c0 => .preEmergent | .Cm => .physicalTime | .cp => .atemporalRecord

theorem c0_cp_roles_differ : temporalRole .c0 ≠ temporalRole .cp := by decide
theorem Cm_has_physical_time : temporalRole .Cm = .physicalTime := by decide

end Evertophy
