/-! Range Formalizm: ΔX_acc / ΔX_pred / ΔX_obs -/
namespace Evertophy

structure Ivl where
  lo : Float
  hi : Float
deriving Repr

def Ivl.disjoint (a b : Ivl) : Bool := a.hi < b.lo || b.hi < a.lo
def Ivl.subsetOf (a b : Ivl) : Bool := b.lo <= a.lo && a.hi <= b.hi
def Ivl.proper (a b : Ivl) : Bool := a.subsetOf b && (b.lo < a.lo || a.hi < b.hi)

inductive BandKind | acc | pred | obs
deriving DecidableEq, Repr

structure Band where
  kind : BandKind
  iv : Ivl

/-- Falsifikasyon YALNIZ pred∩obs=∅ ile. obs-vs-obs GEÇERSİZ. -/
def falsified (p o : Band) : Bool :=
  match p.kind, o.kind with
  | .pred, .obs => p.iv.disjoint o.iv
  | _, _        => false

/-- Kutu-4: pred, acc'nin ÖZ alt kümesi olmalı (non-vacuous). -/
def kutu4 (pred acc : Ivl) : Bool := pred.proper acc

inductive Layer | field | state | domain | read
deriving DecidableEq, Repr

/-- X_domain / X_read TEK BAŞINA Kutu-4 üretemez. -/
def canProduceKutu4 : Layer → Bool
  | .field => true | .state => true | .domain => false | .read => false

theorem domain_cannot : canProduceKutu4 .domain = false := by decide
theorem read_cannot   : canProduceKutu4 .read   = false := by decide
theorem state_can     : canProduceKutu4 .state  = true  := by decide

end Evertophy
