import Evertophy.Quantity
/-! Emergent zaman — İKİ KATMAN (Kimi revizyonu, minor15)
    (a) ONTOLOJİK: zaman Cₘ'ye hapsolur  → TÜRETİLMİŞ (teorem)
    (b) DİNAMİK  : dt = Γ·G_cm·dτ        → POSTÜLA (korunur) -/
namespace Evertophy

-- ── KATMAN (a): TEOREM ────────────────────────────────
/-- Zaman boyutlu ⟹ ne c₀'a ne c⁺'a taşınabilir ⟹ YALNIZ Cₘ. -/
theorem time_confined_c0 : carriable .c0 Dim.time = false := by decide
theorem time_confined_cp : carriable .cp Dim.time = false := by decide
theorem time_lives_in_Cm : carriable .Cm Dim.time = true  := by decide

/-- X boyutsuz ⟹ ÜÇ FAZDA DA taşınır. "X evrensel ⟹ X boyutsuz" tersinin kanıtı. -/
theorem X_universal_c0 : carriable .c0 Dim.one = true := by decide
theorem X_universal_Cm : carriable .Cm Dim.one = true := by decide
theorem X_universal_cp : carriable .cp Dim.one = true := by decide

-- ── KATMAN (b): POSTÜLA (boyut kontrolü yapılır, içerik türetilmez) ──
/-- dt = Γ·G·dτ ,  [Γ]=T, [G]=T⁻¹  ⟹  T·T⁻¹·T = T -/
theorem dt_dimensional : Dim.mul (Dim.mul Dim.time Dim.freq) Dim.time = Dim.time := by decide
/-- Normalize: dt = τ₀·Γ̃·G·dτ , [Γ̃]=1 -/
theorem dt_normalized : Dim.mul (Dim.mul (Dim.mul Dim.time Dim.one) Dim.freq) Dim.time = Dim.time := by decide
/-- HATA: Γ boyutsuz sanılırsa sonuç zaman DEĞİL -/
theorem gamma_wrong : Dim.mul (Dim.mul Dim.one Dim.freq) Dim.time = Dim.one := by decide

-- ── OPERATÖR GEÇERLİLİĞİ (Kimi Görev-2 tam düzeltmesi) ──
/-- Diferansiyel operatör [1/L] gerektirir ⟹ yalnız Cₘ'de tanımlı.
    c₀: operatör YOK.  c⁺: operatör YOK (∇²_spatial dahil — K2 ihlali). -/
def hasDifferentialOp (p : Phase) : Bool := carriable p (Dim.mk 0 (-1) 0)
theorem op_c0_none : hasDifferentialOp .c0 = false := by decide
theorem op_cp_none : hasDifferentialOp .cp = false := by decide
theorem op_Cm_yes  : hasDifferentialOp .Cm = true  := by decide

end Evertophy
