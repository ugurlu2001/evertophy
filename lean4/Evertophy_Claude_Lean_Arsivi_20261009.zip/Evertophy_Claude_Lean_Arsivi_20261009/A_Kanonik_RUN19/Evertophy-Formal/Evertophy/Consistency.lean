import Evertophy.Time
import Evertophy.Range
/-! V23 denklem tutarlılık teoremleri + borç kaydı -/
namespace Evertophy

def MD (n : Int) : Dim := Dim.mk n 0 0   -- doğal birim: saf kütle boyutu

/-- F boyutsuz (468.1 KİLİTLİ). Eski F=(16πG)⁻¹ ihlal. -/
theorem F_dimensionless_ok : Dim.div (MD 0) (MD 0) = MD 0 := by decide
theorem F_old_form_violates : Dim.div (MD 0) (MD (-2)) = MD 2 := by decide

/-- ω_Φ = Z·F/(M_Pl²F'²) boyutsuz -/
theorem omega_dimensionless : Dim.div (MD 0) (Dim.mul (MD 2) (MD (-2))) = MD 0 := by decide
/-- A₀ = M_Pl·|F'|/√(ZF) boyutsuz -/
theorem A0_dimensionless : Dim.mul (MD 1) (MD (-1)) = MD 0 := by decide

/-- Cₘ lemma: m² = V''/(FZ) ~ M² ; V₀≠0 düzeltmesi AYNI boyut ⟹ toplanabilir -/
theorem Cm_lemma_main : Dim.div (MD 2) (Dim.mul (MD 0) (MD 0)) = MD 2 := by decide
theorem Cm_lemma_corr : Dim.mul (MD (-2)) (MD 4) = MD 2 := by decide

/-- Einstein-frame: Z/F ve (3/2)M_Pl²(F'/F)² — ikisi de boyutsuz -/
theorem EF_term1 : Dim.div (MD 0) (MD 0) = MD 0 := by decide
theorem EF_term2 : Dim.mul (MD 2) (Dim.mul (MD (-1)) (MD (-1))) = MD 0 := by decide

/-- η_clock = (ω_ρ-ω_atom)/½(ω_ρ+ω_atom) boyutsuz; çıkarma boyut eşitliği zorlar -/
theorem eta_clock_dimensionless : Dim.div Dim.freq Dim.freq = MD 0 := by decide

/-- BORÇ KAYDI — makine-okunur (Kimi'nin genişletilmiş şeması benimsendi) -/
inductive DebtStatus
  | open_          -- çözülmemiş
  | resolved       -- çözüldü, kanıtlandı
  | transferred    -- BAŞKA borca taşındı (kapanmadı!)
  | reservedCore   -- Ontolojik Çekirdek'e bağlı
  | retired        -- yapısal gerekçeyle emekli
  | violatesK1K2   -- ontolojik kısıt ihlali
deriving DecidableEq, Repr

structure DebtEntry where
  id : String
  description : String
  status : DebtStatus
  since : String
  resolvedAt : Option String
deriving Repr

/-- BİRLEŞTİRİLMİŞ REGISTRY (Fable ∪ Kimi, çakışmalar giderildi).
    ID'ler ARTIK DEĞİŞTİRİLEMEZ — çapraz atıflar bunlara bağlı.
    NOT: 'transferred' = başka BİR BORCA taşındı. Rezerve-çekirdeğe bağlı
    olmak TAŞINMA DEĞİLDİR; onlar 'reservedCore'dur. -/
def debtRegistry : List DebtEntry :=
  [ ⟨"DEBT-001", "Range.mul positivity",              .resolved,     "minor13", some "minor15"⟩
  , ⟨"DEBT-002", "Lambda = eta c^2 kappa_g (P1-P4)",  .transferred,  "minor13", none⟩
  , ⟨"DEBT-003", "chi_S c+ operasyonel tanim",        .reservedCore, "minor13", none⟩
  , ⟨"DEBT-004", "X -> {F,Z,V} cekirdek turetimi",    .reservedCore, "minor05", none⟩
  , ⟨"DEBT-005", "readout map {H,L_k,gamma_k}",       .reservedCore, "minor05", none⟩
  , ⟨"DEBT-006", "Kimi #5 metrik c0->Minkowski",      .resolved,     "minor14", some "minor15"⟩
  , ⟨"DEBT-007", "Qalign korelasyon hatti",           .retired,      "minor14", some "minor14"⟩
  , ⟨"DEBT-008", "eta_core vs eta_effective f(rho)",  .transferred,  "minor15", none⟩
  , ⟨"DEBT-009", "Hubble bandi: rho orani R serbest", .open_,        "minor15", none⟩
  , ⟨"DEBT-010", "axiom kullanimi (Mathlib-siz core)", .resolved,    "minor15", some "minor15"⟩
  , ⟨"DEBT-011", "Emergent zaman integrali G_cm formu", .reservedCore, "minor13", none⟩
  , ⟨"DEBT-012", "J_int / L_link bag terimi",         .reservedCore, "minor13", none⟩
  , ⟨"DEBT-013", "Muhurleme formalizasyonu",          .open_,        "minor13", none⟩
  , ⟨"DEBT-014", "Saat-alt-sistemi secimi invaryansi", .open_,       "minor13", none⟩ ]

def countBy (s : DebtStatus) : Nat := (debtRegistry.filter (fun d => d.status == s)).length
def openCount : Nat := countBy .open_
def transferredCount : Nat := countBy .transferred
def reservedCount : Nat := countBy .reservedCore

/-- "transferred" KAPANMA DEĞİLDİR — ayrı sayılır. -/
theorem transferred_not_resolved : transferredCount = 2 := by decide
/-- Rezerve-çekirdeğe bağlı borçlar TAŞINMIŞ sayılmaz — beşi de aynı kökten. -/
theorem reserved_core_count : reservedCount = 5 := by decide
/-- Toplam kayıt — ID çakışması olmadan -/
theorem registry_size : debtRegistry.length = 14 := by decide

/-- TAM SAYIM — Kimi'nin ozet tablosu teorem olarak sabitlendi. -/
theorem count_resolved     : countBy .resolved     = 3 := by decide
theorem count_transferred  : countBy .transferred  = 2 := by decide
theorem count_reservedCore : countBy .reservedCore = 5 := by decide
theorem count_open         : countBy .open_        = 3 := by decide
theorem count_retired      : countBy .retired      = 1 := by decide
/-- Toplam tutarlilik: 3+2+5+3+1 = 14 -/
theorem counts_sum_to_total :
    countBy .resolved + countBy .transferred + countBy .reservedCore
  + countBy .open_ + countBy .retired = debtRegistry.length := by decide

-- ══════════════════════════════════════════════════════════
-- PARAMETRE BÜTÇESİ — tekrar eden "çarpım sabit / çarpanlar serbest" desenine karşı
-- ══════════════════════════════════════════════════════════

/-- Bir iddia için: kaç SERBEST girdi tüketildi, kaç GÖZLENEBİLİR öngörüldü? -/
structure ParamBudget where
  claim : String
  freeInputs : Nat
  predictedObservables : Nat
deriving Repr

/-- Kanonik öngörü şartı: serbest girdi < öngörülen gözlenebilir. -/
def isPredictive (b : ParamBudget) : Bool := b.freeInputs < b.predictedObservables

def budgets : List ParamBudget :=
  [ ⟨"alpha = Z0/(2 R_K)",        1, 1⟩   -- ozdeslik: 1 in, 1 out
  , ⟨"Lambda = eta c^2 kappa_g",  2, 1⟩   -- eta, kappa_g serbest; carpim sabit
  , ⟨"C_s[Z] = A Z/Z* + B Z*/Z",  2, 1⟩   -- A, B serbest
  , ⟨"Hubble: kappa_g ~ rho^alpha", 2, 1⟩ ] -- alpha VE R serbest

/-- DÖRT VAKA DA aynı desende: girdi >= çıktı ⟹ hiçbiri öngörü değil. -/
theorem no_budget_is_predictive :
    budgets.all (fun b => !isPredictive b) = true := by decide

/-- KANONIK ONGORU SAYACI - degismedi -/
def canonicalPredictions : Nat := 0
theorem still_zero : canonicalPredictions = 0 := by decide

end Evertophy
