#!/usr/bin/env python3
"""RUN-19 · Regresyon negatif testi (Wolfram Tur-18 §13.10): README'den kanonik satır silinirse G1 KALMALI."""
import subprocess, sys, shutil, tempfile, pathlib
here = pathlib.Path(__file__).resolve().parent
d = pathlib.Path(tempfile.mkdtemp())
shutil.copy(here/"final_regression.py", d); shutil.copy(here/"README_BUILD.md", d)
ok_clean = subprocess.run([sys.executable,"final_regression.py","--g1-only"],cwd=d,capture_output=True).returncode == 0
t = (d/"README_BUILD.md").read_text(encoding="utf-8").replace("import Core.Production","Core.Production")
(d/"README_BUILD.md").write_text(t, encoding="utf-8")
fails_corrupt = subprocess.run([sys.executable,"final_regression.py","--g1-only"],cwd=d,capture_output=True).returncode != 0
shutil.rmtree(d)
print(f"temiz README → G1 GEÇTİ: {ok_clean} · bozuk README → G1 KALDI: {fails_corrupt}")
sys.exit(0 if ok_clean and fails_corrupt else 1)
