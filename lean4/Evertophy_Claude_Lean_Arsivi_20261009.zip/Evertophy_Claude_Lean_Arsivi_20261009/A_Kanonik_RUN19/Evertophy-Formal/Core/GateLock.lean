import Core.Roles
/-! Core.GateLock — RUN-14 revizyonu (Kimi Tur-13 V77-5 bulgusu):
    Tam-K3 kapı + Cₘ-yalnız içsel lisans ⇒ Cₘ-yalnız fiziksel ilkeller HİÇBİR kapıdan TAŞINAMAZ.
    Neden: kapı farklı fazları bağlar (irreflexive); taşıma iki uçta da içsel lisans ister;
    Cₘ-yalnız bir nicelik için iki uç da Cₘ olmalıdır ⇒ çelişki. -/
namespace EvCore

/-- Cₘ-yalnız fiziksel ilkeller (Uğur kuralı: zaman, 3B uzay, metrik, içsel hız, c sınırı, durgun kütle). -/
def CmOnlyKind : QuantityKind → Bool
  | .cmRestMass | .physTime | .space3D | .metric | .intrinsicSpeed | .cBoundary => true
  | _ => false

/-- 🎯 KAPI-KİLİDİ: Cₘ-yalnız hiçbir nicelik hiçbir kapıdan taşınamaz. -/
theorem cm_only_gate_locked : ∀ (q : QuantityKind) (a b : Phase),
    CmOnlyKind q = true → TransportPermission q a b = false := by
  intro q a b hq
  cases q <;> simp [CmOnlyKind] at hq <;> cases a <;> cases b <;> rfl

/-- Karşı yön: taşınabilir olanlar yalnız faz-bağımsız etiketler (X koordinatı, kütle boyut etiketi). -/
theorem only_labels_cross : TransportPermission .xCoord .c0 .cp = true ∧
    TransportPermission .dimMassLabel .c0 .cp = true := by decide

/-- Cₘ okuması bu kilitten ETKİLENMEZ: c⁺ kaynaklı olay Cₘ'de okunur (taşıma ≠ okuma). -/
theorem gate_lock_does_not_block_readout :
    TransportPermission .physTime .cp .Cm = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true := by decide

/-- Core'da Band yüklü Cₘ-yalnız değer (Kimi Tur-14 görevi). -/
abbrev CmOnlyBand (p : Phase) := CmOnlyValue Band p
def exampleCmOnlyBand : CmOnlyBand .Cm := .presentCm ⟨0, 2, by decide⟩
end EvCore
