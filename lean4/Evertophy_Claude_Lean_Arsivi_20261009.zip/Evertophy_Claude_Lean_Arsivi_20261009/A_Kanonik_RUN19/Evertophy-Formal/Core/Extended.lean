import Core.Production
/-! Core.Extended — RUN-13 · Wolfram kabul kriterleri C, D, E (ÜRETİM; eski API yok). -/
namespace EvCore

/-! ## D — dört-köşe çarpım sağlamlığı (kesin Int) -/
private theorem mul_between_right {a b x : Int} (y : Int) (h1 : a ≤ x) (h2 : x ≤ b) :
    min (a*y) (b*y) ≤ x*y ∧ x*y ≤ max (a*y) (b*y) := by
  rcases Int.le_total 0 y with hy | hy
  · have l := Int.mul_le_mul_of_nonneg_right h1 hy
    have r := Int.mul_le_mul_of_nonneg_right h2 hy
    constructor
    · exact Int.le_trans (Int.min_le_left _ _) l
    · exact Int.le_trans r (Int.le_max_right _ _)
  · have l := Int.mul_le_mul_of_nonpos_right h1 hy
    have r := Int.mul_le_mul_of_nonpos_right h2 hy
    constructor
    · exact Int.le_trans (Int.min_le_right _ _) r
    · exact Int.le_trans l (Int.le_max_left _ _)
def corners (a b : Band) : List Int := [a.lo*b.lo, a.lo*b.hi, a.hi*b.lo, a.hi*b.hi]
def cmin (a b : Band) : Int := min (min (a.lo*b.lo) (a.lo*b.hi)) (min (a.hi*b.lo) (a.hi*b.hi))
def cmax (a b : Band) : Int := max (max (a.lo*b.lo) (a.lo*b.hi)) (max (a.hi*b.lo) (a.hi*b.hi))
theorem mul_sound {a b : Band} {x y : Int} (hx : a.mem x) (hy : b.mem y) :
    cmin a b ≤ x*y ∧ x*y ≤ cmax a b := by
  obtain ⟨hx1, hx2⟩ := hx; obtain ⟨hy1, hy2⟩ := hy
  have hxy := mul_between_right y hx1 hx2
  have ha := mul_between_right a.lo hy1 hy2
  have hb := mul_between_right a.hi hy1 hy2
  rw [Int.mul_comm y a.lo, Int.mul_comm b.lo a.lo, Int.mul_comm b.hi a.lo] at ha
  rw [Int.mul_comm y a.hi, Int.mul_comm b.lo a.hi, Int.mul_comm b.hi a.hi] at hb
  unfold cmin cmax
  generalize a.lo*b.lo = p1 at *; generalize a.lo*b.hi = p2 at *
  generalize a.hi*b.lo = p3 at *; generalize a.hi*b.hi = p4 at *
  generalize a.lo*y = q1 at *; generalize a.hi*y = q2 at *; generalize x*y = z at *
  omega
def Band.mul (a b : Band) : Band := ⟨cmin a b, cmax a b, by unfold cmin cmax; omega⟩
theorem Band.mul_sound {a b : Band} {x y : Int} (hx : a.mem x) (hy : b.mem y) : (a.mul b).mem (x*y) :=
  EvCore.mul_sound hx hy

/-! ## D — ters/bölme SIFIR DIŞLAMASI gerektirir (tip koruması) -/
def ZeroExcluded (b : Band) : Prop := 0 < b.lo ∨ b.hi < 0
theorem zero_band_not_invertible (b : Band) (h : b.mem 0) : ¬ ZeroExcluded b := by
  unfold Band.mem at h; unfold ZeroExcluded; omega
/-- Kesin ters/bölme Rat/Real gerektirir (Mathlib) → yalnız KORUMA burada; aritmetik sonraki katman. -/
structure InvertibleBand where
  band : Band
  guard : ZeroExcluded band

/-! ## D — boş kesişim ≠ [0,0]; +∞ ≠ yokluk -/
theorem empty_ne_zero_band : Band.inter ⟨0, 1, by decide⟩ ⟨2, 3, by decide⟩ = none ∧
    (Band.inter ⟨0, 0, by decide⟩ ⟨0, 0, by decide⟩).isSome = true :=
  ⟨by simp [Band.inter]; decide, by simp [Band.inter]; decide⟩
inductive Ext | negInf | fin (a : Int) | posInf  deriving DecidableEq, Repr
/-- +∞ üst uçlu bant Cₘ'de PRESENT'tır; c⁺'taki çözünmüşlük ayrı kurucudur. -/
def unboundedCm : CmOnlyValue (Ext × Ext) .Cm := .presentCm (.fin 1, .posInf)
theorem posInf_is_present : ∃ v, unboundedCm = .presentCm v := ⟨_, rfl⟩

/-! ## C — TracePolicy: KAYNAK fazı + OLAY TÜRÜ ile; yokluktan türetilmez -/
inductive EventKind | gateCrossing | sealing | readout | dissolution  deriving DecidableEq, Repr
inductive TraceStatus | retained | notRetained | unknown  deriving DecidableEq, Repr
structure TracePolicy where
  policy : EventKind → Phase → TraceStatus
def TP1 : TracePolicy := ⟨fun _ _ => .retained⟩
def TP2 : TracePolicy := ⟨fun k _ => if k = .dissolution then .notRetained else .retained⟩
/-- Aynı (c⁺ = çözünmüş) semantiği iki farklı politikayla uyumlu → iz AKSİYOMDUR, teorem değil. -/
theorem trace_not_derived_from_dissolution :
    TP1.policy .dissolution .cp ≠ TP2.policy .dissolution .cp := by decide
theorem trace_uses_eventkind :
    TP2.policy .dissolution .cp ≠ TP2.policy .sealing .cp := by decide

/-! ## E — seçici kapsamı: ayrık oyuncak, FİZİKSEL J_X TÜRETİMİ DEĞİL -/
/-- OYUNCAK / ORTA NOKTA: Fin 3 üzerinde 2·B(1)=B(2). Sürekli karşılığı (Cauchy+monotonluk ⇒ B=x)
    matematiksel sonuçtur; toplamsallığın FİZİKSEL gerekçesi ve X→(ρ,Z,μ) haritası AÇIKTIR. -/
theorem toy_midpoint_selector (B : Fin 3 → Nat) (_h0 : B 0 = 0) (h2 : B 2 = 2)
    (hadd : B 1 + B 1 = B 2) : B 1 = 1 := by omega
end EvCore
