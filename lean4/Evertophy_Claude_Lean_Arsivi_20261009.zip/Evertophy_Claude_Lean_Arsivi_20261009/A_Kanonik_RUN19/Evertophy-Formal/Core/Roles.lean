import Core.Extended
/-! Core.Roles — RUN-14 · son KISMİ maddeler: rol tipleri, tipli CmReadout, genel Band α,
    ve ChatGPT Tur-13 §7 koruması (taşıma izni ≠ kaynak→okuma köprüsü). -/
namespace EvCore

/-! ## Rol tipleri — karıştırılamaz sarmalayıcılar -/
structure NativePhase      where p : Phase  deriving DecidableEq, Repr
structure SourcePhase      where p : Phase  deriving DecidableEq, Repr
structure ObservationPhase where p : Phase  deriving DecidableEq, Repr
structure RoleEvent where
  source   : SourcePhase
  observed : ObservationPhase

/-! ## Tipli CmReadout — sonuç GÖZLEM fazına göre indekslenir, neden korunur -/
def CmReadout (α : Type) (e : RoleEvent) : Type := CmOnlyValue α e.observed.p
def readoutAtCm {α : Type} (a : α) (src : SourcePhase) :
    CmReadout α ⟨src, ⟨.Cm⟩⟩ := CmOnlyValue.presentCm a
/-- c⁺ KAYNAKLI olay Cₘ'de okunduğunda değer PRESENT'tır. -/
theorem cp_source_Cm_readout_present {α : Type} (a : α) :
    ∃ v, readoutAtCm a ⟨.cp⟩ = CmOnlyValue.presentCm v := ⟨a, rfl⟩
/-- Gözlem c⁺'ta ise okuma zorunlu olarak dissolvedPlus'tır — kaynaktan bağımsız. -/
theorem observed_cp_is_dissolved {α : Type} (src : SourcePhase) (v : CmReadout α ⟨src, ⟨.cp⟩⟩) :
    v = CmOnlyValue.dissolvedPlus := cp_dissolved v

/-! ## §7 koruması — içsel taşıma izni ile kaynak→okuma AYRI ilişkilerdir -/
theorem transport_is_not_readout :
    TransportPermission .physTime .cp .Cm = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true := by decide

/-! ## Genel Band α (depolama; aritmetik Int katmanında kanıtlı) -/
structure BandG (α : Type) [LE α] where
  lo : α
  hi : α
  valid : lo ≤ hi
def BandG.ofInt (b : Band) : BandG Int := ⟨b.lo, b.hi, b.valid⟩
theorem ofInt_preserves (b : Band) : (BandG.ofInt b).lo = b.lo ∧ (BandG.ofInt b).hi = b.hi := ⟨rfl, rfl⟩
end EvCore
