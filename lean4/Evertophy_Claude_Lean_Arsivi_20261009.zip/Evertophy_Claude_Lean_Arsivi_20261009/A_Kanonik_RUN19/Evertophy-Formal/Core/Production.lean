/-! Core.Production — RUN-12 · ÜRETİM ÇEKİRDEĞİ (varsayılan hedef).
    HİÇBİR eski modülü içe AKTARMAZ: adjacent, K2_cp_mass, GlobalPole(Ux), metricOK, Float Ivl/Qty YOK.
    Wolfram RUN-11 göç listesi P0 + P1 (faz-rolü ayrımı, epistemik katman, minimal Range aritmetiği). -/
namespace EvCore

inductive Phase | c0 | Cm | cp  deriving DecidableEq, Repr

/-! ## P0 — Kapı = tam K3; taşıma izni AYRI ve nicelik-özgü -/
def GateRelated (a b : Phase) : Bool := a != b
theorem gate_full_K3 : GateRelated .c0 .Cm ∧ GateRelated .Cm .cp ∧ GateRelated .c0 .cp := by decide
theorem gate_symm : ∀ a b, GateRelated a b = GateRelated b a := by
  intro a b; cases a <;> cases b <;> rfl
theorem gate_irrefl : ∀ a, GateRelated a a = false := by
  intro a; cases a <;> rfl

inductive QuantityKind | dimMassLabel | cmRestMass | physTime | space3D | metric | intrinsicSpeed | cBoundary | xCoord
  deriving DecidableEq, Repr
/-- Niceliğin İÇSEL olarak tanımlı olduğu faz (NativePhase lisansı). -/
def NativeOK : QuantityKind → Phase → Bool
  | .dimMassLabel, _ => true
  | .xCoord, _ => true
  | _, p => p == .Cm
def TransportPermission (q : QuantityKind) (a b : Phase) : Bool :=
  GateRelated a b && NativeOK q a && NativeOK q b
theorem transport_separate_from_gate :
    GateRelated .c0 .cp = true ∧ TransportPermission .physTime .c0 .cp = false := by decide
theorem x_crosses_every_gate : ∀ a b, GateRelated a b = true → TransportPermission .xCoord a b = true := by
  intro a b h; cases a <;> cases b <;> simp_all [GateRelated, TransportPermission, NativeOK]
theorem K2_as_label_only : NativeOK .dimMassLabel .cp = true ∧ NativeOK .cmRestMass .cp = false := by decide

/-! ## P1 — Faz rolleri: Native ≠ Source ≠ Observation -/
structure Event where
  source   : Phase      -- olayın kaynağı / provenance
  observed : Phase      -- okumanın yapıldığı faz
def CmReadoutDefined (e : Event) : Bool := e.observed == .Cm
/-- c⁺ kaynaklı bir olay Cₘ'de okunabilir — kaynak=c⁺ okumayı "çözünmüş" YAPMAZ. -/
theorem cp_sourced_Cm_readable : CmReadoutDefined ⟨.cp, .Cm⟩ = true := rfl
/-- Kaynak fazı, içsel nicelik lisansı DEĞİLDİR. -/
theorem source_is_not_native_license :
    (⟨.cp, .Cm⟩ : Event).source = .cp ∧ NativeOK .physTime .cp = false ∧ CmReadoutDefined ⟨.cp, .Cm⟩ = true :=
  ⟨rfl, rfl, rfl⟩

/-! ## Ontik yokluk (tam 2) ⟂ epistemik durum -/
inductive OntoAbsence | preAdmissible | dissolved  deriving DecidableEq, Repr
inductive Knowledge | observed | missingData | imputed  deriving DecidableEq, Repr
inductive CmOnlyValue (α : Type) : Phase → Type
  | undefined0    : CmOnlyValue α .c0
  | presentCm     : α → CmOnlyValue α .Cm
  | dissolvedPlus : CmOnlyValue α .cp
theorem c0_undefined {α : Type} (v : CmOnlyValue α .c0) : v = .undefined0 := by cases v; rfl
theorem cp_dissolved {α : Type} (v : CmOnlyValue α .cp) : v = .dissolvedPlus := by cases v; rfl

/-! ## Global düğümler; metrik -/
inductive GlobalNode | U0 | Ux | Uplus  deriving DecidableEq, Repr
def isPole : GlobalNode → Bool | .Ux => false | _ => true
theorem Ux_not_pole : isPole .Ux = false := rfl
def MetricAdmissible (p : Phase) : Bool := p == .Cm
theorem metric_only_Cm : MetricAdmissible .Cm = true ∧ MetricAdmissible .c0 = false ∧ MetricAdmissible .cp = false := by decide

/-! ## P1 — Minimal Band aritmetiği (KESİN Int; yuvarlama gerekmez) -/
structure Band where
  lo : Int
  hi : Int
  valid : lo ≤ hi
def Band.mem (x : Int) (b : Band) : Prop := b.lo ≤ x ∧ x ≤ b.hi
def Band.add (a b : Band) : Band := ⟨a.lo + b.lo, a.hi + b.hi, by have := a.valid; have := b.valid; omega⟩
def Band.neg (a : Band) : Band := ⟨-a.hi, -a.lo, by have := a.valid; omega⟩
theorem add_sound {a b : Band} {x y : Int} (hx : a.mem x) (hy : b.mem y) : (a.add b).mem (x + y) := by
  simp only [Band.mem, Band.add] at *; omega
theorem neg_sound {a : Band} {x : Int} (hx : a.mem x) : a.neg.mem (-x) := by
  simp only [Band.mem, Band.neg] at *; omega
def Band.inter (a b : Band) : Option Band :=
  if h : max a.lo b.lo ≤ min a.hi b.hi then some ⟨max a.lo b.lo, min a.hi b.hi, h⟩ else none
theorem inter_sound {a b : Band} {x : Int} (ha : a.mem x) (hb : b.mem x) :
    ∃ c, a.inter b = some c ∧ c.mem x := by
  unfold Band.mem at ha hb
  have h : max a.lo b.lo ≤ min a.hi b.hi := by omega
  refine ⟨⟨max a.lo b.lo, min a.hi b.hi, h⟩, ?_, ?_⟩
  · simp [Band.inter, h]
  · show max a.lo b.lo ≤ x ∧ x ≤ min a.hi b.hi
    omega
/-- Sert red YALNIZ boş kesişimde; nokta aralık içerideyse kesişim vardır. -/
theorem point_inside_not_rejected (p : Int) (b : Band) (h : b.mem p) :
    (Band.inter ⟨p, p, Int.le_refl p⟩ b).isSome = true := by
  have hp : (⟨p, p, Int.le_refl p⟩ : Band).mem p := ⟨Int.le_refl p, Int.le_refl p⟩
  obtain ⟨c, hc, _⟩ := inter_sound hp h
  simp [hc]

/-! ## Köprü oyuncağının sınırı (Kimi V64): KESİN monotonlukla ayrık oyuncak tekilleşir -/
def StrictAdmissible (B : Fin 3 → Nat) : Prop := B 0 = 0 ∧ B 2 = 2 ∧ B 0 < B 1 ∧ B 1 < B 2
theorem strict_discrete_unique (B : Fin 3 → Nat) (h : StrictAdmissible B) : B 1 = 1 := by
  obtain ⟨h0, h2, h01, h12⟩ := h; omega
end EvCore
