import Core.Final
/-! Core.GateLockGen — RUN-17 · DD-16-03: kapı-kilidinin GENEL biçimi (∀¬Transport),
    içsel-faz kümesine göre dört durum. Mevcut `cm_only_gate_locked` DEĞİŞTİRİLMEDEN korunur. -/
namespace EvCore
/-- Genel taşıma: içsel faz kümesi `nat` ile. -/
def TransportGen (nat : Phase → Bool) (a b : Phase) : Bool := GateRelated a b && nat a && nat b
/-- (i) Hiçbir fazda içsel değil ⇒ hiçbir kapıdan taşınmaz. -/
theorem never_native_locked (nat : Phase → Bool) (h : ∀ x, nat x = false) :
    ∀ a b, TransportGen nat a b = false := by
  intro a b; simp [TransportGen, h a]
/-- (ii) Tek fazda içsel ⇒ hiçbir kapıdan taşınmaz (kapı farklı fazları bağlar). -/
theorem single_native_locked (nat : Phase → Bool) (p : Phase) (h : ∀ x, nat x = true → x = p) :
    ∀ a b, TransportGen nat a b = false := by
  intro a b
  unfold TransportGen
  cases ha : nat a <;> cases hb : nat b <;> simp only [Bool.and_false, Bool.and_true]
  have e : a = b := (h a ha).trans (h b hb).symm
  subst e; exact gate_irrefl a
/-- (iii) Tam olarak iki fazda içsel ⇒ yalnız o iki faz arasında taşınır. -/
def natPair (p q : Phase) : Phase → Bool := fun x => x == p || x == q
theorem pair_transport_c0_Cm :
    TransportGen (natPair .c0 .Cm) .c0 .Cm = true ∧ TransportGen (natPair .c0 .Cm) .c0 .cp = false ∧
    TransportGen (natPair .c0 .Cm) .Cm .cp = false := by decide
/-- (iv) Tüm fazlarda içsel ⇒ her kapıdan taşınır. -/
theorem all_native_crosses (nat : Phase → Bool) (h : ∀ x, nat x = true) :
    ∀ a b, TransportGen nat a b = GateRelated a b := by
  intro a b; simp [TransportGen, h a, h b]
/-- Üretim tanımı genel biçimin özel hâlidir. -/
theorem transport_is_gen (q : QuantityKind) (a b : Phase) :
    TransportPermission q a b = TransportGen (NativeOK q) a b := rfl
end EvCore
