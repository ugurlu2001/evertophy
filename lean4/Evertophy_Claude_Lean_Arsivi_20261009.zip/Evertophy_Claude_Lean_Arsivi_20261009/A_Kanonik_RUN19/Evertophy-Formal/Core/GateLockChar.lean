import Core.GateLockGen
/-! Core.GateLockChar — RUN-18 · DD D-04 / Wolfram Tur-17 §5 tam karakterizasyon:
    tam-K3 altında GateLocked(nat) := ∀ a b, ¬Transport ⟺ içsel faz kümesi en fazla BİR eleman.
    + N_arşiv: salt-ekleme kayıt sayısının KAYNAK SIRASINDA monotonluğu (fiziksel zaman türevi DEĞİL). -/
namespace EvCore
def GateLocked (nat : Phase → Bool) : Prop := ∀ a b, TransportGen nat a b = false
/-- |NativeSet| ≤ 1 (Finset'siz ifade). -/
def AtMostOneNative (nat : Phase → Bool) : Prop := ∀ x y, nat x = true → nat y = true → x = y

/-- 🎯 TAM KARAKTERİZASYON: kapı-kilidi ⟺ en fazla bir içsel faz. -/
theorem gate_locked_iff_at_most_one (nat : Phase → Bool) :
    GateLocked nat ↔ AtMostOneNative nat := by
  constructor
  · intro h x y hx hy
    have h' := h x y
    simp only [TransportGen, hx, hy, Bool.and_true] at h'
    cases x <;> cases y <;> simp_all [GateRelated]
  · intro h a b
    unfold TransportGen
    cases ha : nat a <;> cases hb : nat b <;> simp only [Bool.and_false, Bool.and_true]
    have e : a = b := h a b ha hb
    subst e; exact gate_irrefl a

/-- Eski GT-1 "tanık varlığı" biçimi GENEL olarak yanlış: boş içsel küme kilitli ama tanık yok. -/
theorem empty_native_locked_without_witness :
    GateLocked (fun _ => false) ∧ ∀ a : Phase, ((fun _ : Phase => false) a = true → False) := by
  refine ⟨fun a b => by simp [TransportGen], ?_⟩
  intro a h; simp at h
/-- İki içsel faz: tanık var (c₀→c⁺) ama kilit YOK (c₀→Cₘ geçer) — eski biçimin ikinci karşı-örneği. -/
theorem pair_has_witness_but_not_locked :
    ¬ GateLocked (natPair .c0 .Cm) := by
  intro h; have := h .c0 .Cm; simp [TransportGen, natPair, GateRelated] at this

/-! ## N_arşiv — salt-ekleme ham kayıt önekinin uzunluğu (kaynak indeksinde) -/
def N_archive {α : Type} (log : List α) : Nat := log.length
theorem N_archive_append_mono {α : Type} (log : List α) (r : α) :
    N_archive log ≤ N_archive (log ++ [r]) := by
  simp [N_archive]
theorem N_archive_strict {α : Type} (log : List α) (r : α) :
    N_archive (log ++ [r]) = N_archive log + 1 := by
  simp [N_archive]
end EvCore
