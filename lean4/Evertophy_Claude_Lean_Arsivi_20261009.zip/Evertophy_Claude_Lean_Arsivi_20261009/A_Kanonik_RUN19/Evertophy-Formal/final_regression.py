#!/usr/bin/env python3
"""RUN-14 · SON REGRESYON (ChatGPT Tur-13 §21 A–G). Her madde kaynaktan/derlemeden doğrulanır."""
import re, subprocess, pathlib, sys, os, shutil
def g1_ok(readme="README_BUILD.md"):
    t = open(readme, encoding="utf-8").read()
    return "import Core.Production" in t and "import Core.GateLockChar" in t   # temel + tam yığın
if "--g1-only" in sys.argv:
    ok = g1_ok(); print("G1", "GEÇTİ" if ok else "KALDI"); sys.exit(0 if ok else 1)
def src(*g): return "\n".join(p.read_text(encoding="utf-8") for pat in g for p in pathlib.Path(".").glob(pat))
core, arch = src("Core/*.lean"), src("Evertophy/*.lean","V03/*.lean","V24/*.lean","Claude/*.lean")   # RUN-19: Claude/ dahil (DD)
has = lambda s, name: re.search(rf"^(private )?theorem {re.escape(name)}\b", s, re.M) is not None
def lake(*t):
    """Üç durum (Kimi v2 şeması): 0=GEÇTİ · ≠0=KALDI · None=ATLANDI (lake yok; ASLA PASS sayılmaz)."""
    if shutil.which("lake") is None: return None
    try: return subprocess.run(["lake","build",*t],capture_output=True,text=True,timeout=900).returncode
    except subprocess.TimeoutExpired: return 1
PE, LE = lake(), lake("Evertophy","Claude","V03","V24")
iso = subprocess.run([sys.executable,"check_production_isolation.py"],capture_output=True,text=True).returncode==0
lake = open("lakefile.lean").read()
checks = {
 "A1 varsayılan hedef = Core": bool(re.search(r"@\[default_target\]\s*lean_lib «Core»", lake)),
 "A2 Core eski içe aktarım/sembol içermez (CI)": iso,
 "A3 üretim derlemesi (GERÇEK lake build)": PE == 0,
 "A4 arşiv derlemesi (GERÇEK lake build)": LE == 0,
 "B1 Kapı = tam K3": has(core,"gate_full_K3"),
 "B2 TransportPermission ayrı": has(core,"transport_separate_from_gate"),
 "B3 taşıma ≠ kaynak→okuma (§7)": has(core,"transport_is_not_readout"),
 "B4 Cₘ-yalnız metrik": has(core,"metric_only_Cm"),
 "B5 c₀ tanımsız / c⁺ çözünmüş": has(core,"c0_undefined") and has(core,"cp_dissolved"),
 "B6 K2 etiket ≠ durgun kütle": has(core,"K2_as_label_only"),
 "B7 Uₓ kutup değil": has(core,"Ux_not_pole"),
 "B8 rol tipleri + tipli CmReadout": "structure ObservationPhase" in core and "def CmReadout" in core,
 "C1 Band toplama/negatif/kesişim/çarpım": all(has(core,n) for n in ["add_sound","neg_sound","inter_sound","mul_sound"]),
 "C2 ters için sıfır-dışlama": has(core,"zero_band_not_invertible"),
 "C3 boş kesişim ≠ [0,0] · +∞ ≠ yokluk": has(core,"empty_ne_zero_band") and has(core,"posInf_is_present"),
 "C4 MissingData epistemik (ayrı tip)": "inductive Knowledge" in core and "inductive OntoAbsence | preAdmissible | dissolved" in core,
 "D1 A_min köprü tekil-olmama": has(arch,"bridge_non_uniqueness") and has(arch,"A_does_not_entail_uniqueness"),
 "D2 oyuncak seçiciler OYUNCAK olarak etiketli": "OYUNCAK" in core,
 "E1 damga: birleşme+UN+CR+idempotent": all(has(arch,n) for n in ["mulW_assoc","unique_normal_form","church_rosser","idempotent_iff"]),
 "E2 TracePolicy ayrı + EventKind": has(core,"trace_not_derived_from_dissolution") and has(core,"trace_uses_eventkind"),
 "F1 sorry/admit/axiom = 0": not re.search(r"\bsorry\b|\badmit\b|^axiom ", core+arch, re.M),
 "G1 README kanonik içe aktarım (temel + tam yığın)": g1_ok(),
 "H1 Cₘ-yalnız nicelikler kapı-kilitli (Kimi V77-5)": has(core,"cm_only_gate_locked") and has(core,"gate_lock_does_not_block_readout"),
 "H2 CmOnlyBand Core'da": "abbrev CmOnlyBand" in core,
 "H3 TracePolicy SourcePhase sarmalayıcısı": has(core,"traceS_not_derived_from_dissolution"),
 "H4 X meta-geçişi ≠ fiziksel taşıma": has(core,"meta_cross_not_physical_transport"),
 "H5 kapı-kilidi genel biçim (DD-16-03)": all(has(core,n) for n in ["never_native_locked","single_native_locked","pair_transport_c0_Cm","all_native_crosses","transport_is_gen"]),
 "H7 kapı-kilidi TAM karakterizasyon ⟺ |içsel|≤1 + eski GT-1 karşı-örnekleri": all(has(core,n) for n in ["gate_locked_iff_at_most_one","empty_native_locked_without_witness","pair_has_witness_but_not_locked"]),
 "H8 N_arşiv kaynak-indeksi monotonluğu": has(core,"N_archive_append_mono") and has(core,"N_archive_strict"),
 "H9 regresyon NEGATİF testi — bozuk README → G1 KALDI": subprocess.run([sys.executable,"test_regression_negative.py"],capture_output=True).returncode==0,
 "H6 izolasyon v2.1 DAVRANIŞ testi — 14 vakalık düşman matrisi gerçekten koşulur": subprocess.run([sys.executable,"test_isolation_adversarial.py"],capture_output=True).returncode==0,
}
w=max(len(k) for k in checks)
for tag,val in [("A3 üretim derlemesi (GERÇEK lake build)",PE),("A4 arşiv derlemesi (GERÇEK lake build)",LE)]:
    if val is None: checks[tag]="SKIP"
for k,v in checks.items(): print(("⚠️  ATLANDI (lake yok) " if v=="SKIP" else ("✅  " if v else "❌  "))+k)
real={k:v for k,v in checks.items() if v!="SKIP"}; n=sum(bool(v) for v in real.values())
sk=len(checks)-len(real); print(f"\nSONUÇ: {n}/{len(real)} GERÇEK KONTROL GEÇTİ"+(f" · {sk} ATLANDI" if sk else ""))
sys.exit(0 if n==len(real) else 1)
