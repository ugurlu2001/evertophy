/-! V03.Interval — I(ℚ) interval monoid.
    🔴 FABLE BULGUSU: Float KULLANILMAZ — birleşme yuvarlamada BOZULUYOR.
    Kesin aritmetik (Int pay/payda) zorunlu. -/
namespace V03

/-- Aralık: tam sayı ölçekli (payda sabit) — kesin aritmetik. -/
structure Ivl where
  lo : Int
  hi : Int
deriving DecidableEq, Repr

def Ivl.wf (I : Ivl) : Bool := I.lo ≤ I.hi
def Ivl.add (A B : Ivl) : Ivl := Ivl.mk (A.lo + B.lo) (A.hi + B.hi)
def Ivl.zero : Ivl := Ivl.mk 0 0

/-- Birleşme — KESİN aritmetikte teorem (Float'ta DEĞİL). -/
theorem add_assoc (A B C : Ivl) :
    (A.add B).add C = A.add (B.add C) := by
  simp [Ivl.add, Int.add_assoc]

theorem add_comm (A B : Ivl) : A.add B = B.add A := by
  simp [Ivl.add, Int.add_comm]

theorem add_zero (A : Ivl) : A.add Ivl.zero = A := by
  simp [Ivl.add, Ivl.zero]

theorem zero_add (A : Ivl) : Ivl.zero.add A = A := by
  simp [Ivl.add, Ivl.zero]

/-- 🔴 ZORUNLULUK: K ⊕ K = K  ⟹  K = [0,0]. Tek çözüm. -/
theorem idempotent_forces_zero (K : Ivl) (h : K.add K = K) : K = Ivl.zero := by
  cases K with
  | mk lo hi =>
    simp [Ivl.add, Ivl.zero, Ivl.mk.injEq] at h ⊢
    omega

/-- Ω_char(κ) = [0,0] — cebirsel birim, fiziksel kilit DEĞİL. -/
def Omega_char_kappa : Ivl := Ivl.zero
theorem omega_kappa_is_zero : Omega_char_kappa = Ivl.zero := rfl

/-- Π_κ AYRI nesnedir: bant üzerine projektör. Ω_char=[0,0] onu ETKİSİZ KILMAZ. -/
structure BandProjector where
  apply : Ivl → Ivl
def Pi_kappa_nontrivial (P : BandProjector) (B : Ivl) : Prop := P.apply B ≠ B

end V03
