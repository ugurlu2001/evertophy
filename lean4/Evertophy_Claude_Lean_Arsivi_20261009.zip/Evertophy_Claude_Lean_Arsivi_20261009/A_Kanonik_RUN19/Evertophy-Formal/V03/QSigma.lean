import V03.StampSpec
/-! V03.QSigma — q (damgaları unutan funktör) ve Σ (damga funktörü)
    minor16/546.5 guard yapısı, build-certified. -/
namespace V03

inductive Ph | c0 | Cm | cp
deriving DecidableEq, Repr

/-- P0-1: TAM ÜÇGEN — üç kenar gate düzeyinde çift yönlü. -/
def related : Ph → Ph → Bool
  | .c0, .Cm => true | .Cm, .c0 => true
  | .Cm, .cp => true | .cp, .Cm => true
  | .c0, .cp => true | .cp, .c0 => true
  | _, _ => false

theorem triangle_full_c0cp : related .c0 .cp = true := by decide
theorem triangle_symmetric : ∀ a b : Ph, related a b = related b a := by
  intro a b; cases a <;> cases b <;> rfl

/-- Δ₀₊ DAMGA ÜRETMEZ (minor16/545.3 kenar stratifikasyonu). -/
def stampOf : Ph → Ph → Option Gen
  | .c0, .Cm => some Gen.k0m
  | .cp, .Cm => some Gen.kpm
  | .c0, .cp => none          -- Σ(T₀₊) = e
  | .cp, .c0 => none
  | _, _ => none

theorem sigma_T0p_is_identity : stampOf .c0 .cp = none := by decide
theorem sigma_Tp0_is_identity : stampOf .cp .c0 = none := by decide
theorem sigma_T0m_stamps : stampOf .c0 .Cm = some Gen.k0m := by decide

/-- q: damgaları unutur; çıplak groupoid'de ters YÖN-TERSİ. -/
def qBare (a b : Ph) : Bool := related a b
theorem q_inverse_is_reverse : ∀ a b : Ph, qBare a b = qBare b a := by
  intro a b; cases a <;> cases b <;> rfl

/-- ClockStatus + TemporalRole (minor19/564.1) -/
inductive Clock | timeless | emergent
deriving DecidableEq, Repr
inductive TRole | preEmergent | physicalTime | atemporalRecord
deriving DecidableEq, Repr

def clockOf : Ph → Clock
  | .c0 => .timeless | .Cm => .emergent | .cp => .timeless
def troleOf : Ph → TRole
  | .c0 => .preEmergent | .Cm => .physicalTime | .cp => .atemporalRecord

theorem clock_same_c0_cp : clockOf .c0 = clockOf .cp := by decide
theorem trole_differs_c0_cp : troleOf .c0 ≠ troleOf .cp := by decide

/-- U₀ faz nesnesi DEĞİL (P0-2) -/
def generatedByU0 : Ph → Bool | _ => true
theorem U0_generates_all : generatedByU0 .c0 ∧ generatedByU0 .Cm ∧ generatedByU0 .cp :=
  ⟨rfl, rfl, rfl⟩

end V03
