import V03.StampSpec
import V03.Interval
/-! V03.Archive — İKİ KATMANLI ARŞİV (minor17/552 + minor19/563.4)
    Ham arşiv: Record-ID, salt-ekleme, SİLME PRİMİTİFİ YOK, İPTALCİL.
    M: ham arşivin KABA PROJEKSİYONU (idempotent kilitler burada). -/
namespace V03

/-- P0-4 RANGE-SAFE SEALING: payload BANT kalır, p⁻=p⁺ ZORLANMAZ. -/
structure Record where
  rid     : Nat          -- tekil kimlik
  payload : Ivl          -- BANT (nokta değil)
  stamp   : Gen
  srcCm   : Bool         -- provenance: Cₘ-kökenli mi
deriving Repr

abbrev Archive := List Record

/-- Salt-ekleme. SİLME PRİMİTİFİ TANIMLI DEĞİL. -/
def append (A : Archive) (r : Record) : Archive := A ++ [r]

/-- Kayıt sadakati: r₁r₂ ≠ r₁ (idempotent DEĞİL). -/
theorem archive_faithful (A : Archive) (r : Record) :
    (append A r).length = A.length + 1 := by simp [append]

theorem archive_not_idempotent (A : Archive) (r : Record) :
    (append (append A r) r).length ≠ (append A r).length := by
  simp [append]

/-- π_stamp: ham arşiv → M (KABA projeksiyon). Burada idempotent yaşar. -/
def piStamp (A : Archive) : Word := normalize (A.map Record.stamp)

theorem piStamp_collapses_repeats :
    piStamp [⟨1, Ivl.mk 0 2, Gen.k0m, true⟩, ⟨2, Ivl.mk 0 3, Gen.k0m, true⟩] = [Gen.k0m] := by
  decide

/-- Range-safe seal: bant KORUNUR. -/
def sealRec (rid : Nat) (band : Ivl) (st : Gen) : Record :=
  ⟨rid, band, st, true⟩

theorem sealRec_preserves_band (rid : Nat) (b : Ivl) (st : Gen) :
    (sealRec rid b st).payload = b := rfl

theorem sealRec_does_not_collapse :
    (sealRec 1 (Ivl.mk 0 5) Gen.k0m).payload ≠ Ivl.zero := by decide

end V03
