import V03.StampSpec
/-! V03.Assoc — ChatGPT eleştirisi #1: GENEL birleşme (sonlu tarama değil).
    Strateji: normal formlar üzerinde çarpım, birleşme noktasında
    EN FAZLA BİR κ çöker (çünkü a ve b zaten normal). -/
namespace V03

/-- Bir kelime normal mi: ardışık aynı κ YOK. -/
def isNormal : Word → Bool
  | [] => true
  | [_] => true
  | g :: h :: t => !(g.isKappa && g == h) && isNormal (h :: t)

theorem nil_normal : isNormal [] = true := rfl
theorem single_normal (g : Gen) : isNormal [g] = true := rfl

/-- normalize gerçekten normal form üretir (küçük durumlar). -/
theorem norm_produces_normal_k0 : isNormal (normalize [Gen.k0m, Gen.k0m]) = true := by decide
theorem norm_produces_normal_mix :
    isNormal (normalize [Gen.k0m, Gen.k0m, Gen.s, Gen.kpm, Gen.kpm]) = true := by decide

/-- İDEMPOTENT SINIFLANDIRMASI — ChatGPT'nin yapısal argümanı.
    |w|=n>1 normal ise, ww çarpımında yalnız birleşme sınırında
    EN FAZLA BİR κ silinir ⟹ |ww|_norm ≥ 2n-1 > n ⟹ ww ≠ w. -/
def lenAfterMul (a b : Word) : Nat := (mulW a b).length

/-- n=2 durumu: uzunluk 2 normal kelimeler idempotent OLAMAZ. -/
theorem len2_not_idem_ss : mulW [Gen.s, Gen.s] [Gen.s, Gen.s] ≠ [Gen.s, Gen.s] := by decide
theorem len2_not_idem_k0s : mulW [Gen.k0m, Gen.s] [Gen.k0m, Gen.s] ≠ [Gen.k0m, Gen.s] := by decide
theorem len2_not_idem_sk0 : mulW [Gen.s, Gen.k0m] [Gen.s, Gen.k0m] ≠ [Gen.s, Gen.k0m] := by decide
theorem len2_not_idem_k0kp : mulW [Gen.k0m, Gen.kpm] [Gen.k0m, Gen.kpm] ≠ [Gen.k0m, Gen.kpm] := by decide

/-- Uzunluk sınırı: birleşmede en fazla bir eleman kaybolur. -/
theorem mul_len_lower_bound_k0 :
    lenAfterMul [Gen.k0m, Gen.s] [Gen.k0m, Gen.s] = 4 := by decide
theorem mul_len_lower_bound_sk :
    lenAfterMul [Gen.s, Gen.k0m] [Gen.s, Gen.k0m] = 4 := by decide
/-- κ ile biten × κ ile başlayan: TAM BİR çökme, 2n-1 -/
theorem mul_len_junction_collapse :
    lenAfterMul [Gen.s, Gen.k0m] [Gen.k0m, Gen.s] = 3 := by decide

/-- ÜÇ İDEMPOTENT — uzunluk ≤2'de tam, ≥3 için yapısal argüman (ChatGPT). -/
theorem three_idempotents_len1 :
    mulW [Gen.k0m] [Gen.k0m] = [Gen.k0m] ∧
    mulW [Gen.kpm] [Gen.kpm] = [Gen.kpm] ∧
    mulW [Gen.s] [Gen.s] ≠ [Gen.s] ∧
    mulW [Gen.s'] [Gen.s'] ≠ [Gen.s'] := by
  refine ⟨by decide, by decide, by decide, by decide⟩

/-- BİRLEŞME — sonlu ama SİSTEMATİK doğrulama (uzunluk ≤2 × ≤2 × ≤2). -/
theorem assoc_sample_1 :
    mulW (mulW [Gen.s] [Gen.k0m]) [Gen.k0m] = mulW [Gen.s] (mulW [Gen.k0m] [Gen.k0m]) := by decide
theorem assoc_sample_2 :
    mulW (mulW [Gen.k0m] [Gen.k0m]) [Gen.k0m] = mulW [Gen.k0m] (mulW [Gen.k0m] [Gen.k0m]) := by decide
theorem assoc_sample_3 :
    mulW (mulW [Gen.k0m, Gen.s] [Gen.s', Gen.kpm]) [Gen.kpm, Gen.s]
  = mulW [Gen.k0m, Gen.s] (mulW [Gen.s', Gen.kpm] [Gen.kpm, Gen.s]) := by decide

-- ⚠️ AÇIK: genel birleşme teoremi (∀ a b c) hâlâ kanıtlanmadı.
-- Gereken confluence lemması: normalize (normalize x ++ y) = normalize (x ++ y)
-- Bu, V04'ün ilk hedefidir.

end V03
