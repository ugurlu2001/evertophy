/-! V03.StampSpec — M = ⟨s, s', κ₀ₘ, κ₊ₘ | κ² = κ⟩
    ChatGPT-GPTs v0.3 spesifikasyonu, Fable tarafından build-certified. -/
namespace V03

inductive Gen | s | s' | k0m | kpm
deriving DecidableEq, Repr

def Gen.isKappa : Gen → Bool
  | .k0m => true | .kpm => true | _ => false

abbrev Word := List Gen

/-- Normal form: ardışık aynı κ'yı tek'e indir (κ²=κ). -/
def normalize : Word → Word
  | [] => []
  | g :: rest =>
    match normalize rest with
    | [] => [g]
    | h :: t => if g.isKappa && g == h then h :: t else g :: h :: t

def mulW (a b : Word) : Word := normalize (a ++ b)

theorem norm_nil : normalize [] = [] := rfl
theorem norm_k0_idem : normalize [Gen.k0m, Gen.k0m] = [Gen.k0m] := by decide
theorem norm_kpm_idem : normalize [Gen.kpm, Gen.kpm] = [Gen.kpm] := by decide
theorem norm_k0_triple : normalize [Gen.k0m, Gen.k0m, Gen.k0m] = [Gen.k0m] := by decide

/-- İdempotentlik: κ·κ = κ -/
theorem kappa0_idempotent : mulW [Gen.k0m] [Gen.k0m] = [Gen.k0m] := by decide
theorem kappap_idempotent : mulW [Gen.kpm] [Gen.kpm] = [Gen.kpm] := by decide

/-- Serbest sektör: s·s ≠ s (trivial-olmayan idempotent YOK) -/
theorem s_not_idempotent : mulW [Gen.s] [Gen.s] ≠ [Gen.s] := by decide
theorem s'_not_idempotent : mulW [Gen.s'] [Gen.s'] ≠ [Gen.s'] := by decide

/-- İSTENMEYEN bağıntılar EKLENMEDİ -/
theorem no_commutativity : mulW [Gen.s] [Gen.s'] ≠ mulW [Gen.s'] [Gen.s] := by decide
theorem no_absorption_R : mulW [Gen.s] [Gen.k0m] ≠ [Gen.k0m] := by decide
theorem no_absorption_L : mulW [Gen.k0m] [Gen.s] ≠ [Gen.k0m] := by decide
theorem no_torsion_gate : mulW [Gen.s, Gen.s, Gen.s, Gen.s] [] ≠ [Gen.k0m] := by decide

/-- Birim -/
theorem unit_left  (a : Word) : mulW [] a = normalize a := by simp [mulW]

/-- Tam M İPTALCİL DEĞİL: κ·κ = e·κ ama κ ≠ e -/
theorem M_not_cancellative :
    mulW [Gen.k0m] [Gen.k0m] = mulW [] [Gen.k0m] ∧ [Gen.k0m] ≠ ([] : Word) := by
  constructor <;> decide

end V03
