#!/usr/bin/env python3
"""RUN-19 · İzolasyon denetimi v2.1 — ORTAK SÖZCÜK ÇÖZÜMLEYİCİ (DD Tur-18 A/B/C + Kimi vaka-9 onarımı).
Lexer (lakefile ve Lean için aynı):
  • iç içe blok yorum /- -/ ve satır yorumu --  → BOŞLUKLA değiştirilir (token birleşmesi olmaz: B)
  • string "..." (kaçış \\") ve karakter 'x' / '\\x' içeriği boşaltılır (string içindeki /- yorum sayılmaz: C)
  • kapanmamış blok yorum ya da string → BAŞARISIZ (geçersiz kaynak temiz sayılmaz: D)
Hedef: lakefile YORUMLARDAN ARINDIRILDIKTAN SONRA «Core» aranır; birden fazla «Core» → BAŞARISIZ (A).
Kapanış: köklerden GEÇİŞLİ; satırdaki TÜM modüller; yalnız Core.* izinli; eski önek/eksik modül → ihlal."""
import re, sys, pathlib
ROOT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(".")
LEGACY = ("Evertophy.", "V03.", "V24.", "Claude.")
SYMS = [r"\badjacent\b", r"\bK2_cp_mass\b", r"\bGlobalPole\b", r"\bmetricOK\b", r"\bFloat\b", r"\bIvl\b", r"\bQty\b"]
class LexError(Exception): pass
def lex(txt):
    out, i, n, depth, in_str = [], 0, len(txt), 0, False
    blank = lambda ch: "\n" if ch == "\n" else " "
    while i < n:
        c = txt[i]
        if in_str:
            if c == "\\" and i + 1 < n: out.append("  "); i += 2; continue
            if c == '"': in_str = False
            out.append(blank(c)); i += 1; continue
        if txt.startswith("/-", i): depth += 1; out.append("  "); i += 2; continue
        if depth:
            if txt.startswith("-/", i): depth -= 1; out.append("  "); i += 2; continue
            out.append(blank(c)); i += 1; continue
        if txt.startswith("--", i):
            j = txt.find("\n", i); j = n if j < 0 else j
            out.append(" " * (j - i)); i = j; continue
        if c == '"': in_str = True; out.append(" "); i += 1; continue
        if c == "'" and i + 3 < n and txt[i+1] == "\\" and txt[i+3] == "'": out.append("    "); i += 4; continue
        if c == "'" and i + 2 < n and txt[i+2] == "'" and txt[i+1] not in "'\n": out.append("   "); i += 3; continue
        out.append(c); i += 1
    if depth: raise LexError("kapanmamış blok yorum")
    if in_str: raise LexError("kapanmamış string")
    return "".join(out)
def fail(msg, code=2): print("BAŞARISIZ: " + msg); sys.exit(code)
lf = ROOT / "lakefile.lean"
if not lf.exists(): fail("lakefile.lean yok — denetlenemedi")
try: lake = lex(lf.read_text(encoding="utf-8"))
except LexError as e: fail(f"lakefile ayrıştırılamadı ({e})")
libs = re.findall(r"lean_lib\s+«Core»\s+where\s+roots\s*:=\s*#\[([^\]]*)\]", lake)
if len(libs) == 0: fail("«Core» hedefi/kökleri bulunamadı (yorumlar hariç)")
if len(libs) > 1: fail(f"birden fazla «Core» hedefi ({len(libs)}) — belirsiz")
roots = re.findall(r"`([\w.]+)", libs[0])
if not roots: fail("kök listesi boş")
bad, seen, stack = [], set(), list(roots)
while stack:
    mod = stack.pop()
    if mod in seen: continue
    seen.add(mod)
    if mod.startswith(LEGACY) or mod.split(".")[0] + "." in LEGACY: bad.append(f"ESKİ MODÜL kapanışta: {mod}"); continue
    if not mod.startswith("Core."): bad.append(f"İZİNSİZ MODÜL kapanışta: {mod}"); continue
    p = ROOT / (mod.replace(".", "/") + ".lean")
    if not p.exists(): bad.append(f"BULUNAMAYAN MODÜL: {mod}"); continue
    try: code = lex(p.read_text(encoding="utf-8"))
    except LexError as e: bad.append(f"{p.relative_to(ROOT)}: AYRIŞTIRILAMADI ({e})"); continue
    for line in code.splitlines():
        im = re.match(r"\s*import\s+(.+)", line)
        if im: stack.extend(im.group(1).split())
    for ln, line in enumerate(code.splitlines(), 1):
        for s in SYMS:
            if re.search(s, line): bad.append(f"{p.relative_to(ROOT)}:{ln} ESKİ SEMBOL {s}")
if bad: print("\n".join(sorted(set(bad)))); sys.exit(1)
print(f"ÜRETİM İZOLASYONU: TEMİZ — {len(seen)} modül (geçişli kapanış), 0 eski içe aktarım, 0 eski sembol")
sys.exit(0)
