# Evertophy-Formal — RUN-19
## Kanonik içe aktarım (ÜRETİM, namespace EvCore — eski API yok)
Temel semantik: `import Core.Production`
Tam üretim yığını: `import Core.GateLockChar` (Production → Extended → Roles → GateLock → Final → GateLockGen → GateLockChar)
## Derleme
`lake build` (varsayılan = Core) · Lean 4.12.0 · Mathlib GEREKMEZ · Üretim 46 · Arşiv 223 · Toplam 269 · sorry/admit/axiom 0
Arşiv: `lake build Evertophy Claude V03 V24`
## Güvence araçları
İzolasyon v2.1: `python3 check_production_isolation.py` — ortak lexer (string/karakter farkında, yorumlar boşlukla), lakefile yorumlardan arındırılır, kapanmamış yorum/string BAŞARISIZ
Düşman matrisi: `python3 test_isolation_adversarial.py` (14/14)
Regresyon: `python3 final_regression.py` — gerçek lake build; Lean yoksa A3/A4 ATLANDI (başarı sayılmaz)
Regresyon negatif testi: `python3 test_regression_negative.py` (bozuk README → G1 KALDI)
U40: `U40_RUN14/` — U40-A (aynı Lean-bacağında temiz-oda) KAPALI · U40-B (farklı makine/sağlayıcı) İSTEĞE BAĞLI
## Sıra kuralı
Tüm dosyalar YAZILDIKTAN SONRA regresyon; regresyondan SONRA manifest ve ZIP.
