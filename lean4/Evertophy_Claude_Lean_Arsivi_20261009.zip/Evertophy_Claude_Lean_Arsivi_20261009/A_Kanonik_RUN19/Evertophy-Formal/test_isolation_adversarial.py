#!/usr/bin/env python3
"""RUN-19 · DD D-01 + Tur-18 delta düşman-test matrisi (14 vaka) — izolasyon denetleyicisi için YENİDEN KOŞULABİLİR negatif testler.
Her bacak kendi ortamında: `python3 test_isolation_adversarial.py` → 14/14 beklenir."""
import subprocess, pathlib, shutil, sys, tempfile
CHK = pathlib.Path(__file__).resolve().parent / "check_production_isolation.py"
LF = 'lean_lib «Core» where\n  roots := #[`Core.Production]\n'
CASES = {
 "Temiz Core":                    ({"Core/Production.lean":"def a := 1\n"}, True),
 "import V24.Global":             ({"Core/Production.lean":"import V24.Global\n"}, False),
 "/- yorum -/ import V24.Global": ({"Core/Production.lean":"/- yorum -/ import V24.Global\n"}, False),
 "import Core.Good V24.Global":   ({"Core/Production.lean":"import Core.Good V24.Global\n","Core/Good.lean":"def g := 1\n"}, False),
 "Core→Helpers.Bridge→V24":       ({"Core/Production.lean":"import Helpers.Bridge\n","Helpers/Bridge.lean":"import V24.Global\n"}, False),
 "Core klasörü yok":              ({}, False),
 "Noktasız kök: import V24":       ({"Core/Production.lean":"import V24\n"}, False),
 "Eski sembol yalnız yorumda":     ({"Core/Production.lean":"-- Float adjacent\n/- metricOK -/\ndef a := 1\n"}, True),
 "import yalnız blok yorumda":     ({"Core/Production.lean":"/- import V24.Global -/\ndef a := 1\n"}, True),
 "String içinde --":               ({"Core/Production.lean":'def s : String := "a -- b"\ndef a := 1\n'}, True),
 "DD-A lakefile yorumunda sahte kök": ({"LAKE":"/- lean_lib «Core» where\n  roots := #[`Core.Good] -/\nlean_lib «Core» where\n  roots := #[`Core.Main]\n","Core/Good.lean":"def g := 1\n","Core/Main.lean":"import V24.Global\n"}, False),
 "DD-B boş yorumla birleşen token":  ({"Core/Production.lean":"import/--/V24.Global\n"}, False),
 "DD-C string içinde /- sonra Float": ({"Core/Production.lean":'def marker : String := "/-"\ndef value : Float := 1\n'}, False),
 "Kimi-9 kapanmamış blok yorum":     ({"Core/Production.lean":"def a := 1\n/- açık\nimport V24.Global\n"}, False),
}
ok = 0
for name,(files,should_pass) in CASES.items():
    d = pathlib.Path(tempfile.mkdtemp())
    (d/"lakefile.lean").write_text(files.get("LAKE", LF))
    for f,c in files.items():
        if f == "LAKE": continue
        (d/f).parent.mkdir(parents=True,exist_ok=True); (d/f).write_text(c)
    passed = subprocess.run([sys.executable,str(CHK),str(d)],capture_output=True).returncode == 0
    good = passed == should_pass; ok += good
    print(f"{'✅' if good else '❌'}  {name:34} beklenen={'GEÇ' if should_pass else 'RED'}  gerçek={'GEÇ' if passed else 'RED'}")
    shutil.rmtree(d)
print(f"\nDÜŞMAN-TEST MATRİSİ: {ok}/{len(CASES)}"); sys.exit(0 if ok==len(CASES) else 1)
