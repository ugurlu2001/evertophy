import V24.Production
/-! V24.BridgeNoGo — RUN-09:
  (1) Yokluk-nedeni KORUYAN Cₘ-okuma köprüsü (ChatGPT Tur-08 §3: Option c₀/c⁺ farkını siliyordu).
  (2) KÖPRÜ TEKİL-OLMAMA: dondurulmuş minimal kabul-edilebilirlik aksiyom kümesi A altında
      iki FARKLI köprü A'yı sağlar ⇒ A tek fiziksel köprüyü GEREKTİRMEZ. -/
namespace V24B
open Evertophy V24Ty V24Prod

/-- (1) Neden-koruyan okuma köprüsü: çıktı faz-indeksli; Option yok. -/
structure CmReadoutBridgeR (Ctx Out : Type) where
  bridge : (p : Phase) → Ctx → CmOnlyValue Out p
/-- c₀ ve c⁺ çıktıları yapısal olarak FARKLI kurucular — neden silinmez. -/
theorem reasons_preserved {C O : Type} (B : CmReadoutBridgeR C O) (c : C) :
    B.bridge .c0 c = .undefined0 ∧ B.bridge .cp c = .dissolvedPlus :=
  ⟨c0_is_undefined _, cp_is_dissolved _⟩

/-! (2) Dondurulmuş minimal aksiyom kümesi A (ayrık oyuncak alan {0,1,2} → Band [0,2]):
    A1 tip: Fin 3 → Nat · A2 Range: değerler [0,2] içinde · A3 uç noktalar: B 0 = 0, B 2 = 2
    A4 monotonluk · A5 her girdide tek çıktı (fonksiyon olmak — otomatik). -/
def Admissible (B : Fin 3 → Nat) : Prop :=
  (∀ i, B i ≤ 2) ∧ B 0 = 0 ∧ B 2 = 2 ∧ (B 0 ≤ B 1 ∧ B 1 ≤ B 2)
instance (B : Fin 3 → Nat) : Decidable (Admissible B) := by unfold Admissible; infer_instance
def B1 : Fin 3 → Nat := fun i => i.val          -- doğrusal köprü
def B2 : Fin 3 → Nat := fun i => if i.val = 0 then 0 else 2   -- doygunluklu köprü
theorem B1_admissible : Admissible B1 := by decide
theorem B2_admissible : Admissible B2 := by decide
theorem B1_ne_B2 : B1 ≠ B2 := by
  intro h; have := congrFun h 1; simp [B1, B2] at this
/-- 🎯 TEKİL-OLMAMA: A'yı sağlayan iki farklı köprü vardır ⇒ A, tekliği gerektirmez. -/
theorem bridge_non_uniqueness :
    ∃ Ba Bb : Fin 3 → Nat, Ba ≠ Bb ∧ Admissible Ba ∧ Admissible Bb :=
  ⟨B1, B2, B1_ne_B2, B1_admissible, B2_admissible⟩
/-- Sonuç: A'ya EK bir fiziksel seçim aksiyomu olmadan köprü belirlenmez. -/
theorem A_does_not_entail_uniqueness :
    ¬ (∀ Ba Bb : Fin 3 → Nat, Admissible Ba → Admissible Bb → Ba = Bb) := by
  intro h; exact B1_ne_B2 (h B1 B2 B1_admissible B2_admissible)
end V24B
