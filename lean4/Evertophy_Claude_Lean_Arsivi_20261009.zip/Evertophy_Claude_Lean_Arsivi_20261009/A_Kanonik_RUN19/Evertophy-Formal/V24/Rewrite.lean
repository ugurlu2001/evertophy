import V24.StampAssoc
/-! V24.Rewrite — RUN-06: yeniden-yazma İLİŞKİSİ düzeyinde terminasyon + tek normal form.
    Kural: u ++ [κ,κ] ++ v  →  u ++ [κ] ++ v   (κ ∈ {κ₀ₘ, κ₊ₘ}) -/
namespace V24R
open V03 V24S

/-- Tek adım yeniden-yazma. -/
inductive Step : Word → Word → Prop
  | collapse (u v : Word) (k : Gen) (hk : k.isKappa = true) :
      Step (u ++ k :: k :: v) (u ++ k :: v)

/-- Yansımalı-geçişli kapanış. -/
inductive Star : Word → Word → Prop
  | refl (w : Word) : Star w w
  | tail {a b c : Word} : Star a b → Step b c → Star a c

/-- 1) TERMİNASYON: her adım uzunluğu kesin azaltır. -/
theorem step_decreases {a b : Word} (h : Step a b) : b.length < a.length := by
  cases h; simp [List.length_append]

/-- 2) DEĞİŞMEZLİK: bir adım normal formu korur. -/
theorem step_preserves_normalize {a b : Word} (h : Step a b) : normalize a = normalize b := by
  cases h with
  | collapse u v k hk =>
    rw [normalize_eq_foldr, normalize_eq_foldr, List.foldr_append, List.foldr_append]
    show List.foldr step (step k (step k (List.foldr step [] v))) u
       = List.foldr step (step k (List.foldr step [] v)) u
    rw [step_idem k hk]

theorem star_preserves_normalize {a b : Word} (h : Star a b) : normalize a = normalize b := by
  induction h with
  | refl => rfl
  | tail _ hs ih => exact ih.trans (step_preserves_normalize hs)

/-- İndirgenemezlik: ardışık aynı κ yok. -/
def Irred : Word → Prop
  | [] => True
  | [_] => True
  | g :: h :: t => ¬ (g.isKappa = true ∧ g = h) ∧ Irred (h :: t)

/-- 3) İndirgenemez kelimeyi normalize değiştirmez. -/
theorem normalize_irred : ∀ w : Word, Irred w → normalize w = w
  | [], _ => rfl
  | [g], _ => by rw [normalize_cons]; rfl
  | g :: h :: t, hw => by
    have ih := normalize_irred (h :: t) hw.2
    rw [normalize_cons, ih, step_cons]
    have : ¬ ((g.isKappa && g == h) = true) := by
      intro hc; apply hw.1
      cases g <;> cases h <;> simp_all (config := {decide := true}) [Gen.isKappa]
    rw [if_neg this]

/-- 4) 🎯 TEK NORMAL FORM (UN): aynı kelimeden varılan iki indirgenemez kelime AYNIDIR. -/
theorem unique_normal_form {w a b : Word} (ha : Star w a) (hb : Star w b)
    (ia : Irred a) (ib : Irred b) : a = b := by
  have h1 := star_preserves_normalize ha
  have h2 := star_preserves_normalize hb
  rw [normalize_irred a ia] at h1; rw [normalize_irred b ib] at h2
  exact h1.symm.trans h2
end V24R
