/-! V24.Topology — RUN-04: Q4 düzeltmesi (ChatGPT S¹ karşı-örneği).
    Doğru (ℝ/aralık) üzerinde komşuluk YOL; çember (S¹) üzerinde ÇEVRİM = K3. -/
namespace V24T
/-- Doğrusal (ℝ, aralık) alan: yalnız ardışık havzalar komşu. -/
def adjLine : Fin 3 → Fin 3 → Bool := fun i j => (i.val + 1 == j.val) || (j.val + 1 == i.val)
/-- Çembersel (S¹) alan: ardışık + sarma komşuluğu. -/
def adjCircle : Fin 3 → Fin 3 → Bool := fun i j => i != j && (((i.val + 1) % 3 == j.val) || ((j.val + 1) % 3 == i.val))
theorem line_not_K3   : adjLine 0 2 = false := by decide
theorem circle_is_K3  : adjCircle 0 1 = true ∧ adjCircle 1 2 = true ∧ adjCircle 0 2 = true := by decide
/-- Morse: χ(disk)=1 (3 min − 3 eyer + 1 maks), χ(S¹)=0 (3 min − 3 maks). -/
def chi2 (m s M : Int) : Int := m - s + M
def chi1 (m M : Int) : Int := m - M
theorem disk_morse   : chi2 3 3 1 = 1 := by decide
theorem circle_morse : chi1 3 3 = 0 := by decide
/-- RUN-06 düzeltmesi: bu teorem YALNIZ Euler aritmetiğini kanıtlar (χ(S¹)=0, iç maksimumsuz
    disk sayımı χ≠1). "Çemberin iç bölgesi yoktur" ifadesi topolojik bir olgudur, bu teoremin
    içeriği DEĞİLDİR. Eski ad aşırı-iddiaydı (ChatGPT Tur-5). -/
theorem euler_circle_zero_disk_one : chi1 3 3 = 0 ∧ chi2 3 3 0 ≠ 1 := by decide
end V24T
