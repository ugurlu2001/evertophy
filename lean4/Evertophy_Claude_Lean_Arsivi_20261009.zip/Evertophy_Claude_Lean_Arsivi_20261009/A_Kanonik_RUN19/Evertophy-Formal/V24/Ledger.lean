import V24.Types
/-! V24.Ledger — RUN-10:
  (1) MissingData EPİSTEMİKTİR, ontolojik yokluk DEĞİLDİR (Tur-9 konsensüsü) — tip ayrımı.
  (2) Makine-okunur statü defteri: FORMAL_CORE / MODEL / BRIDGE / RETIRED / OPEN (ChatGPT Tur-9 görev 4). -/
namespace V24L
open Evertophy

/-! ## 1. Ontolojik yokluk TAM İKİ nedendir; veri eksikliği ayrı eksendir -/
inductive OntoAbsence | preAdmissible | dissolved  deriving DecidableEq, Repr
inductive EpistemicStatus | observed | missingData | imputed  deriving DecidableEq, Repr
/-- Ontolojik yokluk yalnız faza bağlıdır; veri durumundan bağımsızdır. -/
def ontoAbsenceOf : Phase → Option OntoAbsence
  | .c0 => some .preAdmissible | .Cm => none | .cp => some .dissolved
theorem exactly_two_onto_absences :
    ∀ a : OntoAbsence, a = .preAdmissible ∨ a = .dissolved := by intro a; cases a <;> simp
theorem Cm_has_no_onto_absence : ontoAbsenceOf .Cm = none := rfl
/-- Cₘ'de bir nicelik eksik veri olabilir — bu onu ontolojik olarak yok YAPMAZ. -/
theorem missing_data_not_absence :
    ontoAbsenceOf .Cm = none ∧ EpistemicStatus.missingData ≠ EpistemicStatus.observed := ⟨rfl, by decide⟩

/-! ## 2. Statü defteri -/
inductive Status | formalCore | model | bridge | retired | openItem  deriving DecidableEq, Repr
def ledger : List (String × Status) :=
  [ ("Phase≠GlobalNode, Ux kutup değil", .formalCore), ("c0 PreAdmissible ≠ c+ Dissolved", .formalCore)
  , ("CmOnlyValue faz-indeksli", .formalCore), ("Band lo≤hi + ExtBand", .formalCore)
  , ("Tipli Gate K3", .formalCore), ("Damga: birleşme+SN+UN+CR+idempotent", .formalCore)
  , ("TracePolicy ⟂ yokluk", .formalCore), ("Köprü tekil-olmama (A_min)", .formalCore)
  , ("det g = −(det E)²", .model), ("İdeal Gauss (3,3,1)/(4,3,0)/(1,0,0)", .model)
  , ("S¹ / disk peyzajı", .model), ("Sabit-nokta faz birlikteliği", .model)
  , ("FS/QSL zaman köprüsü", .bridge), ("η_clock Aralık köprüsü", .bridge), ("Aday A: Einstein/ADM + J_X", .bridge)
  , ("Tek ⊥", .retired), ("IOM sert red", .retired), ("Lojistik temel X", .retired)
  , ("Evrensel d_min≥2", .retired), ("a≤4 ⟺ tek kök", .retired), ("Dissolved ⇒ iz", .retired)
  , ("Fiziksel E_φ / J_X seçimi", .openItem), ("Okuma haritası", .openItem)
  , ("Metrik yeniden inşa", .openItem), ("Postüla-0 metriksiz taşıyıcı", .openItem)
  , ("Üç faz: ilkel mi türetilmiş mi", .openItem) ]
def count (s : Status) : Nat := (ledger.filter (fun e => e.2 == s)).length
/-- Hiçbir kalem iki statüde birden değil (her ad tekil). -/
theorem ledger_names_unique : (ledger.map Prod.fst).Nodup := by decide
theorem ledger_counts :
    count .formalCore = 8 ∧ count .model = 4 ∧ count .bridge = 3 ∧ count .retired = 6 ∧ count .openItem = 5 := by decide
end V24L
