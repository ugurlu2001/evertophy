import Evertophy.Phase
/-! V24.Absence — RUN-05: Uğur'un doğrudan girdisi (2026-09-24):
    "Zaman, 3B Öklid–düz uzay, c faz sınırı vb. temel tanımlar Cₘ'de geçerlidir.
     Bu yapılar c₀'da TANIMSIZ (yokluk c₀), c⁺'ta ÇÖZÜNMÜŞ (yokluk c⁺)."
    ⟹ Tek ⊥ yetmez: iki ontolojik olarak farklı yokluk. -/
namespace V24A
open Evertophy

/-- İki yokluk türü. -/
inductive Absence
  | undefined0      -- c₀: yapı henüz TANIMLANMAMIŞ (ön-doğuş)
  | dissolvedPlus   -- c⁺: yapı ÇÖZÜNMÜŞ (madde desteği kalktı)
  deriving DecidableEq, Repr

/-- Hücre değeri: tanımlı aralık · yokluk (türüyle) · olay gerçekleşmedi. -/
inductive CellV | defined | absent (a : Absence) | noEvent
  deriving DecidableEq, Repr

/-- Cₘ'nin temel yapıları. -/
inductive CmStructure | physTime | euclid3D | flatSpace | cBoundary | metric
  deriving DecidableEq, Repr

def cellOf : Phase → CmStructure → CellV
  | .Cm, _ => .defined
  | .c0, _ => .absent .undefined0
  | .cp, _ => .absent .dissolvedPlus

theorem Cm_time_defined      : cellOf .Cm .physTime  = .defined := rfl
theorem c0_time_undefined    : cellOf .c0 .physTime  = .absent .undefined0 := rfl
theorem cp_time_dissolved    : cellOf .cp .physTime  = .absent .dissolvedPlus := rfl
theorem c0_euclid_undefined  : cellOf .c0 .euclid3D  = .absent .undefined0 := rfl
theorem cp_euclid_dissolved  : cellOf .cp .euclid3D  = .absent .dissolvedPlus := rfl
theorem c_boundary_only_Cm   : cellOf .Cm .cBoundary = .defined ∧
    cellOf .c0 .cBoundary ≠ .defined ∧ cellOf .cp .cBoundary ≠ .defined := by decide
/-- 🎯 İki yokluk AYNI DEĞİL — tek ⊥ bilgiyi siler. -/
theorem two_absences_distinct : cellOf .c0 .physTime ≠ cellOf .cp .physTime := by decide
/-- Yokluk ≠ olay-yok (None). -/
theorem absence_ne_noEvent (a : Absence) : CellV.absent a ≠ CellV.noEvent := by
  cases a <;> decide
/-- Tüm Cₘ yapıları için dış fazlar asla "defined" değil. -/
theorem outer_never_defined : ∀ s : CmStructure,
    cellOf .c0 s ≠ .defined ∧ cellOf .cp s ≠ .defined := by
  intro s; cases s <;> decide

/-! ## BridgeSpec iskeleti (Kimi F-36 devri) — köprü yalnız Cₘ'de değer üretir -/
structure BridgeSpec (State Readout : Type) where
  phaseOf : State → Phase
  bridge  : State → Option Readout
  /-- Faz güvenliği: dış fazda köprü değer ÜRETMEZ. -/
  phaseSafe : ∀ s, phaseOf s ≠ .Cm → bridge s = none

/-- Faz güvenliği iskeletin kendisinden türer. -/
theorem bridge_silent_outside {S R : Type} (B : BridgeSpec S R) (s : S)
    (h : B.phaseOf s = .c0) : B.bridge s = none :=
  B.phaseSafe s (by rw [h]; decide)
end V24A
