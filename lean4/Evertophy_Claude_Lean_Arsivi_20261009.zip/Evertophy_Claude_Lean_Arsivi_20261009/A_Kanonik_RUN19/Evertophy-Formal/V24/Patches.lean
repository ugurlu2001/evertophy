import Evertophy.Phase
/-! V24.Patches — RUN-03: K2 QuantityKind ayrımı + IOM dejenere-aralık koruması. -/
namespace V24P
open Evertophy

/-! ## 1. K2 QuantityKind — ChatGPT önerisi: boyut etiketi ≠ Cₘ durgun-kütle desteği -/
inductive QuantityKind
  | dimLabel (d : Dim)      -- soyut boyut etiketi (K2'nin konuştuğu şey)
  | cmRestMass              -- Cₘ'de farklılaşmış maddenin durgun kütlesi
  | metricLength | physTime | intrinsicSpeed
  deriving DecidableEq, Repr

def admissible : Phase → QuantityKind → Bool
  | p, .dimLabel d      => carriable p d
  | p, .cmRestMass      => p == .Cm
  | p, .metricLength    => p == .Cm
  | p, .physTime        => p == .Cm
  | p, .intrinsicSpeed  => p == .Cm

/-- K2 KORUNUR — ama yalnız boyut etiketi olarak. -/
theorem K2_as_dimLabel : admissible .cp (.dimLabel Dim.mass) = true := by decide
/-- V24 c⁺ kanonu KORUNUR — Cₘ durgun kütlesi c⁺'ta kabul edilemez. -/
theorem cp_no_rest_mass : admissible .cp .cmRestMass = false := by decide
/-- İkisi AYNI ANDA doğru: çelişki tip ayrımıyla çözülür. -/
theorem K2_reconciled :
    admissible .cp (.dimLabel Dim.mass) = true ∧ admissible .cp .cmRestMass = false := by decide
theorem cp_no_speed  : admissible .cp .intrinsicSpeed = false := by decide
theorem c0_no_time   : admissible .c0 .physTime = false := by decide
theorem Cm_all_ok    : admissible .Cm .cmRestMass = true ∧ admissible .Cm .physTime = true := by decide

/-! ## 2. IOM dejenere-aralık koruması -/
structure IvlZ where
  lo : Int
  hi : Int
  deriving DecidableEq, Repr

def intersects (a b : IvlZ) : Bool := max a.lo b.lo ≤ min a.hi b.hi
def overlapWidth (a b : IvlZ) : Int := max 0 (min a.hi b.hi - max a.lo b.lo)
def unionWidth (a b : IvlZ) : Int := max a.hi b.hi - min a.lo b.lo

/-- 🔴 Sorun: [1,1] ⊂ [0,2] — örtüşme GENİŞLİĞİ 0, ama kesişim BOŞ DEĞİL. -/
theorem iom_width_blind :
    overlapWidth ⟨1,1⟩ ⟨0,2⟩ = 0 ∧ intersects ⟨1,1⟩ ⟨0,2⟩ = true := by decide
/-- [P,P] vs [P,P]: birleşim genişliği 0 → IOM = 0/0 tanımsız. -/
theorem iom_zero_over_zero : unionWidth ⟨1,1⟩ ⟨1,1⟩ = 0 := by decide
/-- ✅ Düzeltme: sert red YALNIZ kesişim boşsa. Nokta aralık içeride ise daima geçer. -/
theorem point_inside_passes (p lo hi : Int) (h1 : lo ≤ p) (h2 : p ≤ hi) :
    intersects ⟨p,p⟩ ⟨lo,hi⟩ = true := by
  simp [intersects]; omega
/-- Ayrık aralıklar reddedilir. -/
theorem disjoint_rejected : intersects ⟨0,1⟩ ⟨2,3⟩ = false := by decide

end V24P
