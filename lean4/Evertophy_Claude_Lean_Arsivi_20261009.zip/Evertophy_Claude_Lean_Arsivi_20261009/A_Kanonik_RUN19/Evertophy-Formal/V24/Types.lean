import Evertophy.Phase
/-! V24.Types — RUN-06: ChatGPT Tur-5 tip düzeltmeleri. -/
namespace V24Ty
open Evertophy

/-! ## 1. GlobalNode ≠ Pole — Uₓ bir kutup DEĞİLDİR -/
inductive GlobalNode | U0 | Ux | Uplus  deriving DecidableEq, Repr
def isPole : GlobalNode → Bool | .U0 => true | .Uplus => true | .Ux => false
theorem Ux_not_pole : isPole .Ux = false := rfl
theorem poles_are_U0_Uplus : isPole .U0 = true ∧ isPole .Uplus = true := ⟨rfl, rfl⟩

/-! ## 2. Tipli yokluk nedeni (ChatGPT adlandırması ile Claude Absence eşlemesi) -/
inductive AbsenceReason | PreAdmissible | Dissolved | NotApplicable | MissingData
  deriving DecidableEq, Repr
inductive PhaseValue (α : Type) | present (v : α) | absent (r : AbsenceReason)
def cmTimeValue : Phase → PhaseValue Unit
  | .Cm => .present () | .c0 => .absent .PreAdmissible | .cp => .absent .Dissolved
theorem c0_preadmissible : cmTimeValue .c0 = .absent .PreAdmissible := rfl
theorem cp_dissolved     : cmTimeValue .cp = .absent .Dissolved := rfl
theorem reasons_differ   : AbsenceReason.PreAdmissible ≠ AbsenceReason.Dissolved := by decide

/-! ## 3. MetricAdmissible — AÇIK yüklem; boyut etiketlerinden TÜRETİLMEZ -/
def MetricAdmissible : Phase → Prop | .Cm => True | .c0 => False | .cp => False
instance : DecidablePred MetricAdmissible := fun p => by cases p <;> unfold MetricAdmissible <;> infer_instance
theorem metric_only_Cm : MetricAdmissible .Cm ∧ ¬ MetricAdmissible .c0 ∧ ¬ MetricAdmissible .cp := by
  refine ⟨trivial, ?_, ?_⟩ <;> intro h <;> exact h
/-- Lorentz metriği okuması yalnız Cₘ durumundan, nondejenerelik korumasıyla. -/
structure LorMetricReadout where
  detNonzero : Bool
  signatureOK : Bool
def validReadout (r : LorMetricReadout) : Bool := r.detNonzero && r.signatureOK
theorem degenerate_rejected : validReadout ⟨false, true⟩ = false := rfl

/-! ## 4. Genel Band α — geçerlilik KANITI tip içinde (lo > hi inşa edilemez) -/
structure Band (α : Type) [LE α] where
  lo : α
  hi : α
  valid : lo ≤ hi
/-- Kesişim: ortak bir tanık noktanın varlığı (genişlikten bağımsız). -/
def Intersects {α : Type} [LE α] (a b : Band α) : Prop :=
  ∃ x : α, a.lo ≤ x ∧ x ≤ a.hi ∧ b.lo ≤ x ∧ x ≤ b.hi
/-- Nokta aralık [p,p] geniş bantın içindeyse kesişim VARDIR (IOM'un kaçırdığı durum). -/
theorem point_in_band_intersects {α : Type} [LE α] (p : α) (hp : p ≤ p) (b : Band α)
    (h1 : b.lo ≤ p) (h2 : p ≤ b.hi) : Intersects ⟨p, p, hp⟩ b :=
  ⟨p, hp, hp, h1, h2⟩
/-- Int örneği: geçersiz bant inşa edilemez, geçerli olan edilir. -/
def exampleBand : Band Int := ⟨0, 2, by decide⟩
theorem singleton_in_exampleBand : Intersects (⟨1, 1, by decide⟩ : Band Int) exampleBand :=
  point_in_band_intersects 1 (by decide) exampleBand (by decide) (by decide)
end V24Ty
