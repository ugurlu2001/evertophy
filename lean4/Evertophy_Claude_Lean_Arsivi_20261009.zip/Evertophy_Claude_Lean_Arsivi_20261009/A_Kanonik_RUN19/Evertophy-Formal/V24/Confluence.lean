import V24.Rewrite
/-! V24.Confluence — RUN-07: TAM Church–Rosser. Eksik lemma: her kelime normal formuna indirgenir. -/
namespace V24C
open V03 V24S V24R

theorem star_trans {a b c : Word} (h1 : Star a b) (h2 : Star b c) : Star a c := by
  induction h2 with
  | refl => exact h1
  | tail _ hs ih => exact Star.tail ih hs

theorem step_cons_lift (g : Gen) {a b : Word} (h : Step a b) : Step (g :: a) (g :: b) := by
  cases h with
  | collapse u v k hk => exact Step.collapse (g :: u) v k hk

theorem star_cons_lift (g : Gen) {a b : Word} (h : Star a b) : Star (g :: a) (g :: b) := by
  induction h with
  | refl => exact Star.refl _
  | tail _ hs ih => exact Star.tail ih (step_cons_lift g hs)

/-- 🎯 VARLIK: her kelime kendi normal formuna yeniden-yazma ile ULAŞIR. -/
theorem star_to_normalize : ∀ w : Word, Star w (normalize w)
  | [] => Star.refl _
  | g :: w => by
    have h1 : Star (g :: w) (g :: normalize w) := star_cons_lift g (star_to_normalize w)
    rw [normalize_cons]
    generalize hn : normalize w = n at h1
    cases n with
    | nil => exact h1
    | cons h t =>
      rw [step_cons]
      by_cases hc : (g.isKappa && g == h) = true
      · rw [if_pos hc]
        have hg : g.isKappa = true ∧ g = h := by
          cases g <;> cases h <;> simp_all (config := {decide := true}) [Gen.isKappa]
        obtain ⟨hk, rfl⟩ := hg
        exact Star.tail h1 (Step.collapse [] t g hk)
      · rw [if_neg hc]; exact h1

/-- 🎯 TAM CHURCH–ROSSER: aynı kelimenin herhangi iki indirgemesi ortak bir kelimede birleşir. -/
theorem church_rosser {w a b : Word} (ha : Star w a) (hb : Star w b) :
    ∃ c, Star a c ∧ Star b c := by
  refine ⟨normalize w, ?_, ?_⟩
  · rw [star_preserves_normalize ha]; exact star_to_normalize a
  · rw [star_preserves_normalize hb]; exact star_to_normalize b

/-! ## Köprü düzeltmesi (ChatGPT Tur-6): faz-sessizliği TÜM köprüler için değil,
    yalnız Cₘ-OKUMA köprüleri için zorunludur. -/
structure BridgeSpec (Ctx Out : Type) where
  admissible : Ctx → Prop
  bridge     : Ctx → Option Out
  existsUnique : ∀ c, admissible c → ∃ o, bridge c = some o
structure CmReadoutBridge (Ctx Out : Type) extends BridgeSpec Ctx Out where
  isCm : Ctx → Bool
  cmTyped : ∀ c, isCm c = false → bridge c = none
end V24C
