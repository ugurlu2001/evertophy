import Evertophy.Phase
/-! V24 — İki seviyeli ontoloji, argüman taşınabilirliği, topoloji ve kapanış kontrolleri.
    MiniLab-R maratonu (2026/09). Harici kütüphane yok. -/
namespace V24
open Evertophy

/-! ## 1. İki seviye: faz ve global -/
inductive GlobalPole | U0 | Ux | Up  deriving DecidableEq, Repr
inductive Entity | phase (p : Phase) | pole (g : GlobalPole)  deriving DecidableEq, Repr
def isPhase : Entity → Bool | .phase _ => true | .pole _ => false
theorem U0_not_phase : isPhase (.pole .U0) = false := rfl
theorem Ux_not_phase : isPhase (.pole .Ux) = false := rfl
theorem Up_not_phase : isPhase (.pole .Up) = false := rfl
/-- Faz kapısı yalnız iki faz arasında tanımlıdır. -/
def gate : Entity → Entity → Bool
  | .phase a, .phase b => gateRelated a b
  | _, _ => false
theorem no_gate_U0_c0 : gate (.pole .U0) (.phase .c0) = false := rfl
theorem no_gate_Up_cp : gate (.pole .Up) (.phase .cp) = false := rfl
theorem Up_ne_cp : (Entity.pole .Up) ≠ (Entity.phase .cp) := by decide
/-- Global oklar AYRI bir tiptir; kapı değildir. -/
inductive GlobalArrow | genesis | collapseLimit | dissolutionLimit | reformation  deriving DecidableEq, Repr
def arrowEnds : GlobalArrow → GlobalPole × GlobalPole
  | .genesis => (.U0, .Ux) | .collapseLimit => (.Ux, .U0)
  | .dissolutionLimit => (.Ux, .Up) | .reformation => (.Up, .Ux)
theorem four_global_directions :
    arrowEnds .genesis = (.U0,.Ux) ∧ arrowEnds .collapseLimit = (.Ux,.U0) ∧
    arrowEnds .dissolutionLimit = (.Ux,.Up) ∧ arrowEnds .reformation = (.Up,.Ux) :=
  ⟨rfl, rfl, rfl, rfl⟩

/-! ## 2. Boyut: kuantum eşiği tutarsızlığı -/
def hbarD : Dim := Dim.mk 1 2 (-1)            -- [M L² T⁻¹]
def energyD : Dim := Dim.mk 1 2 (-2)
/-- ∫G dτ boyutsuzdur (G: T⁻¹, dτ: T). -/
def arcD : Dim := Dim.mul Dim.freq Dim.time
theorem arc_dimensionless : arcD = Dim.one := by decide
/-- MEVCUT KANON: ∫G dτ ≥ ħ/2 — iki taraf aynı boyutta DEĞİL. -/
theorem quantum_threshold_mismatch : arcD ≠ hbarD := by decide
/-- KAPANIŞ: τ₀Γ̃ = ħ/ΔE zaman boyutundadır. -/
theorem closure_hbar_over_E_is_time : Dim.div hbarD energyD = Dim.time := by decide

/-! ## 3. X argümanlarının faz-taşınabilirliği -/
inductive XArg | density | curvature | entropyDensity | gravStrength | invariantRatio
  deriving DecidableEq, Repr
/-- Metrik (hacim/eğrilik) gerektiren argümanlar. -/
def needsMetric : XArg → Bool
  | .density => true | .curvature => true | .entropyDensity => true
  | .gravStrength => true | .invariantRatio => false
def metricOK : Phase → Bool := fun p => carriable p Dim.len && carriable p Dim.time
def argAvailable (p : Phase) (a : XArg) : Bool := !needsMetric a || metricOK p
theorem curvature_undefined_c0 : argAvailable .c0 .curvature = false := by decide
theorem curvature_undefined_cp : argAvailable .cp .curvature = false := by decide
theorem density_undefined_c0   : argAvailable .c0 .density   = false := by decide
theorem density_undefined_cp   : argAvailable .cp .density   = false := by decide
theorem invariant_everywhere : ∀ p : Phase, argAvailable p .invariantRatio = true := by
  intro p; cases p <;> rfl
/-- DÜZELTME — değişken arite: her faz kendi taşınabilir argüman kümesini kullanır. -/
def argsOf : Phase → List XArg
  | .Cm => [.density, .curvature, .entropyDensity, .gravStrength, .invariantRatio]
  | .c0 => [.invariantRatio]
  | .cp => [.invariantRatio]
theorem variable_arity_consistent :
    ∀ p : Phase, (argsOf p).all (argAvailable p) = true := by
  intro p; cases p <;> decide

/-! ## 4. Topoloji: 1B okuma → zincir, 2B okuma → üçgen -/
def adj1D : Fin 3 → Fin 3 → Bool := fun i j => (i.val + 1 == j.val) || (j.val + 1 == i.val)
def adj2D : Fin 3 → Fin 3 → Bool := fun i j => i != j
theorem oneD_is_chain  : adj1D 0 2 = false := by decide
theorem oneD_neighbours: adj1D 0 1 = true ∧ adj1D 1 2 = true := by decide
theorem twoD_triangle  : adj2D 0 1 = true ∧ adj2D 1 2 = true ∧ adj2D 0 2 = true := by decide
/-- Morse: 3 minimum − 3 eyer + 1 maksimum = χ(disk) = 1. -/
def eulerMorse (m s M : Int) : Int := m - s + M
theorem morse_disk : eulerMorse 3 3 1 = 1 := by decide
theorem morse_rejects_no_interior_max : eulerMorse 3 3 0 ≠ 1 := by decide

/-! ## 5. K2 çelişkisi (kayıt) ve önerilen K2' -/
def matterSupportV24 : Phase → Bool | .c0 => false | .Cm => true | .cp => false
theorem K2_conflict_recorded :
    carriable .cp Dim.mass = true ∧ matterSupportV24 .cp = false := by decide
def carriableV24 (p : Phase) (d : Dim) : Bool :=
  if d = Dim.mass then carriable p d && matterSupportV24 p else carriable p d
theorem K2prime_cp_mass : carriableV24 .cp Dim.mass = false := by decide
theorem K2prime_Cm_mass : carriableV24 .Cm Dim.mass = true  := by decide
theorem K2prime_keeps_time : carriableV24 .cp Dim.time = carriable .cp Dim.time := by decide

end V24
