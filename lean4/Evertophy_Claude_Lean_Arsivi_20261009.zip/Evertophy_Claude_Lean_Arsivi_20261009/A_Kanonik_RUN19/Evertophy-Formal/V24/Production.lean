import V24.Types
/-! V24.Production — RUN-08 (Wolfram P0 + M&P): faz-İNDEKSLİ değer tipi,
    Band yükü, genişletilmiş uç noktalar, TracePolicy ayrımı. -/
namespace V24Prod
open Evertophy V24Ty

/-- 🎯 Present YALNIZ Cₘ'de inşa edilebilir — tip düzeyinde. -/
inductive CmOnlyValue (α : Type) : Phase → Type
  | undefined0    : CmOnlyValue α .c0
  | presentCm     : α → CmOnlyValue α .Cm
  | dissolvedPlus : CmOnlyValue α .cp

theorem c0_is_undefined {α : Type} (v : CmOnlyValue α .c0) : v = .undefined0 := by cases v; rfl
theorem cp_is_dissolved {α : Type} (v : CmOnlyValue α .cp) : v = .dissolvedPlus := by cases v; rfl
theorem Cm_is_present {α : Type} (v : CmOnlyValue α .Cm) : ∃ a, v = .presentCm a := by
  cases v with | presentCm a => exact ⟨a, rfl⟩

/-- Band yükü doğrudan PresentCm içinde. -/
abbrev CmOnlyBand (α : Type) [LE α] (p : Phase) := CmOnlyValue (Band α) p
def exampleCmBand : CmOnlyBand Int .Cm := .presentCm ⟨0, 2, by decide⟩

/-! ## Genişletilmiş uç noktalar — +∞ bir YOKLUK DEĞİLDİR -/
inductive Ext (α : Type) | negInf | fin (a : α) | posInf
def extLE {α : Type} [LE α] : Ext α → Ext α → Prop
  | .negInf, _ => True
  | _, .posInf => True
  | .fin a, .fin b => a ≤ b
  | _, _ => False
structure ExtBand (α : Type) [LE α] where
  lo : Ext α
  hi : Ext α
  valid : extLE lo hi
/-- ΔE bandı 0'ı içerirse QSL alt-zaman sınırı +∞'a uzanır — Cₘ'de TANIMLI bir değer. -/
def qslUnbounded : CmOnlyValue (ExtBand Int) .Cm := .presentCm ⟨.fin 1, .posInf, trivial⟩
/-- +∞ üst uç, Cₘ'de present'tır; c⁺'taki çözünmüşlük ise farklı bir kurucudur. -/
theorem posInf_is_present : ∃ b, qslUnbounded = .presentCm b := ⟨_, rfl⟩

/-! ## TracePolicy — AbsenceReason'dan TÜRETİLMEZ (M&P K.1, Wolfram §10) -/
inductive TraceStatus | retained | notRetained | unknown  deriving DecidableEq, Repr
structure TracePolicy where
  policy : Phase → TraceStatus
def P1 : TracePolicy := ⟨fun _ => .retained⟩
def P2 : TracePolicy := ⟨fun _ => .notRetained⟩
/-- Aynı yokluk semantiği (c⁺ = Dissolved) İKİ farklı iz politikasıyla uyumludur
    ⇒ "Dissolved ⇒ iz tutulur" bir teorem DEĞİLDİR; ayrı aksiyom gerekir. -/
theorem dissolved_does_not_fix_trace :
    cmTimeValue .cp = .absent .Dissolved ∧ P1.policy .cp ≠ P2.policy .cp := by
  refine ⟨rfl, ?_⟩; decide
end V24Prod
