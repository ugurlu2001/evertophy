import V24.Confluence
/-! V24.Idem — RUN-08: normalize çıktısı indirgenemezdir + TAM idempotent sınıflandırması
    Idem(M) = {e, κ₀ₘ, κ₊ₘ}  (∀ w, mulW w w = w ↔ w ∈ {[], [κ₀ₘ], [κ₊ₘ]}) -/
namespace V24I
open V03 V24S V24R

/-- normalize her zaman indirgenemez kelime üretir. -/
theorem normalize_is_irred : ∀ w : Word, Irred (normalize w)
  | [] => trivial
  | g :: w => by
    rw [normalize_cons]
    have ih := normalize_is_irred w
    generalize hn : normalize w = n at ih
    cases n with
    | nil => trivial
    | cons h t =>
      rw [step_cons]
      by_cases hc : (g.isKappa && g == h) = true
      · rw [if_pos hc]; exact ih
      · rw [if_neg hc]
        refine ⟨?_, ih⟩
        intro ⟨hk, he⟩; apply hc; subst he; simp [hk]

/-- İndirgenemez u'yu herhangi bir acc üzerine itmek: baş harf korunur, en fazla BİR çöküş. -/
theorem push_irred (acc : Word) : ∀ (g : Gen) (rest : Word), Irred (g :: rest) →
    (∃ t, List.foldr step acc (g :: rest) = g :: t) ∧
    acc.length + rest.length + 1 ≤ (List.foldr step acc (g :: rest)).length + 1
  | g, [], _ => by
    show (∃ t, step g acc = g :: t) ∧ _ ≤ (step g acc).length + 1
    cases acc with
    | nil => exact ⟨⟨[], rfl⟩, by simp [step]⟩
    | cons h t =>
      rw [step_cons]
      by_cases hc : (g.isKappa && g == h) = true
      · rw [if_pos hc]
        have : g = h := by
          cases g <;> cases h <;> simp_all (config := {decide := true}) [Gen.isKappa]
        subst this; exact ⟨⟨t, rfl⟩, by simp⟩
      · rw [if_neg hc]; exact ⟨⟨h :: t, rfl⟩, by simp⟩
  | g, h :: t', hw => by
    obtain ⟨⟨t, ht⟩, hlen⟩ := push_irred acc h t' hw.2
    have hnc : ¬ ((g.isKappa && g == h) = true) := by
      intro hc; apply hw.1
      cases g <;> cases h <;> simp_all (config := {decide := true}) [Gen.isKappa]
    have e : List.foldr step acc (g :: h :: t') = g :: h :: t := by
      show step g (List.foldr step acc (h :: t')) = _
      rw [ht, step_cons, if_neg hnc]
    refine ⟨⟨h :: t, e⟩, ?_⟩
    rw [e]; rw [ht] at hlen; simp only [List.length_cons] at hlen ⊢; omega

/-- 🎯 TAM İDEMPOTENT SINIFLANDIRMASI -/
theorem idempotent_iff (w : Word) :
    mulW w w = w ↔ (w = [] ∨ w = [Gen.k0m] ∨ w = [Gen.kpm]) := by
  constructor
  · intro h
    have hirr : Irred w := by rw [← h]; exact normalize_is_irred _
    match w, hirr, h with
    | [], _, _ => exact Or.inl rfl
    | [g], _, h => cases g <;> simp_all [mulW, normalize, Gen.isKappa]
    | g :: h' :: t, hw, h =>
      exfalso
      have e : mulW (g :: h' :: t) (g :: h' :: t)
             = List.foldr step (g :: h' :: t) (g :: h' :: t) := by
        show normalize _ = _
        rw [normalize_eq_foldr, List.foldr_append, ← normalize_eq_foldr, normalize_irred _ hw]
      have hl := (push_irred (g :: h' :: t) g (h' :: t) hw).2
      rw [← e, h] at hl; simp only [List.length_cons] at hl; omega
  · rintro (rfl | rfl | rfl) <;> rfl
end V24I
