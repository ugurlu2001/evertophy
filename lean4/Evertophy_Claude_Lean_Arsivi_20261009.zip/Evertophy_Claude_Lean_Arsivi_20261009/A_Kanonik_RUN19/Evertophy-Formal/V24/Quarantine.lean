import V24.Global
import V24.Types
import V24.Patches
import V24.BridgeNoGo
/-! V24.Quarantine — RUN-11:
  (A) ESKİ API KARANTİNASI (ContextSeed Run10 "kritik yeni formal borç"): her eski API ile
      üretim karşılığı arasındaki ilişki TEOREM olarak kayda geçer; eski dosyalar SHA kararlılığı
      için değiştirilmez, ama üretim semantiği yalnız bu modüldeki eşleme üzerinden okunur.
  (B) FİZİKSEL SEÇİCİ: süperpozisyon (toplamsallık) A_min içinde köprüyü TEKİL seçer. -/
namespace V24Q
open Evertophy V24Ty V24P V24B

/-! ## (A) Eski → üretim eşlemesi -/
/-- L1: eski `adjacent` c₀↔c⁺'ı YOK sayar; üretim kapısı `gateRelated` VAR sayar — ÇELİŞKİ. -/
theorem legacy_adjacent_conflicts :
    adjacent .c0 .cp = false ∧ gateRelated .c0 .cp = true := by decide
/-- L2: eski K2 (kütle c⁺'ta taşınır) yalnız BOYUT ETİKETİ olarak geçerli; Cₘ durgun kütlesi ⊥. -/
theorem legacy_K2_scoped :
    carriable .cp Dim.mass = true ∧ admissible .cp .cmRestMass = false := by decide
/-- L3: eski `GlobalPole` Uₓ'i kutup sayıyordu; üretimde Uₓ kutup DEĞİL. -/
theorem legacy_GlobalPole_superseded :
    (V24.GlobalPole.Ux = V24.GlobalPole.Ux) ∧ isPole .Ux = false := ⟨rfl, rfl⟩
/-- L4: eski `metricOK` DEĞERLERDE üretim `MetricAdmissible` ile uyuşur — hata değerde değil,
    GEREKÇEDEdir (boyut etiketinden metrik varlığı türetilemez). -/
theorem legacy_metricOK_values_agree :
    ∀ p : Phase, (V24.metricOK p = true) ↔ MetricAdmissible p := by
  intro p; cases p <;> simp [V24.metricOK, MetricAdmissible, carriable, actM, actL, actT] <;> decide
/-- L5: eski Float `Ivl`/`Qty` geçerlilik kanıtı TAŞIMAZ; üretim `Band α` taşır.
    (Float karşılaştırma kararlı değil — kanıt yerine kayıt.) -/
def legacyMap : List (String × String) :=
  [ ("Evertophy.adjacent (no-skip)",        "Evertophy.gateRelated (tam K3)")
  , ("Evertophy.K2_cp_mass",                "V24P.admissible + QuantityKind")
  , ("V24.GlobalPole (Ux içerir)",          "V24Ty.GlobalNode + isPole")
  , ("V24.metricOK (boyuttan)",             "V24Ty.MetricAdmissible (açık yüklem)")
  , ("Evertophy.Ivl / Qty (Float)",         "V24Ty.Band α (lo ≤ hi kanıtlı)")
  , ("V24Ty.AbsenceReason (4 neden)",       "V24L.OntoAbsence (2) + EpistemicStatus") ]
theorem legacy_map_complete : legacyMap.length = 6 := rfl

/-! ## (B) Fiziksel seçici — süperpozisyon -/
/-- Ayrık toplamsallık: B(1)+B(1) = B(2). -/
def Additive (B : Fin 3 → Nat) : Prop := B 1 + B 1 = B 2
instance (B : Fin 3 → Nat) : Decidable (Additive B) := by unfold Additive; infer_instance
theorem B1_additive : Additive B1 := by decide
theorem B2_not_additive : ¬ Additive B2 := by decide
/-- 🎯 A_min + SÜPERPOZİSYON ⇒ köprü TEKİLDİR (= B1). -/
theorem superposition_selects_unique :
    ∀ B : Fin 3 → Nat, Admissible B → Additive B → B = B1 := by
  intro B ⟨_, h0, h2, _, _⟩ hadd
  funext i
  have h1 : B 1 = 1 := by unfold Additive at hadd; omega
  match i with
  | ⟨0, _⟩ => simpa [B1] using h0
  | ⟨1, _⟩ => simpa [B1] using h1
  | ⟨2, _⟩ => simpa [B1] using h2
end V24Q
