import V03.StampSpec
/-! V24.StampAssoc — Damga monoidinin GENEL birleşme kanıtı (∀ a b c).
    Sonlu tarama değil: tüm kelimeler için. RUN-03 · ChatGPT Q3 görevi. -/
namespace V24S
open V03

/-- normalize'ın tek adımı: başa bir üreteç ekle, aynı κ ardışıksa çökert. -/
def step (g : Gen) : Word → Word
  | [] => [g]
  | h :: t => if g.isKappa && g == h then h :: t else g :: h :: t

theorem normalize_cons (g : Gen) (w : Word) : normalize (g :: w) = step g (normalize w) := by
  rw [normalize]; generalize normalize w = n; cases n <;> rfl

theorem normalize_eq_foldr : ∀ w : Word, normalize w = List.foldr step [] w
  | [] => rfl
  | g :: w => by rw [normalize_cons, normalize_eq_foldr w]; rfl

/-- κ eylemi idempotenttir. -/
theorem step_idem : ∀ g : Gen, g.isKappa = true → ∀ Z : Word, step g (step g Z) = step g Z := by
  intro g hk Z
  cases g <;> simp [Gen.isKappa] at hk <;>
  (cases Z with
    | nil => rfl
    | cons h t => cases h <;> rfl)

theorem step_cons (g h : Gen) (t : Word) :
    step g (h :: t) = if (g.isKappa && g == h) = true then h :: t else g :: h :: t := rfl

/-- Eylem-değişme: step g, foldr ile değişir. -/
theorem foldr_step_comm (acc : Word) (g : Gen) : ∀ n : Word,
    List.foldr step acc (step g n) = step g (List.foldr step acc n)
  | [] => rfl
  | h :: t => by
    rw [step_cons]
    by_cases hc : (g.isKappa && g == h) = true
    · rw [if_pos hc]
      show step h (List.foldr step acc t) = step g (step h (List.foldr step acc t))
      cases g <;> cases h <;> simp (config := {decide := true}) [Gen.isKappa] at hc <;>
        first
          | exact (step_idem .k0m rfl _).symm
          | exact (step_idem .kpm rfl _).symm
    · rw [if_neg hc]; rfl

/-- ANAHTAR LEMMA: bir kelimenin eylemi yalnız normal formuna bağlıdır. -/
theorem foldr_normalize (acc : Word) : ∀ x : Word,
    List.foldr step acc (normalize x) = List.foldr step acc x
  | [] => rfl
  | g :: rest => by
    rw [normalize_cons, foldr_step_comm, foldr_normalize acc rest]; rfl

/-- 🎯 GENEL BİRLEŞME: ∀ a b c — sonlu tarama değil, tüm kelimeler. -/
theorem mulW_assoc (a b c : Word) : mulW (mulW a b) c = mulW a (mulW b c) := by
  show normalize (normalize (a ++ b) ++ c) = normalize (a ++ normalize (b ++ c))
  calc normalize (normalize (a ++ b) ++ c)
      = List.foldr step [] (normalize (a ++ b) ++ c) := normalize_eq_foldr _
    _ = List.foldr step (List.foldr step [] c) (normalize (a ++ b)) := List.foldr_append _ _ _ _
    _ = List.foldr step (List.foldr step [] c) (a ++ b) := foldr_normalize _ _
    _ = List.foldr step (List.foldr step (List.foldr step [] c) b) a := List.foldr_append _ _ _ _
    _ = List.foldr step (List.foldr step [] (b ++ c)) a := by rw [List.foldr_append]
    _ = List.foldr step (List.foldr step [] (normalize (b ++ c))) a := by rw [foldr_normalize]
    _ = List.foldr step [] (a ++ normalize (b ++ c)) := (List.foldr_append _ _ _ _).symm
    _ = normalize (a ++ normalize (b ++ c)) := (normalize_eq_foldr _).symm

/-- normalize idempotenttir (normal form tektir). -/
theorem normalize_idem (w : Word) : normalize (normalize w) = normalize w := by
  rw [normalize_eq_foldr (normalize w), foldr_normalize, ← normalize_eq_foldr]

end V24S
