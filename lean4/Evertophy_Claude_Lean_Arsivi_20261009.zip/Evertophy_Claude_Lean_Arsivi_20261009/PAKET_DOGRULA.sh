#!/usr/bin/env bash
# Evertophy Claude Lean Arşivi — tek komutla doğrulama (Lean 4.12.0 ve lake PATH'te olmalı).
# Kullanım:  bash PAKET_DOGRULA.sh      (paketin kök klasöründe)
# Hiçbir kaynak dosyayı değiştirmez; derleme artıkları (.lake, *.olean) yalnız geçici kopyada oluşur.
set -u
KOK="$(cd "$(dirname "$0")" && pwd)"; T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
cp -r "$KOK"/A_Kanonik_RUN19 "$KOK"/B_V23_Tip_Sistemi "$KOK"/C_Capraz_Derleme_Duzeltmeleri "$T"/
SONUC=0; ok(){ echo "  ✅ $1"; }; no(){ echo "  ❌ $1"; SONUC=1; }
echo "Lean: $(lean --version 2>/dev/null || echo YOK)"; echo
echo "== A. RUN19 kanonik paket =="
cd "$T"/A_Kanonik_RUN19/Evertophy-Formal
lake build > ../lake_core.log 2>&1 && ok "Üretim çekirdeği (lake build → Core, 7 modül)" || no "Üretim çekirdeği"
lake build Evertophy Claude V03 V24 > ../lake_arsiv.log 2>&1 && ok "Arşiv (Evertophy Claude V03 V24)" || no "Arşiv"
W=$(cat ../lake_core.log ../lake_arsiv.log | grep -c -E "^(warning|error)"); [ "$W" = 0 ] && ok "Derleme uyarı/hata satırı: 0" || no "Derleme uyarı/hata satırı: $W"
python3 -I check_production_isolation.py > ../iso.log 2>&1 && ok "$(tail -1 ../iso.log)" || no "İzolasyon"
python3 -I test_isolation_adversarial.py > ../adv.log 2>&1 && ok "$(tail -1 ../adv.log)" || no "Düşman matrisi"
python3 -I final_regression.py > ../reg.log 2>&1 && ok "$(tail -1 ../reg.log)" || no "Regresyon"
python3 -I test_regression_negative.py > ../neg.log 2>&1 && ok "Negatif regresyon: $(tail -1 ../neg.log)" || no "Negatif regresyon"
python3 -I - << 'PY'
import re,glob,os
n=0;p=0;bad=[]
for f in glob.glob("**/*.lean",recursive=True):
    if f=="lakefile.lean": continue
    t=open(f,encoding='utf-8').read(); c=re.sub(r'/-.*?-/','',t,flags=re.S); c=re.sub(r'--[^\n]*','',c)
    k=len(re.findall(r'^\s*(?:private\s+|protected\s+)?(?:theorem|lemma)\s',c,re.M)); n+=k; p+=k if f.startswith("Core/") else 0
    if re.search(r'\bsorry\b|\badmit\b',c) or re.search(r'^\s*axiom\b',c,re.M): bad.append(f)
print(f"  {'✅' if (n,p)==(269,46) and not bad else '❌'} theorem/lemma: {n} (üretim {p} + arşiv {n-p}) · sorry/admit/axiom: {len(bad)}")
PY
echo; echo "== B. V23 tip sistemi =="
cd "$T"/B_V23_Tip_Sistemi
lake build > ../v23.log 2>&1 && ok "Core, Dim, FormalCore, Kimi5, V23 derlendi" || no "V23 derlemesi"
LEAN_PATH=".lake/build/lib" lean Fail.lean > ../fail.log 2>&1 && no "Fail.lean DERLENDİ (negatif test bozuk)" || ok "Fail.lean beklendiği gibi DERLENMEDİ (negatif test)"
echo; echo "== C. Çapraz derleme düzeltmeleri =="
cd "$T"/C_Capraz_Derleme_Duzeltmeleri
for f in ChatGPT_Run01_fixed Qwen_b5_nomathlib; do lean $f.lean > /dev/null 2>&1 && ok "$f derlendi" || no "$f"; done
echo; [ $SONUC = 0 ] && echo "GENEL SONUÇ: TÜM KONTROLLER GEÇTİ" || echo "GENEL SONUÇ: BAŞARISIZ KONTROL VAR"; exit $SONUC
