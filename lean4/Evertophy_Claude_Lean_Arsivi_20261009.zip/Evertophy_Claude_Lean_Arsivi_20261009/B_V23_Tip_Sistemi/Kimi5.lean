import Core
/- KİMİ BORÇ #5 ÖNERİSİ: c₀ → Minkowski, c⁺ → Static (uzaysal Laplacian)
   K1/K2 ile çelişiyor mu? Tip sistemine soralım. -/

-- Minkowski metriği uzunluk VE zaman tanımlar
def needsLen  : Dim := Dim.len
def needsTime : Dim := Dim.time

-- K1: c₀'da uzunluk taşınabilir mi?
example : carriable .c0 needsLen  = false := by decide
example : carriable .c0 needsTime = false := by decide
-- ⟹ c₀'a Minkowski KONULAMAZ

-- K2: c⁺'da uzaysal Laplacian için uzunluk gerekir
example : carriable .cp needsLen = false := by decide
-- ⟹ c⁺'a "Static + uzaysal Laplacian" KONULAMAZ

-- Yalnız Cₘ metrik taşıyabilir
example : carriable .Cm needsLen  = true := by decide
example : carriable .Cm needsTime = true := by decide
