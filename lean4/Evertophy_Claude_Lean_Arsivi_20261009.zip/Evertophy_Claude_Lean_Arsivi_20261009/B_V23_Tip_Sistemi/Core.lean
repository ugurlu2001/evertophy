/-
  EVERTOPHY — FAZ-DUYARLI BOYUT VE ARALIK TİP SİSTEMİ
  Lean 4.12.0 · Mathlib bağımlılığı YOK

  ÜÇ ONTOLOJİK KISIT (Uğur, 2026/09/07):
    K1. c₀'da BOYUTSUZLUK — geometri tanımsız, uzunluk/süre yok
    K2. c⁺'da boyut kavramının SEYRELMESİ — zaman mühürlü, metrik geçersiz
    K3. RANGE FORMALİZM — her nicelik bant, nokta değil
-/

-- ══════════════════════════════════════════════════════════════
-- BÖLÜM 1 — FAZ VE KANONİK ZİNCİR
-- ══════════════════════════════════════════════════════════════

inductive Phase where
  | c0
  | Cm
  | cp
deriving DecidableEq, Repr

/-- Kanonik zincir c₀ ⇄ Cₘ ⇄ c⁺ : doğrudan c₀↔c⁺ YOK. -/
def adjacent : Phase → Phase → Bool
  | .c0, .Cm => true
  | .Cm, .c0 => true
  | .Cm, .cp => true
  | .cp, .Cm => true
  | _,   _   => false

example : adjacent .c0 .cp = false := rfl
example : adjacent .cp .c0 = false := rfl
example : adjacent .c0 .Cm = true  := rfl
example : adjacent .Cm .cp = true  := rfl

-- ══════════════════════════════════════════════════════════════
-- BÖLÜM 2 — BOYUT
-- ══════════════════════════════════════════════════════════════

structure Dim where
  M : Int
  L : Int
  T : Int
deriving DecidableEq, Repr

namespace Dim
def mul (a b : Dim) : Dim := Dim.mk (a.M+b.M) (a.L+b.L) (a.T+b.T)
def div (a b : Dim) : Dim := Dim.mk (a.M-b.M) (a.L-b.L) (a.T-b.T)
def one  : Dim := Dim.mk 0 0 0
def mass : Dim := Dim.mk 1 0 0
def len  : Dim := Dim.mk 0 1 0
def time : Dim := Dim.mk 0 0 1
def freq : Dim := Dim.mk 0 0 (-1)
end Dim

-- ══════════════════════════════════════════════════════════════
-- BÖLÜM 3 — K1 + K2 : FAZA BAĞLI BOYUT GEÇERLİLİĞİ
-- ══════════════════════════════════════════════════════════════

def actM : Phase → Bool
  | .c0 => false | .Cm => true | .cp => true
def actL : Phase → Bool
  | .c0 => false | .Cm => true | .cp => false
def actT : Phase → Bool
  | .c0 => false | .Cm => true | .cp => false

/-- Boyut d, faz p'de taşınabilir mi? -/
def carriable (p : Phase) (d : Dim) : Bool :=
  (actM p || d.M == 0) && (actL p || d.L == 0) && (actT p || d.T == 0)

-- K1: c₀'da YALNIZ boyutsuz
example : carriable .c0 Dim.one  = true  := by decide
example : carriable .c0 Dim.time = false := by decide
example : carriable .c0 Dim.len  = false := by decide
example : carriable .c0 Dim.mass = false := by decide

-- K2: c⁺'da zaman ve uzunluk SEYRELMİŞ
example : carriable .cp Dim.time = false := by decide
example : carriable .cp Dim.len  = false := by decide
example : carriable .cp Dim.mass = true  := by decide
example : carriable .cp Dim.one  = true  := by decide

-- Cₘ: tam
example : carriable .Cm Dim.time = true := by decide
example : carriable .Cm Dim.len  = true := by decide
example : carriable .Cm Dim.mass = true := by decide

-- ══════════════════════════════════════════════════════════════
-- BÖLÜM 4 — K3 : RANGE FORMALİZM
-- ══════════════════════════════════════════════════════════════

structure Qty (p : Phase) (d : Dim) where
  lo : Float
  hi : Float
deriving Repr

namespace Qty
def width {p : Phase} {d : Dim} (x : Qty p d) : Float := x.hi - x.lo
def isPoint {p : Phase} {d : Dim} (x : Qty p d) : Bool := x.lo == x.hi
def pt {p : Phase} {d : Dim} (v : Float) : Qty p d := Qty.mk v v
def band {p : Phase} {d : Dim} (a b : Float) : Qty p d := Qty.mk a b
end Qty

def qmul {p : Phase} {a b : Dim} (x : Qty p a) (y : Qty p b) : Qty p (Dim.mul a b) :=
  Qty.mk (x.lo * y.lo) (x.hi * y.hi)

def qdiv {p : Phase} {a b : Dim} (x : Qty p a) (y : Qty p b) : Qty p (Dim.div a b) :=
  Qty.mk (x.lo / y.hi) (x.hi / y.lo)

/-- Toplama YALNIZ aynı faz + aynı boyut. -/
def qadd {p : Phase} {d : Dim} (x y : Qty p d) : Qty p d :=
  Qty.mk (x.lo + y.lo) (x.hi + y.hi)

/-- Çıkarma — fark alan ifadelerde boyut eşitliğini zorlar. -/
def qsub {p : Phase} {d : Dim} (x y : Qty p d) : Qty p d :=
  Qty.mk (x.lo - y.hi) (x.hi - y.lo)

-- ══════════════════════════════════════════════════════════════
-- BÖLÜM 5 — FAZLAR ARASI TAŞIMA: OKUMA HARİTASI ZORUNLU
-- ══════════════════════════════════════════════════════════════

/-- 4. kritik soru: {H, L_k, γ_k} REZERVE. Tip düzeyinde varlığı ŞART. -/
structure ReadoutMap (src dst : Phase) where
  adjacentOK : adjacent src dst = true

def transport {src dst : Phase} {d : Dim}
    (_m : ReadoutMap src dst) (x : Qty src d)
    (_h : carriable dst d = true) : Qty dst d :=
  Qty.mk x.lo x.hi

def rm_Cm_c0 : ReadoutMap .Cm .c0 := ⟨by decide⟩
def rm_Cm_cp : ReadoutMap .Cm .cp := ⟨by decide⟩

-- Boyutsuz nicelik Cₘ → c₀ taşınabilir
def dimensionless_Cm : Qty .Cm Dim.one := Qty.pt 1.0
def moved_to_c0 : Qty .c0 Dim.one := transport rm_Cm_c0 dimensionless_Cm (by decide)

#eval moved_to_c0.lo
