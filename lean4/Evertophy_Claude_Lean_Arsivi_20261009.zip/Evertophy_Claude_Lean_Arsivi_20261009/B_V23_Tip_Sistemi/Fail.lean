import Core
-- NEGATİF TESTLER: hepsi DERLENMEMELİ
def MD (n : Int) : Dim := Dim.mk n 0 0
-- 1) Γ boyutsuz sanılırsa dt zaman olmaz
def bad1 : Qty .Cm Dim.time :=
  qmul (qmul (Qty.pt (p:=Phase.Cm) (d:=MD 0) 1.0) (Qty.pt (p:=Phase.Cm) (d:=Dim.freq) 1.0))
       (Qty.pt (p:=Phase.Cm) (d:=Dim.time) 1.0)
