import Lake
open Lake DSL

-- Paketleme kolaylığı (2026-10-09): V23 dönemi dosyaları için derleme tanımı.
-- Fail.lean bilerek DIŞARIDA: negatif testtir, DERLENMEMELİDİR.
package «evertophyV23» where
  leanOptions := #[⟨`autoImplicit, false⟩]

@[default_target]
lean_lib «V23Tip» where
  roots := #[`Core, `Dim, `FormalCore, `Kimi5, `V23]
