/-
  Evertophy — Boyut Tip Sistemi (Lean 4, Mathlib'siz)
  Amaç: birim tutarsızlıklarını DERLEME ZAMANINDA yakalamak.
  Gerekçe: Γ vakası (minor13/523.1-3) — tek tek denklemler doğruydu,
  zincir boyunca birim taşınmadı ve hata aylarca fark edilmedi.
-/

/-- Boyut vektörü: kütle, uzunluk, zaman üsleri (tam sayı). -/
structure Dim where
  M : Int
  L : Int
  T : Int
deriving DecidableEq, Repr

namespace Dim
def mul (a b : Dim) : Dim := ⟨a.M+b.M, a.L+b.L, a.T+b.T⟩
def div (a b : Dim) : Dim := ⟨a.M-b.M, a.L-b.L, a.T-b.T⟩
def one   : Dim := ⟨0,0,0⟩        -- boyutsuz
def time  : Dim := ⟨0,0,1⟩        -- T
def freq  : Dim := ⟨0,0,-1⟩       -- T^-1
def mass  : Dim := ⟨1,0,0⟩
end Dim

/-- Boyutlu nicelik: değer + derleme-zamanı boyut etiketi. -/
structure Qty (d : Dim) where
  val : Float
deriving Repr

/-- Çarpma boyutları TOPLAR — tip düzeyinde zorunlu. -/
def qmul {a b : Dim} (x : Qty a) (y : Qty b) : Qty (Dim.mul a b) := ⟨x.val * y.val⟩

/-- Toplama YALNIZ aynı boyutta mümkün — farklıysa derlenmez. -/
def qadd {d : Dim} (x y : Qty d) : Qty d := ⟨x.val + y.val⟩

-- ══════════════════════════════════════════════════════════
-- TEST 1: V23 emergent zaman denklemi  dt = Γ · G · dτ
-- ══════════════════════════════════════════════════════════
-- ρ_Cm yoğunluk matrisi ⟹ boyutsuz ⟹ [G] = T^-1
def G_Cm : Qty Dim.freq := ⟨1.0⟩
def dtau : Qty Dim.time := ⟨1.0⟩

-- İDDİA (minor13/523.1-3): [Γ] = T,  Γ boyutsuz DEĞİL
def Gamma : Qty Dim.time := ⟨1.0⟩

-- dt = Γ · G · dτ   →  T · T^-1 · T = T ✓
def dt_correct : Qty Dim.time := qmul (qmul Gamma G_Cm) dtau

#eval dt_correct.val
example : Dim.mul (Dim.mul Dim.time Dim.freq) Dim.time = Dim.time := rfl

-- ══════════════════════════════════════════════════════════
-- TEST 2: Normalize form  dt = τ₀ · Γ̃ · G · dτ   [Γ̃]=1, [τ₀]=T
-- ══════════════════════════════════════════════════════════
def tau0        : Qty Dim.time := ⟨1.0⟩
def GammaTilde  : Qty Dim.one  := ⟨1.0⟩   -- 1/(1-g²) BURAYA eşlenir

def dt_normalized : Qty Dim.time := qmul (qmul (qmul tau0 GammaTilde) G_Cm) dtau
#eval dt_normalized.val

-- ══════════════════════════════════════════════════════════
-- TEST 3: HATA YAKALAMA — Γ boyutsuz sanılırsa ne olur
-- ══════════════════════════════════════════════════════════
def Gamma_WRONG : Qty Dim.one := ⟨1.0⟩
def dt_wrong := qmul (qmul Gamma_WRONG G_Cm) dtau
-- Bu, Qty ⟨0,0,0⟩ verir — zaman DEĞİL. Aşağıdaki satır derlenmez:
-- def check : Qty Dim.time := dt_wrong
example : Dim.mul (Dim.mul Dim.one Dim.freq) Dim.time = Dim.one := rfl

-- ══════════════════════════════════════════════════════════
-- TEST 4: F(Φ) boyutsuzluğu (468.1 kilitli kuralı)
-- ══════════════════════════════════════════════════════════
def F_correct : Qty Dim.one := ⟨1.0⟩          -- F = G_N/G_eff ✓
-- 496.1'deki eski ifade F = (16πG)^-1 boyutlu olurdu:
def G_newton : Qty ⟨-1, 3, -2⟩ := ⟨6.674e-11⟩  -- m³ kg⁻¹ s⁻²
example : Dim.div Dim.one ⟨-1,3,-2⟩ = ⟨1,-3,2⟩ := rfl   -- boyutsuz DEĞİL ⟹ 468.1 ihlali

-- ══════════════════════════════════════════════════════════
-- TEST 5: A₀ boyutsuzluğu   A₀ = M_Pl·|F'|/√(Z·F)
-- ══════════════════════════════════════════════════════════
-- [Φ]=M (doğal birim), [F]=1 ⟹ [F']=M^-1, [Z]=1
example : Dim.mul Dim.mass ⟨-1,0,0⟩ = Dim.one := rfl   -- M_Pl · F' boyutsuz ✓

#print axioms dt_correct
