inductive Phase | c0 | cm | cp
inductive Sym | t | v | metric | Xreg | Freg | Xi | z | w
def ChartOK : Phase → Sym → Prop
  | .cm, _ => True
  | .c0, .Xreg => True | .c0, .Freg => True | .c0, .Xi => True
  | .c0, _ => False
  | .cp, .t => False | .cp, .v => False | .cp, .metric => False
  | .cp, _ => True
theorem t_not_in_c0 : ¬ ChartOK Phase.c0 Sym.t := fun h => h
-- Ontolojik postülalar: axiom (derlenmez, beyan edilir)