/- Evertophy cross-AI marathon Run01 candidate formal skeleton.
   NOTE: generated in an environment without Lean/lake; NOT freshly compiled here. -/

inductive Phase where
  | c0 | Cm | cp
  deriving DecidableEq, Repr

inductive GlobalState where
  | U0 | Ux | Up
  deriving DecidableEq, Repr

open Phase GlobalState

def MetricAdmissible : Phase → Bool
  | .Cm => true
  | _   => false

def PhysicalTime : Phase → Bool
  | .Cm => true
  | _   => false

def IntrinsicSpeed : Phase → Bool
  | .Cm => true
  | _   => false

inductive Gate : Phase → Phase → Prop where
  | c0_Cm : Gate c0 Cm
  | Cm_c0 : Gate Cm c0
  | Cm_cp : Gate Cm cp
  | cp_Cm : Gate cp Cm
  | c0_cp : Gate c0 cp
  | cp_c0 : Gate cp c0

inductive GlobalRel : GlobalState → GlobalState → Prop where
  | U0_Ux : GlobalRel U0 Ux
  | Ux_U0 : GlobalRel Ux U0
  | Ux_Up : GlobalRel Ux Up
  | Up_Ux : GlobalRel Up Ux

theorem metric_c0_false : MetricAdmissible c0 = false := rfl
theorem metric_Cm_true  : MetricAdmissible Cm = true := rfl
theorem metric_cp_false : MetricAdmissible cp = false := rfl

theorem time_c0_false : PhysicalTime c0 = false := rfl
theorem time_Cm_true  : PhysicalTime Cm = true := rfl
theorem time_cp_false : PhysicalTime cp = false := rfl

theorem speed_c0_false : IntrinsicSpeed c0 = false := rfl
theorem speed_Cm_true  : IntrinsicSpeed Cm = true := rfl
theorem speed_cp_false : IntrinsicSpeed cp = false := rfl

-- No direct global relation U0 -> Up in the current two-edge architecture.
theorem no_direct_U0_Up : ¬ GlobalRel U0 Up := by
  intro h
  cases h

-- Bidirectional phase adjacency does not imply that the two directed transitions
-- are exact inverse functions. Gate is only a typed admissibility relation here.

structure Band where
  lo : Int
  hi : Int
  ordered : lo ≤ hi

-- A phase-indexed property result must be either inadmissible or a valid band.
inductive Cell where
  | inadmissible
  | band (b : Band)

-- Candidate separation for future work:
-- Syntax: admissibility constraints on states/configurations.
-- Resolver X: deterministic solution on a fully specified admissible state.
-- Readout: protocol-indexed C_m measurement map.
