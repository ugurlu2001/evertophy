# Evertophy — Claude Lean Arşivi (2026-10-09)

**Yazar:** Uğur Yılmaz · **Lean kodlarının derleyicisi:** Claude · **Amaç:** Evertophy kapsamında Claude'un ürettiği tüm Lean kodlarını tek pakette, çapraz denetim için sunmak.

Tek komutla doğrulama (Lean 4.12.0 ve `lake` PATH'te olmalı; Mathlib gerekmez):

```bash
bash PAKET_DOGRULA.sh
```

Betik kaynak dosyalara dokunmaz; derlemeyi geçici bir kopyada yapar. 2026-10-09 tarihli sonuç `DERLEME_RAPORU_20261009.txt` içindedir: **tüm kontroller geçti**.

---

## Paket içeriği

| Klasör | İçerik | Yazar | Bildirim | Derleme (2026-10-09) |
|---|---|---|---|---|
| `A_Kanonik_RUN19/` | Evertophy-Formal RUN-19 paketinin tamamı: 32 Lean modülü, `lakefile.lean`, `lean-toolchain`, güvence araçları, eski derleme kayıtları | Claude | **269 theorem/lemma** — üretim 46 (`Core/`) + arşiv 223 · sorry/admit/axiom **0** | Çekirdek ve arşiv hatasız; uyarı 0; izolasyon temiz; düşman matrisi 14/14; regresyon 31/31 |
| `B_V23_Tip_Sistemi/` | V23 dönemi (Eylül 2026) faz-duyarlı boyut ve aralık tip sistemi: `Core`, `Dim`, `FormalCore`, `Kimi5`, `V23`, `Fail` | Claude | 22 theorem + 46 `example` · sorry/admit/axiom 0 | Beşi derlenir; **`Fail.lean` bilerek derlenmez** (negatif test) |
| `C_Capraz_Derleme_Duzeltmeleri/` | Diğer bacakların kodunun Claude tarafından derlenebilir hâle getirilmiş sürümleri | Kod: ChatGPT / Qwen · Düzeltme: Claude | 10 + 1 | İkisi de derlenir |
| `D_Tarihsel_Surumler/` | Geçersiz kılınmış eski sürümler: `Topology` RUN-04 sürümü ve 16 tarihsel `lakefile` | Claude | — | Kayıt amaçlı; derleme hedefi değil |

### A — Kanonik RUN-19

Tam üretim yığını: `Core.Production → Extended → Roles → GateLock → Final → GateLockGen → GateLockChar` (namespace `EvCore`). Arşiv kütüphaneleri: `Evertophy`, `Claude`, `V03`, `V24`.

- `lake build` → yalnız üretim çekirdeği (varsayılan hedef)
- `lake build Evertophy Claude V03 V24` → arşiv
- Ayrıntılı kullanım: `A_Kanonik_RUN19/Evertophy-Formal/README_BUILD.md`

Bu klasör, orijinal `Evertophy-Formal-RUN19.zip` paketinden derleme artığı olmadan çıkarılmıştır. Orijinal ZIP'in SHA-256 değeri V24'teki kayıtla birebir aynıdır: `f380f0df9f55afff16a9c3f38a72d1b8cde1c96c02e050ef30ace7283ea560c8`. Paketin kendi iç manifesti (`SHA256_MANIFEST.txt`) 45/45 dosyada eşleşir.

**Not:** Eski RUN-08 … RUN-18 paketlerindeki ve `Evertophy-Formal-full.zip` arşivindeki tüm Lean kaynak dosyaları RUN-19'da **bayt düzeyinde aynen** bulunur; RUN-19 kümülatif bir üst kümedir. Sürümler arasında değişen tek dosya `lakefile.lean`'dir (bkz. D).

### B — V23 tip sistemi

RUN-19'a hiç girmemiş, ondan önceki dönemin bağımsız Lean çalışmasıdır:

| Dosya | İçerik |
|---|---|
| `Core.lean` | Faz-duyarlı boyut ve aralık tip sistemi; üç ontolojik kısıt (c₀'da boyutsuzluk, c⁺'ta boyut seyrelmesi, Range formalizmi) |
| `Dim.lean` | Bağımsız boyut tip sistemi: birim tutarsızlıklarını derleme zamanında yakalar (Γ vakası) |
| `FormalCore.lean` | Kimi'nin 17 Python testinin Lean tip sistemine aktarımı (L/R/D/S/M serileri, 22 theorem) |
| `Kimi5.lean` | Kimi'nin açık borç #5 önerisinin (c₀ → Minkowski, c⁺ → statik) tip sistemiyle sınanması: c₀'a Minkowski metriği konulamaz |
| `V23.lean` | V23 denklem koşuları (emergent zaman dahil) |
| `Fail.lean` | **Negatif test — derlenmemelidir.** Boyutsuz Γ ile kurulan $dt$'nin zaman boyutu taşımadığını derleme zamanında gösterir |

`lakefile.lean` ve `lean-toolchain` bu pakette derleme kolaylığı için eklenmiştir (özgün klasörde yoktu); `Fail.lean` derleme hedefine bilerek alınmamıştır.

### C — Çapraz derleme düzeltmeleri

| Dosya | Özgün yazar | Claude'un değişikliği |
|---|---|---|
| `ChatGPT_Run01_fixed.lean` | ChatGPT (maraton Run-01 aday iskeleti) | `Rat` → `Int` (iki satır); özgün dosya Lean 4.12.0'da "typeclass instance problem is stuck" hatası verir. Fark: `ChatGPT_Run01_Claude_duzeltmesi.diff` |
| `Qwen_b5_nomathlib.lean` | Qwen (b5 paketi) | b5'in Mathlib gerektirmeyen `ChartOK` kısmı ayrıldı; `by decide` → `fun h => h` (`Prop` değerli, `Decidable` örneği yok) |

### D — Tarihsel sürümler

- `Topology_RUN04_eski.lean` — RUN-04 sürümü. Teorem adı `circle_has_no_interior_max` aşırı iddialıydı ("çemberin iç bölgesi yoktur" topolojik bir olgudur, teoremin içeriği değildir); RUN-06'da `euler_circle_zero_disk_one` olarak düzeltildi. Güncel sürüm A klasöründedir.
- `lakefile_surumleri/` — RUN-08…RUN-17, `full` ve MiniLab çalışma klasörlerinin birbirinden farklı 16 `lakefile` sürümü.

---

## Pakete alınmayanlar

| Dosya | Neden |
|---|---|
| `Evertophy_Marathon_Run01_Candidate.lean` (= MiniLab `ChatGPT_Run01.lean`) | ChatGPT'nin özgün kodu; Claude'un düzeltmeli sürümü C klasöründedir |
| Qwen `b2.lean`, `b5.lean` | Qwen'in özgün kodu; Mathlib gerektirir, bu ortamda derlenmedi |
| MiniLab-R_V24 içindeki diğer Lean kopyaları | RUN-19'daki dosyalarla bayt düzeyinde aynı |

## Kapsam

- **"0 axiom"** projenin kendi bildirimleri için bir sayımdır. Lean'in standart çekirdek aksiyomları (ör. `propext`, `decide` tabanlı ispatlarda) kullanılabilir; `Dim.lean` içindeki `#print axioms` çıktısı bunu açıkça gösterir.
- Biçimsel sonuçlar **kodlanmış sistem kapsamında** geçerlidir; Evertophy'nin fiziksel doğrulaması değildir. Kanonik sayısal öngörü sayacı **0/10**.
- Bu derleme Claude'un kendi ortamında yapılmıştır. Farklı makine ve sağlayıcıda bağımsız derleme (U40-B) çapraz denetim bacaklarına aittir.
- Bütünlük: `SHA256_MANIFEST.txt` paketteki her dosyanın SHA-256 değerini listeler; ZIP'in kendi SHA-256 değeri paket dışında bildirilir.
